#!/bin/bash
set -e

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
NOW="$(date +%Y%m%d-%H%M%S)"
RESULT_DIR="$BASE_DIR/results"

mkdir -p "$RESULT_DIR"

if [ ! -f /etc/os-release ]; then
  echo "ERROR: Cannot detect OS (/etc/os-release not found)"
  exit 10
fi

. /etc/os-release

case "$ID" in
  centos)
    OS_TAG="centos"
    RUN_DIR="CentOS7"
    ;;
  rocky|rhel|almalinux)
    OS_TAG="rhel"
    RUN_DIR="Rocky_Linux"
    ;;
  ubuntu)
    OS_TAG="ubuntu"
    RUN_DIR="Ubuntu"
    ;;
  *)
    echo "ERROR: Unsupported OS ($ID)"
    exit 20
    ;;
esac

export RESULT_PREFIX="${OS_TAG}_${NOW}"
export RESULT_DIR

TARGET="$BASE_DIR/$RUN_DIR"

if [ ! -d "$TARGET" ]; then
  echo "ERROR: Target directory not found: $TARGET"
  exit 30
fi

echo "Detected OS: $PRETTY_NAME"
echo "Running checks from: $TARGET"
echo "Results directory: $RESULT_DIR"

cd "$TARGET"
chmod +x ALL_system_check.sh
exec ./ALL_system_check.sh "$@"
