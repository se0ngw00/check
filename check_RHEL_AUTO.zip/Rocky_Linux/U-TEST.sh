#!/bin/bash
echo "[TEST MODE] OK" >> "$target"
