#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-26] Remove automountd              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-26 automountd 제거               " >> "$target"
echo "--------------------------------------------------------------------------" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "+점검목적 : 로컬 공격자가 automountd 데몬에 RPC(Remote Procedure Call)를 보낼 수 있는 취약점이 존재하기 때문에 해당 서비스가 실행중일 경우 서비스를 중지시키기 위함" >> "$target"
echo "+보안위협 : 파일 시스템의 마운트 옵션을 변경하여 root 권한을 획득할 수 있으며, 로컬 공격자가 automountd 프로세스 권한으로 임의의 명령을 실행할 수 있음" >> "$target"
echo "+판단기준 양호 : automountd 서비스가 비활성화 되어 있는 경우" >> "$target"
echo "+판단기준 취약 : automountd 서비스가 활성화 되어 있는 경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
u26_Service_Management=0
u26_safe_check=0
u26=0
u26_automount_checks=("automoun" "autofs" "automountd") 
u26_ports=("0")

check_service_status "${u26_ports[@]}" "${u26_automount_checks[@]}"
if [ $? -eq 1 ]; then
    echo "automountd 프로토콜만을 사용하고 있습니다." >> "$target"
    u26_safe_check=$((u26_safe_check+1))
else
    echo "automountd 프로토콜을 사용하지 않고 있습니다." >> "$target"
fi

for u26_automount_check in "${u26_automount_checks[@]}";do
    u26_automount_rc=$(find /etc/init.d/ -type f -name  "$u26_automount_check")
    if [ -n "$u26_automount_rc" ];then
        echo "$u26_automount_rc 시동 스크립트가 식별되었습니다. 삭제 또는 스크립트 이름을 변경하십시오." >> "$target"
        u26_safe_check=$((u26_safe_check+1))
    else
        echo "/etc/init.d/ 경로에서 $u26_automount_check 시동 스크립트가 식별되지 않았습니다." >> "$target"
    fi
done

if [[ $u26_safe_check -ge 1 ]];then
    u26=$((u26+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi
if [[ $u26 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u26_Service_Management=1
fi