#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-01] Remote Login Permission for the root User  =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-01 root 계정 원격 접속 제한                         "  >> "$target"
echo "--------------------------------------------------------------------------" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "점검목적 : 관리자계정 탈취로 인한 시스템 장악을 방지하기 위해 외부 비인가자의 root 계정 접근 시도를 원천적으로 차단하기 위함" >> "$target"
echo "보안위협 : root 계정은 운영체제의 모든기능을 설정 및 변경이 가능하여(프로세스, 커널변경 등) root 계정을 탈취하여 외부에서 원격을 이용한 시스템 장악 및 각종 공격으로(무작위 대입 공격) 인한 root 계정 사용 불가 위협" >> "$target"
echo "+판단기준 양호 : 원격 터미널 서비스를 사용하지 않거나, 사용 시 root 직접 접속을 차단한 경우" >> "$target"
echo "+판단기준 취약 : 원격 터미널 서비스 사용 시 root 직접 접속을 허용한 경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
echo "-------------" >> "$result"
echo "U-1 점검 결과" >> "$result"
u1=0
u1_safe_check=0
u1_Account_Management=0
telnet_access_check() {
    if [ -f "/etc/securetty" ]; then
        echo "/etc/securetty 파일: 존재함" >> "$target"
        if grep -q "pts" "/etc/securetty"; then
            echo "  - pts 항목: 발견됨 " >> "$target"
            u1_safe_check=$((u1_safe_check+1))
        else
            echo "  - pts 항목: 발견되지 않음" >> "$target"
        fi
    else
        echo "/etc/securetty 파일이 존재하지 않습니다." >> "$target"
    fi
    
    if [ -f "/etc/pam.d/login" ]; then
        echo "/etc/pam.d/login 파일이 존재합니다." >> "$target"
        if grep -qiE "^\s*#\s*auth\s*required\s*/lib/security/pam_securetty.so" "/etc/pam.d/login"; then
            echo 'auth required /lib/security/pam_securetty.so 항목이 주석처리 되어 있습니다.' >> "$target"
            u1_safe_check=$((u1_safe_check+1))
        else
            if grep -qiE "^\s*auth\s*required\s*/lib/security/pam_securetty.so" "/etc/pam.d/login"; then
                echo "auth required /lib/security/pam_securetty.so 항목: 발견됨" >> "$target"
            else
                echo "auth required /lib/security/pam_securetty.so 항목: 비활성화" >> "$target"
                u1_safe_check=$((u1_safe_check+1))
            fi
        fi
    else
        echo "/etc/pam.d/login 파일이 존재하지 않습니다." >> "$target"
    fi
    if [[ $u1_safe_check -ge 1 ]];then
        echo "점검 결과 : 취약"
        u1=$((u1+1))
    else
        echo "점검 결과 : 양호"
    fi
}
if pgrep "telnetd" > /dev/null; then
    echo "Telnet 서비스: 동작 중"
    telnet_access_check	
else
    if grep -q '^telnet[[:space:]]*23/tcp' /etc/services; then
        if sudo netstat -tuln | grep :23  > /dev/null; then
            telnet_access_check
        else
	    echo 'telnet 프로세스: 동작 중이 아님' >> "$target"
        fi
    else
        echo 'telnet 기본 포트 23으로 설정되어있지 않음' >> "$target"
        u1_telnet_newport=$(grep '^telnet[[:space:]]' /etc/services | awk '{print $2}' | cut -d'/' -f1)
        if sudo netstat -tuln | grep :$u1_telnet_newport  > /dev/null; then
            telnet_access_check
        else
	    echo 'telnet 프로세스: 동작 중이 아님' >> "$target"
        fi
    fi
fi
ssh_access_check() {
    # /etc/ssh/sshd_config 파일 체크
    if [ -f "/etc/ssh/sshd_config" ]; then
        echo "/etc/ssh/sshd_config 파일: 존재함" >> "$target"
        if grep -iqE "^\s*#\s*PermitRootLogin" "/etc/ssh/sshd_config"; then
            echo 'PermitRootLogin 항목이 주석처리 되어있습니다. : 비활성화' >> "$target"
            u1_safe_check=$((u1_safe_check+1))
        else
            if grep -iE '^\s*PermitRootLogin' "/etc/ssh/sshd_config" | awk '{print tolower($2)}' | grep -iq 'yes'; then
                echo "  - PermitRootLogin Yes : 발견됨" >> "$target"
                u1_safe_check=$((u1_safe_check+1))
            else
                echo "  - PermitRootLogin Yes : 발견되지 않음" >> "$target"
            fi
        fi
    else
        echo "/etc/ssh/sshd_config 파일: 존재하지 않음" >> "$target"
    fi

    # /etc/pam.d/sshd 파일 체크
    if [ -f "/etc/pam.d/sshd" ]; then
        echo "/etc/pam.d/sshd 파일: 존재함" >> "$target"
        if grep -qiE "^\s*#\s*auth\s*required\s*pam_securetty.so" "/etc/pam.d/sshd"; then
            echo "pam_securetty.so 모듈 사용이 주석처리되어있습니다. : 비활성화" >> "$target"
            u1_safe_check=$((u1_safe_check+1))
        else
            if grep -qiE "^\s*auth\s*required\s*pam_securetty.so" "/etc/pam.d/sshd"; then
                echo "pam_securetty.so 모듈을 사용하고 있습니다." >> "$target"
            else
                echo "pam_securetty.so 모듈을 사용하지 않고 있습니다." >> "$target"
                u1_safe_check=$((u1_safe_check+1))
            fi
        fi

        if grep -qiE "^\s*#\s*AllowUsers" "/etc/pam.d/sshd"; then
            echo "AllowUsers 항목은 주석처리 되어 비활성화 되어 있습니다." >> "$target"
        else
            if grep -qiE "^\s*AllowUsers" "/etc/pam.d/sshd"; then
                if grep -qiE "\s*AllowUsers\s*root" "/etc/pam.d/sshd"; then
                    echo "AllowUsers 항목에 root가 설정되어 있습니다." >> "$target"
                    u1_safe_check=$((u1_safe_check+1))
                else
                    echo "AllowUsers 항목이 안전하게 설정되어 있습니다." >> "$target"
                fi
            else
                echo "AllowUsers 항목이 존재하지 않습니다." >> "$target"
            fi
        fi

        if grep -qiE "^\s*#\s*AllowGroups" "/etc/pam.d/sshd"; then
            echo "AllowGroups 항목은 주석처리 되어 비활성화 되어 있습니다." >> "$target"
        else
            if grep -qiE "^\s*AllowGroups" "/etc/pam.d/sshd"; then
                if grep -qiE "\s*AllowGroups\s*root" "/etc/pam.d/sshd"; then
                    echo "AllowGroups 항목에 root가 설정되어 있습니다." >> "$target"
                    u1_safe_check=$((u1_safe_check+1))
                else
                    echo "AllowGroups 항목이 안전하게 설정되어 있습니다." >> "$target"
                fi
            else
                echo "AllowGroups 항목이 존재하지 않습니다." >> "$target"
            fi
        fi
    else
        echo "/etc/pam.d/sshd 파일 : 존재하지 않음" >> "$target"
    fi
    if [[ $u1_safe_check -ge 1 ]];then
        echo "점검 결과 : 취약" >> "$result"
        u1=$((u1+1))
    else
        echo "점검 결과 : 양호" >> "$result"
    fi
}
if pgrep "sshd" > /dev/null; then
    echo "sshd 프로세스: 동작 중" >> "$target"
    ssh_access_check
else
    if grep -q '^ssh[[:space:]]*22/tcp' /etc/services; then
    	if sudo netstat -tuln | grep :22  > /dev/null; then
    	    ssh_access_check
    	else
    	    echo "sshd 프로세스: 동작 중이 아님" >> "$target"
    	fi
    else
        echo 'ssh 기본 포트 22으로 설정되어있지 않음' >> "$target"
        u1_ssh_newport=$(grep '^sshd[[:space:]]' /etc/services | awk '{print $2}' | cut -d'/' -f1)
        if sudo netstat -tuln | grep :$u1_ssh_newport  > /dev/null; then
            ssh_access_check	    
    	else
    	    echo "sshd 프로세스: 동작 중이 아님" >> "$target"
    	fi
    fi
fi

if [ $u1 -ge 1 ];then
    High=$((High+1))
    Account_Management=$((Account_Management+1))
    u1_Account_Management=1
fi