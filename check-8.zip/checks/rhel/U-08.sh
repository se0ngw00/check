#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-08] /etc/shadow file owner and permission settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-08   /etc/shadow 파일 소유자 및 권한 설정                        " >> "$target"
echo "--------------------------------------------------------------------------" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "점검목적 : /etc/shadow 파일을 관리자만 제어할 수 있게 하여 비인가자들의 접근을 차q단하도록 shadow 파일 소유자 및 권한을 관리해야함" >> "$target"
echo "보안위협 : shadow파일은 패스워드를 암호화하여 저장하는 파일이며 해당 파일의 암호화된 해쉬값을 복호화하여(크래킹) 비밀번호를 탈취할 수 있음" >> "$target"
echo "+판단기준 양호 : /etc/shadow 파일의 소유자가 root이고, 권한이 400 이하인 경우" >> "$target"
echo "+판단기준 취약 : /etc/shadow 파일의 소유자가 root가 아니거나, 권한이 400 이하가 아닌 경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
echo "-------------" >> "$result"
echo "U-8 점검 결과" >> "$result"
u8=0
u8_safe_check=0
u8_Files_Directory_Management=0

if [[ -e "/etc/shadow" ]];then
    echo "/etc/shadow 파일이 존재합니다."
    u8_file_owner_user=$(stat -c "%U" "/etc/shadow" 2> /dev/null)
    u8_file_owner=$(stat -c "%a" "/etc/shadow"  2> /dev/null| cut -c1)
    u8_file_group=$(stat -c "%a" "/etc/shadow"  2> /dev/null| cut -c2)
    u8_file_other=$(stat -c "%a" "/etc/shadow"  2> /dev/null| cut -c3)
    u8_check_suid=$(stat -c "%a" "/etc/shadow"  2> /dev/null| tr -d '\n' | wc -c)
    if [[ $u8_check_suid -ge 4 ]];then
        echo "$u8_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> "$target"
        u8_safe_check=$((u8_safe_check+1))
    else
        if [[ "$u8_file_owner_user" == "root" ]];then
            echo "/etc/shadow 파일의 소유자가 root로 적절하게 설정되어 있습니다." >> "$target"
            if [ $u8_file_owner -le 4 ];then
                echo "/etc/shadow 파일의 소유 권한이 4이하로 설정되어 있습니다." >> "$target"
                if [ $u8_file_group -eq 0 ];then
                    echo "/etc/shadow 파일의 소유 그룹 권한이 0이하로 설정되어 있습니다." >> "$target"
                    if [ $u8_file_other -eq 0 ];then
                        echo "/etc/shadow 파일의 기타 사용자(Other) 권한이 0으로 설정되어 있습니다." >> "$target"
                    else
                        echo "/etc/shadow 파일의 기타 사용자(Other) 권한이 0이 아닌 값으로 설정되어 있습니다." >> "$target"
                        u8_safe_check=$((u8_safe_check+1))
                    fi
                else
                    echo "/etc/shadow 파일의 소유 그룹 권한이 0이상으로 설정되어 있습니다." >> "$target"
                    u8_safe_check=$((u8_safe_check+1))
                fi
            else
                echo "/etc/shadow 파일의 소유 권한이 4이상으로 설정되어 있습니다." >> "$target"
                u8_safe_check=$((u8_safe_check+1))
            fi
        else
            echo "/etc/shadow 파일의 소유자가 root가 아닌 다른 사용자로 설정되어 있습니다." >> "$target"
            u8_safe_check=$((u8_safe_check+1))
        fi
    fi
else
    echo "/etc/shadow 파일이 존재하지 않습니다." >> "$target"
    u8_safe_check=$((u8_safe_check+1))
fi

if [ $u8_safe_check -ge 1 ];then
    u8=$((u8+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi
if [[ $u8 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u8_Files_Directory_Management=1
fi