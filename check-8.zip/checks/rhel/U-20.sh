#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-20] Disable Finger Service              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-20  Anonymous FTP 비활성화             " >> "$target"
echo "--------------------------------------------------------------------------" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "점검목적 : 실행중인 FTP 서비스에 익명 FTP 접속이 허용되고 있는지 확인하여 접속허용을 차단하는 것을 목적으로 함" >> "$target"
echo "보안위협 : Anonymous FTP(익명 FTP)를 사용 시 anonymous 계정으로 로그인 후 디렉터리에 쓰기 권한이 설정되어 있다면 악의적인 사용자가 local exploit을 사용하여 시스템에 대한 공격을 가능하게 함" >> "$target"
echo "+판단기준 양호 : Anonymous FTP (익명 ftp) 접속을 차단한 경우" >> "$target"
echo "+판단기준 취약 : Anonymous FTP (익명 ftp) 접속을 차단하지 않은 경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
echo "-------------" >> "$result"
echo "U-20 점검 결과" >> "$result"
u20_Service_Management=0
u20_safe_check=0
u20=0
u20_ftpusers=("ftp" "anonymous")
u20_safe_check=0
for u20_ftpuser in "${u20_ftpusers[@]}";do
    if grep -q "$u20_ftpuser" "/etc/passwd";then
        u20_shellcheck_ftp=$(cat /etc/passwd | grep "$u20_ftpuser" | awk -F':' '{print $7}' | awk -F'/' '{print $3}')
        if [[ $u20_shellcheck == "nologin" ]];then
            echo "$u20_ftpuser 계정이 존재하며, 쉘 설정이 nologin 으로 설정되어 ftp 계증으로의 로그인을 제한하고 있습니다." >> "$target"
        else
            echo "$u20_ftpuser 계정이 존재하며, 쉘 설정이 nologin이 아닙니다. 해당 계정에 대한 삭제조치가 이루어져야 합니다." >> "$target"
            u20_safe_check=$((u20_safe_check+1))
        fi
    else
        echo "$u20_ftpuser 계정이 존재하지 않습니다." >> "$target"
    fi
done

u20_vsftpd_files=("/etc/vsftpd/vsftpd.conf" "/etc/vsftpd.conf")

for u20_vsftpd_file in "${u20_vsftpd_files[@]}";do
    if [ -f "$u20_vsftpd_file" ];then
        echo "$u20_vsftpd_file 이 존재합니다." >> "$target"
        u20_ftpoption=$(grep "anonymous_enable" $u20_vsftpd_file | grep -v "^\s*#" | awk -F'=' '{print $2}' | tr -d ' ')
        u20_lower_vsftpd=$(echo "$u20_ftpoption" | tr '[:upper:]' '[:lower:]')
        if [[ $u20_lower_vsftpd == "no" ]];then
            echo "$u20_vsftpd_file 파일에 Anonymous 설정이 적절하게 비활성화 되어 있습니다." >> "$target"
        else
            echo "$u20_vsftpd_file 파일에 Anonymous 설정이 활성화 되어 있어 취약합니다."  >> "$target"
            u20_safe_check=$((u20_safe_check+1))
        fi
    else
        echo "$u20_vsftpd_file 이 존재하지 않습니다." >> "$target"
    fi
done

u20_proftpd_files=("/etc/proftpd/proftpd.conf" "/etc/proftpd.conf")
for u20_proftpd_file in "${u20_proftpd_files[@]}"; do
    if [ -f "$u20_proftpd_file" ]; then
        echo "$u20_proftpd_file 파일이 존재합니다" >> "$target"
        u20_proftpdoption=$(sed -n '/<Anonymous/,/<\/Anonymous>/p' "$u20_proftpd_file" | sed -n '/<Limit LOGIN/,/<\/Limit>/p' | grep -i "DenyAll")
        u20_lower_proftpd=$(echo "$u20_proftpdoption" | tr '[:upper:]' '[:lower:]')

        if sed -n '/<Anonymous/,/<\/Anonymous>/p' "$u20_proftpd_file" | grep -Eq "^\s*#"; then
            echo "Anonymous 블록이 주석처리 되어 있어 양호합니다." >> "$target"
        else
            if sed -n '/<Anonymous/,/<\/Anonymous>/p' "$u20_proftpd_file" | grep -q "<Anonymous"; then
                if [[ "$u20_lower_proftpd" == *"denyall"* ]]; then
                    echo "Anonymous 계정에 대한 접근을 허용하지 않고 있어 양호합니다." >> "$target"
                else
                    echo "Anonymous 계정에 대한 접근을 거부하는 설정이 존재하지 않아 취약합니다." >> "$target"
                    u20_safe_check=$((u20_safe_check+1))
                fi
            else
                echo "Anonymous 블록이 존재하지 않아 양호합니다." >> "$target"
            fi
        fi
    else
        echo "$u20_proftpd_file 파일이 존재하지 않습니다." >> "$target"
    fi
done

if [[ $u20_safe_check -ge 1 ]];then
    u20=$((u20+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi
if [[ $u20 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u20_Service_Management=1
fi