#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-14] Setting users, system startup files and environment file owners and permissions               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-14 사용자, 시스템 시작파일 및 환경파일 소유자 및 권한 설정                        " >> "$target"
echo "--------------------------------------------------------------------------" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "점검목적 : 비인가자의 환경변수 조작으로 인한 보안 위험을 방지하기 위함" >> "$target"
echo "보안위협 : 홈 디렉터리 내의 사용자 파일 및 사용자별 시스템 시작파일 등과 같은 환경변수 파일의 접근권한 설정이 적절하지 않을 경우 비인가자가 환경변수 파일을 변조하여 정상 사용중인 사용자의 서비스가 제한 될 수 있음" >> "$target"
echo "+판단기준 양호 : 홈 디렉터리 환경변수 파일 소유자가 root 또는, 해당 계정으로 지정되어 있고, 홈 디렉터리 환경변수 파일에 root와 소유자만 쓰기 권한이 부여된 경우" >> "$target"
echo "+판단기준 취약 : 홈 디렉터리 환경변수 파일 소유자가 root 또는, 해당 계정으로 지정되지 않고, 홈 디렉터리 환경변수 파일에 root와 소유자 외에 쓰기 권한이 부여된 경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
echo "-------------" >> "$result"
echo "U-14 점검 결과" >> "$result"
u14_Files_Directory_Management=0
u14_safe_check=0
u14=0

u14_home_Environmental_files=(
    ".profile"
    ".kshrc"
    ".cshrc"
    ".bashrc"
    ".bash_profile"
    ".login"
    ".exrc"
    ".netrc"
    ".bash_logout"
    ".env"
    ".zshrc"
    ".zprofile"
)

u14_check_users=($(cat /etc/passwd | egrep -v '/sbin|false|sync' | awk -F':' '{print $1}'))
for u14_check_user in "${u14_check_users[@]}";do
    u14_user_home=($(getent passwd "$u14_check_user" | awk -F':' '{print$6}'))
    if [ -d "$u14_user_home" ];then
        echo "--------------------------------------" >> "$target"
        echo "$u14_check_user 의 홈 디렉터리가 존재합니다." >> "$target"
        for u14_home_Environmental_file in "${u14_home_Environmental_files[@]}";do
            echo -e "${RED}Checking file: $u14_user_home/$u14_home_Environmental_file${NC}" >> "$target"
            if [ -e "$u14_user_home/$u14_home_Environmental_file" ];then
                echo "$u14_user_home/$u14_home_Environmental_file 파일이 존재합니다." >> "$target"
                u14_file_owner=$(ls -l "$u14_user_home/$u14_home_Environmental_file" | awk '{print $4}')
                if [[ "$u14_file_owner" == "root" ]] || [[ "$u14_file_owner" == "$u14_check_user" ]]; then
                    echo "$u14_user_home/$u14_home_Environmental_file 파일의 소유자가 root 혹은 해당 계정으로 적절하게 설정되어 있습니다." >> "$target" 
                    u14_permissions=$(stat -c "%A" "$u14_user_home/$u14_home_Environmental_file")
                    u14_group_perm=$(echo "$u14_permissions" | cut -c6)
                    u14_other_perm=$(echo "$u14_permissions" | cut -c9)
                    if [ "$u14_group_perm" == "w" ] || [ "$u14_other_perm" == "w" ]; then 
                        echo "$u14_user_home/$home_Environmental_file 파일의 소유자 및 root 외에 기타사용자(Other)에 대한 쓰기 권한이 부여되어 있어 취약합니다." >> "$target"
                        u14_safe_check=$((u14_safe_check+1))
                    else
                        echo "$u14_user_home/$u14_home_Environmental_file 파일의 소유자 및 root 외에 기타사용자(Other)에 대한 쓰기 권한이 부여되어 있지 않아 양호합니다." >> "$target"
                    fi
                else
                    echo "echo "$u14_user_home/$u14_home_Environmental_file 파일의 소유자가 root 혹은 해당 계정으로 설정되어 있지 않아 취약합니다."" >> "$target"
                    u14_safe_check=$((u14_safe_check+1))
                fi
            else
                echo "$u14_user_home/$u14_home_Environmental_file 파일이 존재하지 않습니다." >> "$target"
            fi
        done
    fi
done

if [[ $u14_safe_check -ge 1 ]];then
    u14=$((u14+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi
if [[ $u14 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u14_Files_Directory_Management=1
fi