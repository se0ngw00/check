#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-29] tftp, talk service disabled              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-29 tftp, talk 서비스 비활성화               " >> "$target"
echo "--------------------------------------------------------------------------" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "+점검목적 : 안전하지 않거나 불필요한 서비스를 제거함으로써 시스템 보안성 및 리소스의 효율적 운용" >> "$target"
echo "+보안위협 : 사용하지 않는 서비스나 취약점이 발표된 서비스 운용 시 공격 시도 가능" >> "$target"
echo "+판단기준 양호 : tftp, talk, ntalk 서비스가 비활성화 되어 있는 경우" >> "$target"
echo "+판단기준 취약 : tftp, talk, ntalk 서비스가 활성화 되어 있는 경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
u29=0
u29_Service_Management=0
u29_safe_check=0
u29_services=("tftp" "talk" "ntalk")
u29_ports=("69" "517" "518")

check_service_status "${u29_ports}" "${u29_services[@]}"
if [ $? -eq 1 ]; then
    echo "불필요한 RPC 서비스를  사용하고 있습니다." >> "$target"
    u29_safe_check=$((u29_safe_check+1))
else
    echo "불필요한 RPC 서비스를  사용하지 않고 있습니다." >> "$target"
fi

if [[ $u29_safe_check -ge 1 ]];then
    u29=$((u29+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi
if [[ $u29 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u29_Service_Management=1
fi