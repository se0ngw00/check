#!/bin/bash
set -e

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
HOSTNAME="$(hostname)"
NOW="$(date +%Y%m%d-%H%M%S)"

if [ ! -f /etc/os-release ]; then
    echo "ERROR: Cannot detect OS (/etc/os-release not found)"
    exit 10
fi

. /etc/os-release

OS_ID="$ID"
OS_VER="$VERSION_ID"

echo "Detected OS: $NAME $VERSION_ID"

case "$OS_ID" in
    centos)
        RUN_DIR="CentOS7"
        OS_TAG="centos7"
        ;;
    rocky|rhel|almalinux)
        RUN_DIR="Rocky_Linux"
        OS_TAG="rhel"
        ;;
    ubuntu)
        RUN_DIR="Ubuntu"
        OS_TAG="ubuntu"
        ;;
    *)
        echo "ERROR: Unsupported OS ($OS_ID)"
        exit 20
        ;;
esac

TARGET_DIR="$BASE_DIR/$RUN_DIR"

if [ ! -d "$TARGET_DIR" ]; then
    echo "ERROR: Target directory not found ($TARGET_DIR)"
    exit 30
fi

export RESULT_PREFIX="${HOSTNAME}_${OS_TAG}_${NOW}"
export RESULT_DIR="$BASE_DIR/results"

mkdir -p "$RESULT_DIR"
echo "Using check scripts in: $TARGET_DIR"
echo "Results will be saved to: $RESULT_DIR"
echo "Result file prefix: $RESULT_PREFIX"

cd "$TARGET_DIR"
chmod +x *.sh

if [ -f "./ALL_system_check.sh" ]; then
    exec ./ALL_system_check.sh
else
    echo "ERROR: ALL_system_check.sh not found in $TARGET_DIR"
    exit 40
fi
