check-9: SAFE version. test mode verified, ctrl+c safe, no zombies.
