#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-19] Access IP and Port Restrictions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-19 Finger 서비스 비활성화             " >> "$target"
echo "--------------------------------------------------------------------------" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "점검목적 : Finger(사용자 정보 확인 서비스)를 통해서 네트워크 외부에서 해당 시스템에 등록된 사용자 정보를 확인할 수 있어 비인가자에게 사용자 정보가 조회되는 것을 차단하고자 함" >> "$target"
echo "보안위협 : 비인가자에게 사용자 정보가 조회되어 패스워드 공격을 통한 시스템 권한 탈취 가능성이 있으므로 사용하지 않는다면 해당 서비스를 중지하여야 함" >> "$target"
echo "+판단기준 양호 : Finger 서비스가 비활성화 되어 있는 경우" >> "$target"
echo "+판단기준 취약 : Finger 서비스가 활성화 되어 있는 경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
echo "-------------" >> "$result"
echo "U-19 점검 결과" >> "$result"
u19_Service_Management=0
u19_safe_check=0
u19=0
#finger 서비스는 보통 systemctl이나 pgrep 명령어로는 바로 확인할 수 없음
if [ -f "/etc/inetd.conf" ];then
    if grep -iqE "^\s*finger\s*stream\s*tcp\s*nowait\s*bin" "/etc/inetd.conf";then
        echo "/etc/inetd.conf 파일에 Finger 서비스가 활성화 되어 있어 취약합니다." >> "$target"
        u19_safe_check=$((u19_safe_check+1))
    elif grep -iqE "^#\s*finger\s*stream\s*tcp\s*nowait\s*bin" "/etc/inetd.conf";then
        echo "/etc/inetd.conf 파일에 Finger 서비스가 비활성화 되어 있어 양호합니다." >> "$target"
    else
        echo "/etc/inetd.conf 파일 내에 Finger 설정 항목이 존재하지 않습니다." >> "$target"
    fi
elif [ -f "/etc/xinetd.d/finger" ];then
    u19_fingerconf=$(sed -n '/service finger/,/}/p' "/etc/xinetd.d/finger" | grep -v "^#" | grep -iE "^\s*disable" | awk '{print tolower($3)}' | sed -n '1p')
    u19_lower_string=$(echo "$u19_fingerconf" | tr '[:upper:]' '[:lower:]')
    if [[ $u19_lower_string == "no" ]];then
        echo "/etc/xinerd.d/finger 설정 파일 내에 finger 서비스가 활성화 되어 있어 취약합니다." >> "$target"
        u19_safe_check=$((u19_safe_check+1))
    elif [[ $u19_lower_string == "yes" ]];then
        echo "/etc/xinetd.d/finger 설정 파일 내에 finger 서비스가 비활성화 되어 있어 양호합니다." >> "$target"
    else
        echo "/etc/xinetd.d/finger 설정 파일 내에 finger 서비스 항목이 존재하지 않습니다." >> "$target"
    fi
else
    echo "/etc/inetd.conf 파일 및 /etc/xinetd.d/finger 파일이 존재하지 않습니다." >> "$target"
fi

if [[ $u19_safe_check -ge 1 ]];then
    u19=$((u19+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi
if [[ $u19 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u19_Service_Management=1
fi