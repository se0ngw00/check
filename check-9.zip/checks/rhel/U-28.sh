#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-28] NIS, NIS+ check              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-28 NIS, NIS+ 점검               " >> "$target"
echo "--------------------------------------------------------------------------" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "+점검목적 : 안전하지 않은 NIS 서비스를 비활성화 하고 안전한 NIS+ 서비스를 활성화 하여 시스템 보안수준을 향상하고자 함" >> "$target"
echo "+보안위협 : 보안상 취약한 서비스인 NIS를 사용하는 경우 비인가자가 타시스템의 root 권한 획득이 가능하므로 사용하지 않는 것이 가장 바람직하나 만약 NIS를 사용해야 하는 경우 사용자 정보보안에 많은 문제점을 내포하고 있는 NIS보다 NIS+를 사용하는 것을 권장함 " >> "$target"
echo "+판단기준 양호 : NIS 서비스가 비활성화 되어 있거나, 필요 시 NIS+를 사용하는 경우" >> "$target"
echo "+판단기준 취약 : NIS 서비스가 활성화 되어 있는 경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
u28=0
u28_Service_Management=0
u28_safe_check=0
u28_services=(
    "ypserv"
    "ypbind"
    "ypxfrd"
    "rpc.yppasswdd"
    "rpc.ypupdated"
)
u28_port=("111")

check_service_status "${u28_port[@]}" "${u28_services[@]}"
if [ $? -eq 1 ]; then
    echo "불필요한 RPC 서비스를  사용하고 있습니다." >> "$target"
    u28_safe_check=$((u28_safe_check+1))
else
    echo "불필요한 RPC 서비스를  사용하지 않고 있습니다." >> "$target"
fi

for u28_service in "${u28_services[@]}";do
    u28_nic_rc=$(find /etc/rc.d/rc*.d/ -type f -name "*$u28_service*")
    if [ -n "$u28_nic_rc" ];then
        echo "$u28_nic_rc 시동 스크립트가 식별되었습니다. 삭제 또는 스크립트 이름을 변경하십시오." >> "$target"
        u28=$((u28+1))
    else
        echo "/etc/rc.d/rc*.d/ 경로에서 $u28_service 시동 스크립트가 식별되지 않았습니다." >> "$target"
    fi
done

if [[ $u28_safe_check -ge 1 ]];then
    u28=$((u28+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi
if [[ $u28 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u28_Service_Management=1
fi