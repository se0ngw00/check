#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-68] Provides a warning message when logged on              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-68 로그온 시 경고 메시지 제공             " >> "$target"
echo "--------------------------------------------------------------------------"  >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "점검목적 : 비인가자들에게 서버에 대한 불필요한 정보를 제공하지 않고, 서버 접속 시 관계자만 접속해야 한다는 경각심을 심어 주기위해 경고 메시지 설정이 필요함" >> "$target"
echo "보안위협 : 로그인 배너가 설정되지 않을 경우 배너에 서버 OS 버전 및 서비스 버전이 공격자에게 노출될 수 있으며 공격자는 이러한 정보를 통하여 해당 OS 및 서비스의 취약점을 이용하여 공격을 시도할 수 있음" >> "$target"
echo "+판단기준 양호 : 서버 및 Telnet, FTP, SMTP, DNS 서비스에 로그온 메시지가 설정되어 있는 경우" >> "$target"
echo "+판단기준 취약 : 서버 및 Telnet, FTP, SMTP, DNS 서비스에 로그온 메시지가 설정되어 있지 않은 경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
echo "-------------" >> "$result"
echo "U-68 점검 결과" >> "$result"

u68_Service_Management=0
u68_safe_check=0
u68=0
u68_check_files=("motd" "inssue.net" "vsftpd.conf" "proftpd.conf" "main.cf" "sendmail.cf" "named.conf") 
u68_safe_check=0
for u68_check_file in "${u68_check_files[@]}";do
    u68_find_file=$(find / -type f -name "$u68_check_file" 2> /dev/null)
    if [ -e "$u68_find_file" ];then
        echo "$u68_find_file 파일이 존재합니다." >> "$target"
        u68_file_name=$(basename "$u68_find_file")
        case $u68_file_name in
            "motd")
                if [[ $(wc -c < "$u68_find_file") -ge 1 ]];then
                    echo "$u68_file_name 파일 내에 로그온 메시지가 설정되어 있습니다." >> "$target"
                else
                    echo "$u68_file_name 파일 내에 로그온 메시지가 출력되어 있지 않습니다." >> "$target"
                    u68_safe_check=$((u68_safe_check+1))
                fi
                ;;
            "inssue.net")
                if [[ $(wc -c < "$u68_find_file") -ge 1 ]];then
                    echo "$u68_file_name 파일 내에 로그온 메시지가 설정되어 있습니다." >> "$target"
                else
                    echo "$u68_file_name 파일 내에 로그온 메시지가 출력되어 있지 않습니다." >> "$target"
                    u68_safe_check=$((u68_safe_check+1))
                fi
                ;;
            "vsftpd.conf")
                if grep -v "^\s*#" "$u68_find_file" | grep -iqE "^\s*ftpd_banner\s*=\s*.";then
                    echo "$u68_file_name 파일 내에 로그온 메시지가 설정되어 있습니다." >> "$target"
                else
                    echo "$u68_file_name 파일 내에 로그온 메시지가 출력되어 있지 않습니다." >> "$target"
                    u68_safe_check=$((u68_safe_check+1))
                fi
                ;;
            "proftpd.conf")
                if grep -v "^\s*#" "$u68_find_file" | grep -iqE "^\s*ServerIdent\s*on\s*.";then
                    echo "$u68_file_name 파일 내에 로그온 메시지가 설정되어 있습니다." >> "$target"
                else
                    echo "$u68_file_name 파일 내에 로그온 메시지가 출력되어 있지 않습니다." >> "$target"
                    u68_safe_check=$((u68_safe_check+1))
                fi                ;;
            "main.cf")
                if grep -v "^\s*#" "$u68_find_file" | grep -iqE "^\s*smtpd_banner\s*=\s*.";then
                    echo "$u68_file_name 파일 내에 로그온 메시지가 설정되어 있습니다." >> "$target"
                else
                    echo "$u68_file_name 파일 내에 로그온 메시지가 출력되어 있지 않습니다." >> "$target"
                    u68_safe_check=$((u68_safe_check+1))
                fi 
                ;;
            "sendmail.cf")
                if grep -v "^\s*#" "$u68_find_file" | grep -iqE "^\s*O\s*SmtpGreetingMessage\s*=\s*.";then
                    echo "$u68_file_name 파일 내에 로그온 메시지가 설정되어 있습니다." >> "$target"
                else
                    echo "$u68_file_name 파일 내에 로그온 메시지가 출력되어 있지 않습니다." >> "$target"
                    u68_safe_check=$((u68_safe_check+1))
                fi 
                ;;
            "named.conf")
                 if grep -q "logging" "$u68_find_file";then
                    echo "$u68_file_name 파일 내에 로그온 메시지가 설정되어 있습니다." >> "$target"
                else
                    echo "$u68_file_name 파일 내에 로그온 메시지가 출력되어 있지 않습니다." >> "$target"
                    u68_safe_check=$((u68_safe_check+1))
                fi 
                ;;
            *)
                echo "해당 파일은 존재하지 않는 파일입니다.: $file" >> "$target"
                ;;
        esac
    fi
done
if [[ $u68_safe_check -ge 1 ]];then
    u68=$((u68+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi
if [[ $u68 -ge 1 ]];then
    Low=$((Low+1))
    Service_Management=$((Service_Management+1))
    u68_Service_Management=1
fi