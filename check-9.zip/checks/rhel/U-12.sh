#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-12] /etc/services file owner and permission settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-12   /etc/services 파일 소유자 및 권한 설정                        " >> "$target"
echo "--------------------------------------------------------------------------" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "점검목적 : /etc/services 파일을 관리자만 제어할 수 있게 하여 비인가자들의 임의적인 파일 변조를 방지하기 위함" >> "$target"
echo "보안위협 : services 파일의 접근권한이 적절하지 않을 경우 비인가 사용자가 운영 포트번호를 변경하여 정상적인 서비스를 제한하거나, 허용되지 않은 포트를 오픈하여 악성 서비스를 의도적으로 실행할 수 있음" >> "$target"
echo "+판단기준 양호 : /etc/services 파일의 소유자가 root(또는 bin, sys)이고, 권한이 644 이하인 경우" >> "$target"
echo "+판단기준 취약 : /etc/services 파일의 소유자가 root(또는 bin, sys)가 아니거나, 권한이 644 이하가 아닌 경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
echo "-------------" >> "$result"
echo "U-12 점검 결과" >> "$result"
u12=0
u12_Files_Directory_Management=0
u12_safe_check=0
if [[ -e "/etc/services" ]];then
    echo "/etc/services 파일이 존재합니다." >> "$target"
    u12_file_owner_user=$(stat -c "%U" "/etc/services" 2> /dev/null)
    u12_file_owner=$(stat -c "%a" "/etc/services"  2> /dev/null| cut -c1)
    u12_file_group=$(stat -c "%a" "/etc/services"  2> /dev/null| cut -c2)
    u12_file_other=$(stat -c "%a" "/etc/services"  2> /dev/null| cut -c3)
    u12_check_suid=$(stat -c "%a" "/etc/services"  2> /dev/null| tr -d '\n' | wc -c)
    if [[ $u12_check_suid -ge 4 ]];then
        echo "$u12_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> "$target"
        u12_safe_check=$((u12_safe_check+1))
    else
        if [[ $u12_file_owner_user == "root" || $u12_file_owner_user == "bin" || $u12_file_owner_user == "sys" ]];then
            echo "$syslog_file 파일의 소유자가 root, bin, sys로 적절하게 설정되어 있습니다." >> "$target"
            if [ $u12_file_owner -le 6 ];then
                echo "/etc/services 파일의 소유 권한이 6으로 설정되어 있습니다." >> "$target"
                if [ $u12_file_group -le 4 ];then
                    echo "/etc/services 파일의 소유 그룹 권한이 4로 설정되어 있습니다." >> "$target"
                    if [ $u12_file_other -le 4 ];then
                        echo "/etc/services 파일의 기타 사용자(Other) 권한이 4 이하로 설정되어 있습니다." >> "$target"
                    else
                        echo "/etc/services 파일의 기타 사용자(Other) 권한이 4 이상의 값으로 설정되어 있습니다." >> "$target"
                        u12_safe_check=$((u12_safe_check+1))
                    fi
                else
                    echo "/etc/services 파일의 소유 그룹 권한이 4 이상의 값으로 설정되어 있습니다." >> "$target"
                    u12_safe_check=$((u12_safe_check+1))
                fi
            else
                echo "/etc/services 파일의 소유 권한이 4 이상의 값으로 설정되어 있습니다." >> "$target"
                u12_safe_check=$((u12_safe_check+1)) 
            fi
        else
            echo "/etc/services 파일의 소유자가 root, bin, sys가 아닌 다른 사용자로 설정되어 있습니다." >> "$target"
            u12_safe_check=$((u12_safe_check+1))
        fi 
    fi
else
    echo "/etc/services 파일이 존재하지 않습니다." >> "$target"
    u12=$((u12+1))
fi

if [[ $u12_safe_check -ge 1 ]];then
    u12=$((u12+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi
if [[ $u12 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u12_Files_Directory_Management=1
fi