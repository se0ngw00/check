#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-57] Set Home Directory Owners and Permissions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-57  홈디렉토리 소유자 및 권한 설정             " >> "$target"
echo "--------------------------------------------------------------------------"  >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "점검목적 : 사용자 홈 디렉터리 내 설정파일이 비인가자에 의한 변조를 방지함" >> "$target"
echo "보안위협 : 홈 디렉터리 내 설정파일 변조 시 정상적인 서비스 이용이 제한될 우려가 존재함" >> "$target"
echo "+판단기준 양호 : 홈 디렉터리 소유자가 해당 계정이고, 타 사용자 쓰기 권한이 제거된 경우" >> "$target"
echo "+판단기준 취약 : 홈 디렉터리 소유자가 해당 계정이 아니고, 타 사용자 쓰기 권한이 부여된  경우" >> "$target"
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++ff+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
u57_Files_Directory_Management=0
u57_safe_check=0
u57=0
u57_check_users=($(awk -F':' '!/sbin|sync|false/ {print $1}' /etc/passwd))

for u57_check_user in "${u57_check_users[@]}"; do
    u57_user_home=$(getent passwd "$u57_check_user" | awk -F':' '{print $6}')
    if [ -d "$u57_user_home" ]; then
        echo "--------------------------------------"   >> "$target"
        echo "$u57_check_user 의 홈 디렉터리가 존재합니다."  >> "$target"
        u57_dir_owner=$(stat -c "%U" "$u57_user_home")
        u57_dir_other=$(stat -c "%A" "$u57_user_home" | awk '{print substr($0, length($0)-1)}' | grep -i "w")
        if [ "$u57_dir_owner" == "$u57_check_user" ];then
            if [ -n "$u57_dir_other" ];then
                echo "홈 디렉터리의 기타 사용자(Other)에 대한 쓰기 권한이 부여되어 있습니다." >> "$target"
                echo "현재 설정값 : $u57_dir_other" >> "$target"
                u57_safe_check=$((u57_safe_check+1))
            else
                echo "홈 디렉터리 소유자가 해당 계정으로 되어 있으며, 타 사용자 쓰기 권한이 제거되어 있습니다." >> "$target"
                echo "현재 설정값 : $u57_dir_owner , $(stat -c "%A" "$u57_user_home")" >> "$target"
            fi
        else
            echo "홈 디렉터리 소유자가 해당 계정이 아닙니다." >> "$target"
            echo "현재 설정값 : $u57_dir_owner" >> "$target"
            u57_safe_check=$((u57_safe_check+1))
        fi
    fi 
done

if [[ $u57_safe_check -ge 1 ]];then
    u57=$((u57+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi
if [[ $u57 -ge 1 ]];then
    Mid=$((Mid+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u57_Files_Directory_Management=1
fi