#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-63] ftpersus file owner and permission settings              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-63 ftpusers 파일 소유자 및 권한 설정             " >> "$target"
echo "--------------------------------------------------------------------------"  >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "점검목적 : 비인가자들의 ftp 접속을 차단하기 위해 ftpusers 파일 소유자 및 권한을 관리해야함" >> "$target"
echo "보안위협 : ftpusers 파일에 인가되지 않은 사용자를 등록하여 해당 계정을 이용, 불법적인 FTP 서비스에 접근이 가능함" >> "$target"
echo "+판단기준 양호 : ftpusers 파일의 소유자가 root이고, 권한이 640 이하인 경우" >> "$target"
echo "+판단기준 취약 : tpusers 파일의 소유자가 root가 아니거나, 권한이 640 이하가 아닌경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
echo "-------------" >> "$result"
echo "U-63 점검 결과" >> "$result"

u63=0
u63_safe_check=0
u63_Service_Management=0
u63_check_ftpfiles=("/etc/ftpusers" "/etc/ftpd/ftpusers" "/etc/vsftpd/ftpusers" "/etc/vsftpd/user_list" "/etc/vsftpd.user_list")
u63_safe_check=0
for u63_check_ftpfile in "${u63_check_ftpfiles[@]}";do
    if [ -e "$u63_check_ftpfile" ];then
        echo "$u63_check_ftpfile 파일이 존재합니다."  >> "$target"
        u63_file_owner=$(stat -c "%U" "$u63_check_ftpfile" 2> /dev/null)
        u63_file_perm_user=$(stat -c "%a" "$u63_check_ftpfile" 2> /dev/null | cut -c1)
        u63_file_perm_group=$(stat -c "%a" "$u63_check_ftpfile" 2> /dev/null | cut -c2)
        u63_file_perm_other=$(stat -c "%a" "$u63_check_ftpfile" 2> /dev/null | cut -c3)
        if [[ "$u63_file_owner" == "root" ]];then
            echo "$u63_check_ftpfile 파일의 소유자가 root로 설정되어 있습니다."  >> "$target"
            if [[ $u63_file_perm_user -le 6 ]];then
                echo "$u63_check_ftpfile 파일의 소유 권한이 6이하로 설정되어 있습니다."  >> "$target"
                if [[ $u63_file_perm_group -le 4 ]];then
                    echo "$u63_check_ftpfile 파일의 소유 그룹 권한이 4이하로 설정되어 있습니다."  >> "$target"
                    if [[ $u63_file_perm_other -eq 0 ]];then
                        echo "$u63_check_ftpfile 파일의 기타 사용자(Other)의 권한이 0으로 설정되어 있습니다."  >> "$target"
                    else
                        echo "$u63_check_ftpfile 파일의 기타 사용자(Other)의 권한이 0이상으로 설정되어 있습니다."  >> "$target"
                        u63_safe_check=$((u63_safe_check+1))
                    fi
                else
                    echo "$u63_check_ftpfile 파일의 소유 그룹 권한이 4이상으로 설정되어 있습니다."  >> "$target"
                    u63_safe_check=$((u63_safe_check+1))
                fi
            else
                echo "$u63_check_ftpfile 파일의 소유 권한이 6이상으로 설정되어 있습니다."  >> "$target"
                u63_safe_check=$((u63_safe_check+1))
            fi
        else
            echo "$u63_check_ftpfile 파일의 소유자가 root가 아닌 다른 사용자로 되어 있습니다."  >> "$target"
            u63_safe_check=$((u63_safe_check+1))
        fi
    else
        echo "$u63_check_ftpfile 파일이 존재하지 않습니다."
    fi
done

if [[ $u63_safe_check -ge 1 ]];then
    u63=$((u63+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi

if [[ $u63 -ge 1 ]];then
    Low=$((Low+1))
    Service_Management=$((Service_Management+1))
    u62_Service_Management=1
fi