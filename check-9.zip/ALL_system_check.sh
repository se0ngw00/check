#!/bin/bash

# ================================
# SAFE VERSION (check-9)
# ================================

set -u

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
RESULT_DIR="$BASE_DIR/results"
mkdir -p "$RESULT_DIR"

START_TIME=$(date +%s)

TEST_MODE=0
if [[ "${1:-}" == "--test" ]]; then
  TEST_MODE=1
fi

RESULT_PREFIX="$(date +%Y%m%d-%H%M%S)"
TOTAL_FILE="$RESULT_DIR/${RESULT_PREFIX}.total"
VULN_FILE="$RESULT_DIR/${RESULT_PREFIX}.vuln"

cleanup() {
  echo
  exit 0
}

trap cleanup INT TERM

# ================================
# TEST MODE (deterministic)
# ================================
if [ "$TEST_MODE" -eq 1 ]; then
  echo "[TEST MODE] result file creation test" > "$TOTAL_FILE"
  echo "[TEST MODE] no vulnerability check performed" > "$VULN_FILE"

  END_TIME=$(date +%s)
  ELAPSED=$((END_TIME - START_TIME))

  echo "Total execution time: ${ELAPSED}s"
  echo "Results:"
  echo "  $TOTAL_FILE"
  echo "  $VULN_FILE"
  exit 0
fi

# ================================
# REAL MODE (SAFE, SEQUENTIAL)
# ================================

# Timer (foreground-safe)
while true; do
  NOW=$(date +%s)
  ELAPSED=$((NOW - START_TIME))
  printf "\r[Running] Elapsed time: %dm %02ds"     $((ELAPSED/60)) $((ELAPSED%60))
  sleep 1 &
  wait $!
done &
TIMER_PID=$!

# OS detection
. /etc/os-release
if [[ "$ID" =~ (centos|rhel|rocky|almalinux) ]]; then
  CHECK_DIR="$BASE_DIR/checks/rhel"
else
  CHECK_DIR="$BASE_DIR/checks/ubuntu"
fi

for f in "$CHECK_DIR"/U-*.sh; do
  id=$(basename "$f" .sh)
  output=$(bash "$f" 2>&1 || true)

  echo "===== $id =====" >> "$TOTAL_FILE"
  echo "$output" >> "$TOTAL_FILE"
  echo >> "$TOTAL_FILE"

  echo "$id REVIEW_REQUIRED" >> "$VULN_FILE"
done

kill "$TIMER_PID" 2>/dev/null
wait "$TIMER_PID" 2>/dev/null
echo

END_TIME=$(date +%s)
ELAPSED=$((END_TIME - START_TIME))

echo "Total execution time: ${ELAPSED}s"
echo "Results:"
echo "  $TOTAL_FILE"
echo "  $VULN_FILE"
