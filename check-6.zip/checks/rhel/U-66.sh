#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-66] Check SNMP service drive...              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-66 SNMP 서비스 구동 점검             " >> "$target"
echo "--------------------------------------------------------------------------"  >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "점검목적 : 불필요한 SNMP 서비스 활성화로 인해 필요 이상의 정보가 노출되는 것을 막기 위해 SNMP 서비스를 중지해야함" >> "$target"
echo "보안위협 : SNMP 서비스로 인하여 시스템의 주요 정보 유출 및 정보의 불법수정이 발생할 수 있음" >> "$target"
echo "+판단기준 양호 : SNMP 서비스를 사용하지 않는 경우" >> "$target"
echo "+판단기준 취약 : SNMP 서비스를 사용하는 경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
echo "-------------" >> "$result"
echo "U-66 점검 결과" >> "$result"

u66_Service_Management=0
u66_safe_check=0
u66=0
u66_snmp_checks=("snmp" "snmpd")
u66_snmp_ports=("161" "162")

check_service_status "${u66_snmp_ports}" "${u66_snmp_checks[@]}"
if [[ $? -eq 1 ]]; then
    echo "snmp 서비스를 사용하고 있습니다.">> "$target"
    66_safe_check=$((66_safe_check+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "snmp 서비스를 사용하지 않고 있습니다.">> "$target"
    echo "점검 결과 : 양호" >> "$result"
fi

if [[ $u66_safe_check -ge 1 ]];then
    u66=$((u66+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi
if [[ $u66 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u66_Service_Management=1
fi