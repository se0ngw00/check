#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-54] Session timeout setting              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-54 Session Timeout 설정             " >> "$target"
echo "--------------------------------------------------------------------------"  >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "점검목적 : 사용자의 고의 또는 실수로 시스템에 계정이 접속된 상태로 방치됨을 차단하기 위함" >> "$target"
echo "보안위협 : Session timeout 값이 설정되지 않은 경우 유휴 시간 내 비인가자의 시스템 접근으로 인해 불필요한 내부 정보의 노출 위험이 존재함" >> "$target"
echo "+판단기준 양호 : Session Timeout이 600초(10분) 이하로 설정되e어 있는 경우" >> "$target"
echo "+판단기준 취약 : Session Timeout이 600초(10분) 이하로 설정되지 않은 경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
u54_Account_Management=0
u54_safe_check=0
u54=0
u54_files=("/etc/bash.bashrc" "/etc/zsh/zshrc" "/etc/ksh.kshrc" "/etc/profile" "/etc/.profile")
u54_individual_files=(".bashrc" ".zshrc" ".kshrc" ".bash_profile")
u54_dirs=("/etc/profile.d/*.sh" "/etc/profile.d/*.csh" "/etc/profil.d/*.ksh")
u54_csh_files=("/etc/csh.cshrc" "/etc/csh.login")
u54_csh_individual_files=(".cshrc" ".login")
u54_check_users=($(awk -F':' '!/sbin|sync|false/ {print $1}' /etc/passwd))

for u54_check_dir in ${u54_dirs[@]}; do
    for u54_dir in $u54_check_dir; do
        if [ -e "$u54_dir" ]; then
            echo "$u54_dir 파일이 존재합니다." >> "$target"
            u54_dir_tmoutsh=$(grep -Ev "^\s*#" "$u54_dir" | grep -Ei "^\s*TMOUT" | tr -d ' ' | awk -F'=' '{print $2}')
            if [ -n "$u54_dir_tmoutsh" ]; then
                echo "$u54_dir 파일에 세션 타임아웃 설정 값이 존재합니다." >> "$target"
                if [ "$u54_dir_tmoutsh" -le 600 ]; then
                    echo "세션 타임아웃 설정 값이 600이하로 적절하게 설정되어 있습니다." >> "$target"
                    echo "현재 설정 값 : $u54_dir_tmoutsh" >> "$target"
                else   
                    echo "세션 타임아웃 설정 값이 600이상으로 부적절하게 설정되어 있습니다." >> "$target"
                    echo "현재 설정 값 : $u54_dir_tmoutsh" >> "$target"
                    u54_safe_check=$((u54_safe_check+1))
                fi
            else
                echo "$u54_dir 파일에 세션 타임아웃 설정 값이 존재하지 않습니다." >> "$target"
                u54_safe_check=$((u54_safe_check+1))
            fi
        fi
    done
done

for u54_file in "${u54_files[@]}"; do
    if [ -e "$u54_file" ]; then
        echo "$u54_file 파일이 존재합니다." >> "$target"
        u54_file_tmout=$(grep -Ev "^\s*#" "$u54_file" | grep -Ei "^\s*TMOUT" | tr -d ' ' | awk -F'=' '{print $2}')
        if [ -n "$u54_file_tmout" ]; then
            echo "$u54_file 파일에 세션 타임아웃 설정 값이 존재합니다." >> "$target"
            if [ "$u54_file_tmout" -le 600 ]; then
                echo "세션 타임아웃 설정 값이 600이하로 적절하게 설정되어 있습니다." >> "$target"
                echo "현재 설정 값 : $u54_file_tmout" >> "$target"
            else   
                echo "세션 타임아웃 설정 값이 600이상으로 부적절하게 설정되어 있습니다." >> "$target"
                echo "현재 설정 값 : $u54_file_tmout" >> "$target"
                u54_safe_check=$((u54_safe_check+1))
            fi
        else
            echo "$u54_file 파일에 세션 타임아웃 설정 값이 존재하지 않습니다." >> "$target"
            u54_safe_check=$((u54_safe_check+1))
        fi
    fi
done

for u54_csh_file in "${u54_csh_files[@]}"; do
    if [ -e "$u54_csh_file" ]; then
        echo "$u54_csh_file 파일이 존재합니다." >> "$target"
        u54_cshfile_tmout=$(grep -Ev "^\s*#" "$u54_csh_file" | grep -Ei "^\s*set\s*autologout" | tr -d ' ' | awk -F'=' '{print $2}')
        if [ -n "$u54_cshfile_tmout" ]; then
            echo "$u54_csh_file 파일에 세션 타임아웃 설정 값이 존재합니다." >> "$target"
            if [ "$u54_cshfile_tmout" -le 10 ]; then
                echo "세션 타임아웃 설정 값이 10이하로 적절하게 설정되어 있습니다." >> "$target"
                echo "현재 설정 값 : $u54_cshfile_tmout" >> "$target"
            else   
                echo "세션 타임아웃 설정 값이 10이상으로 부적절하게 설정되어 있습니다." >> "$target"
                echo "현재 설정 값 : $u54_cshfile_tmout" >> "$target"
                u54_safe_check=$((u54_safe_check+1))
            fi
        else
            echo "$u54_csh_file 파일에 세션 타임아웃 설정 값이 존재하지 않습니다." >> "$target"
            u54_safe_check=$((u54_safe_check+1))
        fi
    fi
done

for u54_check_user in "${u54_check_users[@]}"; do
    u54_user_home=$(getent passwd "$u54_check_user" | awk -F':' '{print $6}')
    if [ -d "$u54_user_home" ]; then
        echo "--------------------------------------"  >> "$target"
        echo "$u54_check_user 의 홈 디렉터리가 존재합니다." >> "$target"
        for u54_individual_file in "${u54_individual_files[@]}"; do
            echo -e "Checking file: $u54_user_home/$u54_individual_file"  >> "$target"
            if [ -e "$u54_user_home/$u54_individual_file" ]; then
                echo "$u54_user_home/$u54_individual_file 파일이 존재합니다."  >> "$target"
                u54_check_timeout=$(grep -Ev "^\s*#" "$u54_user_home/$u54_individual_file" | grep -Ei "^\s*TMOUT" | tr -d ' ' | awk -F'=' '{print $2}')
                if [ -n "$u54_check_timeout" ]; then
                    echo "$u54_user_home/$u54_individual_file 파일에 세션 타임아웃 설정 값이 존재합니다." >> "$target"
                    if [ "$u54_check_timeout" -le 600 ]; then
                        echo "세션 타임아웃 설정 값이 600이하로 적절하게 설정되어 있습니다." >> "$target"
                        echo "현재 설정 값 : $u54_check_timeout" >> "$target"
                    else   
                        echo "세션 타임아웃 설정 값이 600이상으로 부적절하게 설정되어 있습니다." >> "$target"
                        echo "현재 설정 값 : $u54_check_timeout" >> "$target"
                        u54_safe_check=$((u54_safe_check+1))
                    fi
                else
                    echo "$u54_user_home/$u54_individual_file 파일에 세션 타임아웃 설정 값이 존재하지 않습니다." >> "$target"
                    u54_safe_check=$((u54_safe_check+1))
                fi
            else
                echo "$u54_user_home/$u54_individual_file 파일이 존재하지 않습니다." >> "$target"
            fi
        done
        for u54_csh_individual_file in "${u54_csh_individual_files[@]}"; do
            echo -e "Checking file: $u54_user_home/$u54_csh_individual_file"  >> "$target"
            if [ -e "$u54_user_home/$u54_csh_individual_file" ]; then
                echo "$u54_user_home/$u54_csh_individual_file 파일이 존재합니다."  >> "$target"
                u54_check_timeout=$(grep -Ev "^\s*#" "$u54_user_home/$u54_csh_individual_file" | grep -Ei "^\s*set\s*autologout" | tr -d ' ' | awk -F'=' '{print $2}')
                if [ -n "$u54_check_timeout" ]; then
                    echo "$u54_user_home/$u54_csh_individual_file 파일에 세션 타임아웃 설정 값이 존재합니다." >> "$target"
                    if [ "$u54_check_timeout" -le 10 ]; then
                        echo "세션 타임아웃 설정 값이 10이하로 적절하게 설정되어 있습니다." >> "$target"
                        echo "현재 설정 값 : $u54_check_timeout" >> "$target"
                    else   
                        echo "세션 타임아웃 설정 값이 10이상으로 부적절하게 설정되어 있습니다." >> "$target"
                        echo "현재 설정 값 : $u54_check_timeout" >> "$target"
                        u54_safe_check=$((u54_safe_check+1))
                    fi
                else
                    echo "$u54_user_home/$u54_csh_individual_file 파일에 세션 타임아웃 설정 값이 존재하지 않습니다." >> "$target"
                    u54_safe_check=$((u54_safe_check+1))
                fi
            else
                echo "$u54_user_home/$u54_csh_individual_file 파일이 존재하지 않습니다." >> "$target"
            fi
        done
    else
        echo "$u54_check_user 의 홈 디렉터리가 존재하지 않습니다." >> "$target"
    fi
done

if [ $u54_safe_check -ge 1 ];then
    u54=$((u54+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi
if [[ $u54 -ge 1 ]];then
    Low=$((Low+1))
    Account_Management=$((Account_Management+1))
    u54_Account_Management=1
fi