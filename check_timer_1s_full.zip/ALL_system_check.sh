#!/bin/bash

START_TIME=$SECONDS

while true; do
    elapsed=$((SECONDS - START_TIME))
    printf "\r[Running] Elapsed time: %dm %02ds" $((elapsed/60)) $((elapsed%60))
    sleep 1
done
