#!/bin/bash
set -e

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ ! -f /etc/os-release ]; then
    echo "Cannot detect OS: /etc/os-release not found"
    exit 1
fi

. /etc/os-release

echo "Detected OS: $NAME $VERSION_ID"

case "$ID" in
    centos)
        RUN_DIR="CentOS7"
        ;;
    rocky|rhel|almalinux)
        RUN_DIR="Rocky_Linux"
        ;;
    ubuntu)
        RUN_DIR="Ubuntu"
        ;;
    *)
        echo "Unsupported OS: $ID"
        exit 1
        ;;
esac

TARGET_DIR="$BASE_DIR/$RUN_DIR"

if [ ! -d "$TARGET_DIR" ]; then
    echo "Target directory not found: $TARGET_DIR"
    exit 1
fi

echo "Using check scripts in: $TARGET_DIR"
cd "$TARGET_DIR"

chmod +x *.sh

if [ -f "./ALL_system_check.sh" ]; then
    exec ./ALL_system_check.sh
else
    echo "ALL_system_check.sh not found in $TARGET_DIR"
    exit 1
fi
