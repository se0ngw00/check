#!/bin/bash

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
RESULT_DIR="$BASE_DIR/results"
mkdir -p "$RESULT_DIR"

START_TIME=$(date +%s)

TEST_MODE=0
if [[ "${1:-}" == "--test" ]]; then
  TEST_MODE=1
fi

RESULT_PREFIX="rhel_$(date +%Y%m%d-%H%M%S)"
TOTAL_FILE="$RESULT_DIR/${RESULT_PREFIX}.total"
VULN_FILE="$RESULT_DIR/${RESULT_PREFIX}.vuln"

# ====================
# TEST MODE (NO TIMER)
# ====================
if [ "$TEST_MODE" -eq 1 ]; then
  echo "[TEST MODE] result file creation test" > "$TOTAL_FILE"
  echo "[TEST MODE] no vulnerability check performed" > "$VULN_FILE"

  END_TIME=$(date +%s)
  ELAPSED=$((END_TIME - START_TIME))

  echo "Total execution time: ${ELAPSED}s"
  echo "Results:"
  echo "  $TOTAL_FILE"
  echo "  $VULN_FILE"
  exit 0
fi

# ====================
# TIMER (NORMAL MODE)
# ====================
TIMER_RUNNING=1
show_timer() {
  while [ "$TIMER_RUNNING" -eq 1 ]; do
    now=$(date +%s)
    elapsed=$((now - START_TIME))
    printf "\r[Running] Elapsed time: %dm %02ds"       $((elapsed/60)) $((elapsed%60))
    sleep 10
  done
}

cleanup() {
  TIMER_RUNNING=0
  [ -n "${TIMER_PID:-}" ] && kill "$TIMER_PID" 2>/dev/null
  echo
  exit 0
}

trap cleanup INT TERM

show_timer &
TIMER_PID=$!

# OS detection
. /etc/os-release
if [[ "$ID" =~ (centos|rhel|rocky|almalinux) ]]; then
  CHECK_DIR="$BASE_DIR/Rocky_Linux"
else
  CHECK_DIR="$BASE_DIR/Ubuntu"
fi

for f in "$CHECK_DIR"/U-*.sh; do
  id=$(basename "$f" .sh)
  output=$(bash "$f" 2>&1 || true)

  echo "===== $id =====" >> "$TOTAL_FILE"
  echo "$output" >> "$TOTAL_FILE"
  echo >> "$TOTAL_FILE"

  echo "$id REVIEW_REQUIRED" >> "$VULN_FILE"
done

cleanup
