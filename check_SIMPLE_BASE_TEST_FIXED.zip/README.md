# Linux Server Security Check Script

## 실행 방법

./ALL_system_check.sh

## 테스트 모드

./ALL_system_check.sh --test

- 실제 점검 스크립트는 실행하지 않음
- OS 판별, 경로, 결과 파일 생성 여부만 확인

## 결과 파일

results/ 디렉터리에 결과 파일이 생성됨

- *.total : 전체 점검 결과
- *.vuln  : 취약 항목만 추출

## 참고

- OS별로 스크립트가 분리되어 있음
- 실행 방식은 단순하게 유지
- 불필요한 옵션은 제거함
