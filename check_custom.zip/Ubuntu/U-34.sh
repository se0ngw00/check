cat << EOF
===== [U-34] DNS Area Transfer Settings              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-34 DNS Zone Transfer 설정              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 허가되지 않는 사용자에게 Zone Transfer를 제한함으로써 호스트 정보, 시스템 정보 등 정보 유출의 방지를 목적으로 함" >> $target
echo "+보안위협 : 비인가자 Zone Transfer를 이용해 Zone 정보를 전송받아 호스트 정보, 시스템 정보, 네트워크 구성 형태 등의 많은 정보를 파악할 수 있음" >> $target
echo "+판단기준 양호 : DNS 서비스 미사용 또는, Zone Transfer를 허가된 사용자에게만 허용한 경우" >> $target
echo "+판단기준 취약 : DNS 서비스를 사용하며 Zone Transfer를 모든 사용자에게 허용한 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u34=0
u34_Service_Management=0
u34_safe_check=0
u34_services=("named" "dnsmasq" "unbound" "pdns_server" "bind9.service" "pdns_server" "bind9" "dnsmasq.service" "unbound.service" "pdns.service")
u34_ports=("53" "853 " "443")

check_service_status "${u34_ports}" "${u34_services[@]}"
if [[ $? -eq 1 ]]; then
    echo "DNS 서비스를 사용하고 있습니다." >> $target
    if grep -vE "^\s*#" "/etc/bind/named.conf" | grep -qi "allow-transfer";then
        echo "특정 ip에 대해서 Zone Transfer를 허용하도록 설정되어 있습니다." >> $target
        echo "현재 Zone Transfer 설정 값 :$(grep -vE "^\s#" "/etc/bind/named.conf" | grep -i "allow-transfer")" >> $target
    elif grep -vE "^\s*#" "/etc/bind/named.conf" | grep -qi "xfrnets";then
        echo "특정 ip에 대해서 Zone Transfer 허용하도록 설정되어 있습니다." >> $target
        echo "현재 Zone Transfer 설정 값 :$(grep -vE "^\s#" "/etc/bind/named.conf" | grep -i "xfrnets")" >> $target
    else
        echo "allow-transfer 및 xfrnets 옵션이 설정되지 않아 모든 클라이언트가 Zone Transfer를 요청할 수 있습니다" >> $target
        u34=$((u34+1))
    fi
    u34_safe_check=$((u34_safe_check+1))
else
    echo "DNS 서비스를 사용하고 있지 않습니다." >> $target
    if grep -vE "^\s*#" "/etc/bind/named.conf" | grep -qi "allow-transfer";then
        echo "특정 ip에 대해서 Zone Transfer를 허용하도록 설정되어 있습니다." >> $target
        echo "현재 Zone Transfer 설정 값 :$(grep -vE "^\s#" "/etc/bind/named.conf" | grep -i "allow-transfer")" >> $target
    elif grep -vE "^\s*#" "/etc/bind/named.conf" | grep -qi "xfrnets";then
        echo "특정 ip에 대해서 Zone Transfer 허용하도록 설정되어 있습니다." >> $target
        echo "현재 Zone Transfer 설정 값 :$(grep -vE "^\s#" "/etc/bind/named.conf" | grep -i "xfrnets")" >> $target
    else
        echo "allow-transfer 및 xfrnets 옵션이 설정되지 않아 모든 클라이언트가 Zone Transfer를 요청할 수 있습니다" >> $target
        u34_safe_check=$((u34_safe_check+1))
    fi
fi

if [[ $u34_safe_check -ge 1 ]];then
    u34=$((u34+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u34 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u34_Service_Management=1
fi