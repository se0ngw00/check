cat << EOF
===== [U-22] Crond file owner and permission settings              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-22  crond 파일 소유자 및 권한 설정             " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 관리자외 cron 서비스를 사용할 수 없도록 설정하고 있는지 점검하는 것을 목적으로 함" >> $target
echo "+보안위협 : root 외 일반사용자에게도 crontab 명령어를 사용할 수 있도록 할 경우, 고의 또는 실수로 불법적인 예약 파일 실행으로 시스템 피해를 일으킬 수 있음" >> $target
echo "+판단기준 양호 : crontab 명령어 일반사용자 금지 및 cron 관련 파일 640 이하인 경우" >> $target
echo "+판단기준 취약 : crontab 명령어 일반사용자 사용가능하거나, crond 관련 파일 640 이상인 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-21 점검 결과" >> $result
u22_cron_checkfiles=("crontab" "cron.allow" "cron.deny")
u22_cron_checkdirs=("cron.d" "cron.hourly" "cron.daily" "cron.weekly" "cron.monthly")
u22_cron_spools=("/var/spool/cron" "/var/spool/cron/crontabs")
u22=0
u22_Service_Management=0
u22_safe_check=0
# 명령어 출력을 읽어 배열에 저장
u22_crontab_pass_s=($(type -a crontab | sort | uniq))
for u22_crontab_pass in "${u22_crontab_pass_s[@]}";do
    if [ -f "$u22_crontab_pass" ];then
        u22_crontab_perm=$(stat -c "%a" "$u22_crontab_pass" | cut -c1)
        u22_crontab_group=$(stat -c "%a" "$u22_crontab_pass" | cut -c2)
        u22_crontab_other=$(stat -c "%A" "$u22_crontab_pass" | awk '{print substr($1, 8, 3)}')
        u22_crontab_owner=$(stat -c "%U" "$u22_crontab_pass")
        if [[ $u22_crontab_perm -lt 6 && $u22_crontab_group -lt 4 ]];then
            if [[ $u22_crontab_other == "---" ]];then
                if [[ $u22_crontab_owner == "root" ]];then
                    echo "$u22_crontab_pass 파일에 대한 소유자 및 권한 설정이 적절하게 되어 있습니다." >> $target
                else
                    echo "$u22_crontab_pass 파일에 대한 3.5 DoS 공격에 취약한 서비스 비활성화유자가 root 소유자가 아닌 $u22_crontab_owenr로 설정되어 있어 취약합니다." >> $target
                    u22_safe_check=$((u22_safe_check+1))
                fi
            else
                echo "$u22_crontab_pass 파일에 대한 기타 사용자(Other)에 대한 권한이 $u22_crontab_other 설정되어 있어 취약합니다." >> $target
                u22_safe_check=$((u22_safe_check+1))
            fi
        else
            echo "$u22_crontab_pass 파일의 권한이 $u22_crontab_perm 으로 640 이상으로 설정되어 있으며 기타 사용자(Other)에 대한 권한이 설정되어 있어 취약합니다." >> $target
            u22_safe_check=$((u22_safe_check+1))
        fi
    fi
done
for u22_cron_checkfile in "${u22_cron_checkfiles[@]}";do
    if [ -f "/etc/$u22_cron_checkfile" ];then
        u22_crontab_file_perm=$(stat -c "%a" "/etc/$u22_cron_checkfile" | cut -c1)
        u22_crontab_file_group=$(stat -c "%a" "/etc/$u22_cron_checkfile" | cut -c2)
        u22_crontab_file_other=$(stat -c "%A" "/etc/$u22_cron_checkfile" | awk '{print substr($1, 8, 3)}')
        u22_crontab_file_owner=$(stat -c "%U" "/etc/$u22_cron_checkfile")
        if [[ $u22_crontab_file_perm -lt 6 && $u22_crontab_file_group -lt 4 ]];then
            if [[ $u22_crontab_file_other == "---" ]];then
                if [[ $u22_crontab_file_owner == "root" ]];then
                    echo "/etc/$u22_cron_checkfile 파일에 대한 소유자 및 권한 설정이 적절하게 되어 있습니다." >> $target
                else
                    echo "/etc/$u22_cron_checkfile 파일에 대한 소유자가 root 소유자가 아닌 $u22_crontab_file_perm 설정되어 있어 취약합니다." >> $target
                    u22_safe_check=$((u22_safe_check+1))
                fi
            else
                echo "/etc/$u22_cron_checkfile 파일에 대한 기타 사용자(Other)에 대한 권한이 $u22_crontab_file_other 설정되어 있어 취약합니다." >> $target
                u22_safe_check=$((u22_safe_check+1))
            fi
        else
            echo "/etc/$u22_cron_checkfile 파일의 권한이 $u22_crontab_file_perm 으로 640 이상으로 설정되어 있으며 기타 사용자(Other)에 대한 권한이 설정되어 있어 취약합니다." >> $target
            u22_safe_check=$((u22_safe_check+1))
        fi
    else
        echo "/etc/$u22_cron_checkfile 파일이 존재하지 않습니다." >> $target
    fi
done
for u22_cron_checkdir in "${u22_cron_checkdirs[@]}";do
    if [ -d "/etc/$u22_cron_checkdir" ];then
        u22_cron_dirinfiles=($(ls -al "/etc/$u22_cron_checkdir" | awk '{print $9}' | grep -v "^\." | sed '1d'))
        if [ -n "$u22_cron_dirinfiles" ];then
            for u22_cron_dirinfile in "${u22_cron_dirinfiles[@]}";do
                if [ -f "/etc/$u22_cron_checkdir/$u22_cron_dirinfile" ];then
                    u22_crontab_dirf_perm=$(stat -c "%a" "/etc/$u22_cron_checkdir/$u22_cron_dirinfile" | cut -c1)
                    u22_crontab_dirf_group=$(stat -c "%a" "/etc/$u22_cron_checkdir/$u22_cron_dirinfile" | cut -c2)
                    u22_crontab_dirf_other=$(stat -c "%A" "/etc/$u22_cron_checkdir/$u22_cron_dirinfile" | awk '{print substr($1, 8, 3)}')
                    u22_crontab_dirf_owner=$(stat -c "%U" "/etc/$u22_cron_checkdir/$u22_cron_dirinfile")
                    if [[ $u22_crontab_dirf_perm -lt 6 && $u22_crontab_dirf_group -lt 4 ]];then
                        if [[ $u22_crontab_dirf_other == "---" ]];then
                            if [[ $u22_crontab_dirf_owner == "root" ]];then
                                echo "/etc/$u22_cron_checkdir/$u22_cron_dirinfile 파일에 대한 소유자 및 권한 설정이 적절하게 되어 있습니다." >> $target
                            else
                                echo "/etc/$u22_cron_checkdir/$u22_cron_dirinfile 파일에 대한 소유자가 root 소유자가 아닌 $u22_crontab_dirf_perm 설정되어 있어 취약합니다." >> $target
                                u22_safe_check=$((u22_safe_check+1))
                            fi
                        else
                            echo "/etc/$u22_cron_checkdir/$u22_cron_dirinfile 파일에 대한 기타 사용자(Other)에 대한 권한이 $u22_crontab_dirf_other 설정되어 있어 취약합니다." >> $target
                            u22_safe_check=$((u22_safe_check+1))
                        fi
                    else
                        echo "/etc/$u22_cron_checkdir/$u22_cron_dirinfile 파일의 권한이 $u22_crontab_dirf_owner 으로 640 이상으로 설정되어 있으며 기타 사용자(Other)에 대한 권한이 설정되어 있어 취약합니다." >> $target
                        u22_safe_check=$((u22_safe_check+1))
                    fi
                fi
            done
        else
            echo "/etc/$u22_cron_checkdir 디렉터리가 존재하나, 파일은 존재하지 않습니다." >> $target
        fi
    else
        echo "/etc/$u22_cron_checkdir 디렉터리가 존재하지 않습니다." >> $target
    fi
done
for u22_cron_spool in "${u22_cron_spools[@]}";do
    if [ -d "$u22_cron_spool" ];then
        u22_cron_spoolinfiles=($(ls -al $u22_cron_spool | awk '{print $9}' | grep -v "^\." | sed '1d'))
        if [ -n "$u22_cron_spoolinfiles" ];then
            for u22_cron_spoolinfile in "${u22_Cron_spoolinfiles[@]}";do
                if [ -f "$u22_cron_spool/$u22_cron_spoolinfile" ];then
                    u22_crontab_spool_perm=$(stat -c "%a" "$u22_cron_spool/$u22_cron_spoolinfile" | cut -c1)
                    u22_crontab_spool_group=$(stat -c "%a" "$u22_cron_spool/$u22_cron_spoolinfile" | cut -c2)
                    u22_crontab_spool_other=$(stat -c "%A" "$u22_cron_spool/$u22_cron_spoolinfile" | awk '{print substr($1, 8, 3)}')
                    u22_crontab_spool_owner=$(stat -c "%U" "$u22_cron_spool/$u22_cron_spoolinfile")
                    if [[ $u22_crontab_spool_perm -lt 6 && $u22_crontab_spool_group -lt 4 ]];then
                        if [[ $u22_crontab_spool_other == "---" ]];then
                            if [[ $u22_crontab_spool_owner == "root" ]];then
                                echo "$u22_cron_spool/$u22_cron_spoolinfile 파일에 대한 소유자 및 권한 설정이 적절하게 되어 있습니다." >> $target
                            else
                                echo "$u22_cron_spool/$u22_cron_spoolinfile 파일에 대한 소유자가 root 소유자가 아닌 $u22_crontab_spool_perm 설정되어 있어 취약합니다." >> $target
                                u22_safe_check=$((u22_safe_check+1))
                            fi
                        else
                            echo "$u22_cron_spool/$u22_cron_spoolinfile 파일에 대한 기타 사용자(Other)에 대한 권한이 $u22_crontab_spool_other 설정되어 있어 취약합니다." >> $target
                            u22_safe_check=$((u22_safe_check+1))
                        fi
                    else
                        echo "$u22_cron_spool/$u22_cron_spoolinfile 파일의 권한이 $u22_crontab_spool_owner 으로 640 이상으로 설정되어 있으며 기타 사용자(Other)에 대한 권한이 설정되어 있어 취약합니다." >> $target
                        u22_safe_check=$((u22_safe_check+1))
                    fi
                fi
            done
        else
            echo "$u22_cron_spool 디렉터리가 존재하나 파일은 존재하지 않습니다." >> $target
        fi
    else
        echo "$u22_cron_spool 디렉터리가 존재하지 않습니다." >> $target
    fi
done

if [[ $u22_safe_check -ge 1 ]];then
    u22=$((u22+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u22 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u22_Service_Management=1
fi