# Linux Server Security Check Script

## 개요
이 스크립트는 Linux 서버의 OS 보안 설정을 점검하기 위한 도구입니다.
서버 OS(CentOS, Rocky Linux, Ubuntu)를 자동으로 판별하여
해당 OS에 맞는 보안 점검 스크립트를 실행합니다.

--------------------------------------------------------------------------------

## 디렉터리 구조

/opt/check 기준

├─ ALL_system_check.sh
├─ CentOS7/
├─ Rocky_Linux/
├─ Ubuntu/
├─ results/
└─ README.md

- 상위 ALL_system_check.sh : 실행 진입점
- OS 디렉터리 : OS별 실제 점검 스크립트
- results/ : 점검 결과 저장 위치

--------------------------------------------------------------------------------

## 실행 방법

./ALL_system_check.sh

### 테스트 모드
./ALL_system_check.sh --test
