#!/bin/bash
set -e

TOTAL_FILE="$RESULT_DIR/${RESULT_PREFIX}.total"
VULN_FILE="$RESULT_DIR/${RESULT_PREFIX}.vuln"

export target="$TOTAL_FILE"
export result="$VULN_FILE"

> "$TOTAL_FILE"
> "$VULN_FILE"


if [ "$MODE" = "safe" ]; then
  elif [ "$MODE" = "fast" ]; then
  fi

if [ "$TEST_MODE" = "1" ]; then
  echo "[TEST MODE] OK" >> "$target"
else
  for s in U-[0-9][0-9].sh; do
  bash "$s"
done >> "$target" 2>/dev/null
fi

grep "취약" "$TOTAL_FILE" > "$VULN_FILE" || true

rm -f "${target}-F:" 2>/dev/null
rm -f "${result}-F:" 2>/dev/null
