#!/bin/bash
set -e

TOTAL_FILE="$RESULT_DIR/${RESULT_PREFIX}.total"
VULN_FILE="$RESULT_DIR/${RESULT_PREFIX}.vuln"

export target="$TOTAL_FILE"
export result="$VULN_FILE"

> "$TOTAL_FILE"
> "$VULN_FILE"

if [ "$TEST_MODE" = "1" ]; then
  echo "[TEST MODE] OK" >> "$target"
else
  ls U-[0-9][0-9].sh | xargs -n 1 -P 4 bash >> "$target" 2>/dev/null
fi

grep "취약" "$TOTAL_FILE" > "$VULN_FILE" || true

# 레거시 -F: 파일 정리
rm -f "${target}-F:" 2>/dev/null
rm -f "${result}-F:" 2>/dev/null
