#!/bin/bash
set -uo pipefail

START_TIME=$SECONDS
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
RESULT_DIR="$BASE_DIR/results"
mkdir -p "$RESULT_DIR"

TEST_MODE=0
if [[ "${1:-}" == "--test" ]]; then
  TEST_MODE=1
fi

RESULT_PREFIX="$(date +%Y%m%d-%H%M%S)"
TOTAL_FILE="$RESULT_DIR/${RESULT_PREFIX}.total"
VULN_FILE="$RESULT_DIR/${RESULT_PREFIX}.vuln"

# TEST MODE: only create result files and exit fast
if [ "$TEST_MODE" -eq 1 ]; then
  echo "[TEST MODE] Result file generation test" > "$TOTAL_FILE"
  echo "[TEST MODE] No vulnerabilities detected" > "$VULN_FILE"
  echo "Results:"
  echo "  $TOTAL_FILE"
  echo "  $VULN_FILE"
  exit 0
fi

# Timer
TIMER_RUNNING=1
show_timer() {
  while [ "$TIMER_RUNNING" -eq 1 ]; do
    elapsed=$((SECONDS - START_TIME))
    printf "\r[Running] Elapsed time: %dm %02ds" $((elapsed/60)) $((elapsed%60))
    sleep 1
  done
}
cleanup() {
  TIMER_RUNNING=0
  [ -n "${TIMER_PID:-}" ] && kill "$TIMER_PID" 2>/dev/null
  echo
}
trap cleanup INT TERM
show_timer &
TIMER_PID=$!

# OS detection
. /etc/os-release
if [[ "$ID" =~ (centos|rhel|rocky|almalinux) ]]; then
  CHECK_DIR="$BASE_DIR/checks/rhel"
else
  CHECK_DIR="$BASE_DIR/checks/ubuntu"
fi

TMP_OUT="$RESULT_DIR/.tmp_${RESULT_PREFIX}"
mkdir -p "$TMP_OUT"

# Parallel execution (4 jobs)
export TMP_OUT
run_check() {
  f="$1"
  id="$(basename "$f" .sh)"
  out="$TMP_OUT/${id}.out"
  bash "$f" > "$out" 2>&1 || true
  echo "$id REVIEW_REQUIRED" >> "$TMP_OUT/vuln.list"
}
export -f run_check

find "$CHECK_DIR" -name 'U-*.sh' ! -name 'U-TEST.sh' | sort | xargs -n 1 -P 4 -I {} bash -c 'run_check "$@"' _ {}

# Merge results
for f in "$TMP_OUT"/*.out; do
  id="$(basename "$f" .out)"
  echo "===== $id =====" >> "$TOTAL_FILE"
  cat "$f" >> "$TOTAL_FILE"
  echo >> "$TOTAL_FILE"
done

sort -u "$TMP_OUT/vuln.list" > "$VULN_FILE"

rm -rf "$TMP_OUT"

elapsed=$((SECONDS - START_TIME))
echo
echo "Total execution time: $((elapsed/60))m $((elapsed%60))s"
echo "Results:"
echo "  $TOTAL_FILE"
echo "  $VULN_FILE"
