#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-31] Spam mail relay restrictions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-31 스팸 메일 릴레이 제한              " >> "$target"
echo "--------------------------------------------------------------------------" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "+점검목적 : 스팸 메일 서버로의 악용방지 및 서버 과부하의 방지를 위함" >> "$target"
echo "+보안위협 : SMTP 서버의 릴레이 기능을 제한하지 않는 경우, 악의적인 사용목적을 가진 사용자들이 스팸메일 서버로 사용하거나 Dos공격의 대상이 될 수 있음" >> "$target"
echo "+판단기준 양호 : SMTP 서비스를 사용하지 않거나 릴레이 제한이 설정되어 있는 경우" >> "$target"
echo "+판단기준 취약 : SMTP 서비스를 사용하며 릴레이 제한이 설정되어 있지 않은 경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
u31=0
u31_Service_Management=0
u31_safe_check=0
u31_service=("sendmail" "postfix" "exim" "sendmail.service" "postfix.service" "exim.service")
u31_ports=("25" "465" "587")
u31_logic() {
    if [ -f "/etc/mail/sendmail.cf" ];then
        echo "/etc/mail/sendmail.cf 파일이 존재합니다." >> "$target"
        if grep -iv "^\s*#" "/etc/mail/sendmail.cf" | grep -iqE 'R\$\*\s*\$:\s*\$1\s*RELAY';then
            echo "모든 조건에서 모든 릴레이를 허용하는 규칙이 정의되어 있습니다." >> "$target"
            u31_safe_check=$((u31_safe_check+1))
        elif grep -ivE "^\s*#" "/etc/mail/sendmail.cf" | grep -iE 'R\$\s*' | grep -iqE '\$@\s*5\.7\.1|(Relaying|Relay?ing)\s*(denie?d|denied)';then
            echo "릴레이를 제한하는 규칙이 정의되어 있습니다." >> "$target"
        else
            echo "/etc/mail/sendmail.cf 파일 내에서 모든 조건에서 모든 릴레이를 허용하는 규칙 및 릴레이를 제한하는 규칙이 존재하지 않습니다." >> "$target"
        fi
    else
        echo "/etc/mail/sendmail.cf 파일이 존재하지 않습니다." >> "$target"
    fi
    if [ -f "/etc/mail/access" ];then
        echo "/etc/mail/access 파일이 존재합니다." >> "$target"
        if grep -vE "^\s*#" "/etc/mail/access" | grep -iqE "\s*Connect:ALL\s*RELAY";then
            echo "모든 연결에 대한 릴레이 설정이 존재합니다." >> "$target"
            u31_safe_check=$((u31_safe_check+1))
        else
            if grep -vE "^\s*#" "/etc/mail/access" | grep -iE "relay$" | awk '{print $1}' | awk -F':' '{print $2}' | grep -ivqE "localhost.localdomain|localhost|127.0.0.1|127|IPv6:::1|IPv6";then
                echo "localhost를 제외한 IP, domain, Email Address에 대한 릴레이 허용 설정값이 존재합니다."  >> "$target"
            else
                echo "localhost를 제외한 IP, domain, Email Address에 대한 릴레이 허용을 제외한 설정값이 존재하지 않습니다." >> "$target"
            fi
        fi
    else
        echo "/etc/mail/access 파일이 존재하지 않습니다." >> "$target"
    fi
}

check_service_status "${u31_ports}" "${u31_service[@]}"
if [[ $? -eq 1 ]]; then
    echo "sendmail 서비스를 사용하고 있습니다." >> "$target"
    u31_logic
    u31_safe_check=$((u31_safe_check+1))
else
    echo "sendmail 서비스를 사용하고 있지 않습니다." >> "$target"
    u31_logic
fi

if [[ $u31_safe_check -ge 1 ]];then
    u31=$((u31+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi
if [[ $u31 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u31_Service_Management=1
fi