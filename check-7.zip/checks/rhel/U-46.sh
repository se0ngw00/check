#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-46] Set password minimum length              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-46 패스워드 최소 길이 설정              " >> "$target"
echo "--------------------------------------------------------------------------" >> "$target"-F: '{print $4}'
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "점검목적 : 패스워드 최소 길이 설정이 적용되어 있는지 점검하여 짧은(8자 미만) 패스워드 길이로 발생하는 취약점을 이용한 공격(무작위 대입 공격, 사전 대입 공격 등)에 대한 대비(사용자 패스워드 유출)가 되어 있는지 확인하기 위함" >> "$target"
echo "보안위협 : 패스워드 문자열이 짧은 경우 유추가 가능 할 수 있으며 암호화된 패스워드 해시값을 무작위 대입공격, 사전대입 공격 등으로 단시간에 패스워드 크렉이 가능함" >> "$target"
echo "+판단기준 양호 : 패스워드 최소 길이가 8자 이상으로 설정되어 있는 경우 " >> "$target"
echo "+판단기준 취약 : 패스워드 최소 길이가 8자 미만으로 설정되어 있는 경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
u46_Account_Management=0
u46_safe_check=0
u46=0
if [ -f "/etc/pamd.d/system-auth" ];then
    u46_systemauth_min=$(grep -v "^\s*#" "/etc/pam.d/system-auth" | grep -iE "^\s*password" | grep -i "min|minlen" | grep -oP 'min=\K\d+|minlen=\K\d+')
    if [ -n "$u46_systemauth_min" ];then
        echo "/etc/pam.d/system-auth 파일내에 패스워드 최소 길이 옵션값이 존재합니다." >> "$target"
        if [ $u46_systemauth_min -gt 90 ];then
            echo "패스워드 최소 길이 설정이 90 이상으로 부적절하게 설정되어 있습니다." >> "$target"
            echo "현재 설정 값 : $u46_systemauth_min" >> "$target"
            u46_safe_check=$((u46_safe_check+1)) 
        else
            echo "패스워드 최소 길이 설정이 90 이하로 적절하게 설정되어 있습니다." >> "$target"
        fi
    else
        echo ""/etc/pam.d/system-auth 파일내에 패스워드 최소 길이 옵션값이 존재하지 않습니다."" >> "$target"
    fi
fi
if [ -f "/etc/security/pwquality.conf" ];then
    echo "패스워드 최소길이 설정파일인 /etc/security/pwquality.conf 파일이 존재합니다." >> "$target"
    u46_pwqualuty_passlen=$(grep -v "^\s*#" "/etc/security/pwquality.conf" | grep -i "minlen" | awk -F= '{print $2}' | tr -d ' ')
    if [ -n "$u46_pwqualuty_passlen" ];then
        if [ $u46_pwqualuty_passlen -lt 8 ];then
            echo "패스워드 최소 길이가 8미만으로 부적절하게 설정되어 있습니다." >> "$target"
            echo "현재 설정 값 : $u46_pwqualuty_passlen" >> "$target"
            u46_safe_check=$((u46_safe_check+1)) 
        else
            echo "패스워드 최소 길이가 8이상으로 적절하게 설정되어 있습니다." >> "$target"
        fi
    else
        echo "/etc/security/pwquality.conf 파일은 조재하지만 관련 설정값이 존재하지 않습니다." >> "$target"
    fi
else
    echo "패스워드 최소길이 설정파일인 /etc/security/pwquality.conf 파일이 존재하지 않습니다." >> "$target"
fi
if [ -f "/etc/login.defs" ];then
    echo "패스워드 최소길이 설정파일인 /etc/login.defs 파일이 존재합니다.">> "$target"
    u46_logindefs_passlen=$(grep -v "^\s*#" "/etc/login.defs" | grep -i "pass_min_len" | awk '{print $2}')
    if [ -n "$u46_logindefs_passlen" ];then
        if [ $u46_logindefs_passlen -lt 8 ];then
            echo "패스워드 최소 길이가 8미만으로 부적절하게 설정되어 있습니다." >> "$target"
            echo "현재 설정 값 : $u46_logindefs_passlen" >> "$target"
            u46_safe_check=$((u46_safe_check+1)) 
        else
            echo "패스워드 최소 길이가 8이상으로 적절하게 설정되어 있습니다." >> "$target"
        fi
    else
        echo "/etc/login.defs 파일은 조재하지만 관련 설정값이 존재하지 않습니다." >> "$target"
        u46_safe_check=$((u46_safe_check+1)) 
    fi
else
    echo "패스워드 최소길이 설정파일인 /etc/login.defs 파일이 존재하지 않습니다." >> "$target"
fi
if [ $u46_safe_check -ge 1 ];then
    u46=$((u46+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi
if [[ $u46 -ge 1 ]];then
    Mid=$((Mid+1))
    Account_Management=$((Account_Management+1))
    u46_Account_Management=1
fi