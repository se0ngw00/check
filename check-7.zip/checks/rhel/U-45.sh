#!/bin/bash

# === AUTO FIX: output file definitions ===
ID="$(basename "$0" .sh)"
TMP_DIR="/tmp/check"
mkdir -p "$TMP_DIR"
target="$TMP_DIR/${ID}.tmp"
result="$TMP_DIR/${ID}.result"

cat << EOF
===== [U-45] Restrict root account su              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$target"
echo "                        U-45 root 계정 su 제한              " >> "$target"
echo "--------------------------------------------------------------------------" >> "$target"-F: '{print $4}'
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "+점검목적 : su 관련 그룹만 su 명령어 사용 권한이 부여되어 있는지 점검하여 su 그룹에 포함되지 않은 일반 사용자의 su 명령 사용을 원천적으로 차단하는지 확인하기 위함" >> "$target"
echo "보안위협 : 무분별한 사용자 변경으로 타 사용자 소유의 파일을 변경 할 수 있으며root 계정으로 변경하는 경우 관리자 권한을 획득 할 수 있음" >> "$target"
echo "※ 일반사용자 계정 없이 root 계정만 사용하는 경우 su 명령어 사용제한 불필요" >> "$target"
echo "+판단기준 양호 : su 명령어를 특정 그룹에 속한 사용자만 사용하도록 제한되어 있는 경우" >> "$target"
echo "+판단기준 취약 : su 명령어를 모든 사용자가 사용하도록 설정되어 있는 경우" >> "$target"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$target"
echo "" >> "$target"
u45_Account_Management=0
u45_safe_check=0
u45=0
u45_wheel_check=$(grep -i "wheel" "/etc/passwd" | awk '{print $1}')
u45_whell_group=$(grep -i "wheel" "/etc/group" | awk -F: '{print $4}')
u45_su_perm=$(stat -c "%a" /usr/bin/su)
u45_su_perm_other=$(stat -c "%A" /usr/bin/su | rev | cut -c 1-3 | rev)
if [ -n "$u45_wheel_check" ];then
    echo "$u45_wheel_check 계정이 존재합니다." >> "$target"
    if grep -i "wheel" "/etc/group";then
        if [ -n "$u45_whell_group" ];then
            echo "$u45_whell_group 계정들이 wheel 그룹에 속해있습니다." >> "$target"
        else
            echo "wheel 그룹의 포함된 계정이 존재하지 않습니다." >> "$target"
            u45_safe_check=$((u45_safe_check+1))
        fi
    fi
else
    echo "wheel 계정이 존재하지 않습니다." >> "$target"
    u45_safe_check=$((u45_safe_check+1))
fi

if [[ $u45_su_perm -eq 4750 && "$u45_su_perm_other" == "---" ]];then
    echo "/usr/bin/su 파일의 권한이 적절하게 설정되어 있습니다." >> "$target"
else
    echo "/usr/bin/su 파일의 권한이 $(stat -c "%A" /usr/bin/su) 로 적절하지 않게 설정되어 있습니다." >> "$target"
    u45_safe_check=$((u45_safe_check+1))
fi

if [ -f "/etc/pam.d/su" ];then
    u45_pam=$(grep -v "#" "/etc/pam.d/su" | grep auth | grep required | grep pam_wheel.so | egrep -E "use_uid|debug\s*group=wheel")
    if [ -n "$u45_pam" ];then
        echo "/etc/pam.d/su 파일 내에 pam_wheel.so 모듈을 사용하여 wheel 그룹의 사용자들만 su 명령을 사용할 수 있게 제한하고 있습니다." >> "$target"
    else
        echo "/etc/pam.d/su 파일 내에 whell 그룹의 사용자들만 su명령을 사용하도록 하는 설정값이 존재하지 않습니다." >> "$target"
        u45_safe_check=$((u45_safe_check+1))
    fi
else
    echo "/etc/pam.d/su 파일이 존재하지 않습니다." >> "$target"
fi

if [ $u45_safe_check -ge 1 ];then
    u45=$((u45+1))
    echo "점검 결과 : 취약" >> "$result"
else
    echo "점검 결과 : 양호" >> "$result"
fi
if [[ $u45 -ge 1 ]];then
    Low=$((Low+1))
    Account_Management=$((Account_Management+1))
    u45_Account_Management=1
fi