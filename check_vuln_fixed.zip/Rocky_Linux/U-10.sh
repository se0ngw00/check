cat << EOF
===== [U-10] /etc/(x)inetd.conf file owner and permission settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-10   /etc/(x)inetd.conf 파일 소유자 및 권한 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : /etc/(x)inetd.conf 파일을 관리자만 제어할 수 있게 하여 비인가자들의 임의적인 파일 변조를 방지하기 위함" >> $target
echo "보안위협 : (x)inetd.conf 파일에 소유자외 쓰기 권한이 부여된 경우, 일반사용자 권한으로 (x)inetd.conf 파일에 등록된 서비스를 변조하거나 악의적인 프로그램(서비스)를 등록할 수 있음" >> $target
echo "+판단기준 양호 : /etc/inetd.conf 파일의 소유자가 root이고, 권한이 600인 경우" >> $target
echo "+판단기준 취약 : /etc/inetd.conf 파일의 소유자가 root가 아니거나, 권한이 600이 아닌 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-10 점검 결과" >> $result
u10=0
u10_x_inetd_confs=("/etc/inetd.conf" "/etc/xinetd.conf")
u10_safe_check=0
u10_Files_Directory_Management=0
for u10_x_inetd_conf in "${u10_x_inetd_confs[@]}";do
    if [[ -e "$u10_x_inetd_conf" ]];then
        echo "$u10_x_inetd_conf 파일이 존재합니다."
        u10_file_owner_user=$(stat -c "%U" "$u10_x_inetd_conf" 2> /dev/null)
        u10_file_owner=$(stat -c "%a" "$u10_x_inetd_conf"  2> /dev/null| cut -c1)
        u10_file_group=$(stat -c "%a" "$u10_x_inetd_conf"  2> /dev/null| cut -c2)
        u10_file_other=$(stat -c "%a" "$u10_x_inetd_conf"  2> /dev/null| cut -c3)
        u10_check_suid=$(stat -c "%a" "$u10_x_inetd_conf"  2> /dev/null| tr -d '\n' | wc -c)
        if [[ $u10_check_suid -ge 4 ]];then
            echo "$u10_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> $target
            u10_safe_check=$((u10_safe_check+1))
        else
            if [[ "$u10_file_owner_user" == "root" ]];then
                echo "/etc/hosts 파일의 소유자가 root로 적절하게 설정되어 있습니다."
                if [ $u10_file_owner -eq 6 ];then
                    echo "$u10_x_inetd_conf 파일의 소유 권한이 6으로 설정되어 있습니다." >> $target
                    if [ $u10_file_group -eq 0 ];then
                        echo "$u10_x_inetd_conf 파일의 소유 그룹 권한이 0으로 설정되어 있습니다." >> $target
                        if [ $u10_file_other -eq 0 ];then
                            echo "$u10_x_inetd_conf 파일의 기타 사용자(Other) 권한이 0으로 설정되어 있습니다." >> $target
                        else
                            echo "$u10_x_inetd_conf 파일의 기타 사용자(Other) 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                            u10_safe_check=$((u10_safe_check+1))
                        fi
                    else
                        ehco "$u10_x_inetd_conf 파일의 소유 그룹 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                        u10_safe_check=$((u10_safe_check+1))
                    fi
                else
                    echo "$u10_x_inetd_conf 파일의 소유 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                    u10_safe_check=$((u10_safe_check+1)) >> $target
                fi
            else
                echo "/etc/hosts 파일의 소유자가 root가 아닌 다른 사용자로 설정되어 있습니다."
                u10_safe_check=$((u10_safe_check+1))
            fi
        fi
    else
        echo "$u10_x_inetd_conf 파일이 존재하지 않습니다." >> $target
    fi
done

if [[ -d "/etc/xinetd.d" ]]; then
    for u10_xinetd_file in /etc/xinetd.d/*; do
        if [[ -f $u10_xinetd_file ]]; then
            echo "$u10_xinetd_file 이 존재합니다."
            u10_file_owner_user=$(stat -c "%U" "$u10_xinetd_file" 2> /dev/null)
            u10_file_owner=$(stat -c "%a" "$u10_xinetd_file"  2> /dev/null| cut -c1)
            u10_file_group=$(stat -c "%a" "$u10_xinetd_file"  2> /dev/null| cut -c2)
            u10_file_other=$(stat -c "%a" "$u10_xinetd_file"  2> /dev/null| cut -c3)
            u10_check_suid=$(stat -c "%a" "$u10_xinetd_file"  2> /dev/null| tr -d '\n' | wc -c)
            if [[ $u10_check_suid -ge 4 ]];then
                echo "$u10_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> $target
                u10_safe_check=$((u10_safe_check+1))
            else
                if [[ "$u10_file_owner_user" == "root" ]];then
                    echo "$u10_xinetd_file 파일의 소유자가 root로 적절하게 설정되어 있습니다." >> $target
                    if [ $u10_file_owner -le 6 ];then
                        echo "$u10_xinetd_file 파일의 소유 권한이 6으로 설정되어 있습니다." >> $target
                        if [ $u10_file_group -le 0 ];then
                            echo "$u10_xinetd_file 파일의 소유 그룹 권한이 0으로 설정되어 있습니다." >> $target
                            if [ $u10_file_other -eq 0 ];then
                                echo "$u10_xinetd_file 파일의 기타 사용자(Other) 권한이 0으로 설정되어 있습니다." >> $target
                            else
                                echo "$u10_xinetd_file 파일의 기타 사용자(Other) 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                                u10_safe_check=$((u10_safe_check+1))
                            fi
                        else
                            ehco "$u10_xinetd_file 파일의 소유 그룹 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                            u10_safe_check=$((u10_safe_check+1))
                        fi
                    else
                        echo "$u10_xinetd_file 파일의 소유 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                        u10_safe_check=$((u10_safe_check+1)) 
                    fi
                else
                    echo "$u10_xinetd_file 파일의 소유자가 root가 아닌 다른 사용자로 설정되어 있습니다." >> $target
                    u10_safe_check=$((u10_safe_check+1))
                fi 
            fi
        fi
    done
else
    echo "/etc/xinetd.d 디렉터리가 존재하지 않거나, 해당 디렉터리 내에 파일이 존재하지 않습니다."  >> $target
fi

if [[ $u10_safe_check -ge 1 ]];then
    u10=$((u10+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u10 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u10_Files_Directory_Management=1
fi