#!/bin/bash
CHECK_TMP="${CHECK_TMP:-/tmp/check_tmp}"
mkdir -p "$CHECK_TMP"
TARGET_FILE="${TARGET_FILE:-$CHECK_TMP/U-55.tmp}"
RESULT_FILE="${RESULT_FILE:-$CHECK_TMP/U-55.result}"

cat << EOF
===== [U-55] hosts.lpd file owner and permission settings              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "                        U-55 hosts.lpd 파일 소유자 및 권한 설정             " >> "$TARGET_FILE"
echo "--------------------------------------------------------------------------"  >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "점검목적 : 비인가자의 임의적인 hosts.lpd 변조를 막기 위해 hosts.lpd 파일 삭제 또는 소유자 및 권한 관리를 해야 함" >> "$TARGET_FILE"
echo "보안위협 : hosts.lpd 파일의 접근권한이 적절하지 않을 경우 비인가자가 /etc/hosts.lpd 파일을 수정하여 허용된 사용자의 서비스를 방해할 수 있으며, 호스트 정보를 획득 할 수 있음" >> "$TARGET_FILE"
echo "+판단기준 양호 : hosts.lpd 파일이 삭제되어 있거나 불가피하게 hosts.lpd 파일을 사용할 시 파일의 소유자가 root이고 권한이 600인 경우" >> "$TARGET_FILE"
echo "+판단기준 취약 : hosts.lpd 파일이 삭제되어 있지 않거나 파일의 소유자가 root가 아니고 권한이 600이 아닌 경우" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "" >> "$TARGET_FILE"
u55=0
u55_Files_Directory_Management=0
u55_safe_check=0
if [[ -e "/etc/hosts.lpd" ]];then
    echo "/etc/hosts.lpd 파일이 존재합니다." >> "$TARGET_FILE"
    u55_hostsfile_owner=$(stat -c "%U" "/etc/hosts.lpd")
    u55_hostsfile_perm=$(stat -c "%a" "/etc/hosts.lpd")
    if [[ $shadowfile_owner == "root" ]];then
        if [[ $shadowfile_perm -eq 600 ]];then
            echo "/etc/hosts.lpd 파일 소유자가 root 이며, 권한이 600 으로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
            echo "현재 설정 값 : $shadowfile_perm" >> "$TARGET_FILE"
        else
            echo "/etc/hosts.lpd 파일 권한이 600이 아닌 값으로 설정되어 취약합니다. " >> "$TARGET_FILE"
            echo "현재 설정 값 : $shadowfile_perm" >> "$TARGET_FILE"
            u55_safe_check=$((u55_safe_check+1))
        fi
    else
        echo "/etc/hosts.lpd 파일 소유자가 root 사용자가 아니므로 취약합니다."  >> "$TARGET_FILE"
        echo "현재 설정 값 : $shadowfile_owner" >> "$TARGET_FILE"
        u55_safe_check=$((u55_safe_check+1))
    fi
else
    echo "/etc/hosts.lpd 파일이 존재하지 않습니다." >> "$TARGET_FILE"
fi

if [[ $u55_safe_check -ge 1 ]];then
    u55=$((u55+1))
    echo "점검 결과 : 취약" >> "$RESULT_FILE"
else
    echo "점검 결과 : 양호" >> "$RESULT_FILE"
fi
if [[ $u55 -ge 1 ]];then
    Low=$((Low+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u55_Files_Directory_Management=1
fi