#!/bin/bash
CHECK_TMP="${CHECK_TMP:-/tmp/check_tmp}"
mkdir -p "$CHECK_TMP"
TARGET_FILE="${TARGET_FILE:-$CHECK_TMP/U-13.tmp}"
RESULT_FILE="${RESULT_FILE:-$CHECK_TMP/U-13.result}"

cat << EOF
===== [U-13] Check SUID, SGID, settings file               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "                        U-13   SUID, SGID, 설정 파일점검                        " >> "$TARGET_FILE"
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "점검목적 : 불필요한 SUID, SGID 설정 제거로 악의적인 사용자의 권한상승을 방지하기 위함" >> "$TARGET_FILE"
echo "보안위협 : SUID, SGID 파일의 접근권한이 적절하지 않을 경우 SUID, SGID 설정된 파일로 특정 명령어를 실행하여 root 권한 획득 가능함" >> "$TARGET_FILE"
echo "+판단기준 양호 : 주요 실행파일의 권한에 SUID와 SGID에 대한 설정이 부여되어 있지 않은 경우" >> "$TARGET_FILE"
echo "+판단기준 취약 : 주요 실행파일의 권한에 SUID와 SGID에 대한 설정이 부여되어 있는 경우" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "" >> "$TARGET_FILE"
echo "-------------" >> "$RESULT_FILE"
echo "U-13 점검 결과" >> "$RESULT_FILE"
u13=0
u13_Files_Directory_Management=0
u13_safe_check=0

u13_default_sugid_files=(
    "/usr/bin/fusermount"
    "/usr/bin/wall"
    "/usr/bin/ksu"
    "/usr/bin/chfn"
    "/usr/bin/chsh"
    "/usr/bin/passwd"
    "/usr/bin/su"
    "/usr/bin/chfn"
    "/usr/bin/chage"
    "/usr/bin/gpasswd"
    "/usr/bin/newgrp"
    "/usr/bin/mount"
    "/usr/bin/pkexec"
    "/usr/bin/umount"
    "/usr/bin/write"
    "/usr/bin/ssh-agent"
    "/usr/bin/crontab"
    "/usr/bin/Xorg"
    "/usr/bin/cgclassify"
    "/usr/bin/cgexec"
    "/usr/bin/at"
    "/usr/bin/sudo"
    "/usr/bin/locate"
    "/usr/bin/staprun"
    "/usr/sbin/unix_chkpwd"
    "/usr/sbin/pam_timestamp_check"
    "/usr/sbin/netreport"
    "/usr/sbin/usernetctl"
    "/usr/sbin/lockdev"
    "/usr/sbin/userhelper"
    "/usr/sbin/mount.nfs"
    "/usr/sbin/postdrop"
    "/usr/sbin/postqueue"
    "/usr/lib/polkit-1/polkit-agent-helper-1"
    "/usr/lib64/vte-2.91/gnome-pty-helper"
    "/usr/share/code/chrome-sandbox"
    "/usr/libexec/utempter/utempter"
    "/usr/libexec/qemu-bridge-helper"
    "/usr/libexec/sssd/krb5_child"
    "/usr/libexec/sssd/ldap_child"
    "/usr/libexec/sssd/selinux_child"
    "/usr/libexec/sssd/proxy_child"
    "/usr/libexec/dbus-1/dbus-daemon-launch-helper"
    "/usr/libexec/flatpak-bwrap"
    "/usr/libexec/openssh/ssh-keysign"
    "/usr/libexec/spice-gtk-x86_64/spice-client-glib-usb-acl-helper"
)

u13_check_sugid_files=(
    "/sbin/dump" 
    "/sbin/restore" 
    "/sbin/unix_chkpwd" 
    "/usr/bin/at" 
    "/usr/bin/lpq" 
    "/usr/bin/lpq-lpd" 
    "/usr/bin/lpr" 
    "/usr/bin/lpr-lpd" 
    "/usr/bin/lprm" 
    "/usr/bin/lprm-lpd" 
    "/usr/bin/newgrp" 
    "/usr/sbin/lpc" 
    "/usr/sbin/lpc-lpd" 
    "/usr/sbin/traceroute"
)
echo -e "${RED}Rocky Linux8 시스템의 기본적으로 설정된 SUID, SGID 파일을 제외한 잘못된 SUID, SGID 설정 파일들을 확인합니다.${NC}"  >> "$TARGET_FILE"
# 결과를 저장할 배열
u13_questionable_files=()

# `find` 명령어의 결과를 배열로 저장합니다.
mapfile -t u13_find_results < <(find / -xdev -user root -type f \( -perm -04000 -o -perm -02000 \) 2>/dev/null)

# 각 파일에 대해 제외할 목록과 비교하여 중복을 처리합니다.
for u13_find_result in "${u13_find_results[@]}"; do
    u13_exclude=0
    for u13_exclude_file in "${u13_default_sugid_files[@]}"; do
        if [[ "$u13_find_result" == "$u13_exclude_file" ]]; then
            u13_exclude=1
            break
        fi
    done
    
    # 중복되지 않거나 제외 목록에 포함되지 않는 경우 배열에 추가
    if [[ $u13_exclude -eq 0 ]]; then
        # 배열에 추가하기 전에 중복 확인
        if [[ ! " ${u13_questionable_files[@]} " =~ " ${u13_find_result} " ]]; then
            u13_questionable_files+=("$u13_find_result")
        fi
    fi
done

if [[ ${#u13_questionable_files[@]} -gt 0 ]]; then
    u13_safe_check=$((u13_safe_check+1))
    echo "다음 파일들은 제외 목록에 없거나 중복되지 않으며, 의심스러운 SUID, SGID가 설정됭어 있습니다." >> "$TARGET_FILE"
    for u13_questionable_file in "${u13_questionable_files[@]}"; do
        echo "$u13_questionable_file" >> "$TARGET_FILE"
    done
else
    echo "제외 목록에 포함되지 않는 파일이 없습니다." >> "$TARGET_FILE"
fi

echo -e "${RED}Check-List 기반의 불필요한 SUID/SGID 설정 파일 목록을 점검합니다.${NC}" >> "$TARGET_FILE"
for u13_check_sugid_file in "${u13_check_sugid_files[@]}";do
    u13_chekc_perm=$(stat -c "%A" "$u13_check_sugid_file" 2> /dev/null )
    if [[ $u13_chekc_perm == *s* || $u13_chekc_perm == *S* ]];then
        echo "$u13_check_sugid_file 파일에 불필요한 SUID/SGID 가 설정되어 있습니다." >> "$TARGET_FILE"
        u13_safe_check=$((u13_safe_check+1))
    fi
done

if [[ $u13_safe_check -ge 1 ]];then
    u13=$((u13+1))
    echo "점검 결과 : 취약" >> "$RESULT_FILE"
else
    echo "점검 결과 : 양호" >> "$RESULT_FILE"
fi
if [[ $u13 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u13_Files_Directory_Management=1
fi