#!/bin/bash
CHECK_TMP="${CHECK_TMP:-/tmp/check_tmp}"
mkdir -p "$CHECK_TMP"
TARGET_FILE="${TARGET_FILE:-$CHECK_TMP/U-TEST.tmp}"
RESULT_FILE="${RESULT_FILE:-$CHECK_TMP/U-TEST.result}"

echo "[TEST MODE] OK" >> "$target"