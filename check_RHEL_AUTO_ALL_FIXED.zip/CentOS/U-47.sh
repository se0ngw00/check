#!/bin/bash
CHECK_TMP="${CHECK_TMP:-/tmp/check_tmp}"
mkdir -p "$CHECK_TMP"
TARGET_FILE="${TARGET_FILE:-$CHECK_TMP/U-47.tmp}"
RESULT_FILE="${RESULT_FILE:-$CHECK_TMP/U-47.result}"

cat << EOF
===== [U-47] Setting the password maximum usage period              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "                        U-47 패스워드 최대 사용기간 설정              " >> "$TARGET_FILE"
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "점검목적 : 패스워드 최대 사용 기간 설정이 적용되어 있는지 점검하여 시스템 정책에서 사용자 계정의 장기간 패스워드 사용을 방지하고 있는지 확인하기 위함" >> "$TARGET_FILE"
echo "보안위협 : 패스워드 최대 사용기간을 설정하지 않은 경우 비인가자의 각종 공격(무작위 대입 공격, 사전 대입 공격 등)을 시도할 수 있는 기간 제한이 없으므로 공격자 입장에서는 장기적인 공격을 시행할 수 있어 시행한 기간에 비례하여 사용자 패스워드가 유출될 수 있는 확률이 증가함" >> "$TARGET_FILE"
echo "+판단기준 양호 : 패스워드 최대 사용기간이 90일(12주) 이하로 설정되어 있는 경우" >> "$TARGET_FILE"
echo "+판단기준 취약 : 패스워드 최대 사용기간이 90일(12주) 이하로 설정되어 있지 않는 경우" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "" >> "$TARGET_FILE"
u47_Account_Management=0
u47_safe_check=0
u47=0
if [ -f "/etc/login.defs" ];then
    echo "패스워드 최대 사용기간 설정파일인 /etc/login.defs 파일이 존재합니다." >> "$TARGET_FILE"
    u47_logindefs_maxdays=$(grep -v "^\s*#" "/etc/login.defs" | grep -i "PASS_MAX_DAYS" | awk '{print $2}')
    if [ -n "$u47_logindefs_maxdays" ];then
        if [ $u47_logindefs_maxdays -gt 90 ];then
            echo "패스워드 최대 사용기간이 90 이상으로 부적절하게 설정되어 있습니다." >> "$TARGET_FILE"
            echo "현재 설정 값 : $u47_logindefs_maxdays" >> "$TARGET_FILE"
            u47_safe_check=$((u47_safe_check+1))
        else
            echo "패스워드 최대 사용기간이 90 이하로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
        fi
    else
        echo "/etc/login.defs 파일에 패스워드 최대 기간 설정값이 존재하지 않습니다." >> "$TARGET_FILE"
        u47_safe_check=$((u47_safe_check+1))
    fi
else
    echo "패스워드 최대 사용기간 설정파일인 /etc/login.defs 파일이 존재하지 않습니다." >> "$TARGET_FILE"
fi

if [ $u47_safe_check -ge 1 ];then
    u47=$((u47+1))
    echo "점검 결과 : 취약" >> "$RESULT_FILE"
else
    echo "점검 결과 : 양호" >> "$RESULT_FILE"
fi
if [[ $u47 -ge 1 ]];then
    Mid=$((Mid+1))
    Account_Management=$((Account_Management+1))
    u47_Account_Management=1
fi