#!/bin/bash
CHECK_TMP="${CHECK_TMP:-/tmp/check_tmp}"
mkdir -p "$CHECK_TMP"
TARGET_FILE="${TARGET_FILE:-$CHECK_TMP/U-66.tmp}"
RESULT_FILE="${RESULT_FILE:-$CHECK_TMP/U-66.result}"

cat << EOF
===== [U-66] Check SNMP service drive...              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "                        U-66 SNMP 서비스 구동 점검             " >> "$TARGET_FILE"
echo "--------------------------------------------------------------------------"  >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "점검목적 : 불필요한 SNMP 서비스 활성화로 인해 필요 이상의 정보가 노출되는 것을 막기 위해 SNMP 서비스를 중지해야함" >> "$TARGET_FILE"
echo "보안위협 : SNMP 서비스로 인하여 시스템의 주요 정보 유출 및 정보의 불법수정이 발생할 수 있음" >> "$TARGET_FILE"
echo "+판단기준 양호 : SNMP 서비스를 사용하지 않는 경우" >> "$TARGET_FILE"
echo "+판단기준 취약 : SNMP 서비스를 사용하는 경우" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "" >> "$TARGET_FILE"
echo "-------------" >> "$RESULT_FILE"
echo "U-66 점검 결과" >> "$RESULT_FILE"

u66_Service_Management=0
u66_safe_check=0
u66=0
u66_snmp_checks=("snmp" "snmpd")
u66_snmp_ports=("161" "162")

check_service_status "${u66_snmp_ports}" "${u66_snmp_checks[@]}"
if [[ $? -eq 1 ]]; then
    echo "snmp 서비스를 사용하고 있습니다.">> "$TARGET_FILE"
    66_safe_check=$((66_safe_check+1))
    echo "점검 결과 : 취약" >> "$RESULT_FILE"
else
    echo "snmp 서비스를 사용하지 않고 있습니다.">> "$TARGET_FILE"
    echo "점검 결과 : 양호" >> "$RESULT_FILE"
fi

if [[ $u66_safe_check -ge 1 ]];then
    u66=$((u66+1))
    echo "점검 결과 : 취약" >> "$RESULT_FILE"
else
    echo "점검 결과 : 양호" >> "$RESULT_FILE"
fi
if [[ $u66 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u66_Service_Management=1
fi