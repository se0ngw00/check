#!/bin/bash
CHECK_TMP="${CHECK_TMP:-/tmp/check_tmp}"
mkdir -p "$CHECK_TMP"
TARGET_FILE="${TARGET_FILE:-$CHECK_TMP/U-50.tmp}"
RESULT_FILE="${RESULT_FILE:-$CHECK_TMP/U-50.result}"

cat << EOF
===== [U-50] Include minimal accounts in administrator groups              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "                        U-50 관리자 그룹에 최소한의 계정 포함              " >> "$TARGET_FILE"
echo "--------------------------------------------------------------------------"  >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "점검목적 : 관리자 그룹에 최소한의 계정만 존재하는지 점검하여 불필요하게 권한이 남용되고 있는지 확인하기 위함" >> "$TARGET_FILE"
echo "보안위협 : 시스템을 관리하는 root 계정이 속한 그룹은 시스템 운영 파일에 대한 접근 권한이 부여되어 있으므로 해당 관리자 그룹에 속한 계정이 비인가자에게 유출될 경우 관리자 권한으로 시스템에 접근하여 계정 정보 유출, 환경설정 파일 및 디렉터리 변조 등의 위협이 존재함" >> "$TARGET_FILE"
echo "+판단기준 양호 : 관리자 그룹에 불필요한 계정이 등록되어 있지 않은 경우" >> "$TARGET_FILE"
echo "+판단기준 취약 : 관리자 그룹에 불필요한 계정이 등록되어 있는 경우" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "" >> "$TARGET_FILE"
u50_Account_Management=0
u50_safe_check=0
u50=0
u50_rootgroup=$(cat /etc/group | grep root | awk -F: '{print $4}')

if [ -n "$u50_rootgroup" ];then
    echo "root 계정의 그룹에 포함된 계정입니다. 불필요한 계정이 존재할 경우 제거 조치 바랍니다." >> "$TARGET_FILE"
    echo "$u50_rootgroup" >> "$TARGET_FILE"
    u50_safe_check=$((u50_safe_check+1))
else
    echo "root 계정의 그룹에 포함된 계정들이 존재하지 않습니다." >> "$TARGET_FILE"
fi

if [ $u50_safe_check -ge 1 ];then
    u50_safe_check=$((u50_safe_check+1))
    echo "점검 결과 : 취약" >> "$RESULT_FILE"
else
    echo "점검 결과 : 양호" >> "$RESULT_FILE"
fi
if [[ $u50 -ge 1 ]];then
    Low=$((Low+1))
    Account_Management=$((Account_Management+1))
    u50_Account_Management=1
fi 