#!/bin/bash
CHECK_TMP="${CHECK_TMP:-/tmp/check_tmp}"
mkdir -p "$CHECK_TMP"
TARGET_FILE="${TARGET_FILE:-$CHECK_TMP/U-65.tmp}"
RESULT_FILE="${RESULT_FILE:-$CHECK_TMP/U-65.result}"

cat << EOF
===== [U-65] Set at Service Permissions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "                        U-65 at 서비스 권한 설정             " >> "$TARGET_FILE"
echo "--------------------------------------------------------------------------"  >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "점검목적 : 관리자외 at 서비스를 사용할 수 없도록 설정하고 있는지 점검하는 것을 목적으로 함" >> "$TARGET_FILE"
echo "보안위협 : root 외 일반사용자에게도 at 명령어를 사용할 수 있도록 할 경우, 고의 또는 실수로 불법적인 예약 파일 실행으로 시스템 피해를 일으킬 수 있음" >> "$TARGET_FILE"
echo "+판단기준 양호 : at 명령어 일반사용자 금지 및 at 관련 파일 640 이하인 경우" >> "$TARGET_FILE"
echo "+판단기준 취약 : at 명령어 일반사용자 사용가능하거나, at 관련 파일 640 이상인 경우" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "" >> "$TARGET_FILE"
echo "-------------" >> "$RESULT_FILE"
echo "U-65 점검 결과" >> "$RESULT_FILE"

u65_Service_Management=0
u65=0
u65_path_at=$(which at)
u65_Other_at_perm=$(stat -c "%a" "$u65_path_at"  2> /dev/null| rev | cut -c1 | rev)
u65_at_files=("/etc/at.allow" "/etc/at.deny")
u65_safe_check=0
if [ -e "$u65_path_at" ];then
    if ! [[ $u65_Other_at_perm -eq 0 ]];then
        echo "at 명령어에 대한 기타 사용자(Other)에 대한 권한이 주어져 있습니다." >> "$TARGET_FILE"
        u65=$((u65+1))
        u65_safe_check=$((u65_safe_check+1))
    else
        echo "at 명령어에 대한 기타 사용자(Other)에 대한 권한이 주어져 있지 않습니다." >> "$TARGET_FILE"
        for u65_at_file in "${u65_at_files[@]}";do
            if [ -e "$u65_at_file" ];then
                echo "$u65_at_file 이 존재합니다." >> "$TARGET_FILE"
                u65_at_file_owner=$(stat -c "%a" "$u65_at_file"  2> /dev/null| cut -c1)
                u65_at_file_group=$(stat -c "%a" "$u65_at_file"  2> /dev/null| cut -c2)
                u65_at_file_other=$(stat -c "%a" "$u65_at_file"  2> /dev/null| cut -c3)
                u65_check_suid=$(stat -c "%a" "$u65_at_file"  2> /dev/null| tr -d '\n' | wc -c)
                if [[ $u65_check_suid -ge 4 ]];then
                    echo "$u65_at_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> "$TARGET_FILE"
                    u65_safe_check=$((u65_safe_check+1))
                else
                    if [ $u65_at_file_owner -le 6 ];then
                        echo "$u65_at_file 파일의 소유 권한이 6이하로 설정되어 있습니다." >> "$TARGET_FILE"
                        if [ $u65_at_file_group -le 4 ];then
                            echo "$u65_at_file 파일의 소유 그룹 권한이 4이하로 설정되어 있습니다." >> "$TARGET_FILE"
                            if [ $u65_at_file_other -eq 0 ];then
                                echo "$u65_at_file 파일의 기타 사용자(Other) 권한이 0으로 설정되어 있습니다." >> "$TARGET_FILE"
                            else
                                echo "$u65_at_file 파일의 기타 사용자(Other) 권한이 0이 아닌 값으로 설정되어 있습니다." >> "$TARGET_FILE"
                                u65_safe_check=$((u65_safe_check+1))
                            fi
                        else
                            ehco "$u65_at_file 파일의 소유 그룹 권한이 4이상으로 설정되어 있습니다." >> "$TARGET_FILE"
                            u65_safe_check=$((u65_safe_check+1))
                        fi
                    else
                        echo "$u65_at_file 파일의 소유 권한이 6이상으로 설정되어 있습니다." >> "$TARGET_FILE"
                        u65_safe_check=$((u65_safe_check+1)) >> "$TARGET_FILE"
                    fi
                fi
            else
                echo "$u65_at_file 이 존재하지 않습니다." >> "$TARGET_FILE"
            fi
        done
    fi
else
    echo "at 실행파일이 존재하지 않습니다."  >> "$TARGET_FILE"
fi

if [[ $u65_safe_check -ge 1 ]];then
    u65=$((u65+1))
    echo "점검 결과 : 취약" >> "$RESULT_FILE"
else
    echo "점검 결과 : 양호" >> "$RESULT_FILE"
fi
if [[ $u65 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u65_Service_Management=1
fi