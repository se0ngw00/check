#!/bin/bash
CHECK_TMP="${CHECK_TMP:-/tmp/check_tmp}"
mkdir -p "$CHECK_TMP"
TARGET_FILE="${TARGET_FILE:-$CHECK_TMP/U-72.tmp}"
RESULT_FILE="${RESULT_FILE:-$CHECK_TMP/U-72.result}"

cat << EOF
===== [U-72] Setting up system logging according to policy              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "                        U-72 정책에 따른 시스템 로깅 설정             " >> "$TARGET_FILE"
echo "--------------------------------------------------------------------------"  >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "점검목적 : 보안 사고 발생 시 원인 파악 및 각종 침해 사실에 대한 확인을 하기 위함" >> "$TARGET_FILE"
echo "보안위협 : 로깅 설정이 되어 있지 않을 경우 원인 규명이 어려우며, 법적 대응을 위한 충분한 증거로 사용할 수 없음" >> "$TARGET_FILE"
echo "+판단기준 양호 : 로그 기록 정책이 정책에 따라 설정되어 수립되어 있으며 보안정책에 따라 로그를 남기고 있을 경우" >> "$TARGET_FILE"
echo "+판단기준 취약 : 로그 기록 정책 미수립 또는, 정책에 따라 설정되어 있지 않거나 보안정책에 따라 로그를 남기고 있지 않을 경우" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "" >> "$TARGET_FILE"
echo "-------------" >> "$RESULT_FILE"
echo "U-72 점검 결과" >> "$RESULT_FILE"
u72_Log_Management=0
u72_safe_check=0
u72=0
echo "귀사의 시스템에 대한 보안 담당자와의 상담을 통해 로그 기록 정책이 정책에 따라 설정되어 수립되어 보안정책에 따라 로그를 남기고 있는지 확인해야함." >> "$TARGET_FILE"


if [[ $u72_safe_check -ge 1 ]];then
    u72=$((u72+1))
    echo "점검 결과 : 취약" >> "$RESULT_FILE"
else
    echo "점검 결과 : 양호" >> "$RESULT_FILE"
fi

if [[ $u72 -ge 1 ]];then
    Low=$((Mid+1))
    Log_Management=$((Log_Management+1))
    u72_Log_Management=1
fi