#!/bin/bash
CHECK_TMP="${CHECK_TMP:-/tmp/check_tmp}"
mkdir -p "$CHECK_TMP"
TARGET_FILE="${TARGET_FILE:-$CHECK_TMP/U-16.tmp}"
RESULT_FILE="${RESULT_FILE:-$CHECK_TMP/U-16.result}"

cat << EOF
===== [U-16] Check device files that do not exist in /dev              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "                        U-16 /dev에 존재하지 않는 device 파일 점검             " >> "$TARGET_FILE"
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "점검목적 : 실제 존재하지 않는 디바이스를 찾아 제거함으로써 root 파일 시스템 손상 및 다운 등의 문제를 방지하기 위함" >> "$TARGET_FILE"
echo "보안위협 : 공격자는 rootkit 설정파일들을 서버 관리자가 쉽게 발견하지 못하도록 /dev에 device 파일인 것처럼 위장하는 수법을 많이 사용함" >> "$TARGET_FILE"
echo "+판단기준 양호 : dev에 대한 파일 점검 후 존재하지 않은 device 파일을 제거한 경우" >> "$TARGET_FILE"
echo "+판단기준 취약 : dev에 대한 파일 미점검 또는, 존재하지 않은 device 파일을 방치한 경우" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "" >> "$TARGET_FILE"
echo "-------------" >> "$RESULT_FILE"
echo "U-16 점검 결과" >> "$RESULT_FILE"
u16_Files_Directory_Management=0
u16_safe_check=0
u16=0

u16_dev_find=$(find /dev -type f -exec ls -l {} \; 2> /dev/null | wc -l)
if [[ $u16_dev_find -gt 0 ]];then
    echo "/dev 디렉터리 내 불필요한 device 파일이 존재합니다." >> "$TARGET_FILE"
    u16_safe_check=$((u16_safe_check+1))
else
    echo "/dev 디렉터리 내 불필요한 device 파일이 존재하지 않습니다.." >> "$TARGET_FILE"
fi

if [[ $u16 -ge 1 ]];then
    High=$((High+1))
fi

if [[ $u16_safe_check -ge 1 ]];then
    u16=$((u16+1))
    echo "점검 결과 : 취약" >> "$RESULT_FILE"
else
    echo "점검 결과 : 양호" >> "$RESULT_FILE"
fi
if [[ $u16 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u16_Files_Directory_Management=1
fi