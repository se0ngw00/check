#!/bin/bash
CHECK_TMP="${CHECK_TMP:-/tmp/check_tmp}"
mkdir -p "$CHECK_TMP"
TARGET_FILE="${TARGET_FILE:-$CHECK_TMP/U-51.tmp}"
RESULT_FILE="${RESULT_FILE:-$CHECK_TMP/U-51.result}"

cat << EOF
===== [U-51] Prohibiting GIDs whose accounts do not exist              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "                        U-51 계정이 존재하지 않는 GID 금지              " >> "$TARGET_FILE"
echo "--------------------------------------------------------------------------"  >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "점검목적 : 시스템에 불필요한 그룹이 존재하는지 점검하여 불필요한 그룹의 소유권으로 설정되어 있는 파일의 노출에 의해 발생할 수 있는 위험에 대한 대비가 되어 있는지 확인하기 위함" >> "$TARGET_FILE"
echo "보안위협 : 계정이 존재하지 않는 그룹은 현재 사용되고 있는 그룹이 아닌 불필요한 그룹으로 삭제 조치가 필요함" >> "$TARGET_FILE"
echo "+판단기준 양호 : 시스템 관리나 운용에 불필요한 그룹이 삭제 되어있는 경우" >> "$TARGET_FILE"
echo "+판단기준 취약 : 시스템 관리나 운용에 불필요한 그룹이 존재할 경우" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "" >> "$TARGET_FILE"
u51_Account_Management=0
u51_safe_check=0
u51=0
# /etc/passwd 파일에서 GID 목록 추출
u51_gid_list=$(cut -d: -f4 /etc/passwd | sort -u)

echo "계정이 존재하지 않는 그룹이 존재할 경우 아래에 출력됩니다." >> "$TARGET_FILE"  

# GID 목록을 순회하면서 /etc/group에 없는 GID 찾기 
for u51_gid in $u51_gid_list; do
    if ! grep -q ":$u51_gid:" /etc/group; then
        echo "GID $u51_gid 는 /etc/group에 존재하지 않습니다." >> "$TARGET_FILE"
        u51_safe_check=$((u51_safe_check+1))
    fi
done

# /etc/group 파일을 순회하면서 존재하지 않는 사용자 찾기
echo "존재하지 않는 사용자 목록이 존재할 경우 아래에 출력됩니다." >> "$TARGET_FILE"
u51_count=0
while IFS=: read -r u51_group_name _ _ u51_group_users; do
    IFS=',' read -ra u51_users <<< "$u51_group_users"
    for u51_user in "${u51_users[@]}"; do
        if [[ -n "$u51_user" ]] && ! grep -q "^$u51_user:" /etc/passwd; then
            echo "그룹 $u51_group_name 에 속한 사용자 $u51_user 는 /etc/passwd에 존재하지 않습니다." >> "$TARGET_FILE"
            u51_safe_check=$((u51_safe_check+1))
        else
            u51_count=$((u51_count+1))
        fi
    done
done < /etc/group

if [[ $u51_count -ge 1 ]];then
    echo "각각의 그룹 내에 존재하지 않는 사용자는 없습니다." >> "$TARGET_FILE"
fi

if [ $u51_safe_check -ge 1 ];then
    u51=$((u51+1))
    echo "점검 결과 : 취약" >> "$RESULT_FILE"
else
    echo "점검 결과 : 양호" >> "$RESULT_FILE"
fi
if [[ $u51 -ge 1 ]];then
    Low=$((Low+1))
    Account_Management=$((Account_Management+1))
    u51_Account_Management=1
fi