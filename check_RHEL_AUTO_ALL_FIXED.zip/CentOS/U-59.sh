#!/bin/bash
CHECK_TMP="${CHECK_TMP:-/tmp/check_tmp}"
mkdir -p "$CHECK_TMP"
TARGET_FILE="${TARGET_FILE:-$CHECK_TMP/U-59.tmp}"
RESULT_FILE="${RESULT_FILE:-$CHECK_TMP/U-59.result}"

cat << EOF
===== [U-59] Search and remove hidden files and directories              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "                        U-59 숨겨진 파일 및 디렉토리 검색 및 제거             " >> "$TARGET_FILE"
echo "--------------------------------------------------------------------------"  >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "점검목적 : 숨겨진 파일 및 디렉터리 중 의심스러운 내용은 정상 사용자가 아닌 공격자에 의해 생성되었을 가능성이 높음으로 이를 발견하여 제거함" >> "$TARGET_FILE"
echo "보안위협 : 공격자는 숨겨진 파일 및 디렉터리를 통해 시스템 정보 습득, 파일 임의 변경 등을 할 수 있음" >> "$TARGET_FILE"
echo "+판단기준 양호 : 불필요하거나 의심스러운 숨겨진 파일 및 디렉터리를 삭제한 경우" >> "$TARGET_FILE"
echo "+판단기준 취약 : 불필요하거나 의심스러운 숨겨진 파일 및 디렉터리를 방치한 경우" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "" >> "$TARGET_FILE"

u59_safe_check=0
u59_Files_Directory_Management=0
u59=0
u59_secret_file=$(find / -type f -name ".*" -atime -30 2> /dev/null)
u59_secret_dir=$(find / -type d -name ".*" -atime -30 2> /dev/null)

if [ -n "$u59_secret_file" ];then
    echo "최근 30일 동안 접근된 숨겨진 파일 목록이 존재합니다. 불필요하거나 의심스러운 파일의 경우 삭제조치가 필요합니다." >> "$TARGET_FILE"
    echo "$u59_secret_file" >> "$TARGET_FILE"
    u59_safe_check=$((u59_safe_check+1))
else
    echo "최근 30일 동안 접근된 숨겨진 파일이 존재하지 않습니다." >> "$TARGET_FILE"
fi
if [ -n "$u59_secret_dir" ];then
    echo "최근 30일 동안 접근된 숨겨진 디렉터리 목록이 존재합니다. 불필요하거나 의심스러운 파일의 경우 삭제조치가 필요합니다." >> "$TARGET_FILE"
    echo "$u59_secret_dir" >> "$TARGET_FILE"
    u59_safe_check=$((u59_safe_check+1))
else
    echo "최근 30일 동안 접근된 숨겨진 디렉터리가 존재하지 않습니다." >> "$TARGET_FILE"
fi


if [[ $u59_safe_check -ge 1 ]];then
    u59=$((u59+1))
    echo "점검 결과 : 취약" >> "$RESULT_FILE"
else
    echo "점검 결과 : 양호" >> "$RESULT_FILE"
fi
if [[ $u59 -ge 1 ]];then
    Low=$((Low+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u59_Files_Directory_Management=1
fi