#!/bin/bash
CHECK_TMP="${CHECK_TMP:-/tmp/check_tmp}"
mkdir -p "$CHECK_TMP"
TARGET_FILE="${TARGET_FILE:-$CHECK_TMP/U-35.tmp}"
RESULT_FILE="${RESULT_FILE:-$CHECK_TMP/U-35.result}"

cat << EOF
===== [U-35] Removing a Web Service Directory Listing              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "                        U-35 웹서비스 디렉토리 리스팅 제거              " >> "$TARGET_FILE"
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "+점검목적 : 외부에서 디렉터리 내의 모든 파일에 대한 접근 및 열람을 제한함을 목적으로 함" >> "$TARGET_FILE"
echo "+보안위협 : 디렉터리 검색 기능이 활성화 되어 있을 경우, 사용자에게 디렉터리내 파일이 표시되어 WEB 서버 구조 노출뿐만 아니라 백업 파일이나 소스파일, 공개되어서는 안되는 파일 등이 노출 가능함" >> "$TARGET_FILE"
echo "+판단기준 양호 : 디렉터리 검색 기능을 사용하지 않는 경우" >> "$TARGET_FILE"
echo "+판단기준 취약 : 디렉터리 검색 기능을 사용하는 경우" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "" >> "$TARGET_FILE"
u35=0
u35_Service_Management=0
u35_safe_check=0
u35_apache_files=("/etc/apache2/conf-available/*.conf" "/etc/apache2/sites-available/*.conf" "/etc/apache2/sites-enabled/*.conf" "/etc/apache2/conf-enabled/*.conf" ".htaccess")
u35_nginx_files=("/etc/nginx/conf.d/*.conf" "/etc/nginx/sites-available/*.conf" "/etc/nginx/sites-enabled/*.conf")
u35_acount=0
u35_ncount=0
u35_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
u35_idx=0
u35_break=0
echo "※Ubuntu 기준 Apache 메인 설정파일인 /etc/apache2/apache2.conf 경로와 Nginx 메인 설정 파일인 /etc/nginx/nginx.conf를 점검합니다. 해당 경로가 존재하지 않을 경우, 아파치 웹 서비스 구성 파일명을 토대로 파일 탐색 후 점검이 진행됩니다. 중복된 파일명이 존재할 경우 수동 점검을 권장합니다.※"  >> "$TARGET_FILE"
for u35_apache_home_check in "${u35_apache_home_checks[@]}";do
    u35_apache_home=$(find / -type f -name "$u35_apache_home_check" 2> /dev/null | egrep -v "tmp|temp|swap|swp")
    if [ -f "$u35_apache_home" ];then
        echo "$u35_apache_home 파일이 존재합니다." >> "$TARGET_FILE"
        u35_dir_lisconfs_a=($(grep -vE "^\s*#" "$u35_apache_home" | sed -n '/<Directory/,/<\/Directory>/p' | grep -i "^\s*options" | grep -i indexes | awk '{print $1}' ))
        u35_check_dirpath_a=($(grep -vE "^\s*#" "$u35_apache_home" | awk 'BEGIN { inBlock = 0; block = "" }/<Directory/ {block = $0;inBlock = 1;dirPath = $2; gsub("\"", "", dirPath)}/<\/Directory>/ {block = block "\n" $0;inBlock = 0;if (block ~ /Indexes/) { print dirPath }block = ""}inBlock && ! /<\/Directory>/ { block = block "\n" $0 }' | tr -d '>'))
        for u35_dir_lisconf_a in "${u35_dir_lisconfs_a[@]}";do
            if [ -n $u35_dir_lisconf_a ];then
                echo "웹 서비스 디렉토리 리스팅이 활성화 있습니다." >> "$TARGET_FILE"
                echo "디렉토리 리스팅이 활성화된 디렉토리 경로 : ${u35_check_dirpath_a[$u35_idx]}" >> "$TARGET_FILE"
                u35_safe_check=$((u35_safe_check+1))
                u35_idx=$((u35_idx+1))
            else
                echo "웹 서비스 디렉토리 리스팅이 비활성화 되어 있습니다" >> "$TARGET_FILE"
                echo "디렉토리 리스팅이 비활성화된 디렉토리 경로 : ${u35_check_dirpath_a[$u35_idx]}" >> "$TARGET_FILE"
                u35_idxn=$((u35_idxn+1))
            fi
        done
        break
    else
        u35_idx=0
        if [[ $u35_break -eq 1 ]];then
            break
        fi
        u35_break=$((u35_break+1))
        echo "Apache 메인 설정 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> "$TARGET_FILE"
        for u35_apache_file in "${u35_apache_files[@]}";do
            for u35_apache_check in $u35_apache_file;do
                if [ -f "$u35_apache_check" ];then
                    u35_adected_filecks=$(grep -vE "^\s*#" "$u35_apache_check"  | grep -iw "options" | grep -iw "indexes" | grep -iwv "\-indexes" )
                    for u35_adected_fileck in "${u35_adected_filecks[@]}";do
                        if [[ -n "$u35_adected_fileck" ]];then
                            echo "$u35_apache_check 파일에서 디렉토리 리스팅을 허용하는 indexes 설정값이 존재합니다." >> "$TARGET_FILE"
                            echo "디렉토리 리스팅이 활성화된 디렉토리 경로 : ${u35_check_dirpath_a[$u35_idx]}" >> "$TARGET_FILE"
                            u35_safe_check=$((u35_safe_check+1))
                            u35_idx=$((u35_idx+1))
                        else
                            echo "$u35_apache_check 파일은 존재하지만 디렉토리 리스팅을 허용하는 indexes 설정값이 존재하지 않습니다." >> "$TARGET_FILE"
                            u35_idxn=$((u35_idxn+1))
                        fi
                    done
                fi
            done
        done
        echo "웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> "$TARGET_FILE"
        u35_idx=0
    fi
done
if [ -f "/etc/nginx/nginx.conf" ];then
    echo "/etc/nginx/nginx.conf 파일이 존재합니다." >> "$TARGET_FILE"
    u35_dir_lisconf=$(grep -vE "^\s*#" "/etc/nginx/nginx.conf" | sed -n '/server {/,/}/p' | grep -i "^\s*autoindex" | awk '{print tolower($2)}' | tr -d ';')
    if [[ $u35_dir_lisconf == "on" ]];then
        echo "웹 서비스 디렉토리 리스팅이 활성화 있습니다." >> "$TARGET_FILE"
        echo "설정 값 : $u35_dir_lisconf" >> "$TARGET_FILE"
        u35_safe_check=$((u35_safe_check+1))
    else
        echo "웹 서비스 디렉토리 리스팅이 비활성화 되어 있습니다" >> "$TARGET_FILE"
    fi
else 
    echo "/etc/nginx/nginx.conf 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> "$TARGET_FILE"
    for u35_ngnix_file in ${u35_nginx_files[@]};do
        for u35_nginx_check in $u35_ngnix_file;do
            if [ -f "$u35_nginx_check" ];then
                u35_ncount=$((u35_ncount+1))
                u35_ndected_fileck=$(grep -vE "^\s*#" "$u35_nginx_check" 2> /dev/null| grep -iw "autoindex" | grep -iw "on")
                if [ -n "$u35_ndected_fileck" ];then
                    echo "$u35_nginx_check 파일에서 디렉토리 리스팅을 허용하는 autoindex 설정값이 존재합니다." >> "$TARGET_FILE"
                    echo "설정 값 : $u35_ndected_fileck" >> "$TARGET_FILE"
                    u35_safe_check=$((u35_safe_check+1))
                else
                    echo "$u35_nginx_check 파일은 존재하지만 디렉토리 리스팅을 허용하는 autoindex 설정값이 존재하지 않습니다." >> "$TARGET_FILE"
                fi
            fi
        done
    done
    if [ $u35_ncount -eq 0 ];then
        echo "웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> "$TARGET_FILE"
    fi
fi

if [[ $u35_safe_check -ge 1 ]];then
    u35=$((u35+1))
    echo "점검 결과 : 취약" >> "$RESULT_FILE"
else
    echo "점검 결과 : 양호" >> "$RESULT_FILE"
fi
if [[ $u35 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u35_Service_Management=1
fi