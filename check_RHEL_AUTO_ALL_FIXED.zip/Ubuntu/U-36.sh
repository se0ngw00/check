#!/bin/bash
CHECK_TMP="${CHECK_TMP:-/tmp/check_tmp}"
mkdir -p "$CHECK_TMP"
TARGET_FILE="${TARGET_FILE:-$CHECK_TMP/U-36.tmp}"
RESULT_FILE="${RESULT_FILE:-$CHECK_TMP/U-36.result}"

cat << EOF
===== [U-36] Restrict Web Services Web Process Permissions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "                        U-36 웹서비스 웹 프로세스 권한 제한              " >> "$TARGET_FILE"
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "+점검목적 : Apache 데몬을 root 권한으로 구동하지 않고 별도의 권한으로 구동함으로써 침해사고 발생 시 피해범위 확산 방지를 목적으로 함" >> "$TARGET_FILE"
echo "+보안위협 : 웹서비스 데몬을 root 권한으로 실행시 웹서비스가 파일을 생성, 수정하는 과정에서 웹서비스에 해당하지 않는 파일도 root 권한에 의해 쓰기가 가능하며 해킹 발생시 root 권한이 노출 될 수 있음" >> "$TARGET_FILE"
echo "+판단기준 양호 : Apache 데몬이 root 권한으로 구동되지 않는 경우" >> "$TARGET_FILE"
echo "+판단기준 취약 : Apache 데몬이 root 권한으로 구동되는 경우" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "" >> "$TARGET_FILE"
u36_safe_check=0
u36_Service_Management=0
u36=0
u36_break=0
u36_apache_files=("/etc/apache2/conf-available/*.conf" "/etc/apache2/sites-available/*.conf" "/etc/apache2/sites-enabled/*.conf")
u36_nginx_files=("/etc/nginx/conf.d/*.conf" "/etc/nginx/sites-available/*.conf" "/etc/nginx/sites-enabled/*.conf")
u36_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
echo "※Cent OS 7 기준 Apache 메인 설정파일 경로와 Nginx 메인 설정 파일인 /etc/nginx/nginx.conf를 점검합니다. 해당 경로가 존재하지 않을 경우, 아파치 웹 서비스 구성 파일명을 토대로 파일 탐색 후 점검이 진행됩니다. 중복된 파일명이 존재할 경우 수동 점검을 권장합니다.※"  >> "$TARGET_FILE"
for u36_apache_home_check in "${u36_apache_home_checks[@]}";do
    u36_apache_home=$(find / -type f -name "$u36_apache_home_check" 2> /dev/null | egrep -v "tmp|temp|swap|swp")
    if [ -f "$u36_apache_home" ];then
        echo "$u36_apache_home 파일이 존재합니다." >> "$TARGET_FILE"
        u36_apache_user=$(grep -vE "^\s*#" "$u36_apache_home" | grep -wiE "^\s*user" | awk '{print tolower($2)}')
        u36_apache_group=$(grep -vE "^\s*#" "$u36_apache_home" | grep -wiE "^\s*group" | awk '{print tolower($2)}')
        if [ -n "$u36_apache_user" ] || [ -n "$u36_apache_group" ];then
            if [ "$u36_apache_user" == "www-data" ] || [ "$u36_apache_user" == "apache" ];then
                echo "Apache 웹 서비스 설정파일의 User 권한이 www-data 혹은 apache로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                if [ "$u36_apache_group" == "www-data" ] || [ "$u36_apache_group" == "apache" ];then
                    echo "Apache 웹 서비스 설정파일의 Group 권한이 www-data 혹은 apache로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                else
                    if [ "$u36_apache_group" == "root" ];then
                        echo "Apache 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                        u35_safe_check=$((u35_safe_check+1))
                    else
                        echo "Apache 웹 서비스 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                    fi
                fi
            else
                if [[ "$u36_apache_user" == "root" ]];then
                    echo "Apache 웹 서비스 설정파일의 User 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                    u35_safe_check=$((u35_safe_check+1))
                else
                    echo "Apache 웹 서비스 설정파일의 User 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                    if [ "$u36_apache_group" == "www-data" ] || [ "$u36_apache_group" == "apache" ];then
                        echo "Apache 웹 서비스 설정파일의 Group 권한이 wwww-data 혹은 apache로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                    else
                        if [ "$u36_apache_group" == "root" ];then
                            echo "Apache 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                        else
                            echo "Apache 웹 서비스 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                        fi
                    fi
                fi
            fi
        else
            echo "$u36_apache_home 파일은 존재하지만, User 및 Group 설정 옵션이 존재하지 않습니다." >> "$TARGET_FILE"
        fi
    else 
        if [ $u36_break -eq 1 ];then
            break
        fi
        u36_break=$((u35_break+1))
        for u36_apache_file in "${u36_apache_files[@]}";do
            for u36_apache_check in $u36_apache_file;do
                if [ -f "$u36_apache_check" ];then
                    echo "$u36_apache_check 파일이 존재합니다." >> "$TARGET_FILE"
                    u36_apache_user=$(grep -vE "^\s*#" "$u36_apache_check" | grep -wiE "^\s*user" | awk '{print tolower($2)}')
                    u36_apache_group=$(grep -vE "^\s*#" "$u36_apache_check" | grep -wiE "^\s*group" | awk '{print tolower($2)}')
                    if [ -n "$u36_apache_user" ] || [ -n "$u36_apache_group" ];then
                        if [ "$u36_apache_user" == "www-data" ] || [ "$u36_apache_user" == "apache" ];then
                            echo "$u36_apache_check 설정파일의 User 권한이 www-data 혹은 apache로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                            if [ "$u36_apache_group" == "www-data" ] || [ "$u36_apache_group" == "apache" ];then
                                echo "$u36_apache_check 설정파일의 Group 권한이 www-data 혹은 apache로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                            else
                                if [ "$u36_apache_group" == "root" ];then
                                    echo "$u36_apache_check 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                                    u35_safe_check=$((u35_safe_check+1))
                                else
                                    echo "$u36_apache_check 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                                fi
                            fi
                        else
                            if [[ "$u36_apache_user" == "root" ]];then
                                echo "$u36_apache_check 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                                u35_safe_check=$((u35_safe_check+1))
                            else
                                echo "$u36_apache_check 설정파일의 User 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                                if [ "$u36_apache_group" == "www-data" ] || [ "$u36_apache_group" == "apache" ];then
                                    echo "$u36_apache_check 설정파일의 Group 권한이 wwww-data 혹은 apache로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                                else
                                    if [ "$u36_apache_group" == "root" ];then
                                        echo "$u36_apache_check 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                                        u35_safe_check=$((u35_safe_check+1))
                                    else
                                        echo "$u36_apache_check 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                                    fi
                                fi
                            fi
                        fi
                    else
                        echo "$u36_apache_check 파일은 존재하지만, User 및 Group 설정 옵션이 존재하지 않습니다." >> "$TARGET_FILE"
                    fi
                fi
            done
        done
        echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> "$TARGET_FILE"
    fi
done

if [ -f "/etc/nginx/nginx.conf" ];then
    echo "/etc/nginx/nginx.conf 파일이 존재합니다." >> "$TARGET_FILE"
    u36_nginx_user=$(grep -vE "^\s*#" "/etc/nginx/nginx.conf" | grep -wiE "^\s*user" | awk '{print tolower($2)}')
    u36_nginx_group=$(grep -vE "^\s*#" "/etc/nginx/nginx.conf" | grep -wiE "^\s*user" | awk '{print tolower($3)}')
    if [ -n "$u36_nginx_user" ] || [ -n "$u36_nginx_group" ];then
        if [ "$u36_nginx_user" == "www-data" ] || [ "$u36_nginx_user" == "nginx" ];then
            echo "Nginx 웹 서비스 설정파일의 User 권한이 www-data 혹은 nginx로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
            if [ "$u36_nginx_group" == "www-data" ] || [ "$u36_nginx_group" == "nginx" ];then
                echo "Nginx 웹 서비스 설정파일의 Group 권한이 www-data 혹은 nginx로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
            else
                if [[ "$u36_nginx_group" == "root" ]];then
                    echo "Nginx 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                    u35_safe_check=$((u35_safe_check+1))
                else
                    echo "Nginx 웹 서비스 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                fi
            fi
        else
            if [[ "$u36_nginx_user" == "root" ]];then
                echo "Nginx 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                u35_safe_check=$((u35_safe_check+1))
            else
                echo "Nginx 웹 서비스 설정파일의 User 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                if [ "$u36_nginx_group" == "www-data" ] || [ "$u36_nginx_group" == "nginx" ];then
                    echo "Nginx 웹 서비스 설정파일의 Group 권한이 wwww-data 혹은 apache로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                else
                    if [ "$u36_nginx_group" == "root" ];then
                        echo "Nginx 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                        u35_safe_check=$((u35_safe_check+1))
                    else
                        echo "Nginx 웹 서비스 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                    fi
                fi
            fi
        fi
    else
        echo "/etc/nginx/nginx.conf 파일은 존재하지만, User 및 Group 설정 옵션이 존재하지 않습니다." >> "$TARGET_FILE"
    fi
else 
    echo "/etc/nginx/nginx.conf 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> "$TARGET_FILE"
    for u36_ngnix_file in "${u36_nginx_files[@]}";do
        for u36_nginx_check in $u36_ngnix_file;do
            if [ -f "$u36_nginx_check" ];then
                echo "$u36_nginx_check 파일이 존재합니다." >> "$TARGET_FILE"
                u36_nginx_user=$(grep -vE "^\s*#" "$u36_nginx_check" | grep -wiE "^\s*user" | awk '{print $2}')
                u36_nginx_group=$(grep -vE "^\s*#" "$u36_nginx_check" | grep -wiE "^\s*user" | awk '{print $3}')
                if [ -n "$u36_nginx_user" ] || [ -n "$u36_nginx_group" ];then
                    if [ "$u36_nginx_user" == "www-data" ] || [ "$u36_nginx_user" == "nginx" ];then
                        echo "Nginx 웹 서비스 설정파일의 User 권한이 www-data 혹은 nginx로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                        if [ "$u36_nginx_group" == "www-data" ] || [ "$u36_nginx_group" == "nginx" ];then
                            echo "Nginx 웹 서비스 설정파일의 Group 권한이 www-data 혹은 nginx로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                        else
                            if [[ "$u36_nginx_group" == "root" ]];then
                                echo "Nginx 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                                u35_safe_check=$((u35_safe_check+1))
                            else
                                echo "Nginx 웹 서비스 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                            fi
                        fi
                    else
                        if [[ "$u36_nginx_user" == "root" ]];then
                            echo "Nginx 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                            u35_safe_check=$((u35_safe_check+1))
                        else
                            echo "Nginx 웹 서비스 설정파일의 User 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                            if [ "$u36_nginx_group" == "www-data" ] || [ "$u36_nginx_group" == "nginx" ];then
                                echo "Nginx 웹 서비스 설정파일의 Group 권한이 wwww-data 혹은 apache로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                            else
                                if [ "$u36_nginx_group" == "root" ];then
                                    echo "Nginx 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                                    u35_safe_check=$((u35_safe_check+1))
                                else
                                    echo "Nginx 웹 서비스 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> "$TARGET_FILE"
                                fi
                            fi
                        fi
                    fi
                else
                    echo "$u36_nginx_check 파일은 존재하지만, User 및 Group 설정 옵션이 존재하지 않습니다." >> "$TARGET_FILE"
                fi
            fi
        done
    done
    echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> "$TARGET_FILE"
fi

if [[ $u36_safe_check -ge 1 ]];then
    u36=$((u36+1))
    echo "점검 결과 : 취약" >> "$RESULT_FILE"
else
    echo "점검 결과 : 양호" >> "$RESULT_FILE"
fi
if [[ $u36 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u36_Service_Management=1
fi