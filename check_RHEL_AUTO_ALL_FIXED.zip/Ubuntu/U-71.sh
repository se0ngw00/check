#!/bin/bash
CHECK_TMP="${CHECK_TMP:-/tmp/check_tmp}"
mkdir -p "$CHECK_TMP"
TARGET_FILE="${TARGET_FILE:-$CHECK_TMP/U-71.tmp}"
RESULT_FILE="${RESULT_FILE:-$CHECK_TMP/U-71.result}"

cat << EOF
===== [U-71] Hide Apache Web Services Information              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "                        U-71 Apache 웹 서비스 정보 숨김             " >> "$TARGET_FILE"
echo "--------------------------------------------------------------------------"  >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "점검목적 : HTTP 헤더, 에러페이지에서 웹 서버 버전 및 종류, OS 정보 등 웹 서버와 관련된 불필요한 정보가 노출되지 않도록 하기 위함" >> "$TARGET_FILE"
echo "보안위협 : 불필요한 정보가 노출될 경우 해당 정보를 이용하여 시스템의 취약점을 수 s집할 수 있음" >> "$TARGET_FILE"
echo "+판단기준 양호 : ServerTokens Prod, ServerSignature Off로 설정되어있는 경우" >> "$TARGET_FILE"
echo "+판단기준 취약 : ServerTokens Prod, ServerSignature Off로 설정되어있지 않은 경우" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "" >> "$TARGET_FILE"
echo "-------------" >> "$RESULT_FILE"
echo "U-71 점검 결과" >> "$RESULT_FILE"

u71_Service_Management=0
u71=0
u71_safe_check=0
u71_apache_files=("/etc/apache2/conf-available/*.conf" "/etc/apache2/sites-available/*.conf" "/etc/apache2/sites-enabled/*.conf" "/etc/apache2/conf-enabled/*.conf" ".htaccess")
u71_nginx_files=("/etc/nginx/conf.d/*.conf" "/etc/nginx/sites-available/*.conf" "/etc/nginx/sites-enabled/*.conf")
u71_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
u71_break=0
echo "※Cent OS 7 기준 Apache 메인 설정파일 경로와 Nginx 메인 설정 파일인 /etc/nginx/nginx.conf를 점검합니다. 해당 경로가 존재하지 않을 경우, 아파치 웹 서비스 구성 파일명을 토대로 파일 탐색 후 점검이 진행됩니다. 중복된 파일명이 존재할 경우 수동 점검을 권장합니다.※" >> "$TARGET_FILE"
for u71_apache_home_check in "${u71_apache_home_checks[@]}";do
    u71_apache_home=$(find / -type f -name "$u71_apache_home_check" 2> /dev/null | egrep -v "tmp|temp|swap|swp")
    if [ -f "$u71_apache_home" ];then
        echo "$u71_apache_home 파일이 존재합니다." >> "$TARGET_FILE"
        u71_server_tokens=$(grep -vE "^\s*#" "$u71_apache_home" | grep -i "ServerTokens" | grep -i "prod")
        u71_serversignature=$(grep -E "^\s*#" "$u71_apache_home" | grep -i "ServerSignature" | grep -i "off")
        if [ -n "$u71_server_tokens" ];then
            echo "ServerTokens 지시자의 옵션이 Prod로 설정되어 있습니다." >> "$TARGET_FILE"
            echo "현재 설정 값 : $u71_server_tokens" >> "$TARGET_FILE"
            if [ -n "$u71_serversignature" ];then
                echo "ServerSignature 지시자의 옵션이 off로 설정되어 있습니다." >> "$TARGET_FILE"
                echo "현재 설정 값 : $u71_serversignature" >> "$TARGET_FILE"
            else
                echo "ServerSignature 지시자의 옵션이 존재하지 않거나, off로 설정되어 있지 않습니다." >> "$TARGET_FILE"
                u71_safe_check=$((u71_safe_check+1))
            fi
        else
            echo "ServerTokens 지시자의 옵션이 존재하지 않거나, Prod로 설정되어 있지 않습니다." >> "$TARGET_FILE"
            u71_safe_check=$((u71_safe_check+1))
        fi
    else 
        if [ $u71_break -eq 1 ];then
            continue
        fi
        u71_break=$((u71_break+1))
        for u71_apache_file in "${u71_apache_files[@]}";do
            for u71_apache_check in $u71_apache_file;do
                if [ -f "$u71_apache_check" ];then
                    echo "$u71_apache_check 파일이 존재합니다." >> "$TARGET_FILE"
                    u71_server_tokens=$(grep -v "^\s*#" "$u71_apache_check" | grep -i "ServerTokens" | grep -i "prod")
                    u71_serversignature=$(grep -v "^\s*#" "$u71_apache_check" | grep -i "ServerSignature" | grep -i "off")
                    if [ -n "$u71_server_tokens" ];then
                        echo "ServerTokens 지시자의 옵션이 Prod로 설정되어 있습니다." >> "$TARGET_FILE"
                        echo "현재 설정 값 : $u71_server_tokens" >> "$TARGET_FILE"
                        if [ -n "$u71_serversignature" ];then
                            echo "ServerSignature 지시자의 옵션이 off로 설정되어 있습니다." >> "$TARGET_FILE"
                            echo "현재 설정 값 : $u71_serversignature" >> "$TARGET_FILE"
                        else
                            echo "ServerSignature 지시자의 옵션이 존재하지 않거나, off로 설정되어 있지 않습니다." >> "$TARGET_FILE"
                            u71_safe_check=$((u71_safe_check+1))
                        fi
                    else
                        echo "ServerTokens 지시자의 옵션이 존재하지 않거나, Prod로 설정되어 있지 않습니다." >> "$TARGET_FILE"
                        u71_safe_check=$((u71_safe_check+1))
                    fi
                fi
            done
        done
    fi
done
echo "추가적인 Apache 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> "$TARGET_FILE"
if [ -f "/etc/nginx/nginx.conf" ];then
    echo "/etc/nginx/nginx.conf 파일이 존재합니다." >> "$TARGET_FILE"
    u71_server_tokens_nginx=$(grep -v "^\s*#" "/etc/nginx/nginx.conf" | grep -i "server_tokens" | grep -i "off")
    if [ -n "$u71_server_tokens_nginx" ];then
        echo "server_tokens 지시자의 옵션이 off로 설정되어 있습니다." >> "$TARGET_FILE"
        echo "현재 설정 값 : $u71_server_tokens_nginx" >> "$TARGET_FILE"
    else
        echo "server_tokens 지시자의 옵션이 존재하지 않거나, off로 설정되어 있지 않습니다." >> "$TARGET_FILE"
        u71_safe_check=$((u71_safe_check+1))
    fi
else 
    echo "/etc/nginx/nginx.conf 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> "$TARGET_FILE"
    for u71_ngnix_file in ${u71_nginx_files[@]};do
        for u71_nginx_check in $u71_ngnix_file;do
            if [ -e "$u71_nginx_check" ];then
                echo "$u71_nginx_check 파일이 존재합니다." >> "$TARGET_FILE"
                u71_server_tokens_nginx=$(grep -v "^\s*#" "$u71_nginx_check" | grep -i "server_tokens" | grep -i "off")
                if [ -n "$u71_server_tokens_nginx" ];then
                    echo "server_tokens 지시자의 옵션이 off로 설정되어 있습니다." >> "$TARGET_FILE"
                    echo "현재 설정 값 : $u71_server_tokens_nginx" >> "$TARGET_FILE"
                else
                    echo "server_tokens 지시자의 옵션이 존재하지 않거나, off로 설정되어 있지 않습니다." >> "$TARGET_FILE"
                    u71_safe_check=$((u71_safe_check+1)) >> "$TARGET_FILE"
                fi
            fi
        done
    done
    echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> "$TARGET_FILE"
fi

if [[ $u71_safe_check -ge 1 ]];then
    u71=$((u71+1))
    echo "점검 결과 : 취약" >> "$RESULT_FILE"
else
    echo "점검 결과 : 양호" >> "$RESULT_FILE"
fi

if [[ $u71 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u71_Service_Management=1
fi