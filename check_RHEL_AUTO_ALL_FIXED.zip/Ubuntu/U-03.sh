#!/bin/bash
CHECK_TMP="${CHECK_TMP:-/tmp/check_tmp}"
mkdir -p "$CHECK_TMP"
TARGET_FILE="${TARGET_FILE:-$CHECK_TMP/U-03.tmp}"
RESULT_FILE="${RESULT_FILE:-$CHECK_TMP/U-03.result}"

cat << EOF
===== [U-03] Set Account Lock Threshold                 =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "                        U-03 계정 잠금 임계값 설정                        " >> "$TARGET_FILE"
echo "--------------------------------------------------------------------------" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "점검목적 : 계정탈취 목적의 무작위 대입 공격 시 해당 계정을 잠금하여 인증 요청에 응답하는 리소스 낭비를 차단하고 대입 공격으로 인한 비밀번호 노출 공격을 무력화하기 위함" >> "$TARGET_FILE"
echo "보안위협 : 패스워드 탈취 공격(무작위 대입 공격, 사전 대입 공격, 추측 공격 등)의 인증 요청에 대해 설정된 패스워드와 일치 할 때까지 지속적으로 응답하여 해당 계정의 패스워드가 유출 될 수 있음" >> "$TARGET_FILE"
echo "+판단기준 양호 : 계정 잠금 임계값이 10회 이하의 값으로 설정되어 있는 경우" >> "$TARGET_FILE"
echo "+판단기준 취약 : 계정 잠금 임계값이 설정되어 있지 않거나, 10회 이하의 값으로 설정되지 않은 경우" >> "$TARGET_FILE"
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> "$TARGET_FILE"
echo "" >> "$TARGET_FILE"
echo "-------------" >> "$RESULT_FILE"
echo "U-3 점검 결과" >> "$RESULT_FILE"
u3=0
u3_safe_check=0
u3_Account_Management=0
echo "/etc/pam.d/common-auth 파일 점검" >> "$TARGET_FILE"
if [ -e "/etc/pam.d/common-auth" ]; then
    u3_auth_module_check=("pam_tally.so" "pam_tally2.so" "pam_faillock.so")    
    u3_modules_found=0
    for u3_auth_module in "${u3_auth_module_check[@]}";do
        echo "$u3_auth_module 점검" >> "$TARGET_FILE"
        if grep -qiE "^\s*auth\s+.*$u3_auth_module" "/etc/pam.d/common-auth";then
            echo "auth 에 대한 $u3_auth_module 가 존재합니다." >> "$TARGET_FILE"
            u3_auth_check_values=$(grep -iE "^\s*auth\s+.*$u3_auth_module"  "/etc/pam.d/common-auth" | sed -E "s/^.*$u3_auth_module\s*//")
            echo "$(grep -iE "^\s*auth\s+.*$auth_module" "/etc/pam.d/common-auth")" >> "$TARGET_FILE"
            echo "현재 auth 의 $u3_auth_module 모듈에 적용된 설정값은 아래와 같습니다." >> "$TARGET_FILE"
            echo "$u3_auth_check_values" | sed 's/\s\+/\n/g' | while read -r auth_field; do
                    echo "$u3_auth_field" >> "$TARGET_FILE"
                    done
            echo "--------------------" >> "$TARGET_FILE"
            u3_deny_count=$(grep -iE "^\s*auth\s+.*$u3_auth_module" "/etc/pam.d/common-auth" | sed -E "s/^.*$u3_auth_module\s*//" | grep -oP 'deny=\K\d+')
            if (( deny_count <= 10 )); then
                echo "계정 임계값 설정이 $u3_deny_count 로 보안권고 사항인 10 이하로 적절하게 설정되었습니다." >> "$target"
                echo "--------------------" >> "$TARGET_FILE"
            else
                echo "계정 임계값 설정이 $u3_deny_count 로 보안권고 사항인 10 이상으로 부적절하게 설정되었습니다." >> "$target"
                echo "--------------------" >> "$TARGET_FILE"
                u3_safe_check=$((u3_safe_check+1))
            fi
        else
            if grep -qiE "^\s*#.*$u3_auth_stack\s+.*$u3_auth_module" "/etc/pam.d/common-auth"; then  
                echo "계정 임계값 설정 모듈($u3_auth_module)이 주석처리 되어 있습니다." >> "$TARGET_FILE"
                u3_safe_check=$((u3_safe_check+1))
            else    
                echo "$u3_auth_module가 존재하지 않습니다." >> "$TARGET_FILE"
            fi
        fi
    done
else
    echo "/etc/pam.d/common-password 파일이 존재하지 않습니다." >> "$TARGET_FILE"
fi

if [ $u3_safe_check -ge 1 ];then
    u3=$((u3+1))
    echo "점검 결과 : 취약" >> "$RESULT_FILE"
else
    echo "점검 결과 : 양호" >> "$RESULT_FILE"
fi
if [[ $u3 -ge 1 ]];then
    High=$((High+1))
    Account_Management=$((Account_Management+1))
    u3_Account_Management=1
fi