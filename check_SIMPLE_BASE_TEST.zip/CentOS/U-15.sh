cat << EOF
===== [U-15] world writable file check               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-15 world writable 파일 점검                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : world writable 파일을 이용한 시스템 접근 및 악의적인 코드 실행을 방지하기 위함" >> $target
echo "보안위협 : 시스템 파일과 같은 중요 파일에 world writable 설정이 될 경우, 일반사용자 및 비인가된 사용자가 해당 파일을 임의로 수정, 삭제가 가능함" >> $target
echo "+판단기준 양호 : 시스템 중요 파일에 world writable 파일이 존재하지 않거나, 존재 시 설정 이유를 확인하고 있는 경우" >> $target
echo "+판단기준 취약 : 시스템 중요 파일에 world writable 파일이 존재하나 해당 설정 이유를 확인하고 있지 않는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-15 점검 결과" >> $result
u15_Files_Directory_Management=0
u15_safe_check=0
u15=0

u15_world_wr=$(find / -type f -perm -2 -exec ls -l {} \; 2> /dev/null | wc -l)
if [[ $u15_world_wr -gt 0 ]];then
    echo "world writable 파일들이 존재합니다. [관리자와의 상담 필요]" >> $target
    u15_safe_check=$((u15_safe_check+1))
else
    echo "world writable 파일들이 존재하지 않습니다." >> $target
fi

if [[ $u15_safe_check -ge 1 ]];then
    u15=$((u15+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u15 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u15_Files_Directory_Management=1
fi
