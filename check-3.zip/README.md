check-3: test mode generates result files immediately
