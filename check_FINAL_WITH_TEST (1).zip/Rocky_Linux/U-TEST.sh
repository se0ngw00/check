#!/bin/bash
echo "[TEST] OS check script execution OK"
echo "위험도 (하)"
