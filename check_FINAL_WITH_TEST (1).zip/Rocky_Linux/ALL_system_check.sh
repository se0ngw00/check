#!/bin/bash
set -e

DETAIL_FILE="$RESULT_DIR/${RESULT_PREFIX}.detail"
RESULT_FILE="$RESULT_DIR/${RESULT_PREFIX}.result"
SEVERITY_FILE="$RESULT_DIR/${RESULT_PREFIX}.severity"

> "$DETAIL_FILE"
> "$RESULT_FILE"
> "$SEVERITY_FILE"

if [ "$TEST_MODE" = "1" ]; then
  SCRIPTS="U-TEST.sh"
else
  SCRIPTS="U-*.sh"
fi

for script in $SCRIPTS; do
  bash "$script" >> "$DETAIL_FILE"
done

grep -E "취약|양호" "$DETAIL_FILE" >> "$RESULT_FILE"

HIGH=$(grep -c "위험도 \(상\)" "$DETAIL_FILE" || true)
MID=$(grep -c "위험도 \(중\)" "$DETAIL_FILE" || true)
LOW=$(grep -c "위험도 \(하\)" "$DETAIL_FILE" || true)

{
  echo "위험도 (상)"
  echo "$HIGH"
  echo "위험도 (중)"
  echo "$MID"
  echo "위험도 (하)"
  echo "$LOW"
} > "$SEVERITY_FILE"

echo "모든 보안 점검이 정상적으로 완료되었습니다."
echo "상세 결과 파일:"
echo "  $DETAIL_FILE"
echo "요약 결과 파일:"
echo "  $RESULT_FILE"
echo "위험도 요약 파일:"
echo "  $SEVERITY_FILE"
