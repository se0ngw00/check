#!/bin/bash
set -e

START_TIME=$(date +%s)
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
NOW="$(date +%Y%m%d-%H%M%S)"
RESULT_DIR="$BASE_DIR/results"
mkdir -p "$RESULT_DIR"

. /etc/os-release

case "$ID" in
  centos) OS_TAG="centos"; RUN_DIR="CentOS7" ;;
  rocky|rhel|almalinux) OS_TAG="rhel"; RUN_DIR="Rocky_Linux" ;;
  ubuntu) OS_TAG="ubuntu"; RUN_DIR="Ubuntu" ;;
  *) echo "Unsupported OS"; exit 20 ;;
esac

export RESULT_PREFIX="${OS_TAG}_${NOW}"
export RESULT_DIR

TARGET="$BASE_DIR/$RUN_DIR"
cd "$TARGET"
chmod +x ALL_system_check.sh

if [ "$1" = "--test" ]; then
  export TEST_MODE=1
fi

(
  while true; do
    sleep 1
    NOW_T=$(date +%s)
    ELAPSED=$((NOW_T - START_TIME))
    MIN=$((ELAPSED / 60))
    SEC=$((ELAPSED % 60))
    printf "\r[Running] Elapsed time: %dm %02ds" "$MIN" "$SEC"
  done
) &
TIMER_PID=$!

./ALL_system_check.sh > /dev/null 2>&1

kill $TIMER_PID 2>/dev/null || true
echo

END_TIME=$(date +%s)
ELAPSED=$((END_TIME - START_TIME))
MIN=$((ELAPSED / 60))
SEC=$((ELAPSED % 60))

TOTAL_FILE="$RESULT_DIR/${RESULT_PREFIX}.total"
VULN_FILE="$RESULT_DIR/${RESULT_PREFIX}.vuln"

echo
echo "Total execution time: ${MIN}m ${SEC}s"
echo
echo "모든 보안 점검이 정상적으로 완료되었습니다."
echo
echo "전체 결과 파일:"
echo "  $TOTAL_FILE"
echo
echo "취약 항목 파일:"
echo "  $VULN_FILE"
