#!/bin/bash
# ALL_system_check.sh - Auto OS Detect + Safe Timer

START_TIME=$SECONDS

show_timer() {
    while true; do
        elapsed=$((SECONDS - START_TIME))
        printf "\r[Running] Elapsed time: %dm %02ds" $((elapsed/60)) $((elapsed%60))
        sleep 10
    done
}

cleanup() {
    echo
    echo "[INFO] System check finished."
    kill "$TIMER_PID" 2>/dev/null
    exit 0
}

trap cleanup INT TERM EXIT

show_timer &
TIMER_PID=$!

# ================= OS Detection =================
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS_ID=$ID
else
    echo "[ERROR] Cannot detect OS"
    cleanup
fi

echo "[INFO] Detected OS: $OS_ID"

case "$OS_ID" in
    centos|rhel|rocky|almalinux)
        echo "[INFO] Running RHEL-based checks"
        sleep 25
        ;;
    ubuntu)
        echo "[INFO] Running Ubuntu checks"
        sleep 25
        ;;
    *)
        echo "[WARN] Unsupported OS"
        sleep 5
        ;;
esac

cleanup
