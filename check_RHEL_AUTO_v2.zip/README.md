# Linux Server Security Check Script (Final)

## Features
- Auto OS detection (RHEL / Rocky / CentOS / Ubuntu)
- Safe elapsed-time display (single-line)
- Proper cleanup on Ctrl+C or normal exit

## Usage
chmod +x ALL_system_check.sh
./ALL_system_check.sh
