cat << EOF
===== [U-37] Do not access the web service parent directory              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-37 웹서비스 상위 디렉토리 접근 금지              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 상위 경로 이동 명령으로 비인가자의 특정 디렉터리에 대한 접근 및 열람을 제한하여 중요 파일 및 데이터 보호를 목적으로 함" >> $target
echo "+보안위협 : 상위 경로로 이동하는 것이 가능할 경우 접근하고자 하는 디렉터리의 하위 경로에 접속하여 상위경로로 이동함으로써 악의적인 목적을 가진 사용자의 접근이 가능함" >> $target
echo "+판단기준 양호 : 상위 디렉터리에 이동제한을 설정한 경우" >> $target
echo "+판단기준 취약 : 상위 디렉터리에 이동제한을 설정하지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u37=0
u37_safe_check=0
u37_Service_Management=0
u37_apache_files=("/etc/apache2/conf-available/*.conf" "/etc/apache2/sites-available/*.conf" "/etc/apache2/sites-enabled/*.conf")
u37_nginx_files=("/etc/nginx/conf.d/*.conf" "/etc/nginx/sites-available/*.conf" "/etc/nginx/sites-enabled/*.conf")
u37_idx=0
u37_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
u37_break=0
echo "※Cent OS 7 기준 Apache 메인 설정파일 경로와 Nginx 메인 설정 파일인 /etc/nginx/nginx.conf를 점검합니다. 해당 경로가 존재하지 않을 경우, 아파치 웹 서비스 구성 파일명을 토대로 파일 탐색 후 점검이 진행됩니다. 중복된 파일명이 존재할 경우 수동 점검을 권장합니다.※"  >> $target
echo "apache, nginx 의 주요 설정파일을 토대로 apache 홈 디렉터리 점검 후 추가 설정 파일 및 디렉터리를 점검하므로, 중복된 결과가 존재할 수 있습니다." >> $target
for u37_apache_home_check in "${u37_apache_home_checks[@]}";do
    u37_apache_home=$(find / -type f -name "$u37_apache_home_check" 2> /dev/null | egrep -v "tmp|temp|swap|swp")
    if [ -f "$u37_apache_home" ];then
        echo "$u37_apache_home 파일이 존재합니다." >> $target
        u37_dir_pathconfs_a=($(grep -vE "^\s*#" "$u37_apache_home" | sed -n '/<Directory/,/<\/Directory>/p' | grep -i "^\s*AllowOverride" | awk '{print tolower($2)}'))
        u37_check_dirpath_a=($(grep -vE "^\s*#" "$u37_apache_home" | awk 'BEGIN { inBlock = 0; block = "" }/<Directory/ {block = $0;inBlock = 1;dirPath = $2; gsub("\"", "", dirPath)}/<\/Directory>/ {block = block "\n" $0;inBlock = 0;if (block ~ /AllowOverride/) { print dirPath }block = ""}inBlock && ! /<\/Directory>/ { block = block "\n" $0 }' | tr -d '>'))
        for u37_dir_pathconf_a in "${u37_dir_pathconfs_a[@]}";do
            if [ -n "$u37_dir_pathconf_a" ];then
                if [[ "$u37_dir_pathconf_a" == "none" ]];then
                    echo "AllowOverride 지시자의 옵션이 $u37_dir_pathconf_a 로 설정되어 상위 디렉토리로의 접근을 허용하고 있습니다." >> $target
                    #u37_result=$(grep -vE "^\s*#" "/etc/httpd/conf/httpd.conf" | awk 'BEGIN { IGNORECASE = 1 }/<Directory/ { block = $0; inBlock = 1 }/<\/Directory>/ { block = block "\n" $0; inBlock = 0; if (block ~ /AllowOverride\s+all/) { print block; block="" } }inBlock && !/<\/Directory>/ { block = block "\n" $0 }' | sed '1d')
                    #echo "$u37_result"
                    echo "$u37_dir_pathconf_a 로 설정된 경로 : ${u37_check_dirpath_a[$u37_idx]}"   >> $target
                    u37_safe_check=$((u37_safe_check+1))
                    u37_idx=$((u37_idx+1))
                elif [ "$u37_dir_pathconf_a" == "authconfig" ] || [ "$u37_dir_pathconf_a" == "all" ];then
                    echo "AllowOverride 지시자의 옵션이 $u37_dir_pathconf_a 로 설정되어 상위 디렉토리로의 접근을 거부하고 있습니다." >> $target
                    echo "$u37_dir_pathconf_a 로 설정된 경로 : ${u37_check_dirpath_a[$u37_idx]}" >> $target
                    u37_idx=$((u37_idx+1))
                else
                    echo "AllowOverride 지시자의 옵션이 $u37_dir_pathconf_a 로 설정되어 있습니다. 관리자와의 상의바랍니다." >> $target
                fi
            else
                echo "$u37_apache_home 파일이 존재하지만, 설정값이 존재하지 않습니다."
            fi
        done
        break
    else 
        u37_idx=0
        if [ $u37_break -eq 1 ];then
            continue
        fi
        u37_break=$((u37_break+1))
        echo "$u37_apache_home_check 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> $target
        for u37_apache_file in "${u37_apache_files[@]}";do
            for u37_apache_check in $u37_apache_file;do
                if [ -f "$u37_apache_check" ];then
                    echo "$u37_apache_check 파일이 존재합니다." >> $target
                    u37_dir_pathconfs=($(grep -vE "^\s*#" "$u37_apache_check" | sed -n '/<Directory/,/<\/Directory>/p' | grep -i "^\s*AllowOverride" | awk '{print tolower($2)}'))
                    u37_check_dirpath=($(grep -vE "^\s*#" "$u37_apache_check" | awk 'BEGIN { inBlock = 0; block = "" }/<Directory/ {block = $0;inBlock = 1;dirPath = $2; gsub("\"", "", dirPath)}/<\/Directory>/ {block = block "\n" $0;inBlock = 0;if (block ~ /AllowOverride/) { print dirPath }block = ""}inBlock && ! /<\/Directory>/ { block = block "\n" $0 }' | tr -d '>'))
                    if [ ${#u37_dir_pathconfs[@]} -gt 0 ];then
                        for u37_dir_pathconf in "${u37_dir_pathconfs[@]}";do
                            if [[ "$u37_dir_pathconf" == "none" ]];then
                                echo "$u37_apache_check 파일은 존재하지만, AllowOverride 지시자의 옵션이 $u37_dir_pathconf 로 설정되어 상위 디렉토리로의 접근을 허용하고 있습니다." >> $target
                                #u37_result=$(grep -vE "^\s*#" "$u37_apache_check" | awk 'BEGIN { IGNORECASE = 1 }/<Directory/ { block = $0; inBlock = 1 }/<\/Directory>/ { block = block "\n" $0; inBlock = 0; if (block ~ /AllowOverride\s+all/) { print block; block="" } }inBlock && !/<\/Directory>/ { block = block "\n" $0 }' | sed '1d')
                                #echo "$u37_result"
                                echo "$u37_dir_pathconf 로 설정된 경로 : ${u37_check_dirpath[$u37_idx]}"   >> $target
                                u37_safe_check=$((u37_safe_check+1))
                                u37_idx=$((u37_idx+1))
                            elif [ "$u37_dir_pathconf" == "authconfig" ] || [ "$u37_dir_pathconf" == "all" ];then
                                echo "AllowOverride 지시자의 옵션이 $u37_dir_pathconf 로 설정되어 상위 디렉토리로의 접근을 거부하고 있습니다." >> $target
                                #u37_result=$(grep -vE "^\s*#" "$u37_apache_check" | awk 'BEGIN { IGNORECASE = 1 }/<Directory/ { block = $0; inBlock = 1 }/<\/Directory>/ { block = block "\n" $0; inBlock = 0; if (block ~ /AllowOverride\s+all/) { print block; block="" } }inBlock && !/<\/Directory>/ { block = block "\n" $0 }' | sed '1d')
                                #echo "$u37_result"
                                echo "$u37_dir_pathconf 로 설정된 경로 : ${u37_check_dirpath[$u37_idx]}" >> $target
                                u37_idx=$((u37_idx+1))
                            else
                                echo "$u37_apache_check 파일이 존재하며, AllowOverride 지시자의 옵션이 $u37_dir_pathconf 로 설정되어 있습니다. 관리자와의 상의바랍니다." >> $target
                            fi
                        done
                    else
                        echo "$u37_apache_check 파일은 존재하지만, 관련 설정값이 존재하지 않습니다." >> $target
                    fi
                fi
            done
        done
        echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
        u37_idx=0
    fi
done
u37_idx=0
if [ -f "/etc/nginx/nginx.conf" ];then
    echo "/etc/nginx/nginx.conf 파일이 존재합니다." >> $target
    u37_dir_pathconfs_n=($(cat /etc/nginx/nginx.conf | sed -n '/location ~\* \/\\.\\. /,/}/p' | grep -i 'deny' | awk '{print $2}' | tr -d ';'))
    if [ -n "$u37_dir_pathconfs_n" ];then
        for u37_dir_pathconf_n in "${u37_dir_pathconfs_n[@]}";do
            if [[ "$u37_dir_pathconf_n" == "all" ]];then 
                echo "/etc/nginx/nginx.conf 파일에서 상위 디렉토리로의 접근 제한 설정 deny 값이 all로 적절하게 설정되어 있습니다." >> $target
                u37_idx=$((u37_idx+1))
            else
                echo "/etc/nginx/nginx.conf 파일에서 상위 디렉토리로의 접근 제한 설정 deny 값이 all로 설정되어 있지 않습니다." >> $target
                u37_safe_check=$((u37_safe_check+1))
            fi
        done
        if [[ $u37_idx -ge 1 ]];then
            echo "/etc/nginx/nginx.conf 파일에서 상위 디렉토리로의 이동이 허용되어 있습니다." >> $target
            echo "설정 값 : $u37_dir_pathconf_n" >> $target
            echo "총 $u37_idx 개의 취약한 all 설정이 존재합니다. /etc/nginx/nginx.conf 파일을 확인하십시오." >> $target
        else
            echo "/etc/nginx/nginx.conf 파일에서 상위 디렉토리로의 이동이 허용되어 있지 않습니다." >> $target
        fi
    else
        echo "/etc/nginx/nginx.conf 파일은 존재하지만, 상위 디렉토리의 접근을 제한하는 설정값이 존재하지 않습니다." >> $target
    fi
else 
    echo "/etc/nginx/nginx.conf 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> $target
    for u37_ngnix_file in "${u37_nginx_files[@]}";do
        for u37_nginx_check in $u37_ngnix_file;do 
            if [ -f "$u37_nginx_check" ];then
                echo "$u37_nginx_check 파일이 존재합니다." >> $target
                u37_dir_pathconfs_n=($(cat "$u37_nginx_check" | sed -n '/location ~\* \/\\.\\. /,/}/p' | grep -i 'deny' | awk '{print $2}' | tr -d ';'))
                if [ ${#u37_dir_pathconfs_n[@]} -gt 0 ];then
                    for u37_dir_pathconf_n in "${u37_dir_pathconfs_n[@]}";do
                        if [[ "$u37_dir_pathconf_n" == "all" ]];then
                            echo "/etc/nginx/nginx.conf 파일에서 상위 디렉토리로의 접근 제한 설정 deny 값이 all로 적절하게 설정되어 있습니다." >> $target
                            u37_idx=$((u37_idx+1))
                        else
                            echo "$u37_nginx_check 파일은 존재하나, 상위 디렉토리로의 이동이 제한 설정값이 deny all로 설정되어 있지 않습니다." >> $target
                            u37_safe_check=$((u37_safe_check+1))
                        fi
                    done
                else
                    echo echo "$u37_nginx_check 파일은 존재하나, 상위 디렉토리로의 이동이 제한 설정이 존재하지 않습니다." >> $target
                fi
                if [[ $u37_idx -ge 1 ]];then
                    echo "$u37_nginx_check 파일에서 상위 디렉토리로의 이동이 허용되어 있습니다." >> $target
                    echo "설정 값 : $u37_dir_pathconf_n" >> $target
                    echo "총 $u37_idx 개의 취약한 all 설정이 존재합니다. $u37_nginx_check 파일을 확인하십시오." >> $target
                fi
            fi
        done
    done
    echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
fi

if [[ $u37_safe_check -ge 1 ]];then
    u37=$((u37+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u37 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u37_Service_Management=1
fi