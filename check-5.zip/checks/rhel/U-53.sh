cat << EOF
===== [U-53] Check user shell              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-53 사용자 shell 점검              " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 로그인이 불필요한 계정에 쉘 설정을 제거하여, 로그인이 필요하지 않은 계정을 통한 시스템 명령어를 실행하지 못하게 하기 위함" >> $target
echo "보안위협 : 로그인이 불필요한 계정은 일반적으로 OS 설치 시 기본적으로 생성되는 계정으로 쉘이 설정되어 있을 경우, 공격자는 기본 계정들을 이용하여 시스템에 명령어를 실행 할 수 있음" >> $target
echo "+판단기준 양호 : 로그인이 필요하지 않은 계정에 /bin/false(/sbin/nologin) 쉘이 부여되어 있는 경우" >> $target
echo "+판단기준 취약 : 로그인이 필요하지 않은 계정에 /bin/false(/sbin/nologin) 쉘이 부여되지 않은 경우" >> $target
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++w+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u53_Account_Management=0
u53_safe_check=0
u53=0

u53_passwd_lists=$(sudo awk -F: '($3 <= 999 || $3 >= 60000) && $1 != "root" {
    split($7, u53_path, "/");
    u53_shell = u53_path[length(u53_path)];
    if (u53_shell != "nologin" && u53_shell != "false" && u53_shell != "sync" && u53_shell != "shutdown" && u53_shell != "halt") {
        print $1, $7;
    }
}' /etc/passwd
)
u53_shadow_lists=$(awk -F: '($2 == "*" || $2 == "!!") {print $1}' /etc/shadow)

if [ -n "$u53_passwd_lists" ];then
    echo "일반 사용자가 아닌 계정에 대해 Shell이 부여되어 있습니다." >> $target
    u53_safe_check=$((u53_safe_check+1))
    for u53_passwd_list in "${u53_passwd_lists[@]}";do
        echo "$u53_passwd_list" >> $target
    done
fi

readarray -t u53_user_list <<< "$u53_shadow_lists"
u53_result=""
u53_check='for u53_user in "${u53_user_list[@]}"; do
    u53_result+=$(awk -F: -v u53_user="$u53_user" '\''($1 == u53_user) {
        split($7, u53_path, "/");
        shell = u53_path[length(u53_path)];
        if (shell != "nologin" && shell != "false" && shell != "sync" && shell != "shutdown" && shell != "halt") {
            print $1, $7;
        }
    }'\'' /etc/passwd)
done'

if [[ ${#u53_user_list[@]} -gt 0 ]]; then
    eval "$u53_check"
    if [[ -n "$u53_result" ]]; then
        echo "패스워드를 필요로 하지 않는, 격리된 계정에 대해 쉘이 설정되어 있습니다." >> $target
        u53_safe_check=$((u53_safe_check+1))
        echo "$u53_result" >> $target
    else
        echo "/etc/shadow 파일에서 격리된 계정에 대해 전부 쉘이 설정되어 있지 않습니다." >> $target
    fi
else
    echo "'*' 혹은 '!!' 으로 설정된 계정이 /etc/shadow 파일에 존재하지 않습니다." >> $target
fi

if [ $u53_safe_check -ge 1 ];then
    u53=$((u53+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u53 -ge 1 ]];then
    Low=$((Low+1))
    Account_Management=$((Account_Management+1))
    u53_Account_Management=1
fi