cat << EOF
===== [U-38] Remove unnecessary Web Services files              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-38 웹서비스 불필요한 파일 제거              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : Apache 설치 시 디폴트로 설치되는 불필요한 파일을 제거함을 목적으로 함" >> $target
echo "+보안위협 : Apache 설치 시 htdocs 디렉터리 내에 매뉴얼 파일은 시스템 관련정보를 노출하거나 해킹에 악용될 수 있음" >> $target
echo "+판단기준 양호 : 기본으로 생성되는 불필요한 파일 및 디렉터리가 제거되어 있는 경우" >> $target
echo "+판단기준 취약 : 기본으로 생성되는 불필요한 파일 및 디렉터리가 제거되지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u38=0
u38_safe_check=0
u38_Service_Management=0
echo "Apache 및 Nginx 에 대해 설치 시 디폴트로 설치되는 불필요한 파일을 탐색합니다." >> $target
u38_unnecessary_dirs=(
    "/usr/share/doc/apache2"
    "/usr/share/examples/apache2"
    "/var/www/error/"
    "/var/www/icons/"
    "/var/www/cgi-bin/"
    "/usr/share/doc/nginx/"
    "/usr/share/nginx/modules/"
    "/usr/share/nginx/html/"
    "/usr/share/examples/nginx"
)
u38_unnecessary_files=(
    "/etc/apache2/sites-available/000-default.conf"
    "/usr/share/man/man8/httpd.8.gz"
    "/etc/apache2/conf-enabled/autoindex.conf"
    "/var/www/html/index.html"
    "/var/www/html/favicon.ico"
    "/usr/share/man/man1/apache2.1.gz"
    "/usr/share/nginx/html/index.html"
    "/usr/share/nginx/html/50x.html"
    "/usr/share/nginx/html/favicon.ico"
    "/etc/nginx/sites-available/default"
    "/usr/share/man/man1/nginx.1.gz"
    "/usr/share/man/man8/nginx.8.gz"
)
u38_unnecessary_files_sample=(
    "/var/www/html/*.png"
    "/var/www/html/*.gif"
)
u38_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
u38_idx=0
#/etc/nginx/sites-available/default -> debian 
# /etc/httpd/conf.d/welcome.conf -> REHL
echo "apache, nginx 의 주요 설정파일을 토대로 apache 홈 디렉터리 점검 후 추가 설정 파일 및 디렉터리를 점검하므로, 중복된 결과가 존재할 수 있습니다." >> $target
for u38_apache_home_check in "${u38_apache_home_checks[@]}";do
    u38_apache_home=$(find / -type f -name "$u38_apache_home_check" 2> /dev/null | egrep -v "tmp|temp|swap|swp")
    if [ -f "$u38_apache_home" ];then
        u38_documentroot=$(grep -i 'documentroot' "$u38_apache_home" | grep -v "#" | awk '{print $2}' | tr -d '"')
        if [ -n "$u38_documentroot" ];then
            u38_unnecessary_apache_home=$(ls -d "$u38_documentroot/htdocs/manual" 2> /dev/null)
            if [ -d "$u38_unnecessary_apache_home" ];then
                echo "$u38_unnecessary_apache_home 경로가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                u38_safe_check=$((u38_safe_check+1))
                for u38_unnecessary_apache_file in "$u38_unnecessary_apache_home/*";do
                    if [ -f "$u38_unnecessary_apache_file" ];then
                        echo "$u38_unnecessary_apache_file 파일이 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                        u38_safe_check=$((u38_safe_check+1))
                    elif [ -d "$u38_unnecessary_apache_file" ];then
                        echo "$u38_unnecessary_apache_file 디렉터리가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                        u38_safe_check=$((u38_safe_check+1))
                        echo "$u38_unnecessary_apache_file 디렉터리를 재귀적으로 탐색합니다." >> $target
                        echo "$(tree $u38_unnecessary_apache_file)" >> $target
                    else
                        u38_idx=$((u38_idx+1))
                    fi
                done
                if [ $u38_idx -eq 0 ];then
                    echo "$u38_unnecessary_apache_home 경로 내에 파일 및 디렉터리가 존재하지 않습니다." >> $target
                fi
            else
                u38_unnecessary_apache_home=$(ls -d "$u38_documentroot/manual" 2> /dev/null)
                if [ -d "$u38_unnecessary_apache_home" ];then
                    echo "$u38_unnecessary_apache_home 경로가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                    u38_safe_check=$((u38_safe_check+1))
                    for u38_unnecessary_apache_file in "$u38_unnecessary_apache_home/*";do
                        if [ -f "$u38_unnecessary_apache_file" ];then
                            echo "$u38_unnecessary_apache_file 파일이 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                            u38_safe_check=$((u38_safe_check+1))
                        elif [ -d "$u38_unnecessary_apache_file" ];then
                            echo "$u38_unnecessary_apache_file 디렉터리가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                            u38_safe_check=$((u38_safe_check+1))
                            echo "$u38_unnecessary_apache_file 디렉터리를 재귀적으로 탐색합니다." >> $target
                            echo "$(tree $u38_unnecessary_apache_file)" >> $target
                        else
                            u38_idx=$((u38_idx+1))

                        fi
                    done
                    if [ $u38_idx -eq 0 ];then
                        echo "$u38_unnecessary_apache_home 경로 내에 파일 및 디렉터리가 존재하지 않습니다." >> $target
                    fi
                fi
            fi
        else
            for i in "/etc/httpd/conf.d/*";do
                u38_documentroot=$(grep -iR 'documentroot' /etc/apache2/* | grep -v "#" | awk -F':' '{print $2}' | awk '{print $2}' | tr -d '"')
                if [ -n "$u38_documentroot" ];then
                    u38_unnecessary_apache_home=$(ls -ld "$u38_documentroot/htdocs/manual" 2> /dev/null)
                    if [ -d "$u38_unnecessary_apache_home" ];then
                        echo "$u38_unnecessary_apache_home 경로가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                        u38_safe_check=$((u38_safe_check+1))
                        for u38_unnecessary_apache_file in "$u38_unnecessary_apache_home/*";do
                            if [ -f "$u38_unnecessary_apache_file" ];then
                                echo "$u38_unnecessary_apache_file 파일이 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                                u38_safe_check=$((u38_safe_check+1))
                            elif [ -d "$u38_unnecessary_apache_file" ];then
                                echo "$u38_unnecessary_apache_file 디렉터리가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                                u38_safe_check=$((u38_safe_check+1))
                                echo "$u38_unnecessary_apache_file 디렉터리를 재귀적으로 탐색합니다." >> $target
                                echo "$(tree $u38_unnecessary_apache_file)" >> $target
                            else
                                u38_idx=$((u38_idx+1))

                            fi
                        done
                        if [ $u38_idx -eq 0 ];then
                            echo "$u38_unnecessary_apache_home 경로 내에 파일 및 디렉터리가 존재하지 않습니다." >> $target
                        fi
                    else
                        u38_unnecessary_apache_home=$(ls -ld "$u38_documentroot/manual" 2> /dev/null)
                        if [ -d "$u38_unnecessary_apache_home" ];then
                            echo "$u38_unnecessary_apache_home 경로가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                            u38_safe_check=$((u38_safe_check+1))
                            for u38_unnecessary_apache_file in "$u38_unnecessary_apache_home/*";do
                                if [ -f "$u38_unnecessary_apache_file" ];then
                                    echo "$u38_unnecessary_apache_file 파일이 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                                    u38_safe_check=$((u38_safe_check+1))
                                elif [ -d "$u38_unnecessary_apache_file" ];then
                                    echo "$u38_unnecessary_apache_file 디렉터리가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                                    u38_safe_check=$((u38_safe_check+1))
                                    echo "$u38_unnecessary_apache_file 디렉터리를 재귀적으로 탐색합니다." >> $target
                                    echo "$(tree $u38_unnecessary_apache_file)" >> $target
                                else
                                    u38_idx=$((u38_idx+1))

                                fi
                            done
                            if [ $u38_idx -eq 0 ];then
                                echo "$u38_unnecessary_apache_home 경로 내에 파일 및 디렉터리가 존재하지 않습니다." >> $target
                            fi
                        fi
                    fi
                fi
            done
        fi     
    fi
done
u38_idx=0
for u38_unnecessary_dir in "${u38_unnecessary_dirs[@]}";do
    echo "$u38_unnecessary_dir 경로에 대해 점검합니다." >> $target
    if [ -d "$u38_unnecessary_dir" ];then
         for u38_dected_file in "$u38_unnecessary_dir";do
            if [ -f "$u38_dected_file" ];then
                echo "$u38_unnecessary_dir 경로에서 $u38_dected_file 파일이 식별되었습니다. 불필요한 파일일 경우 삭제 바랍니다." >> $target
                u38_safe_check=$((u38_safe_check+1))
            elif [ -d "$u38_dected_file" ];then
                echo "$u38_dected_file 디렉터리가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                u38_safe_check=$((u38_safe_check+1))
                echo "$u38_dected_file 디렉터리를 재귀적으로 탐색합니다." >> $target
                echo "$(tree $u38_dected_file)" >> $target
            else
                u38_idx=$((u38_idx+1))

            fi
         done
    else
        echo "$u38_unnecessary_dir 경로가 존재하지 않습니다." >> $target
    fi  
done

for u38_unnecessary_file in "${u38_unnecessary_files[@]}";do
    if [ -f "$u38_unnecessary_file" ];then
        echo "$u38_unnecessary_file 파일이 존재합니다. 불필요한경우 삭제 바랍니다." >> $target
        u38_safe_check=$((u38_safe_check+1))
        u38_idx=$((u38_idx+1))
    else
        echo "$u38_unnecessary_file 파일은 존재하지 않습니다." >> $target
    fi
done
if [ $u38_idx -eq 0 ];then
    echo "기본적으로 불필요한 파일은 발견되지 않았습니다. 추가적인 수동 점검을 권장합니다." >> $target
fi
for u38_unnecessary_file_sample in "$u38_unnecessary_files_sample";do
    if [ -f "$u38_unnecessary_file_sample" ];then >> $target
        echo "$u38_unnecessary_file_sample 파일이 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
        u38_safe_check=$((u38_safe_check+1))
    fi
done

if [[ $u38_safe_check -ge 1 ]];then
    u38=$((u38+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u38 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u38_Service_Management=1
fi