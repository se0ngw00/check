#!/bin/bash
set -uo pipefail

START_TIME=$SECONDS
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
RESULT_DIR="$BASE_DIR/results"
mkdir -p "$RESULT_DIR"

TEST_MODE=0
if [[ "${1:-}" == "--test" ]]; then
  TEST_MODE=1
fi

RESULT_PREFIX="$(date +%Y%m%d-%H%M%S)"
TOTAL_FILE="$RESULT_DIR/${RESULT_PREFIX}.total"
VULN_FILE="$RESULT_DIR/${RESULT_PREFIX}.vuln"

# ---------------- Timer ----------------
TIMER_RUNNING=1
show_timer() {
  while [ "$TIMER_RUNNING" -eq 1 ]; do
    elapsed=$((SECONDS - START_TIME))
    printf "\r[Running] Elapsed time: %dm %02ds"       $((elapsed/60)) $((elapsed%60))
    sleep 1
  done
}

cleanup() {
  TIMER_RUNNING=0
  [ -n "${TIMER_PID:-}" ] && kill "$TIMER_PID" 2>/dev/null
  echo
}

trap cleanup INT TERM

show_timer &
TIMER_PID=$!

# ---------------- TEST MODE ----------------
if [ "$TEST_MODE" -eq 1 ]; then
  echo "[TEST MODE] Result file generation test" > "$TOTAL_FILE"
  echo "[TEST MODE] No vulnerabilities detected" > "$VULN_FILE"

  elapsed=$((SECONDS - START_TIME))
  echo
  echo "Total execution time: $((elapsed/60))m $((elapsed%60))s"
  echo "Results:"
  echo "  $TOTAL_FILE"
  echo "  $VULN_FILE"
  cleanup
  exit 0
fi

# ---------------- REAL CHECK ----------------
. /etc/os-release
if [[ "$ID" =~ (centos|rhel|rocky|almalinux) ]]; then
  CHECK_DIR="$BASE_DIR/checks/rhel"
else
  CHECK_DIR="$BASE_DIR/checks/ubuntu"
fi

for f in "$CHECK_DIR"/U-*.sh; do
  id=$(basename "$f" .sh)
  output=$(bash "$f" 2>&1)

  echo "===== $id =====" >> "$TOTAL_FILE"
  echo "$output" >> "$TOTAL_FILE"
  echo >> "$TOTAL_FILE"

  # Method A: always review required
  echo "$id REVIEW_REQUIRED" >> "$VULN_FILE"
done

elapsed=$((SECONDS - START_TIME))
echo
echo "Total execution time: $((elapsed/60))m $((elapsed%60))s"
echo "Results:"
echo "  $TOTAL_FILE"
echo "  $VULN_FILE"

cleanup
