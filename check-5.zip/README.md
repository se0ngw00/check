check-5: test mode generates files and prints result paths
