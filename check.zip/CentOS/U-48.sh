cat << EOF
===== [U-48] Setting the minimum password usage period              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-48 패스워드 최소 사용기간 설정              " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 사용자가 자주 패스워드를 변경할 수 없도록 하고 관련 설정(최근 암호 기억)과 함께 시스템에 적용하여 패스워드 변경 전에 사용했던 패스워드를 재사용 할 수 없도록 방지하는지 확인하기 위함" >> $target
echo "보안위협 : ※ 최소 사용기간이 설정되어 있지 않아 반복적으로 즉시 변경이 가능한 경우 이전 패스워드 기억 횟수를 설정하여도 반복적으로 즉시 변경하여 이전 패스워드로 설정이 가능함" >> $target
echo "+판단기준 양호 🔘: 패스워드 최소 사용기간이 1일 이상 설정되어 있는 경우" >> $target
echo "+판단기준 취약 🚫: 패스워드 최소 사용기간이 설정되어 있지 않는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u48_Account_Management=0
u48_safe_check=0
u48=0
if [ -f "/etc/login.defs" ];then
    echo "패스워드 최소길이 설정파일인 /etc/login.defs 파일이 존재합니다." >> $target
    u48_logindefs_mindays=$(grep -v "^\s*#" "/etc/login.defs" | grep -i "PASS_MIN_DAYS" | awk '{print $2}')
    if [ -n "$u48_logindefs_mindays" ];then
        if [ $u48_logindefs_mindays -le 1 ];then
            echo "패스워드 최소 사용기간이 1 미만으로 부적절하게 설정되어 있습니다." >> $target
            echo "현재 설정 값 : $u48_logindefs_mindays" >> $target
            u48_safe_check=$((u48_safe_check+1))
        else
            echo "패스워드 최소 사용기간이 1 이상으로 적절하게 설정되어 있습니다." >> $target
        fi
    else
        echo "/etc/login.defs 파일에 패스워드 최소 기간 설정값이 존재하지 않습니다." >> $target
        u48_safe_check=$((u48_safe_check+1))
    fi
else
    echo "패스워드 최소길이 설정파일인 /etc/login.defs 파일이 존재하지 않습니다." >> $target
fi

if [ $u48_safe_check -ge 1 ];then
    u48=$((u48+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u48 -ge 1 ]];then
    Mid=$((Mid+1))
    Account_Management=$((Account_Management+1))
    u48_Account_Management=1
fi