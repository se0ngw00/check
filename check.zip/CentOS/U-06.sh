cat << EOF
===== [U-06] File and Directory Owner Settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-06   파일 및 디렉터리 소유자 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 소유자가 존재하지 않는 파일 및 디렉터리를 삭제 및 관리하여 임의의 사용자가 해당파일을 열람, 수정하는 행위를 사전에 차단하기 위함" >> $target
echo "보안위협 : 소유자가 존재하지 않는 파일의 UID와 동일한 값으로 특정계정의 UID값을 변경하면 해당 파일의 소유자가 되어 모든 작업이 가능함" >> $target
echo "+판단기준 양호 🔘: 소유자가 존재하지 않는 파일 및 디렉터리가 존재하지 않는 경우" >> $target
echo "+판단기준 취약 🚫: 소유자가 존재하지 않는 파일 및 디렉터리가 존재하는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-6 점검 결과" >> $result
u6=0
u6_safe_check=0
u6_Files_Directory_Management=0
echo "#소유자 또는 그룹이 없는 파일은 파일 속성 해당 필드에 숫자로 표시됨#" >> $target
declare -a u6_file_list
declare -a u6_dir_list

# find 명령어의 출력을 배열에 저장
mapfile -t u6_noowner_lists < <(find / \( -nouser -o -nogroup \) -print 2> /dev/null)

# 파일 및 디렉터리 경로를 분리하여 배열에 저장
for u6_noowner_list in "${u6_noowner_lists[@]}"; do
    if [[ -e "$u6_noowner_list" ]]; then
        if [[ -f "$u6_noowner_list" ]]; then
            u6_file_list+=("$u6_noowner_list")
        elif [[ -d "$u6_noowner_list" ]]; then
            u6_dir_list+=("$u6_noowner_list")
        fi
    fi
done

# 파일 목록을 출력
# #은 배열의 길이를 얻는데 사용됨
if [[ ${#u6_file_list[@]} -gt 0 ]]; then
    u6_safe_check=$((u6_safe_check+1))
    echo "소유자가 존재하지 않는 파일 목록:" >> "$target"
    for u6_file in "${u6_file_list[@]}"; do
        echo "파일: $u6_file" >> "$target"
        ls -l "$u6_file" >> "$target"
    done
else
    echo "소유자가 존재하지 않는 파일이 없습니다." >> "$target"
fi

# 디렉터리 목록을 출력
if [[ ${#u6_dir_list[@]} -gt 0 ]]; then
    u6_safe_check=$((u6_safe_check+1))
    echo "소유자가 존재하지 않는 디렉터리 목록:" >> "$target"
    for u6_dir in "${u6_dir_list[@]}"; do
        u6=$((u6 + 1))
        echo "디렉터리: $u6_dir" >> "$target"
        ls -ld "$u6_dir" >> "$target"
    done
else
    echo "소유자가 존재하지 않는 디렉터리가 없습니다." >> "$target"
fi

if [ $u6_safe_check -ge 1 ];then
    u6=$((u6+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u6 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u6_Files_Directory_Management=1
fi
