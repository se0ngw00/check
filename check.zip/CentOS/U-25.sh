cat << EOF
===== [U-25] NFS access control              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-25 NFS 접근 통제               " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 접근권한이 없는 비인가자의 접근을 통제함" >> $target
echo "+보안위협 : 접근제한 설정이 적절하지 않을 경우 인증절차 없이 비인가자의 디렉터리나 파일의 접근이 가능하며, 해당 공유 시스템에 원격으로 마운트하여 중요 파일을 변조하거나 유출할 위험이 있음" >> $target
echo "+판단기준 양호 🔘: 불필요한 NFS 서비스를 사용하지 않거나, 불가피하게 사용 시 everyone 공유를 제한한 경우" >> $target
echo "+판단기준 취약 🚫: 불필요한 NFS 서비스를 사용하고 있고, everyone 공유를 제한하지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u25=0
u25_Service_Management=0
u25_safe_check=0

if [ -f "/etc/exports" ];then
    echo "/etc/exports 파일이 존재합니다" >> $target
    u25_nfsoptions=$(grep -Ev "^\s*#" /etc/exports | grep "*" | awk -F'(' '{print $2}' | sed 's/[\(|\)]//g')
    if [ -n "$u25_nfsoptions" ];then
        echo "NFS 설정 파일 내에  everyone 설정을 통해 모든 사용자가 접근할 수 있도록 설정되어 있습니다." >> $target
        u25_safe_check=$((u25_safe_check+1))
        echo "설정된 값 : $u25_nfsoptions" >> $target
        IFS=',' read -ra u25_nfsoptions_arry <<< "$u25_nfsoptions"
        for u25_nfsoption in "${u25_nfsoptions_arry[@]}";do
            case "$u25_nfsoption" in
                rw)
                    echo "$u25_nfsoption 옵션이 설정되어 읽기/쓰기 모드를 허용합니다." >> $target
                    ;;
                sync)
                    echo "$u25_nfsoption 옵션이 설정되어 데이터를 디스크에 즉시 쓰고 응답합니다." >> $target
                    ;;
                no_root_squash)
                    echo "$u25_nfsoption 옵션이 설정되어 클라이언트의 루트 사용자도 서버에서는 일반 사용자 권한으로 접근하도록 허용됩니다." >> $target
                    ;;  
                no_subtree_check)
                    echo "$u25_nfsoption 옵션이 설정되어 서브트리 검사를 수행하지 않습니다." >> $target
                    ;;
                *)
                    echo "$u25_nfsoption 옵션이 설정되어 있습니다." >> $target
                    ;;
            esac
        done
    else
        echo "/etc/exports 파일은 존재하지만 관련 설정 값이 존재하지 않습니다." >> $target
    fi
else
    echo "/etc/exports 파일이 존재하지 않습니다."  >> $target
fi

if [[ $u25_safe_check -ge 1 ]];then
    u25=$((u25+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u25 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u25_Service_Management=1
fi