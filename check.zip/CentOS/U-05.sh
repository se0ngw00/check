
cat << EOF
===== [U-05] root home, pass directory permissions, and pass settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-05  root홈, 패스 디렉터리 권한 및 패스 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 비인가자가 불법적으로 생성한 디렉터리 및 명령어를 우선으로 실행되지 않도록 설정하기 위해 환경변수 점검이 필요함" >> $target
echo "보안위협 : root 계정의 PATH(환경변수)에 정상적인 관리자 명령어(예: ls, mv, cp등)의 디렉터리 경로 보다 현재 디렉터리를 지칭하는 “.” 표시가 우선하면 현재 디렉터리에 변조된 명령어를 삽입하여 관리자 명령어 입력 시 악의적인 기능이 실행 될 수 있음" >> $target
echo "+판단기준 양호 🔘: PATH 환경변수에 “.” 이 맨 앞이나 중간에 포함되지 않은 경우" >> $target
echo "+판단기준 취약 🚫: PATH 환경변수에 “.” 이 맨 앞이나 중간에 포함되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-5 점검 결과" >> $result
u5=0
u5_safe_check=0
u5_Files_Directory_Management=0

u5_etc_configure_files=(
    "/etc/profile"
    "/etc/.login"
    "/etc/bashrc"
)

u5_home_configure_files=(
    ".profile"
    ".cshrc"
    ".login"
    "kshrc"
    ".bash_profile"
)

if [[ $PATH =~ (^|:)(\.|::)(:|$) ]]; then 
    echo "PATH 환경변수에 . 및 :: 문자가 PATH 변수의 맨 앞 혹은 중간에 위치하고 있습니다. 해당 문자를 맨 마지막으로 이동하십시오." >> $target
    u5_safe_check=$((u5_safe_check+1))
else
    echo "PATH 환경변수에 . 및 :: 문자가 올바른 위치에 존재합니다." >> $target
fi


for u5_etc_configure_file in "${u5_etc_configure_files[@]}"; do
    echo -e "${RED}Checking file: $u5_etc_configure_file${NC}" >> $target
    if [ -e "$u5_etc_configure_file" ]; then
        # 파일이 존재하면 권한을 확인하는 구문 추가하기
        #ls -l "$etc_configure_file"
        if grep -qiE "^#\s*PATH\s*=" "$u5_etc_configure_file"; then  
            echo "PATH 설정 구문이 주석처리되어 비활성화 되어 있습니다." >> $target
            echo "--------------------------------------" >> $target
        else
            if grep -qiE "^\s*PATH\s*=" "$u5_etc_configure_file"; then
                grep -iE "^\s*PATH\s*=" "$u5_etc_configure_file" | while read -r line ; do
                    echo "PATH setting found: $u5_line" >> $target
                    # PATH 설정에서 . 또는 :: 문자가 맨 앞이나 중간에 포함되어 있는지 확인
                    if echo "$u5_line" | grep -iqE "(^|:)(\.|::)(:|$)"; then
                        echo "PATH 설정 값에 “.”, “::”이 맨 앞 혹은 중간에 위치하고 있습니다.- 취약" >> $target
                        echo "--------------------------------------" >> $target
                        u5_safe_check=$((u5_safe_check+1))
                    else
                        echo "PATH 관련 설정이 안전하게 설정되어 있습니다." >> $target
                        echo "--------------------------------------" >> $target
                    fi
                done
            else
                echo "PATH 관련 설정이 존재하지 않습니다." >> $target
                echo "--------------------------------------" >> $target
            fi
        fi

        #if 

        #fi
    else
        # 파일이 존재하지 않으면 메시지 출력
        echo "$u5_configure_file 파일이 존재하지 않습니다.." >> $target
        echo "--------------------------------------" >> $target
    fi
done

u5_check_users=($(cat /etc/passwd | egrep -v '/sbin|sync|false' | awk -F':' '{print $1}'))
for u5_check_user in "${u5_check_users[@]}";do
    u5_user_home=($(getent passwd "$u5_check_user" | awk -F':' '{print$6}'))
    if [ -d "$u5_user_home" ];then
        echo "--------------------------------------" >> $target
        echo "$u5_check_user 의 홈 디렉터리가 존재합니다." >> $target
        for u5_home_configure_file in "${u5_home_configure_files[@]}";do
            echo -e "${RED}Checking file: $u5_user_home/$u5_home_configure_file${NC}" >> $target
            if [ -e "$u5_user_home/$u5_home_configure_file" ];then
                echo "$u5_user_home/$u5_home_configure_file 파일이 존재합니다." >> $target

                if grep -qiE "^#\s*PATH\s*=" "$u5_user_home/$u5_home_configure_file"; then  
                    echo "PATH 설정 구문이 주석처리되어 비활성화 되어 있습니다." >> $target
                    echo "--------------------------------------" >> $target
                else
                    if grep -qiE "^\s*PATH\s*=" "$u5_user_home/$u5_home_configure_file"; then
                        grep -iE "^\s*PATH\s*=" "$u5_user_home/$u5_home_configure_file" | while read -r line ; do
                            echo "PATH setting found: $line" >> $target
                            # PATH 설정에서 . 또는 :: 문자가 맨 앞이나 중간에 포함되어 있는지 확인
                            if echo "$u5_line" | grep -qiE "(^|:)(\.|::)(:|$)"; then
                                echo "PATH 설정 값에 “.”, “::”이 맨 앞 혹은 중간에 위치하고 있습니다.- 취약" >> $target
                                echo "--------------------------------------" >> $target
                                u5_safe_check=$((u5_safe_check+1))
                            else
                                echo "PATH 관련 설정이 안전하게 설정되어 있습니다." >> $target
                                echo "--------------------------------------" >> $target
                            fi
                        done
                    else
                        echo "PATH 관련 설정이 존재하지 않습니다." >> $target
                        echo "--------------------------------------" >> $target
                    fi
                fi

            else
                echo "$u5_user_home/$u5_home_configure_file 파일이 존재하지 않습니다." >> $target
                echo "--------------------------------------" >> $target
            fi
        done
    else
        echo "$u5_check_user 의 홈 디렉턱리가 존재하지 않습니다." >> $target
        echo "--------------------------------------" >> $target
    fi
done


if [ $u5_safe_check -ge 1 ];then
    u5=$((u5+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u5 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u5_Files_Directory_Management=1
fi