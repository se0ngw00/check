cat << EOF
===== [U-23] Disabling a Service Vulnerable to DoS Attacks              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-23 DoS 공격에 취약한 서비스 비활성화               " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 시스템 보안성을 높이기 위해 취약점이 많이 발표된 echo, discard, daytime, chargen, ntp, snmp 등 서비스를 중지함" >> $target
echo "+보안위협 :  해당 서비스가 활성화되어 있는 경우 시스템 정보 유출 및 DoS(서비스 거부 공격)의 대상이 될 수 있음" >> $target
echo "+판단기준 양호 🔘: 사용하지 않는 DoS 공격에 취약한 서비스가 비활성화 된 경우" >> $target
echo "+판단기준 취약 🚫: 사용하지 않는 DoS 공격에 취약한 서비스가 활성화 된 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
# ntp 서비스는 보통 별도의 데몬(ntpd, chronyd)으로 관리됨 (inetd.conf에는 없음)
# snmp 서비스는 별도의 데몬(snmpd)으로 관리됨 (inetd.conf에는 없음)
# dns 서비스는 보통 별도의 데몬(named, systemd-resolved)으로 관리됨 (inetd.conf에는 없음)
# smtp 서비스는 보통 별도의 데몬(postfix, exim, sendmail)으로 관리됨 (inetd.conf에는 없음)

# ntpd 또는 chronyd는 /etc/xinetd.d 파일이 아닌 별도의 데몬으로 관리되며, /etc/xinetd.d에는 항목이 없음 systemctl로 상태를 확인하고 설정할 수 있음
# snmp 는 /etc/xinetd.d 파일이 아닌 별도의 데몬으로 관리되며, /etc/xinetd.d에는 항목이 없음 systemctl로 상태를 확인하고 설정할 수 있음
# named (BIND) 또는 systemd-resolved는 /etc/xinetd.d 파일이 아닌 별도의 데몬으로 관리되며, /etc/xinetd.d에는 항목이 없음. 대신 systemctl로 상태를 확인하고 설정할 수 있음
# (smtp) postfix, exim, 또는 sendmail은 /etc/xinetd.d 파일이 아닌 별도의 데몬으로 관리되며, /etc/xinetd.d에는 항목이 없음. 대신 systemctl로 상태를 확인하고 설정할 수 있음:
u23=0
u23_Service_Management=0
u23_safe_check=0
u23_service_checks=("echo" "discard" "daytime" "chargen" "ntp" "snmp" "tcpmux" "time" "smtp" "domain")
u23_service_ports=("7" "9" "13" "19" "123" "161" "68" "37" "25" "53")
u23_inetd_checks=("echo" "discard" "daytime" "chargen" "tcpmux" "time")
u23_xinetd_checks=("echo" "discard" "daytime" "chargen" "tcpmux" "time")
u23_systemctl_checks=("ntpd" "chronyd" "snmpd" "named" "systemd-resolved" "postfix" "exim" "sendmail")
u23_length=${#u23_service_checks[@]}
# systemctl 서비스 체크
for u23_systemctl_check in "${u23_systemctl_checks[@]}"; do
    if systemctl is-active --quiet "$u23_systemctl_check"; then
        echo "현재 시스템에 $u23_systemctl_check 서비스가 활성화 되어 있습니다. 불필요한 경우 비활성화가 이루어져야 합니다." >> $target
        u23_safe_check=$((u23_safe_check+1))
    else
        echo "현재 시스템에 $u23_systemctl_check 서비스가 비활성화 되어 있습니다." >> $target
    fi
done

# 네트워크 포트 체크
u23_netstat_ports=$(netstat -tuln | awk '{print $4}' | awk -F':' '{print $2}')

for ((i=0; i<$u23_length; i++)); do
    u23_port=${u23_service_ports[$i]}
    u23_service=${u23_service_checks[$i]}
    
    if echo "$u23_netstat_ports" | grep -qE "^$u23_port$"; then
        echo "$u23_service 서비스가 $u23_port 번 포트번호로 서비스가 동작중입니다." >> $target
    else
        u23_newport=$(grep -wE "^$u23_service\s+" /etc/services | awk '{print $2}' | awk -F'/' '{print $1}' | head -n 1)
        if [ -n "$u23_newport" ]; then
            echo "$u23_service 서비스가 $u23_newport 포트번호로 설정되어 있습니다." >> $target
            if echo "$u23_netstat_ports" | grep -qE "^$u23_newport$"; then
                echo "$u23_service 서비스가 $u23_newport 포트번호로 서비스가 동작중입니다." >> $target
                u23_safe_check=$((u23_safe_check+1))
            else
                echo "$u23_service 서비스가 $u23_newport 포트번호로 동작중인 서비스가 없습니다." >> $target
            fi
        else
            echo "$u23_service 서비스가 /etc/services 파일에 정의되어 있지 않습니다." >> $target
        fi
    fi        
done

# inetd 서비스 체크
if [ -f "/etc/inetd.conf" ]; then
    for u23_inetd_check in "${u23_inetd_checks[@]}"; do
        if grep -qiwE "^\s*$u23_inetd_check" /etc/inetd.conf; then
            echo "/etc/inetd.conf 파일에서 $u23_inetd_check 서비스가 활성화 되어 있습니다." >> $target
            u23_safe_check=$((u23_safe_check+1))
        else
            echo "/etc/inetd.conf 파일에서 $u23_inetd_check 서비스가 비활성화 되어 있습니다." >> $target
        fi
    done
else
    echo "/etc/inetd.conf 파일이 존재하지 않습니다." >> $target
fi

# xinetd 서비스 체크
if [ -d "/etc/xinetd.d" ]; then
    for u23_xinetd_check in "${u23_xinetd_checks[@]}"; do
        if [ -f "/etc/xinetd.d/$u23_xinetd_check" ]; then
            u23_xinetd_conf=$(grep -iE "\s*disable" "/etc/xinetd.d/$u23_xinetd_check" | grep -v "^#" | awk '{print $3}' | head -n 1)
            if [[ "$u23_xinetd_conf" == "no" ]]; then
                echo "/etc/xinetd.d/$u23_xinetd_check 파일내에 $u23_xinetd_check 항목이 활성화 되어 있습니다." >> $target
                u23_safe_check=$((u23_safe_check+1))
            else
                echo "/etc/xinetd.d/$u23_xinetd_check 파일내에 $u23_xinetd_check 항목이 비활성화 되어 있습니다." >> $target
            fi
        else
            echo "/etc/xinetd.d/$u23_xinetd_check 파일이 존재하지 않습니다." >> $target
        fi
    done
else
    echo "/etc/xinetd.d 디렉터리가 존재하지 않습니다." >> $target
fi

if [[ $u23_safe_check -ge 1 ]];then
    u23=$((u23+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u23 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u23_Service_Management=1
fi