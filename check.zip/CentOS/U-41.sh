cat << EOF
===== [U-41] Separation of Web Service Areas              =====
=====                  Chaking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-41 웹서비스 영역의 분리              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 웹 서비스 영역과 시스템 영역을 분리시켜서 웹 서비스의 침해가 시스템 영역으로 확장될 가능성을 최소화하기 위함" >> $target
echo "+보안위협 : 웹 서버의 루트 디렉터리와 OS의 루트 디렉터리를 다르게 지정하지 않았을 경우, 비인가자가 웹 서비스를 통해 해킹이 성공할 경우 시스템 영역까지 접근이 가능하여 피해가 확장될 수 있음" >> $target
echo "+판단기준 양호 🔘: DocumentRoot를 별도의 디렉터리로 지정한 경우" >> $target
echo "+판단기준 취약 🚫: DocumentRoot를 기본 디렉터리로 지정한 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u41=0
u41_Service_Management=0
u41_safe_check=0
u41_apache_files=("/etc/httpd/conf.d/*.conf" "/etc/httpd/sites-available/*.conf" "/etc/httpd/sites-enabled/*.conf")
u41_nginx_files=("/etc/nginx/conf.d/*.conf")
u41_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
u41_idx=0
u41_break=0
u41_home_dected=0
echo "apache, nginx 의 주요 설정파일을 토대로 apache 홈 디렉터리 점검 후 추가 설정 파일 및 디렉터리를 점검하므로, 중복된 결과가 존재할 수 있습니다." >> $target
for u41_apache_home_check in "${u41_apache_home_checks[@]}";do
    u41_apache_home=$(find / -type f -name "$u41_apache_home_check" 2> /dev/null | egrep -v "tmp|temp|swap|swp")
    if [ -f "$u41_apache_home" ];then
        u41_virutalhost=$(grep -v "#" "$u41_apache_home" | awk '/<VirtualHost/,/<\/VirtualHost>/' | sed -n '/<VirtualHost/,/<\/VirtualHost>/p')
        u41_default_documentroot=$(grep -v "#" $u41_apache_home | grep -m 1 -i "^DocumentRoot" | awk '{print $2}' | tr -d '"')
        echo "$u41_apache_home 파일이 존재합니다." >> $target
        u41_home_dected=$((u41_home_dected+1))
        if [ -n "$u41_default_documentroot" ];then
            if [[ "$u41_default_documentroot" == "/usr/local/apache/htdocs" || "$u41_default_documentroot" == "/usr/local/apache2/htdocs" || "$u41_default_documentroot" ==  "/var/www/html" ]];then
                echo "기본 서버의 DocumentRoot가 $u41_default_documentroot 로 설정되어, 기본 디렉터리로 지정되어 있는 설정값이 존재합니다. $u41_apache_home 파일을 확인하십시오." >> $target
                u41_safe_check=$((u41_safe_check+1))
            else
                echo "기본 서버의 DocumentRoot가 기본 디렉터리 이외의 별도의 디렉터리로 적절하게 설정되어 있습니다." >> $target
            fi
        else
            echo "$u41_apache_home_check 파일은 존재하지만, 관련 설정값이 존재하지 않습니다." >> $target
        fi
        if [ -n "$u41_virutalhost" ];then
            echo "가상 호스트 설정이 존재합니다." >> $target
            u41_virutalhost_documentroot=($(grep -v "#" "$u41_apache_home" | awk '/<VirtualHost/,/<\/VirtualHost>/' | sed -n '/<VirtualHost/,/<\/VirtualHost>/p' | grep -E "(DocumentRoot|ServerName)" | grep -i 'DocumentRoot' | awk '{print $2}' | tr -d '"' ))
            u41_virutalhost_servdrname=($(grep -v "#" "$u41_apache_home" | awk '/<VirtualHost/,/<\/VirtualHost>/' | sed -n '/<VirtualHost/,/<\/VirtualHost>/p' | grep -E "(DocumentRoot|ServerName)" | grep -i 'ServerName' | awk '{print $2}' | tr -d '"' ))
            for (( u41_i=0; u41_i<${#u41_virutalhost_documentroot[@]}; u41_i++ )); do
                if [[ "${u41_virutalhost_documentroot[$u41_i]}" == "/usr/local/apache/htdocs" || "${u41_virutalhost_documentroot[$u41_i]}" == "/usr/local/apache2/htdocs" || "${u41_virutalhost_documentroot[$u41_i]}" ==  "/var/www/html" ]]; then
                    echo "가상 호스트 주소 ${u41_virutalhost_servdrname[$u41_i]} 의 DocumentRoot 값이 ${u41_virutalhost_documentroot[$u41_i]} 인 기본 디렉터리로 설정되어 있습니다." >> $target
                    u41_safe_check=$((u41_safe_check+1))
                else
                    echo "가상 호스트 주소 ${u41_virutalhost_servdrname[$u41_i]} DocumentRoot 값이 기본 디렉터리 이외의 별도의 디렉터리로 적절하게 설정되어 있습니다." >> $target
                fi
            done
            echo "가상 호스트 설정의 전체 값" >> $target
            echo "$u41_virutalhost" >> $target
        else
            echo "가상 호스트 설정은 따로 존재하지 않습니다." >> $target
        fi
    else
        u41_idx=0
        if [[ $u41_break -eq 1 && $u41_home_dected -eq 1 ]];then
            break 
        fi
        u41_break=$((u41_break+1))
        for u41_apache_file in "${u41_apache_files[@]}";do
            for u41_apache_check in $u41_apache_file;do
                if [ -f "$u41_apache_check" ];then
                    u41_virutalhost=$(grep -v "#" "$u41_apache_check" | awk '/<VirtualHost/,/<\/VirtualHost>/' | sed -n '/<VirtualHost/,/<\/VirtualHost>/p')
                    u41_default_documentroot=$(grep -v "#" $u41_apache_check | grep -m 1 -i "^DocumentRoot" | awk '{print $2}' | tr -d '"')
                    echo "$u41_apache_check 파일이 존재합니다." >> $target
                    u41_home_dected=$((u41_home_dected+1))
                    if [ -n "$u41_default_documentroot" ];then
                        if [[ "$u41_default_documentroot" == "/usr/local/apache/htdocs" || "$u41_default_documentroot" == "/usr/local/apache2/htdocs" || "$u41_default_documentroot" ==  "/var/www/html" ]];then
                            echo "기본 서버의 DocumentRoot가 $u41_default_documentroot 로 설정되어, 기본 디렉터리로 지정되어 있는 설정값이 존재합니다. $u41_apache_check 파일을 확인하십시오." >> $target
                            u41_safe_check=$((u41_safe_check+1))
                        else
                            echo "기본 서버의 DocumentRoot가 기본 디렉터리 이외의 별도의 디렉터리로 적절하게 설정되어 있습니다." >> $target
                        fi
                    else
                        echo "$u41_apache_check 파일은 존재하지만, 관련 설정값이 존재하지 않습니다." >> $target
                    fi
                    if [ -n "$u41_virutalhost" ];then
                        echo "가상 호스트 설정이 존재합니다." >> $target
                        u41_virutalhost_documentroot=($(grep -v "#" "$u41_apache_check" | awk '/<VirtualHost/,/<\/VirtualHost>/' | sed -n '/<VirtualHost/,/<\/VirtualHost>/p' | grep -E "(DocumentRoot|ServerName)" | grep -i 'DocumentRoot' | awk '{print $2}' | tr -d '"' ))
                        u41_virutalhost_servdrname=($(grep -v "#" "$u41_apache_check" | awk '/<VirtualHost/,/<\/VirtualHost>/' | sed -n '/<VirtualHost/,/<\/VirtualHost>/p' | grep -E "(DocumentRoot|ServerName)" | grep -i 'ServerName' | awk '{print $2}' | tr -d '"' ))
                        for (( u41_i=0; u41_i<${#u41_virutalhost_documentroot[@]}; u41_i++ )); do
                            if [[ "${u41_virutalhost_documentroot[$u41_i]}" == "/usr/local/apache/htdocs" || "${u41_virutalhost_documentroot[$u41_i]}" == "/usr/local/apache2/htdocs" || "${u41_virutalhost_documentroot[$u41_i]}" ==  "/var/www/html" ]]; then
                                echo "가상 호스트 주소 ${u41_virutalhost_servdrname[$u41_i]} 의 DocumentRoot 값이 ${u41_virutalhost_documentroot[$u41_i]} 인 기본 디렉터리로 설정되어 있습니다." >> $target
                                u41_safe_check=$((u41_safe_check+1))
                            else
                                echo "가상 호스트 주소 ${u41_virutalhost_servdrname[$u41_i]} DocumentRoot 값이 기본 디렉터리 이외의 별도의 디렉터리로 적절하게 설정되어 있습니다." >> $target
                            fi
                        done
                        echo "가상 호스트 설정의 전체 값" >> $target
                        echo "$u41_virutalhost" >> $target
                    else
                        echo "가상 호스트 설정은 따로 존재하지 않습니다." >> $target
                    fi
                fi
            done
        done
    fi
done

if [ -f "/etc/nginx/nginx.conf" ];then
    echo "/etc/nginx/nginx.conf 파일이 존재합니다." >> $target
    u41_default_root=(grep -m 1 -i "root" "/etc/nginx/nginx.conf")
    u41_default_aliass=($(grep -i "alias" "/etc/nginx/nginx.conf"))
    u41_virutalhost_roots=($(grep -i "root" /etc/nginx/nginx.conf | sed '1d'))
    if [ -n "$u41_default_root" ];then
        if [[ "$u41_default_root" == "/usr/share/nginx/html" || "$u41_default_root" == "/var/www/html" ]];then
            echo "nginx 설정 파일 내에 root 지시자로 인해 기본 디렉터리인 $u41_default_root 로 설정되어 있습니다." >> $target
            u41_safe_check=$((u41_safe_check+1))
        else
            echo "nginx 설정 파일 내에 root 지시자가 기본 디렉터리 이외의 디렉터리로 적절하게 설정되어 있습니다." >> $target
        fi
    else
        echo "/etc/nginx/nginx.conf 파일은 존재하지만 관련 설정값이 존재하지 않습니다." >> $target
    fi
    if [ -n "$u41_default_aliass" ];then
        echo "/etc/nginx/nginx.conf 파일내에 alias 설정이 존재합니다." >> $target
        u41_count=1
        for u41_default_alias in "${u41_default_aliass[@]}";do
            if [[ "$u41_default_alias" == "/usr/share/nginx/html" || "$u41_default_alias" == "/var/www/html" ]];then
                echo "$u41_count 번째로 설정된 alias에 설정되어 있는 경로가 기본 디렉터리인 $u41_default_alias 로 설정되어 있습니다." >> $target
                u41_safe_check=$((u41_safe_check+1))
            else
                echo "$u41_count 번째로 설정된 alias에 설정되어 있는 경로가 $u41_default_alias 로 설정되어, 기본 디렉터리 이외의 디렉터리로 적절하게 설정되어 있습니다." >> $target
            fi
            u41_count=$((u41_count+1))
        done
    else
        echo "/etc/nginx/nginx.conf 파일 내에 alias 설정이 존재하지 않습니다." >> $target
    fi
    if [ -n "$u41_virutalhost_root" ];then
        echo "/etc/nginx/nginx.conf 파일 내에 가상 호스트 설정이 존재합니다." >> $target
        u41_count=1
        for u41_virutalhost_root in "${u41_virutalhost_roots[@]}";do
            if [[ "$u41_virutalhost_root" == "/usr/share/nginx/html" || "$u41_virutalhost_root" == "/var/www/html" ]];then
                echo "$u41_count 번째 가상 호스트의 설정 경로가 기본 디렉터리인 $u41_virutalhost_root 로 설정되어 있습니다."
                u41_safe_check=$((u41_safe_check+1))
            else
                echo "$u41_count 번째 가상 호스트 설정 내에 설정되어 있는 경로가 기본 디렉터리 이외의 디렉터리로 적절하게 설정되어 있습니다." >> $target
            fi
            u41_count=$((u41_count+1))
        done
    else
        echo "/etc/nginx/nginx.conf 파일 내에 가상 호스트 설정은 존재하지 않습니다." >> $target
    fi
else 
    echo "/etc/nginx/nginx.conf 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다."  >> $target
    for u41_ngnix_file in "${u41_nginx_files[@]}";do
        for u41_nginx_check in $u41_ngnix_file;do
            if [ -f "$u41_nginx_check" ];then
                echo "$u41_nginx_check 파일이 존재합니다." >> $target
                u41_default_root=(grep -m 1 -i "root" "$u41_nginx_check")
                u41_default_aliass=($(grep -i "alias" "$u41_nginx_check"))
                u41_virutalhost_roots=($(grep -i "root" $u41_nginx_check | sed '1d'))
                if [ -n "$u41_default_root" ];then
                    if [[ "$u41_default_root" == "/usr/share/nginx/html" || "$u41_default_root" == "/var/www/html" ]];then
                        echo "nginx 설정 파일 내에 root 지시자로 인해 기본 디렉터리인 $u41_default_root 로 설정되어 있습니다."  >> $target
                        u41_safe_check=$((u41_safe_check+1))
                    else
                        echo "nginx 설정 파일 내에 root 지시자가 기본 디렉터리 이외의 디렉터리로 적절하게 설정되어 있습니다." >> $target
                    fi
                else
                    echo "$u41_nginx_check 파일은 존재하지만 관련 설정값이 존재하지 않습니다." >> $target
                fi
                if [ -n "$u41_default_aliass" ];then
                    echo "$u41_nginx_check 파일내에 alias 설정이 존재합니다." >> $target
                    u41_count=1
                    for u41_default_alias in "${u41_default_aliass[@]}";do
                        if [[ "$u41_default_alias" == "/usr/share/nginx/html" || "$u41_default_alias" == "/var/www/html" ]];then
                            echo "$u41_count 번째로 설정된 alias 에 설정되어 있는 경로가 기본 디렉터리인 $u41_default_alias 로 설정되어 있습니다." >> $target
                            u41_safe_check=$((u41_safe_check+1))
                        else
                            echo "$u41_count 번째로 설정된 alias 로 설정되어 있는 경로가 $u41_default_alias 로 설정되어, 기본 디렉터리 이외의 디렉터리로 적절하게 설정되어 있습니다." >> $target
                        fi
                        u41_count=$((u41_count+1))
                    done
                else
                    echo "$u41_nginx_check 파일 내에 alias 설정이 존재하지 않습니다." >> $target
                fi
                if [ -n "$u41_virutalhost_root" ];then
                    echo "$u41_nginx_check 파일 내에 가상 호스트 설정이 존재합니다." >> $target
                    for u41_virutalhost_root in "${u41_virutalhost_roots[@]}";do
                        u41_count=1
                        if [[ "$u41_virutalhost_root" == "/usr/share/nginx/html" || "$u41_virutalhost_root" == "/var/www/html" ]];then
                            echo "$u41_count 번째 가상 호스트의 설정 경로가 기본 디렉터리인 $u41_virutalhost_root 로 설정되어 있습니다." >> $target
                            u41_safe_check=$((u41_safe_check+1))
                        else
                            echo "$u41_count 번째 가상 호스트 설정 내에 설정되어 있는 경로가 기본 디렉터리 이외의 디렉터리로 적절하게 설정되어 있습니다." >> $target
                        fi
                        u41_count=$((u41_count+1))
                    done
                else
                    echo "$u41_nginx_check 파일 내에 가상 호스트 설정은 존재하지 않습니다." >> $target
                fi
            fi
        done
    done
    echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
fi

if [[ $u41_safe_check -ge 1 ]];then
    u41=$((u41+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u41 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u41_Service_Management=1
fi