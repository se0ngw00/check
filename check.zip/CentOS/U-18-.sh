cat << EOF
===== [U-18] Access IP and Port Restrictions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-18 접속 IP 및 포트 제한             " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 허용한 호스트만 서비스를 사용하게 하여 서비스 취약점을 이용한 외부자 공격을 방지하기 위함" >> $target
echo "보안위협 :  허용할 호스트에 대한 IP 및 포트제한이 적용되지 않은 경우, Telnet, FTP같은 보안에 취약한 네트워크 서비스를 통하여 불법적인 접근 및 시스템 침해사고가 발생할 수 있음" >> $target
echo "+판단기준 양호 🔘: 접속을 허용할 특정 호스트에 대한 IP 주소 및 포트 제한을 설정한 경우" >> $target
echo "+판단기준 취약 🚫: 접속을 허용할 특정 호스트에 대한 IP 주소 및 포트 제한을 설정하지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-17 점검 결과" >> $result
u18_Files_Directory_Management=0
u18_safe_check=0
u18=0
u18_allowcheck=10
if command -v iptables &> /dev/null; then
    echo "IPtables 서비스가 설치되어 있습니다." >> $target
    if systemctl is-active --quiet "iptables";then
        echo "IPtables 서비스가 사용중입니다." >> $target
        # 모든 ACCEPT 규칙이 *와 0.0.0.0/0으로 설정되어 있는지 확인합니다.
        iptables -L -v -n | grep "ACCEPT" | grep -vE "^Chain" | while read -r u18_iptables_line; do
            # 필드를 분리합니다.
            IFS=' ' read -r -a u18_iptables_fields <<< "$u18_iptables_line"
            # 트래픽 허용 여부를 확인합니다.
            if [[ "${u18_iptables_fields[5]}" == "*" && \
                "${u18_iptables_fields[6]}" == "*" && \
                "${u18_iptables_fields[7]}" == "0.0.0.0/0" && \
                "${u18_iptables_fields[8]}" == "0.0.0.0/0" ]]; then
                # 체크할 체인 배열
                u18_chains=("INPUT" "OUTPUT" "FORWARD")

                # 각 체인에 대해 기본 정책과 규칙 확인
                for u18_chain in "${u18_chains[@]}"; do
                    # 기본 정책 확인
                    u18_default_policy=$(iptables -L $u18_chain -n | grep "Chain $u18_chain" | awk '{print $4}')

                    # 기본 정책이 DROP인지 확인
                    if [ "$u18_default_policy" == "DROP" ]; then
                        # 규칙이 있는지 확인
                        u18_rules=$(iptables -L $u18_chain -v -n | grep -v "^Chain")

                        # 규칙이 없는 경우
                        if [ -z "$u18_rules" ]; then
                            echo "DROP 정책이 기본 정책으로 되어 있지만 규칙이 없으며, 모든 트래픽을 허용하는 정책이 설정되어 있어 취약합니다." >> $target
                            echo "모든 트래픽을 허용하는 규칙: $u18_iptables_line" >> $target
                            u18_allowcheck=$((u18_allowcheck-1))
                            u18_safe_check=$((u18_safe_check+1))
                            break
                        else
                            echo "DROP 정책이 기본 정책으로 되어 있지만 규칙이 존재하며, 모든 트래픽을 허용하는 정책이 설정되어 있어 취약합니다." >> $target
                            echo "모든 트래픽을 허용하는 규칙: $u18_iptables_line" >> $target
                            u18_allowcheck=$((u18_allowcheck-1))
                            u18_safe_check=$((u18_safe_check+1))
                            break
                        fi
                    else
                        echo "기본 정책이 DROP이 아니며, 모든 트래픽을 허용하는 정책이 설정되어 있어 취약합니다." >> $target
                        echo "모든 트래픽을 허용하는 규칙: $u18_iptables_line" >> $target
                        u18_allowcheck=$((u18_allowcheck-1))
                        u18_safe_check=$((u18_safe_check+1))
                        break
                    fi
                done
            fi
        done
        if [[ $u18_allowcheck -eq 10 ]];then
            echo "모든 트래픽을 허용하는 정책이 설정되어 있지 않아 양호합니다." >> $target
        fi
    else
        echo "IPtables 서비스가 사용중이지 않습니다." >> $target
    fi
else
    echo "IPtables 서비스가 설치되어 있지 않습니다."  >> $target
fi
if [ -f "/sbin/ipf" ];then
    ehco "IPfilter를 사용하고 있습니다." >> $target
    u18_ipfilterfiles=("/etc/ipf/ipf.conf" "/etc/ipf/ipf.rules")
    for u18_ipfilterfile in "${u18_ipfilterfiles[@]}";do
        if [ -e "$u18_ipfilterfile" ];then
            if grep -q "pass" "$u18_ipfilterfile" && ! grep -q "block" "$u18_ipfilterfile"; then
                echo "기본 정책이 모든 트래픽을 허용하는 것으로 설정되어 있습니다." >> $target
                u18_safe_check=$((u18_safe_check+1))
                if ipf -l | grep -E "pass in|pass out"; then
                    echo "모든 트래픽을 허용하는 규칙이 발견되었습니다." >> $target
                    u18_allowcheck=$((u18_allowcheck+1))
                    u18_safe_check=$((u18_safe_check+1))
                else
                    echo "모든 트래픽을 허용하는 규칙이 없습니다." >> $target
                fi
            else
                echo "기본 정책에 블록 규칙이 포함되어 있거나 모든 트래픽을 허용하지 않습니다." >> $target
            fi
        else    
            echo "ipfilter설정파일이 존재하지 않습니다." >> $target
        fi 
    done
else
    echo "IPfilter를 사용하고 있지 않습니다." >> $target
fi
# TCP Wrapper를 사용하는지 확인
if [[ -f "/usr/sbin/tcpd" || -x "$(command -v tcpd)" ]]; then
    echo "TCP Wrapper를 사용하고 있습니다." >> $target

    # /etc/hosts.allow 파일 점검
    if [ -f "/etc/hosts.allow" ]; then
        if grep -vq "^\s*#" "/etc/hosts.allow";then
            if grep -iE "^\s*ALL:ALL\s*" "/etc/hosts.allow" | grep -qv "^\s*#"; then
                echo "/etc/hosts.allow 파일에 ALL:ALL 설정이 되어 있어 취약합니다." >> $target
                u18_allowcheck=$((u18_allowcheck+1))
                u18_safe_check=$((u18_safe_check+1))
            else
                echo "/etc/hosts.allow 파일에 ALL:ALL 설정이 되어 있지 않아 양호합니다." >> $target
            fi
        else
            echo "/etc/hosts.allow 파일 내에 설정값들이 존재하지 않습니다." >> $target
        fi
    else
        echo "/etc/hosts.allow 파일이 존재하지 않습니다." >> $target
    fi

    # /etc/hosts.deny 파일 점검
    if [ -f "/etc/hosts.deny" ]; then
        if grep -vq "^\s*#" "/etc/hosts.deny";then
            if grep -iE "^\s*ALL:ALL\s*" "/etc/hosts.deny" | grep -qv "^\s*#"; then
                echo "/etc/hosts.deny 파일에 ALL:ALL 설정 항목이 존재하여 양호합니다." >> $target
            else
                echo "/etc/hosts.deny 파일에 ALL:ALL 설정 항목이 존재하지 않아 취약합니다." >> $target
                u18_allowcheck=$((u18_allowcheck+1))
                u18_safe_check=$((u18_safe_check+1))
            fi
        else
            echo "/etc/hosts.deny 파일 내에 설정값들이 존재하지 않습니다." >> $target
        fi
    else
        echo "/etc/hosts.deny 파일이 존재하지 않습니다." >> $target
    fi

else
    echo "TCP Wrapper를 사용하지 않습니다." >> $target
fi

if [[ $u18_safe_check -ge 1 ]];then
    u18=$((u18+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u18 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u18_Files_Directory_Management=1
fi