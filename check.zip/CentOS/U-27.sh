cat << EOF
===== [U-27] Check RPC service              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-27 RPC 서비스 확인               " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 다양한 취약성(버퍼 오버플로우, Dos, 원격실행 등)이 존재하는 RPC 서비스를 점검하여 해당 서비스를 비활성화 하도록 함" >> $target
echo "+보안위협 : 버퍼 오버플로우(Buffer Overflow), Dos, 원격실행 등의 취약성이 존재하는 RPC 서비스를 통해 비인가자의 root 권한 획득 및 침해사고 발생 위험이 있으므로 서비스를 중지하여야 " >> $target
echo "+판단기준 양호 🔘: 불필요한 RPC 서비스가 비활성화 되어 있는 경우" >> $target
echo "+판단기준 취약 🚫: 불필요한 RPC 서비스가 활성화 되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u27=0
u27_Service_Management=0
u27_safe_check=0
u27_services=(
    "rpc.cmsd"
    "rpc.ttdbserverd"
    "sadmind"
    "rusersd"
    "walld"
    "sprayd"
    "rstatd"
    "rpc.nisd"
    "rexd"
    "rpc.pcnfsd"
    "rpc.statd"
    "rpc.ypupdated"
    "rpc.rquotad"
    "kcms_server"
    "cachefsd"
    "rpc.lockd"
    "rpc.mountd"
    "rpc.quotad"
    "rpc.smserverd"
    "rpc.vxid"
    "rpc.ypserv"
    "rpc.yppasswdd"
    "rpc.bootparamd"
)
u27_ports=("111" "512" "150001" "875" "2108" "20048")

check_service_status "${u27_ports}" "${u27_services[@]}"
if [ $? -eq 1 ]; then
    echo "불필요한 RPC 서비스를  사용하고 있습니다." >> $target
    u27_safe_check=$((u27_safe_check+1))
else
    echo "불필요한 RPC 서비스를  사용하지 않고 있습니다." >> $target
fi

if [[ $u27_safe_check -ge 1 ]];then
    u27=$((u27+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u27 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u27_Service_Management=1
fi