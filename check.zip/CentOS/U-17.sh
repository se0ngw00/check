    cat << EOF
===== [U-17] \$HOME/.rhosts, hosts.equiv disabled              =====
=====                  Chaking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-17 \$HOME/.rhosts, hosts.equiv 사용 금지             " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : ‘r’ command 사용을 통한 원격 접속은 인증 없이 관리자 원격접속이 가능하므로 서비스 포트를 차단해야 함" >> $target
echo "보안위협 :  rlogin, rsh 등과 같은 ‘r’ command의 보안 설정이 적용되지 않은 경우, 원격지의 공격자가 관리자 권한으로 목표 시스템상의 임의의 명령을 수행시킬수 있으며, 명령어 원격 실행을 통해 중요 정보 유출 및 시스템 장애를 유발시킬 수 있음. 또한 공격자 백도어 등으로도 활용될 수 있음" >> $target
echo "+판단기준 양호 🔘:  login, shell, exec 서비스를 사용하지 않거나, 사용 시 아래와 같은 설정이 적용된 경우" >> $target
echo " 1. /etc/hosts.equiv 및 $HOME/.rhosts 파일 소유자가 root 또는, 해당 계정인 경우" >> $target
echo " 2. /etc/hosts.equiv 및 $HOME/.rhosts 파일 권한이 600 이하인 경우" >> $target
echo " 3. /etc/hosts.equiv 및 $HOME/.rhosts 파일 설정에 ‘+’ 설정이 없는 경우" >> $target
echo "+판단기준 취약 🚫: ogin, shell, exec 서비스를 사용하고, 위와 같은 설정이 적용되지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-17 점검 결과" >> $result
u17_Files_Directory_Management=0
u17_safe_check=0
u17=0
u17_check_users=($(cat /etc/passwd | egrep -v 'nologin|sync|false' | awk -F':' '{print $1}'))
for u17_check_user in "${u17_check_users[@]}";do
    u17_user_home=($(getent passwd "$u17_check_user" | awk -F':' '{print$6}'))
    if [ -e "$u17_user_home/.rhosts" ];then
        u17_rhosts_owner=$(stat -c "%U" "$u17_user_home/.rhosts")
        if [[ "$u17_rhosts_owner" == "$u17_check_user" ||"$u17_rhosts_owner" == "root" ]];then
            echo "$u17_user_home/.rhosts 파일의 소유자가 roo또는 $u17_check_user 로 적절하게 설정되어 있습니다." >> $target
            u17_rhosts_perm=$(stat -c "%a" "$u17_user_home/.rhosts" | cut -c1)
            if [[ $u17_rhosts_perm -le 6 ]];then
                echo "$u17_user_home/.rhosts 파일의 권한이 600이하로 설정되어 양호합니다." >> $target
                if ! grep -qE "$u17_user_home/.rhosts";then
                    echo "$u17_user_home/.rhosts 파일에 + 설정이 되어있지 않아 양호합니다." >> $target
                else
                    echo "$u17_user_home/.rhosts 파일에 + 설정이 되어있어 취약합니다." >> $target
                    u17_safe_check=$((u17_safe_check+1))
                fi
            else
                echo "$u17_user_home/.rhosts 파일의 권한이 600이상으로 설정되어 취약합니다."  >> $target
                u17_safe_check=$((u17_safe_check+1))
            fi
        else
            echo "$u17_user_home/.rhosts파일의 소유작 $u17_check_user로 설정되어 있지 않아 취약합니다." >> $target
            u17_safe_check=$((u17_safe_check+1))
        fi
    else
        echo "$u17_user_home/.rhosts 파일이 존재하지 않습니다." >> $target
    fi
done
if [ -e "/etc/hosts.equiv" ];then
    u17_equivfile_owner=$(stat -c "%U" "/etc/hosts.equiv")
    if [[ "$u17_equivfile_owner" == "root" || "$u17_equivfile_owner" == "$u17_check_users" ]];then
        echo "/etc/hosts.equiv 파일의 소유자가 또는, 해당 계정으로 적절하게 설정되어 있습니다." >> $target
        u17_equivfile_perm=$(stat -c "%a" "/etc/hosts.equiv")
        if [[ $u17_equivfile_perm -le 600 ]];then
             echo "/etc/hosts.equiv 파일의 권한이 600이하로 설정되어 양호합니다." >> $target
            if ! grep -qE "etc/hosts.equiv";then
                echo "/etc/hosts 파일에 + 설정이 되어있지 않아 양호합니다." >> $target
            else
                echo "/etc/hosts 파일에 + 설정이 되어있어 취약합니다." >> $target
                u17_safe_check=$((u17_safe_check+1))
            fi
        else
            echo "/etc/hosts.equiv 파일의 권한이 600이상으로 설정되어 취약합니다."  >> $target
            u17_safe_check=$((u17_safe_check+1))
        fi
    else
        echo "/etc/hosts.equiv 파일의 소유작 root로 설정되어 있지 않아 취약합니다." >> $target
        u17_safe_check=$((u17_safe_check+1))
    fi
else
    echo "/etc/hosts.equiv 파일이 존재하지 않습니다." >> $target
fi

u17_service_checks=("login" "shell" "exec")
u17_service_count=0

for u17_service_check in "${u17_service_checks[@]}"; do
    if systemctl is-active --quiet "$u17_service_check"; then
        echo "login, shell, exec와 같은 서비스를 사용하고 있어 취약합니다." >> $target
        u17_safe_check=$((u17_safe_check+1))
    else
        u17_service_count=$((u17_service_count+1))
    fi
done
if [[ $u17_service_count -ge 1 ]];then
    echo "login, shell, exec 와 같은 서비스를 사용하고 있지 않아 양호합니다." >> $target
fi



if [[ $u17_safe_check -ge 1 ]];then
    u17=$((u17+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u17 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u17_Files_Directory_Management=1
fi