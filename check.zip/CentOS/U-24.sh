cat << EOF
===== [U-24] Disable NFS Service              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-24 NFS 서비스 비활성화               " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : NFS(Network File System) 서비스는 한 서버의 파일을 많은 서비스 서버들이 공유하여 사용할 때 많이 이용되는 서비스이지만 이를 이용한 침해사고 위험성이 높으므로 사용하지 않는 경우 중지함" >> $target
echo "+보안위협 : NFS 서비스는 서버의 디스크를 클라이언트와 공유하는 서비스로 적정한 보안설정이 적용되어 있지 않다면 불필요한 파일 공유로 인한 유출위험이 있음" >> $target
echo "+판단기준 양호 🔘: 불필요한 NFS 서비스 관련 데몬이 비활성화 되어 있는 경우" >> $target
echo "+판단기준 취약 🚫: 불필요한 NFS 서비스 관련 데몬이 활성화 되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u24=0
u24_Service_Management=0
u24_safe_check=0
u24_nfs_daemons=("nfs" "nfsd" "rpc.mountd" "rpcbind" "statd" "lockd" "nfs-kernel-server")
u24_nfs_ports=("111" "2049")

check_service_status "${u24_nfs_ports}" "${u24_nfs_daemons[@]}"
if [[ $? -eq 1 ]]; then
    echo "nfs 서비스를 사용하고 있습니다." >> $target
    u24_safe_check=$((u24_safe_check+1))
else
    echo "nfs 서비스를 사용하고 있지 않습니다." >> $target
fi

if [[ $u24_safe_check -ge 1 ]];then
    u24=$((u24+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u24 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u24_Service_Management=1
fi