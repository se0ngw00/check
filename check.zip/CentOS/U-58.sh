cat << EOF
===== [U-58] Managing the existence of a directory that you specify as your home directory              =====
=====                  Chaking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-58 홈디렉토리로 지정한 디렉토리의 존재 관리             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : /home 이외 사용자의 홈 디렉터리 존재 여부를 점검하여 비인가자가 시스템 명령어의 무단 사용을 방지하기 위함" >> $target
echo "보안위협 : passwd 파일에 설정된 홈디렉터리가 존재하지 않는 경우, 해당 계정으로 로그인시 홈디렉터리가 루트 디렉터리(“/“)로 할당되어 접근이 가능함" >> $target
echo "+판단기준 양호 🔘: 홈 디렉터리가 존재하지 않는 계정이 발견되지 않는 경우" >> $target
echo "+판단기준 취약 🚫: 홈 디렉터리가 존재하지 않는 계정이 발견된 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u58_safe_check=0
u58_Files_Directory_Management=0
u58=0
IFS=$'\n' u58_check_users=($(awk -F':' '!/\/sbin|false|sync/ && $1 != "root" {print $1}' /etc/passwd))

for u58_check_user in "${u58_check_users[@]}"; do
    u58_user_home=$(getent passwd "$u58_check_user" | awk -F':' '{print $6}')
    if [[ "$u58_user_home" == "/home/$u58_check_user" ]]; then
        echo "$u58_check_user 의 홈 디렉터리가 존재합니다." >> $target
    else
        echo "--------------------------------------"  >> $target
        echo "$u58_check_user 의 홈 디렉터리가 /home하위에 존재하지 않습니다." >> $target
        u58_safe_check=$((u58_safe_check+1))
    fi
done

if [[ $u58_safe_check -ge 1 ]];then
    u58=$((u58+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u58 -ge 1 ]];then
    Mid=$((Mid+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u58_Files_Directory_Management=1
fi