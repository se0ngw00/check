cat << EOF
===== [U-67] Configuring the Complexity of SNMP Service Community Strings              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-67 SNMP 서비스 Community String의 복잡성 설정             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : Community String 기본 설정인 Public, Private는 공개된 내용으로 공격자가 이를 이용하여 SNMP 서비스를 통해 시스템 정보를 얻을 수 있기 때문에 Community String을 유추하지 못하도록 설정해야함" >> $target
echo "보안위협 : Community String은 Default로 public, private로 설정된 경우가 많으며, 이를 변경하지 않으면 이 String을 악용하여 환경설정 파일 열람 및 수정을 통한 공격, 간단한 정보수집에서부터 관리자 권한 획득 및 Dos공격까지 다양한 형태의 공격이 가능함" >> $target
echo "+판단기준 양호 🔘: SNMP Community 이름이 public, private 이 아닌 경우" >> $target
echo "+판단기준 취약 🚫: SNMP Community 이름이 public, private 인 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-67 점검 결과" >> $result

u67_Service_Management=0
u67_safe_check=0
u67=0
u67_snmpd_conf_paths=($(find / -type f -name "snmpd.conf" 2> /dev/null))
if [ -n "$u67_snmpd_conf_paths" ];then
    for u67_snmpd_conf_path in "${u67_snmpd_conf_paths[@]}";do
        if [ -e "$u67_snmpd_conf_path" ];then
            echo "$u67_snmpd_conf_path 파일이 존재합니다." >> $target
            u67_check_string=$(grep -v "^\s*#" "$u67_snmpd_conf_path" 2> /dev/null | grep -i "public" | grep -i "private")
            if [ -n "$u67_check_string" ];then
                echo "SNMP Community 이름이 public, private로 설정되어 있습니다." >> $target
                echo "현재 설정값 : $u67_check_string" >> $target
                u67_safe_check=$((u67_safe_check+1))
            else
                echo "SNMP Community 이름이 public, private로 설정되어 있지 않습니다." >> $target
                echo "현재 설정값 : $u67_check_string" >> $target
            fi
        fi
    done
else
    echo "snmp 설정파일이 존재하지 않습니다." >> $target
fi

if [[ $u67_safe_check -ge 1 ]];then
    u67=$((u67+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u67 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u67_Service_Management=1
fi