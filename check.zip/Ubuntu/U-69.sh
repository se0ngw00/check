cat << EOF
===== [U-69] NFS Configuration File Access Permissions              =====
=====                  Chaking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-69 NFS 설정파일 접근권한             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 비인가자에 의한 불법적인 외부 시스템 마운트를 차단하기 위해 NFS 접근 제어 파일의 소유자 및 파일 권한을 설정" >> $target
echo "보안위협 : NFS 접근제어 설정파일에 대한 권한 관리가 이루어지지 않을 시 인가되지 않은 사용자를 등록하고 파일시스템을 마운트하여 불법적인 변조를 시도할 수 있음" >> $target
echo "+판단기준 양호 🔘: NFS 접근제어 설정파일의 소유자가 root 이고, 권한이 644 이하인 경우" >> $target
echo "+판단기준 취약 🚫: NFS 접근제어 설정파일의 소유자가 root 가 아니거나, 권한이 644 이하가 아닌 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-69 점검 결과" >> $result

u69_Service_Management=0
u69_safe_check=0
u69=0
if [ -e "/etc/exports" ];then
    echo "exports 파일이 존재 합니다." >> $target
    u69_file_owner=$(stat -c "%U" "/etc/exports" 2> /dev/null)
        u69_file_perm_user=$(stat -c "%a" "/etc/exports" 2> /dev/null | cut -c1)
        u69_file_perm_group=$(stat -c "%a" "/etc/exports" 2> /dev/null | cut -c2)
        u69_file_perm_other=$(stat -c "%a" "/etc/exports" 2> /dev/null | cut -c3)
        if [[ "$u69_file_owner" == "root" ]];then
            echo "/etc/exports 파일의 소유자가 root로 설정되어 있습니다." >> $target
            if [[ $u69_file_perm_user -le 6 ]];then
                echo "/etc/exports 파일의 소유 권한이 6이하로 설정되어 있습니다." >> $target
                if [[ $u69_file_perm_group -le 4 ]];then
                    echo "/etc/exports 파일의 소유 그룹 권한이 4이하로 설정되어 있습니다." >> $target
                    if [[ $u69_file_perm_other -le 4 ]];then
                        echo "/etc/exports 파일의 기타 사용자(Other)의 권한이 4이하로 설정되어 있습니다." >> $target
                    else
                        echo "/etc/exports 파일의 기타 사용자(Other)의 권한이 6이상으로 설정되어 있습니다." >> $target
                        u69_safe_check=$((u69_safe_check+1))
                    fi
                else
                    echo "/etc/exports 파일의 소유 그룹 권한이 4이상으로 설정되어 있습니다." >> $target
                    u69_safe_check=$((u69_safe_check+1))
                fi
            else
                echo "/etc/exports 파일의 소유 권한이 6이상으로 설정되어 있습니다." >> $target
                u69_safe_check=$((u69_safe_check+1))
            fi
        else
            echo "/etc/exports 파일의 소유자가 root가 아닌 다른 사용자로 되어 있습니다." >> $target
            u69_safe_check=$((u69_safe_check+1))
        fi
else
    echo "exports 파일이 존재하지 않습니다." >> $target
fi
if [[ $u69_safe_check -ge 1 ]];then
    u69=$((u69+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi

if [[ $u69 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u69_Service_Management=1
fi
