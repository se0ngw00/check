cat << EOF
===== [U-70] NFS Configuration File Access Permissions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-70 NFS 설정파일 접근권한             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : SMTP 서비스의 expn, vrfy 명령을 통한 정보 유출을 막기 위하여 두 명령어를 사용하지 못하게 옵션을 설정해야함" >> $target
echo "보안위협 : VRFY, EXPN 명령어를 통하여 특정 사용자 계정의 존재유무를 알 수 있고, 사용자의 정보를 외부로 유출 할 수 있음" >> $target
echo "+판단기준 양호 🔘: SMTP 서비스 미사용 또는, noexpn, novrfy 옵션이 설정되어 있는 경우" >> $target
echo "+판단기준 취약 🚫: SMTP 서비스를 사용하고, noexpn, novrfy 옵션이 설정되어 있지 않는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-70 점검 결과" >> $result

u70_Service_Management=0
u70_safe_check=0
u70=0
u70_snmp_checks=("snmp" "snmpd")
u70_snmp_ports=("161" "162")
u70_safe_check=0
check_service_status "${u70_snmp_ports}" "${u70_snmp_checks[@]}"
if [[ $? -eq 1 ]]; then
    echo "snmp 서비스를 사용하고 있습니다.">> $target
    u70_safe_check=$((u70_safe_check+1))
else
    echo "snmp 서비스를 사용하지 않고 있습니다.">> $target
fi
u70_files=("sendmail.cf" "main.cf")
for u70_file in "${u70_files[@]}";do
    u70_file_path=$(find / -type f -name "$u70_file" 2> /dev/null)
    if [ -n "$u70_file_path" ];then
        echo "$u70_file 파일이 존재합니다.">> $target
        if [[ "$u70_file" == "sendmail.cf" ]];then
            u70_check_option=$(grep -vE "^\s*#" "$u70_file_path" 2> /dev/null | grep -iE "^\s*O\s*PrivacyOptions\s*=\s*." | grep -iE "noexpn|goaway" | grep -iE "novrfy|goaway")
            if [ -n "$u70_check_option" ];then
                echo "$u70_file 파일에 noexpn, novrfy 옵션이 설정되어 있습니다.">> $target
                echo "현재 설정 값 : $u70_check_option" >> $target 
            else
                echo "$u70_file 파일에 noexpn, novrfy 옵션이 설정되어 있지 않습니다.">> $target
                u70_safe_check=$((u70_safe_check+1))
            fi
        else
            u70_check_option=$(grep -vE "^\s*#" "$u70_file_path" 2> /dev/null | grep -iE "^\s*smtpd_privacy_options\s*=\s*." | grep -iE "noexpn|goaway" | grep -iE "novrfy|goaway")
            if [ -n "$u70_check_option" ];then
                echo "$u70_file 파일에 noexpn, novrfy 옵션이 설정되어 있습니다.">> $target
                echo "현재 설정 값 : $u70_check_option" >> $target
            else
                echo "$u70_file 파일에 noexpn, novrfy 옵션이 설정되어 있지 않습니다.">> $target
                u70_safe_check=$((u70_safe_check+1))
            fi
        fi
    fi
done

if [[ $u70_safe_check -ge 1 ]];then
    u70=$((u70+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi

if [[ $u70 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u70_Service_Management=1
fi