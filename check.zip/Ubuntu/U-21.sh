cat << EOF
===== [U-21] Disabling r Family Services              =====
=====                  Chaking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-21  r 계열 서비스 비활성화             " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : r-command 사용을 통한 원격 접속은 NET Backup 또는 클러스터링 등 용도로 사용되기도 하나, 인증 없이 관리자 원격접속이 가능하여 이에 대한 보안위협을 방지하고자 함" >> $target
echo "보안위협 :  rsh, rlogin, rexec 등의 r command를 이용하여 원격에서 인증절차 없이 터미널 접속, 쉘 명령어를 실행이 가능함" >> $target
echo "+판단기준 양호 🔘: 불필요한 r 계열 서비스가 비활성화 되어 있는 경우" >> $target
echo "+판단기준 취약 🚫: 불필요한 r 계열 서비스가 활성화 되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-21 점검 결과" >> $result
u21_Service_Management=0
u21_safe_check=0
u21=0
u21_checkrcommands=("rsh" "rlogin" "rexec" "shell" "login" "exec")
u21_checkports=("514" "513" "512")

check_service_status "${u21_checkports}" "${u21_checkrcommands[@]}"
if [[ $? -eq 1 ]]; then
    echo "r 계열 서비스를 사용하고 있습니다." >> $target
    u24_safe_check=$((u24_safe_check+1))
else
    echo "r 계열 서비스를 사용하고 있지 않습니다." >> $target
fi

if [[ $u21_safe_check -ge 1 ]];then
    u21=$((u21+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u21 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u21_Service_Management=1
fi