# 공통 함수 로드
if [ -f "/opt/check/common_functions.sh" ]; then
    . "/opt/check/common_functions.sh"
fi

cat << EOF
===== [U-30] Check Sendmail version              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-30 Sendmail 버전 점검               " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : Sendmail 서비스 사용 목적 검토 및 취약점이 없는 버전의 사용 유무 점검으로 최적화된 Sendmail 서비스의 운영" >> $target
echo "+보안위협 : 취약점이 발견된 Sendmail 버전의 경우 버퍼 오버플로우(Buffer Overflow) 공격에 의한 시스템 권한 획득 및 주요 정보 요출 가능성이 있음" >> $target
echo "+판단기준 양호 : Sendmail 버전이 최신버전인 경우" >> $target
echo "+판단기준 취약 : Sendmail 버전이 최신버전이 아닌 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u30=0
# sendmail 명령어가 없을 수 있으므로 에러 처리
u30_sendmail_ver=""
if command -v sendmail >/dev/null 2>&1; then
    u30_sendmail_ver=$(sendmail -d0.1 -t < /dev/null 2>&1 | grep -i "version" | awk '{print $2}')
fi
#apt-cache show sendmail | grep Version  :  Debian 에서 최신버전확인
#yum info sendmail | grep Version  :  Red Had 계열에서 최신버전 확인
u30_sendmail_latest=$(yum info sendmail 2>/dev/null | grep -i Version | awk '{print $3}' | head -1)
u30_Service_Management=0
u30_safe_check=0
u30_ports=("25" "465" "587")
u30_service=("sendmail" "postfix" "exim" "sendmail.service" "postfix.service" "exim.service")

# check_service_status 함수가 없을 경우 대체 로직
if ! command -v check_service_status >/dev/null 2>&1; then
    sendmail_active=0
    if ss -tuln 2>/dev/null | grep -qE ":(25|465|587) " || netstat -tuln 2>/dev/null | grep -qE ":(25|465|587) "; then
        sendmail_active=1
    fi
    for svc in "${u30_service[@]}"; do
        if pgrep -f "$svc" >/dev/null 2>&1 || systemctl is-active --quiet "$svc" 2>/dev/null; then
            sendmail_active=1
            break
        fi
    done
    sendmail_status=$sendmail_active
else
    check_service_status "${u30_ports[@]}" "${u30_service[@]}"
    sendmail_status=$?
fi

if [[ $sendmail_status -eq 1 ]]; then
    echo "sendmail 서비스를 사용하고 있습니다." >> $target
    if [[ -z "$u30_sendmail_ver" ]] || [[ -z "$u30_sendmail_latest" ]]; then
        echo "sendmail 버전 정보를 확인할 수 없습니다." >> $target
    elif [[ "$u30_sendmail_ver" == "$u30_sendmail_latest" ]]; then
        echo "현재 실행중인 서비스가 최신버전과 동일합니다." >> $target
        echo "현재 설치되어 있는 sendmail 서비스 버전 : $u30_sendmail_ver" >> $target
        echo "최신 sendmail 서비스 버전 : $u30_sendmail_latest" >> $target
    else
        echo "현재 설치되어 있는 sendmail 서비스의 버전이 최신버전과 일치하지 않습니다." >> $target
        echo "현재 설치되어 있는 sendmail 서비스 버전 : $u30_sendmail_ver" >> $target
        echo "최신 sendmail 서비스 버전 : $u30_sendmail_latest" >> $target
        u30_safe_check=$((u30_safe_check+1))
    fi
else
    echo "sendmail 서비스를 사용하고 있지 않습니다." >> $target
    # sendmail 서비스를 사용하지 않으면 양호 (u30_safe_check 증가하지 않음)
fi

if [[ $u30_safe_check -ge 1 ]];then
    u30=$((u30+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u30 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u30_Service_Management=1
fi