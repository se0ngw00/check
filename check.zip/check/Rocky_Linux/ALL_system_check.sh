#!/bin/bash
set -e

. /etc/os-release

# 공통 함수 로드
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
COMMON_FUNCTIONS="$BASE_DIR/../common_functions.sh"
if [ -f "$COMMON_FUNCTIONS" ]; then
    . "$COMMON_FUNCTIONS"
else
    echo "Warning: common_functions.sh not found at $COMMON_FUNCTIONS" >&2
fi

TOTAL_FILE="$RESULT_DIR/${RESULT_PREFIX}.total"
VULN_FILE="$RESULT_DIR/${RESULT_PREFIX}.vuln"

> "$TOTAL_FILE"
> "$VULN_FILE"

export target="/dev/stdout"
export result="/dev/stdout"

{
  echo "Linux Security Check Result"
  echo "Host : $(hostname)"
  echo "OS   : $PRETTY_NAME"
  echo "Date : $(date '+%Y-%m-%d %H:%M:%S')"
  echo "----------------------------------------"
} >> "$TOTAL_FILE"

if [ "$TEST_MODE" = "1" ]; then
  SCRIPTS="U-TEST.sh"
else
  SCRIPTS=$(ls U-[0-9][0-9].sh 2>/dev/null | sort)
fi

TOTAL_COUNT=0
VULN_COUNT=0
VULN_ITEMS=""

echo "[취약 항목 점검 결과]" >> "$VULN_FILE"
echo >> "$VULN_FILE"

# 순차 실행
for script in $SCRIPTS; do
  ITEM_ID="$(basename "$script" .sh)"
  TMP_OUT=$(mktemp)
  SCRIPT_EXIT=0
  STATUS="UNKNOWN"

  # 현재 실행 중인 스크립트 표시
  echo "[$(date '+%H:%M:%S')] 실행 중: $ITEM_ID" >&2

  # 스크립트 직접 실행
  (
    # 공통 함수 다시 로드 (서브셸에서는 상속되지 않으므로)
    COMMON_FUNC_PATH="/opt/check/common_functions.sh"
    
    # 만약 파일이 없으면 현재 디렉터리에서 계산
    if [ ! -f "$COMMON_FUNC_PATH" ]; then
      SCRIPT_DIR="$(cd "$(dirname "$0")" 2>/dev/null && pwd 2>/dev/null)"
      if [ -n "$SCRIPT_DIR" ]; then
        COMMON_FUNC_PATH="$SCRIPT_DIR/../common_functions.sh"
        if [ -f "$COMMON_FUNC_PATH" ]; then
          COMMON_FUNC_PATH="$(cd "$(dirname "$COMMON_FUNC_PATH")" && pwd)/$(basename "$COMMON_FUNC_PATH")"
        fi
      fi
    fi
    
    if [ -f "$COMMON_FUNC_PATH" ]; then
      . "$COMMON_FUNC_PATH"
      export -f check_service_status 2>/dev/null || true
    else
      echo "Error: common_functions.sh not found. Tried: $COMMON_FUNC_PATH" >&2
    fi
    
    export target result
    bash "$script"
  ) > "$TMP_OUT" 2>&1 || SCRIPT_EXIT=$?
  
  echo "[$(date '+%H:%M:%S')] 완료: $ITEM_ID (종료코드: $SCRIPT_EXIT)" >&2
  
  # 결과 파싱
  if grep -q "점검 결과[[:space:]]*:[[:space:]]*취약" "$TMP_OUT"; then
    STATUS="취약"
  elif grep -q "점검 결과[[:space:]]*:[[:space:]]*양호" "$TMP_OUT"; then
    STATUS="양호"
  elif [ "$SCRIPT_EXIT" -ne 0 ]; then
    STATUS="ERROR"
  fi

  echo >> "$TOTAL_FILE"
  echo "[$ITEM_ID]" >> "$TOTAL_FILE"

  if [ "$SCRIPT_EXIT" -ne 0 ]; then
    echo "[WARNING] $ITEM_ID 스크립트가 오류로 종료되었습니다. (종료 코드: $SCRIPT_EXIT)" >> "$TOTAL_FILE"
  fi

  {
    echo "=================================================================="
    echo "[$ITEM_ID] 결과 요약"
    echo "------------------------------------------------------------------"
    cat "$TMP_OUT"
    echo "------------------------------------------------------------------"
  } >> "$TOTAL_FILE"

  if [ "$STATUS" = "취약" ]; then
    echo "- $ITEM_ID : REVIEW_REQUIRED" >> "$VULN_FILE"
    VULN_COUNT=$((VULN_COUNT + 1))
    VULN_ITEMS="${VULN_ITEMS}- ${ITEM_ID}\n"
  elif [ "$STATUS" = "ERROR" ]; then
    echo "[ERROR] $ITEM_ID: 점검 결과를 확인할 수 없습니다." >> "$TOTAL_FILE"
  fi

  echo "결과 요약 : $STATUS" >> "$TOTAL_FILE"
  if [ "$SCRIPT_EXIT" -ne 0 ]; then
    echo "스크립트 종료 코드 : $SCRIPT_EXIT" >> "$TOTAL_FILE"
  fi
  
  if grep -qi "command not found\|오류\|error\|failed" "$TMP_OUT"; then
    echo "[경고] $ITEM_ID: 스크립트 실행 중 오류 또는 경고가 발생했습니다." >> "$TOTAL_FILE"
  fi

  rm -f "$TMP_OUT"
  TOTAL_COUNT=$((TOTAL_COUNT + 1))
done

echo >> "$VULN_FILE"
echo "총 점검 항목 수 : $TOTAL_COUNT" >> "$VULN_FILE"
echo "검토 필요 항목 수 : $VULN_COUNT" >> "$VULN_FILE"

{
  echo
  echo "----------------------------------------"
  echo "요약"
  echo "총 점검 항목 수 : $TOTAL_COUNT"
  echo "검토 필요 항목 수 : $VULN_COUNT"
  if [ -n "$VULN_ITEMS" ]; then
    echo "검토 필요 목록:"
    printf "%b" "$VULN_ITEMS"
  fi
} >> "$TOTAL_FILE"
