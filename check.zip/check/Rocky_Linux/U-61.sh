# 공통 함수 로드
if [ -f "/opt/check/common_functions.sh" ]; then
    . "/opt/check/common_functions.sh"
fi

cat << EOF
===== [U-61] Check ftp service              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-61 ftp 서비스 확인             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 취약한 서비스인 FTP서비스를 가급적 제한함을 목적으로 함" >> $target
echo "보안위협 : FTP 서비스는 통신구간이 평문으로 전송되어 계정정보(아이디, 패스워드) 및 전송 데이터의 스니핑이 가능함" >> $target
echo "+판단기준 양호 : FTP 서비스가 비활성화 되어 있는 경우" >> $target
echo "+판단기준 취약 : FTP 서비스가 활성화 되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-61 점검 결과" >> $result
u61_safe_check=0
u61_Service_Management=0
u61=0
# 값 설정
u61_ftp_checks=("ftp" "vsftpd" "proftpd")

u61_ftp_ports=("21" "20")

# check_service_status 함수가 없을 경우 대체 로직
if ! command -v check_service_status >/dev/null 2>&1; then
    ftp_active=0
    if ss -tuln 2>/dev/null | grep -qE ":(21|20) " || netstat -tuln 2>/dev/null | grep -qE ":(21|20) "; then
        ftp_active=1
    fi
    for svc in "${u61_ftp_checks[@]}"; do
        if pgrep -f "$svc" >/dev/null 2>&1 || systemctl is-active --quiet "$svc" 2>/dev/null; then
            ftp_active=1
            break
        fi
    done
    ftp_status=$ftp_active
else
    check_service_status "${u61_ftp_ports[@]}" "${u61_ftp_checks[@]}"
    ftp_status=$?
fi

if [[ $ftp_status -eq 1 ]]; then
    echo "ftp 서비스를 사용하고 있습니다." >> $target
    u61_safe_check=$((u61_safe_check+1))
else
    echo "ftp 서비스를 사용하고 있지 않습니다." >> $target
fi

if [[ $u61_safe_check -ge 1 ]];then
    u61=$((u61+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u61 -ge 1 ]];then
    Low=$((Low+1))
    Service_Management=$((Service_Management+1))
    u61_Service_Management=1
fi