#!/bin/bash
# 공통 함수 정의 파일

# 서비스 상태 확인 함수
# 사용법: check_service_status "포트1" "포트2" ... "서비스1" "서비스2" ...
# 또는: check_service_status "${ports_array[@]}" "${services_array[@]}"
# 반환값: 0 = 서비스 비활성화 (양호), 1 = 서비스 활성화 (취약)
check_service_status() {
    local ports=()
    local services=()
    local found=0
    local in_ports=1
    
    # 인자 파싱: 숫자면 포트, 문자열이면 서비스
    for arg in "$@"; do
        # 공백으로 구분된 문자열 처리 (배열이 아닌 경우)
        if [[ "$arg" =~ [[:space:]] ]]; then
            # 공백이 포함된 경우 공백으로 분리
            for item in $arg; do
                if [[ "$item" =~ ^[0-9]+$ ]]; then
                    if [ $in_ports -eq 1 ]; then
                        ports+=("$item")
                    fi
                else
                    in_ports=0
                    services+=("$item")
                fi
            done
        elif [[ "$arg" =~ ^[0-9]+$ ]]; then
            # 숫자이면 포트
            if [ $in_ports -eq 1 ]; then
                ports+=("$arg")
            else
                # 포트 구분이 끝났는데 다시 숫자가 나오면 무시
                continue
            fi
        else
            # 문자열이면 서비스
            in_ports=0
            services+=("$arg")
        fi
    done
    
    # 포트 확인 (netstat 또는 ss 사용)
    if command -v ss >/dev/null 2>&1; then
        for port in "${ports[@]}"; do
            if ss -tuln 2>/dev/null | grep -q ":$port "; then
                found=1
                break
            fi
        done
    elif command -v netstat >/dev/null 2>&1; then
        for port in "${ports[@]}"; do
            if netstat -tuln 2>/dev/null | grep -q ":$port "; then
                found=1
                break
            fi
        done
    fi
    
    # 서비스 프로세스 확인
    if [ $found -eq 0 ] && [ ${#services[@]} -gt 0 ]; then
        for service in "${services[@]}"; do
            # 프로세스 이름으로 확인
            if pgrep -x "$service" >/dev/null 2>&1 || pgrep -f "$service" >/dev/null 2>&1; then
                found=1
                break
            fi
            # 프로세스 목록에서 패턴 확인
            if ps aux 2>/dev/null | grep -v grep | grep -q "$service"; then
                found=1
                break
            fi
        done
    fi
    
    # systemd 서비스 확인 (가능한 경우)
    if [ $found -eq 0 ] && command -v systemctl >/dev/null 2>&1; then
        for service in "${services[@]}"; do
            # 서비스 이름 패턴 매칭
            if systemctl is-active --quiet "$service" 2>/dev/null; then
                found=1
                break
            fi
            # 일부 서비스는 다른 이름으로 등록될 수 있음
            if systemctl list-units --type=service --all --no-pager 2>/dev/null | grep -q "$service"; then
                if systemctl is-active --quiet "$(systemctl list-units --type=service --all --no-pager 2>/dev/null | grep "$service" | awk '{print $1}')" 2>/dev/null; then
                    found=1
                    break
                fi
            fi
        done
    fi
    
    # init.d 스크립트 확인 (레거시 시스템)
    if [ $found -eq 0 ] && [ -d "/etc/rc.d" ] || [ -d "/etc/init.d" ]; then
        for service in "${services[@]}"; do
            if [ -f "/etc/init.d/$service" ] && [ -x "/etc/init.d/$service" ]; then
                # 서비스가 실행 중인지 확인
                if /etc/init.d/$service status >/dev/null 2>&1; then
                    found=1
                    break
                fi
            fi
        done
    fi
    
    return $found
}

# 에러 로깅 함수
log_error() {
    local script_name="$1"
    local error_msg="$2"
    echo "[ERROR] $script_name: $error_msg" >&2
    if [ -n "$target" ] && [ "$target" != "/dev/stdout" ]; then
        echo "[ERROR] $script_name: $error_msg" >> "$target" 2>&1
    fi
}

# 경고 로깅 함수
log_warning() {
    local script_name="$1"
    local warning_msg="$2"
    echo "[WARNING] $script_name: $warning_msg" >&2
    if [ -n "$target" ] && [ "$target" != "/dev/stdout" ]; then
        echo "[WARNING] $script_name: $warning_msg" >> "$target" 2>&1
    fi
}
