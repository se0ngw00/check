cat << EOF
===== [U-52] Do not allow the same UID              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-52 동일한 UID 금지              " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : UID가 동일한 사용자 계정을 점검함으로써 타 사용자 계정 소유의 파일 및 디렉터리로의 악의적 접근 예방 및 침해사고 시 명확한 감사추적을 목적으로 함" >> $target
echo "보안위협 : 중복된 UID가 존재할 경우 시스템은 동일한 사용자로 인식하여 소유자의 권한이 중복되어 불필요한 권한이 부여되며 시스템 로그를 이용한 감사 추적시 사용자가 구분되지 않음 (권한 할당은 그룹권한을 이용하여 운영)" >> $target
echo "+판단기준 양호 : 동일한 UID로 설정된 사용자 계정이 존재하지 않는 경우" >> $target
echo "+판단기준 취약 : 동일한 UID로 설정된 사용자 계정이 존재하는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u52_Account_Management=0
u52_safe_check=0
u52=0
u52_user_uid=$(awk -F: '{print $3}' "/etc/passwd" 2> /dev/null)
u52_uniq_uids=$(awk -F: '{print $3}' "/etc/passwd" 2> /dev/null | sort | uniq -d | paste -sd '|')
u52_uniq_users=$(awk -F: '{print $1, $3}' /etc/passwd 2> /dev/null | grep -E -iw "$u52_uniq_uids" | sort -r)
readarray -t u52_lines <<< "$u52_uniq_users"


if [ -n "$u52_uniq_uids" ];then
    echo "동일한 UID를 가진 계정들이 존재합니다." >> $target
    for i in "${u52_lines[@]}";do
        echo "$i" >> $target >> $target
        u52_safe_check=$((u52_safe_check+1))
    done
else
    echo "동일한 UID를 가진 계정들이 존재하지 않습니다." >> $target
fi

if [ $u52_safe_check -ge 1 ];then
    u52=$((u52+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u52 -ge 1 ]];then
    Mid=$((Mid+1))
    Account_Management=$((Account_Management+1))
    u52_Account_Management=1
fi