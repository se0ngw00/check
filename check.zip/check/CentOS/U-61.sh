cat << EOF
===== [U-61] Check ftp service              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-61 ftp 서비스 확인             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 취약한 서비스인 FTP서비스를 가급적 제한함을 목적으로 함" >> $target
echo "보안위협 : FTP 서비스는 통신구간이 평문으로 전송되어 계정정보(아이디, 패스워드) 및 전송 데이터의 스니핑이 가능함" >> $target
echo "+판단기준 양호 : FTP 서비스가 비활성화 되어 있는 경우" >> $target
echo "+판단기준 취약 : FTP 서비스가 활성화 되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-61 점검 결과" >> $result
u61_safe_check=0
u61_Service_Management=0
u61=0
# 값 설정
u61_ftp_checks=("ftp" "vsftpd" "proftpd")

u61_ftp_ports=("21" "20")

check_service_status "${u61_ftp_ports}" "${u61_ftp_checks[@]}"
if [[ $? -eq 1 ]]; then
    echo "ftp 서비스를 사용하고 있습니다." >> $target
    u61_safe_check=$((u61_safe_check+1))
else
    echo "ftp 서비스를 사용하고 있지 않습니다." >> $target
fi

if [[ $u61_safe_check -ge 1 ]];then
    u61=$((u61+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u61 -ge 1 ]];then
    Low=$((Low+1))
    Service_Management=$((Service_Management+1))
    u61_Service_Management=1
fi