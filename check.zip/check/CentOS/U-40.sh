cat << EOF
===== [U-40] Upload and downloading web service file files              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-40 웹서비스 파일 업로드 및 다운로드 제한              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 기반시설 특성상 원칙적으로 파일 업로드 및 다운로드를 금지하고 있지만불가피하게 필요시 용량 사이즈를 제한함으로써 불필요한 업로드와 다운로드를 방지해 서버의 과부하 예방 및 자원을 효율적으로 관리하기 위함" >> $target
echo "+보안위협 : 악의적 목적을 가진 사용자가 반복 업로드 및 웹 쉘 공격 등으로 시스템 권한을 탈취하거나 대용량 파일의 반복 업로드로 서버자원을 고갈시키는 공격의 위험이 있음" >> $target
echo "+판단기준 양호 : 일 업로드 및 다운로드를 제한한 경우" >> $target
echo "+판단기준 취약 : 파일 업로드 및 다운로드를 제한하지 않은 경" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u40=0
u40_apache_files=("/etc/httpd/conf.d/*.conf" "/etc/httpd/sites-available/*.conf" "/etc/httpd/sites-enabled/*.conf")
u40_nginx_files=("/etc/nginx/conf.d/*.conf")
u40_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
u40_idx=0
u40_break=0
u40_idxn=0
u40_safe_check=0
u40_Service_Management=0
echo "※Cent OS 7 기준 Apache 메인 설정파일 경로와 Nginx 메인 설정 파일인 /etc/nginx/nginx.conf를 점검합니다. 해당 경로가 존재하지 않을 경우, 아파치 웹 서비스 구성 파일명을 토대로 파일 탐색 후 점검이 진행됩니다. 중복된 파일명이 존재할 경우 수동 점검을 권장합니다.※"  >> $target
echo "apache, nginx 의 주요 설정파일을 토대로 apache 홈 디렉터리 점검 후 추가 설정 파일 및 디렉터리를 점검하므로, 중복된 결과가 존재할 수 있습니다." >> $target
for u40_apache_home_check in "${u40_apache_home_checks[@]}";do
    u40_apache_home=$(find /etc /usr /opt -type f -name "$u40_apache_home_check" 2>/dev/null | grep -E -v "tmp|temp|swap|swp" | head -5)
    if [ -f "$u40_apache_home" ];then
        echo "$u40_apache_home 파일이 존재합니다." >> $target
        u40_dir_pathconfs_a=($(grep -vE "^\s*#" "$u40_apache_home" | sed -n '/<Directory/,/<\/Directory>/p' | grep -i "^\s*LimitRequestBody" | awk '{print $2}'))
        u40_check_dirpath_a=($(grep -vE "^\s*#" "$u40_apache_home" | awk 'BEGIN { inBlock = 0; block = "" }/<Directory/ {block = $0;inBlock = 1;dirPath = $2; gsub("\"", "", dirPath)}/<\/Directory>/ {block = block "\n" $0;inBlock = 0;if (block ~ /LimitRequestBody/) { print dirPath }block = ""}inBlock && ! /<\/Directory>/ { block = block "\n" $0 }' | tr -d '>'))
        if [ -n "$u40_dir_pathconfs_a" ];then
            for u40_dir_pathconf_a in "${u40_dir_pathconfs_a[@]}";do
                if [[ $u40_dir_pathconf_a -ge 5242880 ]];then
                    echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이상 설정되어 있습니다." >> $target
                    echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이상으로 설정된 디렉토리 경로 : ${u40_check_dirpath_a[$u40_idx]}" >> $target
                    u40_safe_check=$((u40_safe_check+1))
                    u40_idx=$((u40_idx+1))
                else
                    echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이하로 적절하게 설정되어 있습니다.." >> $target
                    echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이상으로 설정된 디렉토리 경로 : ${u40_check_dirpath_a[$u40_idx]}" >> $target
                    u40_idxn=$((u40_idxn+1))
                fi
            done
            break
        else
            echo "$u40_dir_pathconfs_a 파일은 존재하지만, 파일 업로드 및 다운로드 사이즈를 설정할 수 있는 LimitRequestBody 지시자가 존재하지 않습니다."
        fi
    else 
        u40_idx=0
        if [ "$u40_break" -eq 1 ];then
            break
        fi
        u40_break=$((u40_break+1))
        echo "$u40_apache_home_check 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> $target
        for u40_apache_file in "${u40_apache_files[@]}";do
            for u40_apache_check in $u40_apache_file;do
                if [ -f "$u40_apache_check" ];then
                    u40_adected_filecks=$(grep -vE "^\s*#" "$u40_apache_check" | grep -iw "LimitRequestBody" | awk '{print $2}' )
                    for u40_adected_fileck in "${u40_adected_filecks[@]}";do
                        if [ -n "$u40_adected_fileck" ];then
                            if [[ "$u40_adected_fileck" -ge 5242880 ]];then
                                echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이상 설정되어 있습니다." >> $target
                                echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이상으로 설정된 디렉토리 경로 : ${u40_apache_check[$u40_idx]}" >> $target
                                u40_safe_check=$((u40_safe_check+1))
                                u40_idx=$((u40_idx+1))
                            else
                                echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이하로 적절하게 설정되어 있습니다.." >> $target
                                echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이하로 설정된 디렉토리 경로 : ${u40_check_dirpath_a[$u40_idx]}" >> $target
                                u40_idxn=$((u40_idxn+1))
                            fi
                        else
                            echo "$u40_apache_check 파일은 존재하지만 파일 업로드 및 다운로드 사이즈를 설정할 수 있는 LimitRequestBody 지시자가 존재하지 않습니다." >> $target
                            u40_idxn=$((u40_idxn+1))
                        fi
                    done
                fi
            done
        done
        u40_idx=0
    fi
done
echo "추가적인 Apache 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
u40_idx=0
u40_idxn=0
if [ -f "/etc/nginx/nginx.conf" ];then
    echo "/etc/nginx/nginx.conf 파일이 존재합니다." >> $target
    u40_dir_sizechecks_n=($(grep -vE "^\s*#" "/etc/nginx/nginx.conf" | grep -iw "^\s*client_max_body_size" | sed 's/^[ \t]*//' | awk '{print $2}' | tr -d ';'))
    if [ -n "$u40_dir_sizechecks_n" ];then
        for u40_dir_sizecheck_n in "${u40_dir_sizechecks_n[@]}";do
            if [[ $u40_dir_sizecheck_n -ge 5242880 ]];then
                echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이상 설정되어 있습니다." >> $target
                u40_safe_check=$((u40_safe_check+1))
                u40_idx=$((u40_idx+1))
            else
                echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이하로 적절하게 설정되어 있습니다.." >> $target
                u40_idxn=$((u40_idxn+1))
            fi
        done
    else
        echo "/etc/nginx/nginx.conf 파일은 존재하지만, 파일 업로드 및 다운로드 사이즈를 설정할 수 있는 client_max_body_size 지시자가 존재하지 않습니다." >> $target
    fi    
else 
    echo "/etc/nginx/nginx.conf 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> $target
    for u40_ngnix_file in "${u40_nginx_files[@]}";do
        for u40_nginx_check in $u39_ngnix_file;do
            u40_dir_sizechecks_n=($(grep -vE "^\s*#" "$u40_nginx_check" | grep -iw "^\s*client_max_body_size" | sed 's/^[ \t]*//' | awk '{print $2}' | tr -d ';'))
            if [ -f "$u40_nginx_check" ];then
                echo "$u40_nginx_check 파일이 존재합니다."
                #u39_ndected_filecks=$(grep -vE "^\s*#" "$u39_nginx_check" | grep -iw "autoindex" | tr -d ';' | grep -iw "on")
                for u40_dir_sizecheck_n in "${u40_dir_sizechecks_n[@]}";do
                    if [ -n "$u40_dir_sizecheck_n" ];then
                        if [ "$u40_dir_sizecheck_n" -ge 5242880 ];then
                            echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이상 설정되어 있습니다." >> $target
                            u40_safe_check=$((u40_safe_check+1))
                            u40_idx=$((u40_idx+1))
                        else
                            echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이하로 적절하게 설정되어 있습니다.." >> $target
                            u40_idxn=$((u40_idxn+1))
                        fi
                    else
                        echo "$u39_nginx_check 파일은 존재하지만 Body 사이즈를 제한하는 client_max_body_size 지시자가 존재하지 않습니다." >> $target
                        u40_idxn=$((u40_idxn+1))
                    fi
                done
                if [[ $u40_idx -ge 1 ]];then
                    echo "$u40_nginx_check 파일에서 파일 업로드 및 다운로드 사이즈가 5M이상으로 설정된 client_max_body_size가 있습니다." >> $target
                    echo "설정 값 : $u40_dir_sizecheck_n" >> $target
                    echo "총 $u40_idx 개의 취약한 사이즈 설정이 존재합니다. $u40_nginx_check 파일을 확인하십시오." >> $target
                    echo "파일 업로드 및 다운로드 사이즈가 적절하게 설정된 $u40_idxn 개의 설정이 존재 합니다. $u40_nginx_check 파일을 확인하십시오." >> $target
                fi
            fi
        done
    done
    echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
fi
if [[ $u40_safe_check -ge 1 ]];then
    u40=$((u40+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u40 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u40_Service_Management=1
fi