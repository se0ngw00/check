# 공통 함수 로드
if [ -f "/opt/check/common_functions.sh" ]; then
    . "/opt/check/common_functions.sh"
fi

cat << EOF
===== [U-33] DNS Security Version Patch              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-33 DNS 보안 버전 패치              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 취약점이 발표되지 않은 BIND 버전의 사용을 목적으로 함" >> $target
echo "+보안위협 : 최신버전(2016.01 기준 9.10.3-P2) 이하의 버전에서는 서비스거부 공격, 버퍼오버플로우(Buffer Overflow) 및 DNS 서버 원격 침입 등의 취약성이 존재함" >> $target
echo "+판단기준 양호 : DNS 서비스를 사용하지 않거나 주기적으로 패치를 관리하고 있는 경우" >> $target
echo "+판단기준 취약 : DNS 서비스를 사용하며 주기적으로 패치를 관리하고 있지 않는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
# Inverse Query 취약점 (Buffer Overflow) : BIND 4.9.7이전 버전과 BIND 8.1.2 이전 버전
# NXT버그 (buffer overflow) : BIND 8.2, 8.2 p1, 8.2.1버전

# solinger버그 (Denial of Service) : BIND 8.1 이상버전
# fdmax 버그 (Denial of Service) : BIND 8.1 이상버전
# Remote Execution of Code(Buffer Overflow) : BIND 4.9.5 to 4.9.10, 8.1, 8.2 to 8.2.6, 8.3.0 to 8.3.3 버전
# Multiple Denial of Service: BIND 8.3.0 - 8.3.3, 8.2 - 8.2.6 버전
# LIBRESOLV: buffer overrun(Buffer Overflow) : BIND 4.9.2 to 4.9.10 버전
# OpenSSL (buffer overflow) : BIND 9.1, BIND 9.2 if built with OpenSSL(configure --with-openssl)
# libbind (buffer overflow) : BIND 4.9.11, 8.2.7, 8.3.4, 9.2.2 이외의 모든 버전
# DoS internal consistency check (Denial of Service) : BIND 9 ~ 9.2.0 버전
# tsig bug (Access possible) : BIND 8.2 ~ 8.2.3 버전
# complain bug (Stack corruption, possible remote access) : BIND 4.9.x 거의 모든 버전
# zxfr bug (Denial of service) : BIND 8.2.2, 8.2.2 patchlevels 1 through 6 버전
# sigdiv0 bug (Denial of service) : BIND 8.2, 8.2 patchlevel 1, 8.2.2 버전
# srv bug(Denial of service): BIND 8.2, 8.2 patchlevel 1, 8.2.1, 8.2.2, 8.2.2 patchlevels 1-6 버전
# nxt bug (Access possible) : BIND 8.2, 8.2 patchlevel 1, 8.2.1 버전

# BIND 4.9.8 이전 버전, 8.2.3 이전 버전과 관련된 취약점
# - TSIG 핸들링 버퍼오버플로우 취약점
# - nslookupComplain() 버퍼오버플로우 취약점
# - nslookupComplain() input validation 취약점
# - information leak 취약점
# - sig bug Denial of service 취약점
# - naptr bug Denial of service 취약점
# - maxdname bug Denial of service 취약점
u33=0
u33_Service_Management=0
u33_safe_check=0
u33_current_ver=$(dpkg -s bind9 | grep '^Version' | awk '{print $2}')
u33_latest_ver=$(apt-cache show bind9 | grep '^Version' | head -n 1 | awk '{print $2}')
u33_services=("named" "dnsmasq" "unbound" "pdns_server" "bind9.service" "pdns_server" "bind9" "dnsmasq.service" "unbound.service" "pdns.service")
u33_ports=("53" "853" "443")

check_service_status "${u33_ports[@]}" "${u33_services[@]}"
if [[ $? -eq 1 ]]; then
    echo "DNS 서비스를 사용하고 있습니다." >> $target
    if [[ "$u33_current_ver" == "$u33_latest_ver" ]];then
        echo "현재 설치되어 있는 DNS(named) 서비스의 버전이 최신버전과 일치합니다." >> $target
        echo "현재 설치되어 있는 DNS(named) 서비스 버전 : $U33_cuu33_current_verrrent_ver" >> $target
        echo "최신 DNS(named) 서비스 버전 : $u33_latest_ver" >> $target
    else
        echo "현재 설치되어 있는 DNS(named) 서비스의 버전이 최신버전과 일치하지 않습니다." >> $target
        echo "현재 설치되어 있는 DNS(named) 서비스 버전 : $u33_current_ver" >> $target
        echo "최신 DNS(named) 서비스 버전 : $u33_latest_ver" >> $target
        u33_safe_check=$((u33_safe_check+1))
    fi
    u33_safe_check=$((u33_safe_check+1))
else
    echo "DNS 서비스를 사용하고 있지 않습니다." >> $target
    if [[ "$u33_current_ver" == "$u33_latest_ver" ]];then
        echo "현재 설치되어 있는 DNS(named) 서비스의 버전이 최신버전과 일치합니다." >> $target
        echo "현재 설치되어 있는 DNS(named) 서비스 버전 : $U33_cuu33_current_verrrent_ver" >> $target
        echo "최신 DNS(named) 서비스 버전 : $u33_latest_ver" >> $target
    else
        echo "현재 설치되어 있는 DNS(named) 서비스의 버전이 최신버전과 일치하지 않습니다." >> $target
        echo "현재 설치되어 있는 DNS(named) 서비스 버전 : $U33_cuu33_current_verrrent_ver" >> $target
        echo "최신 DNS(named) 서비스 버전 : $u33_latest_ver" >> $target
        u33_safe_check=$((u33_safe_check+1))
    fi
fi

if [[ $u33_safe_check -ge 1 ]];then
    u33=$((u33+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u33 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u33_Service_Management=1
fi