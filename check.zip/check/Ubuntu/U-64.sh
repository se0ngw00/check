cat << EOF
===== [U-64] FTP service root account access restrictions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-64 ftpusers 파일 설정(FTP 서비스 root 계정 접근제한)             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : root의 FTP 직접 접속을 방지하여 root 패스워드 정보를 노출되지 않도록 하기 위함" >> $target
echo "보안위협 : FTP 서비스는 아이디 및 패스워드가 암호화되지 않은 채로 전송되어 스니핑에 의해서 관리자 계정의 아이디 및 패스워드가 노출될 수 있음" >> $target
echo "+판단기준 양호 : FTP 서비스가 비활성화 되어 있거나, 활성화 시 root 계정 접속을 차단한 경우" >> $target
echo "+판단기준 취약 : FTP 서비스가 활성화 되어 있고, root 계정 접속을 허용한 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-64 점검 결과" >> $result

u64_Service_Management=0
u64=0
u64_ftp_checks=("ftp" "vsftpd" "proftpd")
u64_ftp_ports=("21" "20")
u64_ftp_root_setting_files=("/etc/ftpusers" "/etc/ftpd/ftpusers" "/etc/vsftpd/ftpusers" "/etc/vsftpd/user_list" "/etc/vsftpd.user_list" "/etc/proftpd.conf")
u64_safe_check=0
check_service_status "${u64_ftp_ports[@]}" "${u64_ftp_checks[@]}"
if [[ $? -eq 1 ]]; then
    echo "ftp 서비스를 사용하고 있습니다." >> $target
    u64=$((u64+1))
    u64_root_allowed=0
    for u64_ftp_root_setting_file in "${u64_ftp_root_setting_files[@]}";do
        if [ -e "$u64_ftp_root_setting_file" ];then
            echo "$u64_ftp_root_setting_file 파일이 존재합니다.">> $target
            if [[ "$u64_ftp_root_setting_file" == "/etc/proftpd.conf" ]];then
                if grep -iv "^\s*#" "$u64_ftp_root_setting_file" | grep -iqE  "^\s*RootLogin\s*on$";then
                    echo "$u64_ftp_root_setting_file 에서 root 계정 접속을 허용하고 있습니다.">> $target
                    echo "현재 설정값 : $(grep -i "RootLogin" "$u64_ftp_root_setting_file")">> $target
                    u64_root_allowed=1
                else
                    echo "$u64_ftp_root_setting_file 에서 root 계정 접속을 차단 하고 있습니다.">> $target
                    echo "현재 설정값 (존재할 경우 출력): $(grep -i "RootLogin" "$u64_ftp_root_setting_file")">> $target
                fi
            else
                # ftpusers 파일의 경우 root가 있으면 차단, 없으면 허용
                if grep -iv "^\s*#" "$u64_ftp_root_setting_file" | grep -iqE  "^\s*root\s*$";then
                    echo "$u64_ftp_root_setting_file 에서 root 계정 접속을 차단 하고 있습니다.">> $target
                    echo "현재 설정값 (존재할 경우 출력): $(grep -i "^root$" "$u64_ftp_root_setting_file")">> $target
                else
                    echo "$u64_ftp_root_setting_file 에서 root 계정 접속이 허용되어 있습니다.">> $target
                    u64_root_allowed=1
                fi
            fi
        fi
    done
    if [[ $u64_root_allowed -eq 1 ]]; then
        u64_safe_check=$((u64_safe_check+1))
    fi
else
    echo "ftp 서비스를 사용하고 있지 않습니다." >> $target
fi
if [[ $u64_safe_check -ge 1 ]];then
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi

if [[ $u64 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u64_Service_Management=1
fi