cat << EOF
===== [U-60] Allow ssh remote access              =====w
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-60 ssh 원격접속 허용             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 비교적 안전한 SSH 프로토콜을 사용함으로써 스니핑 등 아이디/패스워드의 누출의 방지를 목적으로함" >> $target
echo "보안위협 : 원격 접속 시 Telnet, FTP 등은 암호화되지 않은 상태로 데이터를 전송하기 때문에 아이디/패스워드 및 중요 정보가 외부로 유출될 위험성이 있음" >> $target
echo "+판단기준 양호 : 원격 접속 시 SSH 프로토콜을 사용하는 경우" >> $target
echo "※ ssh, telnet이 동시에 설치되어 있는 경우 취약한 것으로 평가됨" >> $target
echo "+판단기준 취약 : 원격 접속 시 Telnet, FTP 등 안전하지 않은 프로토콜을 사용하는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-60 점검 결과" >> $result
u60_safe_check=0
u60_Service_Management=0
u60=0
# 값 설정
u60_ssh_checks=("ssh" "sshd")
u60_telnet_ftp_checks=("telnet" "vsftpd" "proftpd")

u60_telnet_ports=("23" "21" "20")

# 함수 호출
u60_ssh_port=("22")  # 단일 포트 번호를 배열 형태로 설정

check_service_status "${u60_ssh_port[@]}" "${u60_ssh_checks[@]}"
u60_ssh_status=$?
check_service_status "${u60_telnet_ports[@]}" "${u60_telnet_ftp_checks[@]}"
u60_telnet_status=$?

if [ $u60_ssh_status -eq 1 ]; then
    echo "ssh 프로토콜을 사용하고 있습니다." >> $target
    if [ $u60_telnet_status -eq 1 ]; then
        echo "ssh 서비스와 함께 telnet 또는 ftp 서비스를 사용하고 있습니다." >> $target
        u60_safe_check=$((u60_safe_check+1))
    else
        echo "ssh 프로토콜만을 사용하고 있습니다." >> $target
    fi
else
    echo "ssh 프로토콜을 사용하지 않고 있습니다." >> $target
    u60_safe_check=$((u60_safe_check+1))
fi

if [[ $u60_safe_check -ge 1 ]];then
    u60=$((u60+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u60 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u60_Service_Management=1
fi