cat << EOF
===== [U-32] Prevent end-user Sendmail execution              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-32 일반사용자의 Sendmail 실행 방지              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 일반사용자의 q 옵션을 제한하여 Sendmail 설정 및 메일큐를 강제적으로 drop 시킬 수 없게 하여 비인가자에 의한 SMTP 서비스 오류 방지" >> $target
echo "+보안위협 : 일반 사용자가 q 옵션을 이용해서 메일큐, Sendmail 설정을 보거나 메일큐를 강제적으로 drop 시킬 수 있어 악의적으로 SMTP 서버의 오류를 발생시킬 수 있음" >> $target
echo "+판단기준 양호 : SMTP 서비스 미사용 또는, 일반 사용자의 Sendmail 실행 방지가 설정된 경우" >> $target
echo "+판단기준 취약 : SMTP 서비스 사용 및 일반 사용자의 Sendmail 실행 방지가 설정되어 있지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u32=0
u32_Service_Management=0
u32_safe_check=0
u32_service=("sendmail" "postfix" "exim" "sendmail.service" "postfix.service" "exim.service")
u32_ports=("25" "465" "587")

check_service_status "${u32_ports[@]}" "${u32_service[@]}"
if [[ $? -eq 1 ]]; then
    echo "sendmail 서비스를 사용하고 있습니다." >> $target
    u32_sendmail_conf=$(grep -vE "^\s*#" "/etc/mail/sendmail.cf" | grep -i "PrivacyOptions")
    if grep -vE "^\s*#" "/etc/mail/sendmail.cf" | grep -i "PrivacyOptions" | grep -qi "restrictqrun";then
        echo "메일 큐(queue)에 대한 일반 사용자의 접근을 제한하고 있습니다." >> $target
        echo "현재 설정된 값 : $u32_sendmail_conf" >> $target
    else
        echo "메일 큐(queue)에 대한 일반 사용자의 접근을 제한하고 있지 않습니다." >> $target
        echo "현재 설정된 값 : $u32_sendmail_conf" >> $target
        u32_safe_check=$((u32_safe_check+1))
    fi
    u32_safe_check=$((u32_safe_check+1))
else
    echo "sendmail 서비스를 사용하고 있지 않습니다." >> $target
    u32_sendmail_conf=$(grep -vE "^\s*#" "/etc/mail/sendmail.cf" | grep -i "PrivacyOptions")
    if grep -vE "^\s*#" "/etc/mail/sendmail.cf" | grep -i "PrivacyOptions" | grep -qi "restrictqrun";then
        echo "메일 큐(queue)에 대한 일반 사용자의 접근을 제한하고 있습니다." >> $target
        echo "현재 설정된 값 : $u32_sendmail_conf" >> $target
    else
        echo "메일 큐(queue)에 대한 일반 사용자의 접근을 제한하고 있지 않습니다." >> $target
        echo "현재 설정된 값 : $u32_sendmail_conf" >> $target
        u32_safe_check=$((u32_safe_check+1))
    fi
fi

if [[ $u32_safe_check -ge 1 ]];then
    u32=$((u32+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u32 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u32_Service_Management=1
fi