cat << EOF
===== [U-62] restricting tp account shell              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-62 tp 계정 shell 제한             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : FTP 서비스 설치 시 기본으로 생성되는 ftp 계정은 로그인이 필요하지 않은 계정으로 쉘을 제한하여 해당 계정으로의 시스템 접근을 차단하기 위함" >> $target
echo "보안위협 :  불필요한 기본 계정에 쉘(Shell)을 부여할 경우, 공격자에게 해당 계정이 노출되어 ftp 기본 계정으로 시스템 접근하여 공격이 가능해" >> $target
echo "+판단기준 양호 : ftp 계정에 /bin/false 쉘이 부여되어 있는 경우" >> $target
echo "+판단기준 취약 : ftp 계정에 /bin/false 쉘이 부여되어 있지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-62 점검 결과" >> $result

u62_safe_check=0
u62_Service_Management=0
u62=0
u62_ftp_shell=$(grep -i "ftp" "/etc/passwd" | awk -F':' '{print $7}' | awk -F'/' '{print $NF}')
u62_check_safe_shells=("nologin" "false" "ftp-only")

if [ -n "$u62_ftp_shell" ];then
    echo "ftp 계정이 존재합니다." >> $target
    u62_check=0
    for u62_check_safe_shell in "${u62_check_safe_shells[@]}";do
        if [[ "$u62_ftp_shell" == "$u62_check_safe_shell" ]];then
            echo "ftp 계정의 shell 이 $u62_ftp_shell 로 설정되어 있습니다." >> $target
            u62_check=$((u62_check+1))
            break
        else   
            if [ $u62_check -eq 1 ];then
                echo "ftp 계정의 shell 이 $u62_ftp_shell 로 설정되어 있습니다." >> $target
                u62_safe_check=$((u62_safe_check+1))
            fi
        fi
    done
else
    echo "ftp 계정이 존재하지 않습니다." >> $target
fi

if [[ $u62_safe_check -ge 1 ]];then
    u62=$((u62+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u62 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u62_Service_Management=1
fi