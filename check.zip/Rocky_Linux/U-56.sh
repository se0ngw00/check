cat << EOF
===== [U-56] Managing UMASK Settings              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-56  UMASK 설정 관리             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 잘못 설정된 UMASK 값으로 인해 신규 파일에 대한 과도한 권한 부여되는 것을 방지하기 위함" >> $target
echo "보안위협 : 잘못된 UMASK 값으로 인해 파일 및 디렉터리 생성시 과도하게 퍼미션이 부여 될 수 있다." >> $target
echo "+판단기준 양호 🔘: UMASK 값이 022 이상으로 설정된 경우" >> $target
echo "+판단기준 취약 🚫: UMASK 값이 022 이상으로 설정되지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target

u56_Files_Directory_Management=0
u56_safe_check=0
u56=0
u56_files=("/etc/bash.bashrc" "/etc/zsh/zshrc" "/etc/ksh.kshrc" "/etc/profile" "/etc/.profile" "/etc/login.defs" "/etc/default/useradd" "/etc/default/login" "/etc/.login")
u56_individual_files=(".bashrc" ".zshrc" ".kshrc" ".bash_profile" ".cshrc" ".login" )
u56_dirs=("/etc/profile.d/*.sh" "/etc/profile.d/*.csh" "/etc/profile.d/*.ksh")
u56_csh_files=("/etc/csh.cshrc" "/etc/csh.login")

u56_check_users=($(awk -F':' '!/sbin|sync|false/ {print $1}' /etc/passwd))

u56_to_decimal() {
    printf "%d\n" "$((8#$1))"
}
u56_umask=$(u56_to_decimal 022)
for u56_check_dir in ${u56_dirs[@]}; do
    for u56_dir in $u56_check_dir; do
        if [ -e "$u56_dir" ]; then
            echo "$u56_dir 파일이 존재합니다." >> $target
            IFS=$'\n' u56_dir_umasksh=($(grep -Ev "^\s*#" "$u56_dir" | grep -Ei "^\s*umask" | awk '{print $2}'))
            if [ -n "$u56_dir_umasksh" ]; then
                echo "$u56_dir umask 설정 값이 존재합니다." >> $target
                for u56_dir_umask in "${u56_dir_umasksh[@]}";do
                    u56_dec_dir=$(u56_to_decimal $u56_dir_umasksh)
                    if [ $u56_dec_dir -ge $u56_umask ]; then
                        echo "umask 설정 값이 022이상으로 적절하게 설정되어 있습니다." >> $target
                        echo "현재 설정 값 : $u56_dir_umask" >> $target
                    else   
                        echo "umask 설정 값이 022이하로 부적절하게 설정되어 있습니다." >> $target
                        echo "현재 설정 값 : $u56_dir_umask" >> $target
                        u56_safe_check=$((u56_safe_check+1))
                    fi
                done
            else
                echo "$u56_dir 파일에 umask 설정 값이 존재하지 않습니다." >> $target
                u56_safe_check=$((u56_safe_check+1))
            fi
        fi
    done
done

for u56_file in "${u56_files[@]}"; do
    if [ -e "$u56_file" ]; then
        echo "$u56_file 파일이 존재합니다." >> $target
        u56_file_umask=($(grep -Ev "^\s*#" "$u56_file" | grep -Ei "^\s*umask" | awk '{print $2}'))
        if [ -n "$u56_file_umask" ]; then
            echo "$u56_file umask 설정 값이 존재합니다." >> $target
            for u56_umask_value in "${u56_file_umask[@]}"; do
                u56_dec_file=$(u56_to_decimal "$u56_umask_value")    
                if [ "$u56_dec_file" -ge "$u56_umask" ]; then
                    echo "umask 설정 값이 022이상으로 적절하게 설정되어 있습니다." >> $target
                    echo "현재 설정 값 : $u56_umask_value" >> $target
                else   
                    echo "umask 설정 값이 022이하로 부적절하게 설정되어 있습니다." >> $target
                    echo "현재 설정 값 : $u56_umask_value" >> $target
                    u56_safe_check=$((u56_safe_check+1))
                fi
            done    
        else
            echo "$u56_file 파일에 umask 설정 값이 존재하지 않습니다." >> $target
            u56_safe_check=$((u56_safe_check+1))
        fi
    fi
done

for u56_csh_file in "${u56_csh_files[@]}"; do
    if [ -e "$u56_csh_file" ]; then
        echo "$u56_csh_file 파일이 존재합니다." >> $target
        u56_cshfile_umask=($(grep -Ev "^\s*#" "$u56_csh_file" | grep -Ei "^\s*umask" | awk '{print $2}'))
        if [ -n "$u56_cshfile_umask" ]; then
            echo "$u56_csh_file umask 설정 값이 존재합니다." >> $target
            for u56_csh_umask in "${u56_cshfile_umask[@]}";do
                u56_dec_cshfile=$(u56_to_decimal $u56_csh_umask)
                if [ $u56_dec_cshfile -ge $u56_umask ]; then
                    echo "umask 설정 값이 022이상으로 적절하게 설정되어 있습니다." >> $target
                    echo "현재 설정 값 : $u56_csh_umask" >> $target
                else   
                    echo "umask 설정 값이 022이하로 부적절하게 설정되어 있습니다." >> $target
                    echo "현재 설정 값 : $u56_csh_umask" >> $target
                    u56_safe_check=$((u56_safe_check+1))
                fi
            done
        else
            echo "$u56_csh_file 파일에 umask 설정 값이 존재하지 않습니다." >> $target
            u56_safe_check=$((u56_safe_check+1))
        fi
    fi
done

for u56_check_user in "${u56_check_users[@]}"; do
    u56_user_home=$(getent passwd "$u56_check_user" | awk -F':' '{print $6}')w
    if [ -d "$u56_user_home" ]; then
        echo "--------------------------------------"  >> $target
        echo "$u56_check_user 의 홈 디렉터리가 존재합니다." >> $target
        for u56_individual_file in "${u56_individual_files[@]}"; do
            echo -e "Checking file: $u56_user_home/$u56_individual_file"  >> $target
            if [ -e "$u56_user_home/$u56_individual_file" ]; then
                echo "$u56_user_home/$u56_individual_file 파일이 존재합니다."  >> $target
                u56_check_umask=($(grep -Ev "^\s*#" "$u56_user_home/$u56_individual_file" | grep -Ei "^\s*umask" | awk '{print $2}'))
                if [ -n "$u56_check_umask" ]; then
                    echo "$u56_user_home/$u56_individual_file 파일에 umask 설정 값이 존재합니다." >> $target
                    for u56_individual_umask in "${u56_check_umask[@]}";do
                    u56_dec_userumask=$(u56_to_decimal $u56_individual_umask)
                    if [ $u56_dec_userumask -ge $u56_umask ]; then
                        echo "umask 설정 값이 022이상으로 적절하게 설정되어 있습니다." >> $target
                        echo "현재 설정 값 : $u56_individual_umask" >> $target
                    else   
                        echo "umask 설정 값이 022이하로 부적절하게 설정되어 있습니다." >> $target
                        echo "현재 설정 값 : $u56_individual_umask" >> $target
                        u56_safe_check=$((u56_safe_check+1))
                    fi
                    done
                else
                    echo "$u56_user_home/$u56_individual_file 파일에 파일에 umask 설정 값이 존재하지 않습니다." >> $target
                    u56_safe_check=$((u56_safe_check+1))
                fi
            else
                echo "$u56_user_home/$u56_individual_file 파일이 존재하지 않습니다." >> $target
            fi
        done
    else
        echo "$u56_check_user 의 홈 디렉터리가 존재하지 않습니다." >> $target
    fi
done

if [[ $u56_safe_check -ge 1 ]];then
    u56=$((u56+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u56 -ge 1 ]];then
    Mid=$((Mid+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u56_Files_Directory_Management=1
fi