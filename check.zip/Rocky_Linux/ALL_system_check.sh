#!/bin/bash
set -e

. /etc/os-release

TOTAL_FILE="$RESULT_DIR/${RESULT_PREFIX}.total"
VULN_FILE="$RESULT_DIR/${RESULT_PREFIX}.vuln"

> "$TOTAL_FILE"
> "$VULN_FILE"

export target="/dev/stdout"
export result="/dev/stdout"

{
  echo "Linux Security Check Result"
  echo "Host : $(hostname)"
  echo "OS   : $PRETTY_NAME"
  echo "Date : $(date '+%Y-%m-%d %H:%M:%S')"
  echo "----------------------------------------"
} >> "$TOTAL_FILE"

if [ "$TEST_MODE" = "1" ]; then
  SCRIPTS="U-TEST.sh"
else
  SCRIPTS=$(ls U-[0-9][0-9].sh 2>/dev/null | sort)
fi

TOTAL_COUNT=0
VULN_COUNT=0
VULN_ITEMS=""

echo "[취약 항목 점검 결과]" >> "$VULN_FILE"
echo >> "$VULN_FILE"

for script in $SCRIPTS; do
  ITEM_ID="$(basename "$script" .sh)"
  TMP_OUT=$(mktemp)
  SCRIPT_EXIT=0

  echo >> "$TOTAL_FILE"
  echo "[$ITEM_ID]" >> "$TOTAL_FILE"

  if ! bash "$script" > "$TMP_OUT" 2>&1; then
    SCRIPT_EXIT=$?
  fi

  {
    echo "=================================================================="
    echo "[$ITEM_ID] 결과 요약"
    echo "------------------------------------------------------------------"
    cat "$TMP_OUT"
    echo "------------------------------------------------------------------"
  } >> "$TOTAL_FILE"

  STATUS="UNKNOWN"
  if grep -q "점검 결과[[:space:]]*:[[:space:]]*취약" "$TMP_OUT"; then
    STATUS="취약"
    echo "- $ITEM_ID : REVIEW_REQUIRED" >> "$VULN_FILE"
    VULN_COUNT=$((VULN_COUNT + 1))
    VULN_ITEMS="${VULN_ITEMS}- ${ITEM_ID}\n"
  elif grep -q "점검 결과[[:space:]]*:[[:space:]]*양호" "$TMP_OUT"; then
    STATUS="양호"
  fi

  echo "결과 요약 : $STATUS" >> "$TOTAL_FILE"
  if [ "$SCRIPT_EXIT" -ne 0 ]; then
    echo "스크립트 종료 코드 : $SCRIPT_EXIT" >> "$TOTAL_FILE"
  fi

  TOTAL_COUNT=$((TOTAL_COUNT + 1))
  rm -f "$TMP_OUT"
done

echo >> "$VULN_FILE"
echo "총 점검 항목 수 : $TOTAL_COUNT" >> "$VULN_FILE"
echo "검토 필요 항목 수 : $VULN_COUNT" >> "$VULN_FILE"

{
  echo
  echo "----------------------------------------"
  echo "요약"
  echo "총 점검 항목 수 : $TOTAL_COUNT"
  echo "검토 필요 항목 수 : $VULN_COUNT"
  if [ -n "$VULN_ITEMS" ]; then
    echo "검토 필요 목록:"
    printf "%b" "$VULN_ITEMS"
  fi
} >> "$TOTAL_FILE"
