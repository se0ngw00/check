cat << EOF
===== [U-21] Disabling r Family Services              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-21  r 계열 서비스 비활성화             " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : r-command 사용을 통한 원격 접속은 NET Backup 또는 클러스터링 등 용도로 사용되기도 하나, 인증 없이 관리자 원격접속이 가능하여 이에 대한 보안위협을 방지하고자 함" >> $target
echo "보안위협 :  rsh, rlogin, rexec 등의 r command를 이용하여 원격에서 인증절차 없이 터미널 접속, 쉘 명령어를 실행이 가능함" >> $target
echo "+판단기준 양호 🔘: 불필요한 r 계열 서비스가 비활성화 되어 있는 경우" >> $target
echo "+판단기준 취약 🚫: 불필요한 r 계열 서비스가 활성화 되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-21 점검 결과" >> $result
u21_Service_Management=0
u21_safe_check=0
u21=0
u21_checkrcommands=("rsh" "rlogin" "rexec" "shell" "login" "exec")
u21_doublechecks=("shell" "login" "exec")
u21_checkports=("514" "513" "512")
u21_cmdlen=${#u21_checkrcommands[@]}

for u21_checkrcommand in "${u21_checkrcommands[@]}"; do 
    u21_checkservice=$(systemctl status "$u21_checkrcommand" 2> /dev/null | grep -i "Active" | grep -i "running" | awk -F')' '{print tolower($1)}' | tr -d ' ')
    if [ "$u21_checkservice"  == "active:active(running" ]; then
        for u21_checkport in "${u21_checkports[@]}"; do
            u21_checkprotstat=$(netstat -tlun | awk '{print $4}' | grep "$u21_checkport")
            if [ -n "$u21_checkprotstat" ]; then
                echo "$u21_checkrcommand 서비스가 동작 중이며, $u21_checkport 포트로 동작하고 있습니다." >> $target
                u21_safe_check=$((u21_safe_check+1))
                break
            else
                echo "$u21_checkrcommand 서비스가 동작 중이지만 $u21_checkport 포트로 동작하고 있지 않습니다." >> $target
                u21_safe_check=$((u21_safe_check+))
                u21_newport=$(grep "^$u21_checkrcommand[[:space:]]" /etc/services | awk '{print $2}' | cut -d'/' -f1)
                u21_newportstat=$(netstat -tlun | awk '{print $4}' | grep -wE "$u21_newport")
                if [ -n "$u21_newportstat" ]; then
                    echo "$u21_checkrcommand 서비스가 $u21_newport 포트로 동작하고 있습니다." >> $target
                    break
                fi
            fi
        done
    else
        echo "$u21_checkrcommand 서비스가 동작 중이지 않습니다." >> $target
    fi
done
for u21_checkrcommand_inetd in "${u21_checkrcommands[@]}"; do
    if [ -f "/etc/inetd.conf" ];then
        echo "/etc/inetd.conf 파일이 존재합니다." >> $target
        for (( i=0; i<u21_cmdlen; i++ ))
        do
            if ! grep -iqE "^\s*#\s*$u21_checkrcommand_inetd\s*";then
                echo "$u21_checkrcommand_inetd 서비스가 활성화 되어 있습니다." >> $target
                u21_safe_check=$((u21_safe_check+))
                echo "설정 값 : $(grep -iE "^\s*#\s*$u21_checkrcommand_inetd\s*")" >> $target
            elif grep -iqE "^\s*$u21_checkrcommand_inetd\s*";then
                echo "$u21_checkrcommand_inetd 서비스가 비활성화 되어 있습니다." >> $target
            else
                echo "r-command 설정값이 존재하지 않습니다." >> $target
            fi
        done
    else
        echo "/etc/inetd.conf 파일이 존재하지 않습니다." >> $target
        break
    fi
done
u21_checkconf=0
for u21_checkrcommand_xinetd in "${u21_checkrcommands[@]}"; do 
    if [ -f "/etc/xinetd.d/$u21_checkrcommand_xinetd" ];then   
        echo "/etc/xinetd.d/$u21_checkrcommand_xinetd 파일이 존재 합니다." >> $target
        if ls -alL /etc/xinetd.d/* | grep -i "$u21_checkrcommand_xinetd" | awk '{print $9}' | awk -F'/' '{print $4}' | grep -iqvE "^k";then
            #u21_doubelcheckoption=$(sed -n "/service\s*$u21_checkrcommand_xinetd/,/}/p" "$u21_/etc/xinetd.d/$u21_checkrcommand_xinetd";)
            for u21_doublecheck in "${u21_checkrcommands[@]}";do
                #if [ -n "$u21_doubelcheckoption" ];then
                    u21_rcmdoption=$(sed -n "/service\s*$u21_doublecheck/,/}/p" "$u21_/etc/xinetd.d/$u21_checkrcommand_xinetd" | grep -ivE "^\s*#" | grep -iE "disable" | awk '{print tolower($3)}' | sed -n '1p')
                    if [[ $u21_rcmdoption == "no" ]];then
                        echo "r-command 중 $u21_checkrcommand_xinetd 서비스가 활성화 되어 있습니다." >> $target
                        u21_safe_check=$((u21_safe_check+))
                        break
                    elif [[ $u21_rcmdoption == "yes" ]];then
                        echo "r-command 중 $u21_checkrcommand_xinetd 서비스가 비활성화 되어 있습니다." >> $target
                        break
                    elif sed -n "/service\s*$u21_doublecheck/,/}/p" "/etc/xinetd.d/$u21_checkrcommand_xinetd" | grep -iE "^\s*#";then
                        echo "설정값이 주석처리 되어 있습니다." 
                        break
                    else
                        u21_checkconf=$((u21_checkconf+1))  
                    fi
                #fi
            done
            if [[ $u21_checkconf -eq ${#u21_checkrcommands[@]} ]];then
                echo "설정값이 존재하지 않습니다." >> $target
            fi
            u21_checkconf=0
        fi
    else
        echo "/etc/xinetd.d/$u21_checkrcommand_xinetd 파일이 존재하지 않습니다." >> $target
    fi
done

if [[ $u21_safe_check -ge 1 ]];then
    u21=$((u21+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u21 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u21_Service_Management=1
fi