cat << EOF
===== [U-07] /etc/passwd file owner and permission settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-07   /etc/passwd 파일 소유자 및 권한 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : /etc/passwd 파일의 임의적인 변경을 차단하기 위함을 통해 비인가자가 권한 상승하는 것을 막기 위함" >> $target
echo "보안위협 : 관리자(root) 외 사용자가 /etc/passwd 파일의 사용자 정보를 변조하여 shell 변경, 사용자 추가/삭제 등 root를 포함한 사용자 권한 획득 가능" >> $target
echo "+판단기준 양호 🔘: /etc/passwd 파일의 소유자가 root이고, 권한이 644 이하인 경우" >> $target
echo "+판단기준 취약 🚫: /etc/passwd 파일의 소유자가 root가 아니거나, 권한이 644 이하가 아닌경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-7 점검 결과" >> $result
u7=0
u7_safe_check=0
u7_Account_Management=0

if [[ -e "/etc/passwd" ]];then
    echo "/etc/passwd 파일이 존재합니다."
    u7_file_owner=$(stat -c "%U" "/etc/passwd" 2> /dev/null)
    u7_file_owner=$(stat -c "%a" "/etc/passwd"  2> /dev/null| cut -c1)
    u7_file_group=$(stat -c "%a" "/etc/passwd"  2> /dev/null| cut -c2)
    u7_file_other=$(stat -c "%a" "/etc/passwd"  2> /dev/null| cut -c3)
    u7_check_suid=$(stat -c "%a" "/etc/passwd"  2> /dev/null| tr -d '\n' | wc -c)
    if [[ $u7_check_suid -ge 4 ]];then
        echo "$u7_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> $target
        u7_safe_check=$((u7_safe_check+1))
    else
        if [[ "$u7_file_owner" == "root" ]];then
            echo "/etc/passwd 파일의 소유자가 root로 적절하게 설정되어 있습니다." >> $target
            if [ $u7_file_owner -le 6 ];then
                echo "/etc/passwd 파일의 소유 권한이 6이하로 설정되어 있습니다." >> $target
                if [ $u7_file_group -le 4 ];then
                    echo "/etc/passwd 파일의 소유 그룹 권한이 4이하로 설정되어 있습니다." >> $target
                    if [ $u7_file_other -eq 4 ];then
                        echo "/etc/passwd 파일의 기타 사용자(Other) 권한이 4으로 설정되어 있습니다." >> $target
                    else
                        echo "/etc/passwd 파일의 기타 사용자(Other) 권한이 4이 아닌 값으로 설정되어 있습니다." >> $target
                        u7_safe_check=$((u7_safe_check+1))
                    fi
                else
                    ehco "/etc/passwd 파일의 소유 그룹 권한이 4이상으로 설정되어 있습니다." >> $target
                    u7_safe_check=$((u7_safe_check+1))
                fi
            else
                echo "/etc/passwd 파일의 소유 권한이 6이상으로 설정되어 있습니다." >> $target
                u7_safe_check=$((u7_safe_check+1)) 
            fi
        else
            echo "/etc/passwd 파일의 소유자가 root가 아닌 다른 사용자로 설정되어 있습니다." >> $target
            u7_safe_check=$((u7_safe_check+1))
        fi
    fi
else
    echo "/etc/passwd 파일이 존재하지 않습니다." >> $target
    u7_safe_check=$((u7_safe_check+1))
fi


if [ $u7_safe_check -ge 1 ];then
    u7=$((u7+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u7 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u7_Files_Directory_Management=1
fi
