#!/bin/bash
echo "[TEST MODE] OK" >> "$target"

echo "점검 결과 : 양호"
