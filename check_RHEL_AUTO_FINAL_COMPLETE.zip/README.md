Final complete version including OS-specific U-xx.sh scripts.
