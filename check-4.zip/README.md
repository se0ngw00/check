check-4: enterprise infra security check, conservative REVIEW_REQUIRED mode
