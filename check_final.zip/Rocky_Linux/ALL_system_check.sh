#!/bin/bash

# bash shell로 실행 시키세요.
if [ "$EUID" -ne 0 ]
        then echo "root 권한으로 실행시키세요."
        exit
fi

#yum install tree
RED='\033[31m'
NC='\033[0m' # No Color
hostname=$(hostname)
date_time=$(date '+%Y%m%d-%H%M%S')
release=$(cat /etc/redhat-release )
info=$(uname -a)

target="./${hostname}.${date_time}.detail"
result="./${hostname}.${date_time}.result"

rm -f $target
rm -f $result
severity_total="./severity_total"
echo -n > "$severity_total"

High=0
Mid=0
Low=0
Account_Management=0
Files_Directory_Management=0
Service_Management=0
Patch_Management=0
Log_Management=0
check_service_status() {
    local port_numbers=("$1")  # 첫 번째 인자는 포트 번호 배열 또는 단일 포트 번호
    shift  # 첫 번째 인자를 제거하고 나머지 인자들을 서비스 이름으로 설정

    local services=("$@")  # 나머지 인자를 배열에 저장
    local any_service_active=0  # 플래그 초기화

    for i in "${!services[@]}"; do
        local service_name=${services[$i]}
        local port_number=${port_numbers[$i]:-0}  # 포트 번호가 없으면 기본값 0

        echo "Checking $service_name..." >> "$target"

        # 서비스 활성화 여부 체크
        if systemctl is-active --quiet "$service_name"; then
            echo "현재 시스템에 $service_name 서비스가 활성화 되어 있습니다. 불필요한 경우 비활성화가 이루어져야 합니다." >> "$target"
            any_service_active=1  # 플래그를 1로 설정
        else
            echo "현재 시스템에 $service_name 서비스가 비활성화 되어 있습니다." >> "$target"
        fi

        # 네트워크 포트 체크
        local netstat_ports=$(netstat -tuln | awk '{print $4}' | awk -F':' '{print $2}')

        if [ $port_number -ne 0 ] && echo "$netstat_ports" | grep -qE "^$port_number$"; then
            echo "$service_name 서비스가 $port_number 포트번호로 설정되어 있습니다." >> "$target"
            echo "$service_name 서비스가 $port_number 번 포트번호로 서비스가 동작중입니다." >> "$target"
        else
            local new_port=$(grep -wE "^$service_name\s+" /etc/services | awk '{print $2}' | awk -F'/' '{print $1}' | head -n 1)
            if [ -n "$new_port" ]; then
                echo "$service_name 서비스가 $new_port 포트번호로 설정되어 있습니다." >> "$target"
                if echo "$netstat_ports" | grep -qE "^$new_port$"; then
                    echo "$service_name 서비스가 $new_port 포트번호로 서비스가 동작중입니다." >> "$target"
                else
                    echo "$service_name 서비스가 $new_port 포트번호로 동작중인 서비스가 없습니다." >> "$target"
                fi
            else
                echo "$service_name 서비스가 /etc/services 파일에 정의되어 있지 않습니다." >> "$target"
            fi
        fi

        # inetd 서비스 체크
        if [ -f "/etc/inetd.conf" ]; then
            if grep -qiwE "^\s*$service_name" /etc/inetd.conf; then
                echo "/etc/inetd.conf 파일에서 $service_name 서비스가 활성화 되어 있습니다." >> "$target"
            else
                echo "/etc/inetd.conf 파일에서 $service_name 서비스가 비활성화 되어 있습니다." >> "$target"
            fi
        else
            echo "/etc/inetd.conf 파일이 존재하지 않습니다." >> "$target"
        fi

        # xinetd 서비스 체크
        if [ -d "/etc/xinetd.d" ]; then
            if [ -f "/etc/xinetd.d/$service_name" ]; then
                local xinetd_conf=$(grep -iE "\s*disable" "/etc/xinetd.d/$service_name" | grep -v "^#" | awk '{print $3}' | head -n 1)
                if [[ "$xinetd_conf" == "no" ]]; then
                    echo "/etc/xinetd.d/$service_name 파일내에 $service_name 항목이 활성화 되어 있습니다." >> "$target"
                else
                    echo "/etc/xinetd.d/$service_name 파일내에 $service_name 항목이 비활성화 되어 있습니다." >> "$target"
                fi
            else
                echo "/etc/xinetd.d/$service_name 파일이 존재하지 않습니다." >> "$target"
            fi
        else
            echo "/etc/xinetd.d 디렉터리가 존재하지 않습니다." >> "$target"
        fi

        echo "Finished checking $service_name." >> "$target"
        echo "" >> "$target"  # 빈 줄 추가
    done

    # 동작 중인 서비스가 하나라도 있으면 1을 출력
    if [ $any_service_active -eq 1 ]; then
        return 1
    else
        return 0
    fi
}

cat << EOF
===== [U-01] Remote Login Permission for the root User  =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-01 [위험도 상] root 계정 원격 접속 제한                         "  >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 관리자계정 탈취로 인한 시스템 장악을 방지하기 위해 외부 비인가자의 root 계정 접근 시도를 원천적으로 차단하기 위함" >> $target
echo "보안위협 : root 계정은 운영체제의 모든기능을 설정 및 변경이 가능하여(프로세스, 커널변경 등) root 계정을 탈취하여 외부에서 원격을 이용한 시스템 장악 및 각종 공격으로(무작위 대입 공격) 인한 root 계정 사용 불가 위협" >> $target
echo "+판단기준 양호 : 원격 터미널 서비스를 사용하지 않거나, 사용 시 root 직접 접속을 차단한 경우" >> $target
echo "+판단기준 취약 : 원격 터미널 서비스 사용 시 root 직접 접속을 허용한 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-1 점검 결과" >> $result
u1=0
u1_safe_check=0
u1_Account_Management=0

telnet_access_check() {
    if [ -f "/etc/securetty" ]; then
        echo "/etc/securetty 파일: 존재함" >> "$target"
        if grep -q "pts" "/etc/securetty"; then
            u1_safe_check=$((u1_safe_check+1))
        else
            echo "pts 항목: 발견되지 않음">> "$target"
        fi
    else
        echo "/etc/securetty 파일이 존재하지 않습니다." >> "$target"
    fi
    
    if [ -f "/etc/pam.d/login" ]; then
        echo "/etc/pam.d/login 파일이 존재합니다." >> "$target"
        if grep -qiE "^\s*#\s*auth\s*required\s*/lib/security/pam_securetty.so" "/etc/pam.d/login"; then
            echo "auth required /lib/security/pam_securetty.so 항목이 주석처리 되어 있습니다." >> "$target"
            u1_safe_check=$((u1_safe_check+1))
        else
            if grep -qiE "^\s*auth\s*required\s*/lib/security/pam_securetty.so" "/etc/pam.d/login"; then
                echo "auth required /lib/security/pam_securetty.so 항목: 발견됨" >> "$target"
            else
                echo "auth required /lib/security/pam_securetty.so 항목: 비활성화" >> "$target"
                u1_safe_check=$((u1_safe_check+1))
            fi
        fi
    else
        echo "/etc/pam.d/login 파일이 존재하지 않습니다." >> "$target"
    fi
    if [[ $u1_safe_check -ge 1 ]];then
        echo "점검 결과 : 취약" >> $result
        u1=$((u1+1)) 
    else
        echo "점검 결과 : 양호" >> $result
    fi
}
if pgrep "telnetd" > /dev/null; then
    echo "Telnet 서비스: 동작 중"
    telnet_access_check	
else
    if grep -q '^telnet[[:space:]]*23/tcp' /etc/services; then
        if netstat -tuln | grep :23  > /dev/null; then
            telnet_access_check
        else
	    echo 'telnet 프로세스: 동작 중이 아님' >> $target
        fi
    else
        echo 'telnet 기본 포트 23으로 설정되어있지 않음' >> $target
        u1_telnet_newport=$(grep '^telnet[[:space:]]' /etc/services | awk '{print $2}' | cut -d'/' -f1)
        if netstat -tuln | grep :$u1_telnet_newport  > /dev/null; then
            telnet_access_check
        else
	    echo 'telnet 프로세스: 동작 중이 아님' >> $target
        fi
    fi
fi
ssh_access_check() {
    # /etc/ssh/sshd_config 파일 체크
    if [ -f "/etc/ssh/sshd_config" ]; then
        echo "/etc/ssh/sshd_config 파일: 존재함" >> "$target"
        if grep -iqE "^\s*#\s*PermitRootLogin" "/etc/ssh/sshd_config"; then
            echo "PermitRootLogin 항목이 주석처리 되어있습니다. : 비활성화" >> "$target"
            u1_safe_check=$((u1_safe_check+1))
        else
            if grep -iE '^\s*PermitRootLogin' "/etc/ssh/sshd_config" | awk '{print tolower($2)}' | grep -iq 'yes'; then
                echo "  - PermitRootLogin Yes : 발견됨" >> "$target"
                u1_safe_check=$((u1_safe_check+1))
            else
                echo "  - PermitRootLogin Yes : 발견되지 않음 " >> "$target"
            fi
        fi
    else
        echo "/etc/ssh/sshd_config 파일: 존재하지 않음" >> "$target"
    fi

    # /etc/pam.d/sshd 파일 체크
    if [ -f "/etc/pam.d/sshd" ]; then
        echo "/etc/pam.d/sshd 파일: 존재함" >> "$target"
        if grep -qiE "^\s*#\s*auth\s*required\s*pam_securetty.so" "/etc/pam.d/sshd"; then
            echo "pam_securetty.so 모듈 사용이 주석처리되어있습니다. : 비활성화" >> "$target"
            u1_safe_check=$((u1_safe_check+1))
        else
            if grep -qiE "^\s*auth\s*required\s*pam_securetty.so" "/etc/pam.d/sshd"; then
                echo "pam_securetty.so 모듈을 사용하고 있습니다." >> "$target"
            else
                echo "pam_securetty.so 모듈을 사용하지 않고 있습니다." >> "$target"
                u1_safe_check=$((u1_safe_check+1))
            fi
        fi

        if grep -qiE "^\s*#\s*AllowUsers" "/etc/pam.d/sshd"; then
            echo "AllowUsers 항목은 주석처리 되어 비활성화 되어 있습니다." >> "$target"
        else
            if grep -qiE "^\s*AllowUsers" "/etc/pam.d/sshd"; then
                if grep -qiE "\s*AllowUsers\s*root" "/etc/pam.d/sshd"; then
                    echo "AllowUsers 항목에 root가 설정되어 있습니다." >> "$target"
                    u1_safe_check=$((u1_safe_check+1))
                else
                    echo "AllowUsers 항목이 안전하게 설정되어 있습니다." >> "$target"
                fi
            else
                echo "AllowUsers 항목이 존재하지 않습니다." >> "$target"
            fi
        fi

        if grep -qiE "^\s*#\s*AllowGroups" "/etc/pam.d/sshd"; then
            echo "AllowGroups 항목은 주석처리 되어 비활성화 되어 있습니다." >> "$target"
        else
            if grep -qiE "^\s*AllowGroups" "/etc/pam.d/sshd"; then
                if grep -qiE "\s*AllowGroups\s*root" "/etc/pam.d/sshd"; then
                    echo "AllowGroups 항목에 root가 설정되어 있습니다." >> "$target"
                    u1_safe_check=$((u1_safe_check+1))
                else
                    echo "AllowGroups 항목이 안전하게 설정되어 있습니다." >> "$target"
                fi
            else
                echo "AllowGroups 항목이 존재하지 않습니다." >> "$target"
            fi
        fi
    else
        echo "/etc/pam.d/sshd 파일 : 존재하지 않음" >> "$target"
    fi
    if [[ $u1_safe_check -ge 1 ]];then
        echo "점검 결과 : 취약" >> $result
        u1=$((u1+1)) 
        
    else
        echo "점검 결과 : 양호" >> $result
    fi
}
if pgrep "sshd" > /dev/null; then
    echo "sshd 프로세스: 동작 중" >> $target
    ssh_access_check
else
    if grep -q '^ssh[[:space:]]*22/tcp' /etc/services; then
    	if netstat -tuln | grep :22  > /dev/null; then
    	    ssh_access_check
    	else
    	    echo "sshd 프로세스: 동작 중이 아님" >> $target
    	fi
    else
        echo 'ssh 기본 포트 22으로 설정되어있지 않음' >> $target
        u1_ssh_newport=$(grep '^sshd[[:space:]]' /etc/services | awk '{print $2}' | cut -d'/' -f1)
        if netstat -tuln | grep :$u1_ssh_newport  > /dev/null; then
            ssh_access_check	    
    	else
    	    echo "sshd 프로세스: 동작 중이 아님" >> $target
    	fi
    fi
fi

if [ $u1 -ge 1 ];then
    High=$((High+1))
    Account_Management=$((Account_Management+1))
    u1_Account_Management=1
fi


cat << EOF
===== [U-02] Weak password complexity settings          =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-02 [위험도 상] 패스워드 복잡성 설정 미흡 점검                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 패스워드 복잡성 관련 정책이 설정되어 있는지 점검하여 비인가자의 공격(무작위 대입 공격, 사전 대입 공격 등)에 대비가 되어 있는지 확인하기 위함" >> $target
echo "보안위협 : 복잡성 설정이 되어있지 않은 패스워드는 사회공학적인 유추가 가능 할 수 있으며 암호화된 패스워드 해시값을 무작위 대입공격, 사전대입 공격 등으로 단시간에 패스워드 크렉이 가능함" >> $target
echo "+판단기준 양호 : 패스워드 최소길이 8자리 이상, 영문·숫자·특수문자 최소 입력 기능이 설정된 경우" >> $target
echo "+판단기준 취약 : 패스워드 최소길이 8자리 이상, 영문·숫자·특수문자 최소 입력 기능이 설정된 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-2 점검 결과" >> $result
u2=0
u2_safe_check=0
u2_Account_Management=0
echo '' >> $target
echo "/etc/login.defs 파일 점검" >> $target
if [ -e "/etc/login.defs" ]; then
    u2_defs_check_values=("PASS_MAX_DAYS" "PASS_REUSE_DAYS" "PASS_MIN_DAYS" "PASS_WARN_AGE" "PASS_MIN_LEN")

    for u2_defs_check_value in "${u2_defs_check_values[@]}"; do
        # 설정값 가져오기
        u2_defs_value=$(grep -iE "^\s*$u2_defs_check_value" /etc/login.defs | tr -d ' ' | grep -v '^#' | awk '{print $2}')

        if grep -iqE "^#.*$u2_defs_check_value[[:space:]]*([0-9]{1,4})?$" /etc/login.defs; then
            echo "$u2_defs_check_value 설정이 주석처리 되어 비활성화 되어있습니다." >> $target
            u2_safe_check=$((u2_safe_check+1))
        else
            case "$u2_defs_check_value" in
                "PASS_MAX_DAYS")
                    if grep -q "$u2_defs_check_value" /etc/login.defs; then
                    	if [[ $defs_value -gt 90 ]]; then 
                        	echo "$defs_check_value 의 보안권고 설정 값인 90 보다 크게 설정되어 있습니다. | 현재 설정된 값 $u2_defs_value" >> $target
                            u2_safe_check=$((u2_safe_check+1))
                    	else
                        	echo "$u2_defs_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
                    	fi
                    else
                    	echo "$u2_defs_check_value 설정값이 존재하지 않습니다."  >> $target
                    fi
                    ;;
                "PASS_REUSE_DAYS")               
                    if grep -q "$u2_defs_check_value" /etc/login.defs; then
                    	if [[ $u2_defs_value -gt 4 ]]; then 
                        	echo "$u2_defs_check_value 의 보안권고 설정 값인 4 보다 크게 설정되어 있습니다. | 현재 설정된 값 $u2_defs_value" >> $target
                            u2_safe_check=$((u2_safe_check+1))
                    	else
                        	echo "$u2_defs_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
                    	fi
                    else
                    	echo "$u2_defs_check_value 설정값이 존재하지 않습니다." >> $target
                    fi
                    ;;
                "PASS_MIN_DAYS"|"PASS_WARN_AGE")
                    if grep -q "$u2_defs_check_value" /etc/login.defs; then
                    	if [[ $u2defs_value -gt 7 ]]; then 
                        	echo "$u2defs_check_value 의 보안권고 설정 값인 7 보다 크게 설정되어 있습니다. | 현재 설정된 값 $u2_defs_value" >> $target
                            u2_safe_check=$((u2_safe_check+1))
                    	else
                        	echo "$u2_defs_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
                    	fi
                    else
                    	echo "$u2_defs_check_value 설정값이 존재하지 않습니다." >> $target
                    fi
                    ;;
                "PASS_MIN_LEN")
                    if grep -q "$u2_defs_check_value" /etc/login.defs; then
                    	if [[ $u2_defs_value -gt 8 ]]; then 
                        	echo "$defs_check_value 의 보안권고 설정 값인 8 보다 크게 설정되어 있습니다. | 현재 설정된 값 $u2_defs_value" >> $target
                            u2_safe_check=$((u2_safe_check+1))
                    	else
                        	echo "$u2_defs_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
                    	fi
                    else
                    	echo "$u2_defs_check_value 설정값이 존재하지 않습니다." >> $target
                    fi
                    ;;
                *)
                    echo "해당 설정값이 존재하지 않습니다.: $u2_defs_check_value" >> $target
                    ;;
            esac
        fi
    done
else
    echo "/etc/login.defs 파일이 존재하지 않습니다." >> $target
fi
echo "" >> $target
echo "/etc/security/pwquality.conf 파일 점검" >> $target
if [ -e "/etc/security/pwquality.conf" ]; then
    u2_pwquality_check_values=("minlen" "dcredit" "ucredit" "ocredit" "lcredit" "minclass" "retry")
    for u2_pwquality_check_value in "${u2_pwquality_check_values[@]}"; do
        u2_pwquality_value=$(grep "^\s*$u2_pwquality_check_value" /etc/security/pwquality.conf | tr -d ' ' | awk -F= '{print $2}')
        
        u2_pwquality_Annotations=$(grep "^\s*#.*$u2_pwquality_check_value" /etc/security/pwquality.conf)

	if [[ -n $u2_pwquality_Annotations ]]; then
	    echo "$pwquality_check_value 값은 주석처리 되어 비활성화 되어있습니다." >> $target
        u2_safe_check=$((u2_safe_check+1))
        else
	    if [[ -n $u2_pwquality_value ]]; then
	        case "$u2_pwquality_check_value" in
	            "minlen")
                    if [[ $u2_pwquality_value -lt 8 ]]; then
                        echo "$u2_pwquality_check_value 의 보안권고 설정 값인 8 보다 작게 설정되어 있습니다. | 현재 설정된 값 $u2_pwquality_value" >> $target
                        u2_safe_check=$((u2_safe_check+1))
                    else
                        echo "$u2_pwquality_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
                    fi
                    ;;
	            "dcredit"|"ucredit"|"ocredit"|"lcredit")
                    if [[ $u2_pwquality_value -lt 1 ]]; then
                        echo "$pwquality_check_value 의 보안권고 설정 값인 1 보다 작게 설정되어 있습니다. | 현재 설정된 값 $u2_pwquality_value" >> $target
                        u2_safe_check=$((u2_safe_check+1))
                    else
                        echo "$u2_pwquality_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
                    fi
                    ;;
		    "minclass")
		        if [[ $u2_pwquality_value -lt 3 ]]; then
                    echo "$u2_pwquality_check_value 의 보안권고 설정 값인 3 보다 작게 설정되어 있습니다. | 현재 설정된 값 $u2_pwquality_value" >> $target
                    u2_safe_check=$((u2_safe_check+1))
		        else
			        echo "$u2_pwquality_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
		        fi
			;;
		    "retry")
		        if [[ $u2_pwquality_value -gt 3 ]]; then
                    echo "$u2_pwquality_check_value 의 보안권고 설정 값인 3 보다 크게 설정되어 있습니다. | 현재 설정 값 : $u2_pwquality_value" >> $target
                    u2_safe_check=$((u2_safe_check+1))
		        else
			        echo "$u2_pwquality_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
			fi
		        ;;
	        *)
	        esac
	    else
            echo "해당 옵션은 값이 설정되어 있지 않습니다.: $u2_pwquality_check_value" >> $target
            u2=$((u2+1))
            u2_safe_check=$((u2_safe_check+1))
	    fi
	fi
    done
fi	

echo "" >> $target
u2_pam_files=("/etc/pam.d/system-auth" "/etc/pam.d/password-auth")
for u2_pam_file in "${u2_pam_files[@]}";do
    echo "" >> $target
    echo "$u2_pam_file 파일 점검" >> $target
    if [ -e "$u2_pam_file" ]; then
        u2_pam_module_check=("pam_cracklib.so" "pam_pwquality.so" "pam_unix.so")
        u2_pam_check=("minlen" "ucredit" "lcredit" "dcredit" "ocredit" "difok" "retry")
        u2_modules_found=0
    
        for u2_pam_module in "${u2_pam_module_check[@]}"; do
            # 모듈이 존재하는지 확인
            if grep -qE "^\s*password\s+.*$u2_pam_module" "$u2_pam_file"; then
                u2_modules_found=$((modules_found + 1))
                # 설정이 존재하는 경우에만 검증 및 주석 검증
                if grep -qiE "^\s*#.*password\s+.*$u2_pam_module" "$u2_pam_file"; then
                    echo "패스워드 복잡성 설정($u2_pam_module)이 주석처리 되어 있습니다." >> $target
                    u2_safe_check=$((u2_safe_check+1))
                elif [ "$u2_pam_module" == "pam_unix.so" ]; then
                    if grep -iE "^\s*#.*password\s+.*$u2_pam_module" "$u2_pam_file" | awk '{print $1}' | grep -Eo "^#"; then
                        echo "패스워드 복잡성 설정($u2_pam_module)이 주석처리 되어 있습니다." >> $target
                        u2_safe_check=$((u2_safe_check+1))
                    else grep -qiE "^\s*password\s+.*$u2_pam_module" "$u2_pam_file"; 
                        echo "$u2_pam_file 파일이 존재하며, 패스워드 복잡도 설정($u2_pam_module)이 설정되어 있습니다." >> $target
                        #검증로직 설정 하기
                        u2_pam_check_value2=$(cat $u2_pam_file | grep -iE "^\s*password\s+.*$u2_pam_module" | sed "s/.*$u2_pam_module\s*//")
                        echo "현재 $u2_pam_module 모듈에 적용된 설정값은 아래와 같습니다." >> $target
                        echo "$u2_pam_check_value2" | sed 's/\s\+/\n/g' | while read -r pam_field; do
                            echo "$u2_pam_field" >> $target
                            done

                        u2_corrent_control_keyworld=$( grep -iE "^\s*password\s+.*$u2_pam_module" "$u2_pam_file" | awk '{print $2}')
                        if [[ $u2_corrent_control_keyworld == "sufficient" ]]; then
                            echo "$u2_pam_module 모듈의 제어 키워드로 $u2_corrent_control_keyworld 로 적절하게 설정되어 있습니다." >> $target
                        else
                            echo "$u2_pam_module 모듈의 제어 키워드로 $u2_corrent_control_keyworld 로 부적절하게 설정되어 있습니다." >> $target
                            u2_safe_check=$((u2_safe_check+1))
                        fi
                    fi
                else
                    if grep -qE "^\s*password\s+.*$u2_pam_module" $u2_pam_file; then
                        echo "$u2_pam_file 파일이 존재하며, 패스워드 복잡도 설정($u2_pam_module)이 설정되어 있습니다." >> "$target"
                        for u2_pam_value in "${u2_pam_check[@]}"; do
                            # 설정 값 확인
                            u2_pam_check_value=$(grep "$u2_pam_module" $u2_pam_file | grep -o "$u2_pam_value=[^ ]*" | tr -d ' ' | awk -F= '{print $2}')
                            
                            # 설정 값이 존재하는 경우에만 출력
                            if [[ -n "$u2_pam_check_value" ]]; then
                                case "$u2_pam_value" in	
                                    "minlen")
                                        if [[ $u2_pam_check_value -lt 8 ]]; then
                                            echo "$u2_pam_value 의 보안 권고 설정 값인 8 보다 작게 설정되어 있습니다. | 현재 설정 값 : $u2_pam_check_value" >> $target
                                            u2_safe_check=$((u2_safe_check+1))
                                        else
                                            echo "$u2_pam_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
                                        fi
                                        ;;
                                    "ucredit"|"lcredit"|"dcredit"|"ocredit"|"difok")
                                        if [[ $u2_pam_check_value -lt 1 ]]; then
                                            echo "$u2_pam_value 의 보안 권고 설정 값인 1 보다 작게 설정되어 있습니다. | 현재 설정 값 : $u2_pam_check_value" >> $target
                                            u2_safe_check=$((u2_safe_check+1))
                                        else
                                            echo "$pam_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
                                        fi 
                                        ;;
                                    "retry")
                                        if [[ $u2_pam_check_value -gt 3 ]]; then
                                            echo "$u2_pam_value 의 보안 권고 설정 값인 3 보다 크게 설정되어 있습니다. | 현재 설정 값 : $u2_pam_check_value" >> $target
                                            u2_safe_check=$((u2_safe_check+1))
                                        else
                                            echo "$u2_pam_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
                                        fi
                                        ;;
                                    *)
                                        echo "알 수 없는 설정 값: $u2_pam_value" >> $target
                                        ;;
                                esac
                            else
                                echo "$u2_pam_value 설정이 존재하지 않습니다." >> $target
                                u2_safe_check=$((u2_safe_check+1))
                            fi
                        done
                        if [[ "$u2_pam_module" == "pam_pwquality.so" || "$u2_pam_module" == "pam_cracklib.so" ]]; then
                            u2_corrent_control_keyworld=$( grep -iE "^\s*password\s+.*$u2_pam_module" "$u2_pam_file" | awk '{print $2}')
                            if [[ $u2_corrent_control_keyworld == "requisite" ]]; then
                                echo "$u2_pam_module 모듈의 제어 키워드로 $u2_corrent_control_keyworld 로 적절하게 설정되어 있습니다." >> $target
                            else
                                echo "$u2_pam_module 모듈의 제어 키워드로 $u2_corrent_control_keyworld 로 부적절하게 설정되어 있습니다." >> $target
                                u2_safe_check=$((u2_safe_check+1))
                            fi
                        fi
                    else
                        echo "$u2_pam_file 파일이 존재하며, 패스워드 복잡성 설정이($u2_pam_module)이 존재하지 않습니다." >> $target
                        u2_safe_check=$((u2_safe_check+1))
                    fi
                fi
            else
                echo "$u2_pam_file 파일이 존재하며, 패스워드 복잡성 설정이($u2_pam_module)이 존재하지 않습니다." >> $target
                u2_safe_check=$((u2_safe_check+1))
            fi
        done
        
    #  모듈 모두 발견되지 않았을 경우
    if [[ $u2_modules_found -eq 0 ]]; then
        echo "$u2_pam_file 파일이 존재하지만, 패스워드 복잡성 설정 관련 모듈이 존재하지 않습니다." >> $target
        u2_safe_check=$((u2_safe_check+1))
    fi
else
    echo "$u2_pam_file 파일이 존재하지 않습니다." >> "$target"
fi
done

if [ $u2_safe_check -ge 1 ];then
    u2=$((u2+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u2 -ge 1 ]];then
    High=$((High+1))
    Account_Management=$((Account_Management+1))
    u2_Account_Management=1
fi

cat << EOF
===== [U-03] Set Account Lock Threshold                 =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-03 계정 잠금 임계값 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 계정탈취 목적의 무작위 대입 공격 시 해당 계정을 잠금하여 인증 요청에 응답하는 리소스 낭비를 차단하고 대입 공격으로 인한 비밀번호 노출 공격을 무력화하기 위함" >> $target
echo "보안위협 : 패스워드 탈취 공격(무작위 대입 공격, 사전 대입 공격, 추측 공격 등)의 인증 요청에 대해 설정된 패스워드와 일치 할 때까지 지속적으로 응답하여 해당 계정의 패스워드가 유출 될 수 있음" >> $target
echo "+판단기준 양호 : 계정 잠금 임계값이 10회 이하의 값으로 설정되어 있는 경우" >> $target
echo "+판단기준 취약 : 계정 잠금 임계값이 설정되어 있지 않거나, 10회 이하의 값으로 설정되지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-3 점검 결과" >> $result
u3=0
u3_safe_check=0
u3_Account_Management=0
u3_auth_files=("/etc/pam.d/system-auth" "/etc/pam.d/password-auth")
for u3_auth_file in "${u3_auth_files[@]}";do
    echo "" >> $target
    echo "$u3_auth_file 파일 점검" >> $target
    if [ -e "$u3_auth_file" ]; then
        u3_auth_module_check=("pam_tally.so" "pam_tally2.so" "pam_faillock.so")    
        u3_auth_stacks=("auth" "account")
        u3_modules_found=0
        for u3_auth_module in "${u3_auth_module_check[@]}";do
            echo "$u3_auth_module 점검" >> $target
            for u3_auth_stack in "${u3_auth_stacks[@]}";do
                if grep -qiE "^\s*$u3_auth_stack\s+.*$u3_auth_module" "$u3_auth_file";then
                    echo "$u3_auth_stack 에 대한 $u3_auth_module 가 존재합니다." >> $target
                    u3_auth_check_values=$(grep -iE "^\s*$u3_auth_stack\s+.*$u3_auth_module"  "$u3_auth_file" | sed -E "s/^.*$u3_auth_module\s*//")
                    echo "$(grep -iE "^\s*$u3_auth_stack\s+.*$u3_auth_module" "$u3_auth_file")" >> $target
                    echo "현재 $u3_auth_stack 의 $u3_auth_module 모듈에 적용된 설정값은 아래와 같습니다." >> $target
                    echo "$u3_auth_check_values" | sed 's/\s\+/\n/g' | while read -r auth_field; do
                            echo "$u3_auth_field" >> $target
                            done
                    echo "--------------------" >> $target
                    if [[ $u3_auth_stack == "auth" ]];then
                        u3_deny_count=$(grep -iE "^\s*auth\s+.*$u3_auth_module" "$u3_auth_file" | sed -E "s/^.*$u3_auth_module\s*//" | grep -oP 'deny=\K\d+')
                        if (( $u3_deny_count <= 10 )); then
                            echo "계정 임계값 설정이 $u3_deny_count 로 보안권고 사항인 10 이하로 적절하게 설정되었습니다." >> "$target"
                            echo "--------------------" >> $target
                        else
                            echo "계정 임계값 설정이 $u3_deny_count 로 보안권고 사항인 10 이상으로 부적절하게 설정되었습니다." >> "$target"
                            echo "--------------------" >> $target
                            u3_safe_check=$((u3_safe_check+1))
                        fi
                    fi
                else
                    if grep -qiE "^\s*#.*$u3_auth_stack\s+.*$u3_auth_module" "$u3_auth_file"; then  
                        echo "계정 임계값 설정 모듈($u3_auth_module)이 주석처리 되어 있습니다." >> $target
                        u3_safe_check=$((u3_safe_check+1))
                    else    
                        echo "$u3_auth_module가 존재하지 않습니다." >> $target
                        break
                    fi
                fi
            done
        done
    else
        echo "$u3_auth_file 파일이 존재하지 않습니다." >> $target
    fi
done

if [ $u3_safe_check -ge 1 ];then
    u3=$((u3+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u3 -ge 1 ]];then
    High=$((High+1))
    Account_Management=$((Account_Management+1))
    u3_Account_Management=1
fi

cat << EOF
===== [U-04] password file protection                 =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-04 패스워드 파일 보호                        " >> $target
echo "--------------------------------------------------------------------------" >> $target

u4=0
u4_safe_check=0
u4_Account_Management=0
if [ -e "/etc/passwd" ];then
    u4_check_encryption=$(cat "/etc/passwd" | awk -F':' '{print $2}' | grep -v 'x')
    u4_count_noencryption=$(cat "/etc/passwd" | awk -F':' '{print $2}' | grep -v 'x' | wc -l)
    if [[ -n $u4_check_encryption ]];then
        echo "passwd 파일 내에 패스워드가 암호화 저장이 아닌 평문으로 저장된 계정이 $u4_count_noencryption 개 존재합니다." >> $target
        echo "$u4_check_encryption" | while IFS= read -r view_account; do
            echo "암호화 되지 않은 계정 : $u4_view_account" >> "$target"
            u4_safe_check=$((u4_safe_check+1))
        done
    else
        echo "passwd 파일 내에 평문 저장된 계정은 확인되지 않았습니다." >> $target
    fi
    if [ -e "/etc/shadow" ];then
        u4_check_hash=$(cat /etc/shadow | awk -F':' '{print $2}')
        u4_unsafe_user=$(grep -vE '^([^:]+:(\*|\$y|\$5|\$6|\!|\!!))' /etc/shadow)
        u4_count_unsafe_user=$(grep -vE '^([^:]+:(\*|\$y|\$5|\$6|\!|\!!))' /etc/shadow | wc -l)
        if [[ $u4_count_unsafe_user -eq 0 ]];then
            echo "passwd 파일이 존재하며, 모든 계정에 대한 패스워드가 암호화 되어 안전하게 shadow 파일에 저장되어 있습니다." >> $target
        else
            echo "shadow 파일 내에 패스워드가 존재하지 않거나 안전하지 않은 해시 알고르짐으로 저장된 계정이 존재합니다." >> $target
            echo "안전하지 않은 계정 : $u4_unsafe_user" >> $target
            u4_safe_check=$((u4_safe_check+1))
        fi
    else
        echo "shadow 파일이 존재하지 않으며, 패스워드 암호화가 되어있지 않습니다." >> $target
        u4_safe_check=$((u4_safe_check+1))
    fi
fi

if [ $u4_safe_check -ge 1 ];then
    u4=$((u4+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u4 -ge 1 ]];then
    High=$((High+1))
    Account_Management=$((Account_Management+1))
    u4_Account_Management=1
fi

cat << EOF
===== [U-05] root home, pass directory permissions, and pass settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-05  root홈, 패스 디렉터리 권한 및 패스 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 비인가자가 불법적으로 생성한 디렉터리 및 명령어를 우선으로 실행되지 않도록 설정하기 위해 환경변수 점검이 필요함" >> $target
echo "보안위협 : root 계정의 PATH(환경변수)에 정상적인 관리자 명령어(예: ls, mv, cp등)의 디렉터리 경로 보다 현재 디렉터리를 지칭하는 “.” 표시가 우선하면 현재 디렉터리에 변조된 명령어를 삽입하여 관리자 명령어 입력 시 악의적인 기능이 실행 될 수 있음" >> $target
echo "+판단기준 양호 : PATH 환경변수에 “.” 이 맨 앞이나 중간에 포함되지 않은 경우" >> $target
echo "+판단기준 취약 : PATH 환경변수에 “.” 이 맨 앞이나 중간에 포함되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-5 점검 결과" >> $result
u5=0
u5_safe_check=0
u5_Files_Directory_Management=0

u5_etc_configure_files=(
    "/etc/profile"
    "/etc/.login"
    "/etc/bashrc"
)

u5_home_configure_files=(
    ".profile"
    ".cshrc"
    ".login"
    "kshrc"
    ".bash_profile"
)

if [[ $PATH =~ (^|:)(\.|::)(:|$) ]]; then 
    echo "PATH 환경변수에 . 및 :: 문자가 PATH 변수의 맨 앞 혹은 중간에 위치하고 있습니다. 해당 문자를 맨 마지막으로 이동하십시오." >> $target
    u5_safe_check=$((u5_safe_check+1))
else
    echo "PATH 환경변수에 . 및 :: 문자가 올바른 위치에 존재합니다." >> $target
fi


for u5_etc_configure_file in "${u5_etc_configure_files[@]}"; do
    echo -e "${RED}Checking file: $u5_etc_configure_file${NC}" >> $target
    if [ -e "$u5_etc_configure_file" ]; then
        # 파일이 존재하면 권한을 확인하는 구문 추가하기
        #ls -l "$etc_configure_file"
        if grep -qiE "^#\s*PATH\s*=" "$u5_etc_configure_file"; then  
            echo "PATH 설정 구문이 주석처리되어 비활성화 되어 있습니다." >> $target
            echo "--------------------------------------" >> $target
        else
            if grep -qiE "^\s*PATH\s*=" "$u5_etc_configure_file"; then
                grep -iE "^\s*PATH\s*=" "$u5_etc_configure_file" | while read -r line ; do
                    echo "PATH setting found: $u5_line" >> $target
                    # PATH 설정에서 . 또는 :: 문자가 맨 앞이나 중간에 포함되어 있는지 확인
                    if echo "$u5_line" | grep -iqE "(^|:)(\.|::)(:|$)"; then
                        echo "PATH 설정 값에 “.”, “::”이 맨 앞 혹은 중간에 위치하고 있습니다.- 취약" >> $target
                        echo "--------------------------------------" >> $target
                        u5_safe_check=$((u5_safe_check+1))
                    else
                        echo "PATH 관련 설정이 안전하게 설정되어 있습니다." >> $target
                        echo "--------------------------------------" >> $target
                    fi
                done
            else
                echo "PATH 관련 설정이 존재하지 않습니다." >> $target
                echo "--------------------------------------" >> $target
            fi
        fi

        #if 

        #fi
    else
        # 파일이 존재하지 않으면 메시지 출력
        echo "$u5_configure_file 파일이 존재하지 않습니다.." >> $target
        echo "--------------------------------------" >> $target
    fi
done

u5_check_users=($(cat /etc/passwd | egrep -v '/sbin|sync|false' | awk -F':' '{print $1}'))
for u5_check_user in "${u5_check_users[@]}";do
    u5_user_home=($(getent passwd "$u5_check_user" | awk -F':' '{print$6}'))
    if [ -d "$u5_user_home" ];then
        echo "--------------------------------------" >> $target
        echo "$u5_check_user 의 홈 디렉터리가 존재합니다." >> $target
        for u5_home_configure_file in "${u5_home_configure_files[@]}";do
            echo -e "${RED}Checking file: $u5_user_home/$u5_home_configure_file${NC}" >> $target
            if [ -e "$u5_user_home/$u5_home_configure_file" ];then
                echo "$u5_user_home/$u5_home_configure_file 파일이 존재합니다." >> $target

                if grep -qiE "^#\s*PATH\s*=" "$u5_user_home/$u5_home_configure_file"; then  
                    echo "PATH 설정 구문이 주석처리되어 비활성화 되어 있습니다." >> $target
                    echo "--------------------------------------" >> $target
                else
                    if grep -qiE "^\s*PATH\s*=" "$u5_user_home/$u5_home_configure_file"; then
                        grep -iE "^\s*PATH\s*=" "$u5_user_home/$u5_home_configure_file" | while read -r line ; do
                            echo "PATH setting found: $line" >> $target
                            # PATH 설정에서 . 또는 :: 문자가 맨 앞이나 중간에 포함되어 있는지 확인
                            if echo "$u5_line" | grep -qiE "(^|:)(\.|::)(:|$)"; then
                                echo "PATH 설정 값에 “.”, “::”이 맨 앞 혹은 중간에 위치하고 있습니다.- 취약" >> $target
                                echo "--------------------------------------" >> $target
                                u5_safe_check=$((u5_safe_check+1))
                            else
                                echo "PATH 관련 설정이 안전하게 설정되어 있습니다." >> $target
                                echo "--------------------------------------" >> $target
                            fi
                        done
                    else
                        echo "PATH 관련 설정이 존재하지 않습니다." >> $target
                        echo "--------------------------------------" >> $target
                    fi
                fi

            else
                echo "$u5_user_home/$u5_home_configure_file 파일이 존재하지 않습니다." >> $target
                echo "--------------------------------------" >> $target
            fi
        done
    else
        echo "$u5_check_user 의 홈 디렉턱리가 존재하지 않습니다." >> $target
        echo "--------------------------------------" >> $target
    fi
done


if [ $u5_safe_check -ge 1 ];then
    u5=$((u5+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u5 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u5_Files_Directory_Management=1
fi

cat << EOF
===== [U-06] File and Directory Owner Settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-06   파일 및 디렉터리 소유자 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 소유자가 존재하지 않는 파일 및 디렉터리를 삭제 및 관리하여 임의의 사용자가 해당파일을 열람, 수정하는 행위를 사전에 차단하기 위함" >> $target
echo "보안위협 : 소유자가 존재하지 않는 파일의 UID와 동일한 값으로 특정계정의 UID값을 변경하면 해당 파일의 소유자가 되어 모든 작업이 가능함" >> $target
echo "+판단기준 양호 : 소유자가 존재하지 않는 파일 및 디렉터리가 존재하지 않는 경우" >> $target
echo "+판단기준 취약 : 소유자가 존재하지 않는 파일 및 디렉터리가 존재하는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-6 점검 결과" >> $result
u6=0
u6_safe_check=0
u6_Files_Directory_Management=0
echo "#소유자 또는 그룹이 없는 파일은 파일 속성 해당 필드에 숫자로 표시됨#" >> $target
declare -a u6_file_list
declare -a u6_dir_list

# find 명령어의 출력을 배열에 저장
mapfile -t u6_noowner_lists < <(find / \( -nouser -o -nogroup \) -print 2> /dev/null)

# 파일 및 디렉터리 경로를 분리하여 배열에 저장
for u6_noowner_list in "${u6_noowner_lists[@]}"; do
    if [[ -e "$u6_noowner_list" ]]; then
        if [[ -f "$u6_noowner_list" ]]; then
            u6_file_list+=("$u6_noowner_list")
        elif [[ -d "$u6_noowner_list" ]]; then
            u6_dir_list+=("$u6_noowner_list")
        fi
    fi
done

# 파일 목록을 출력
# #은 배열의 길이를 얻는데 사용됨
if [[ ${#u6_file_list[@]} -gt 0 ]]; then
    u6_safe_check=$((u6_safe_check+1))
    echo "소유자가 존재하지 않는 파일 목록:" >> "$target"
    for u6_file in "${u6_file_list[@]}"; do
        echo "파일: $u6_file" >> "$target"
        ls -l "$u6_file" >> "$target"
    done
else
    echo "소유자가 존재하지 않는 파일이 없습니다." >> "$target"
fi

# 디렉터리 목록을 출력
if [[ ${#u6_dir_list[@]} -gt 0 ]]; then
    u6_safe_check=$((u6_safe_check+1))
    echo "소유자가 존재하지 않는 디렉터리 목록:" >> "$target"
    for u6_dir in "${u6_dir_list[@]}"; do
        u6=$((u6 + 1))
        echo "디렉터리: $u6_dir" >> "$target"
        ls -ld "$u6_dir" >> "$target"
    done
else
    echo "소유자가 존재하지 않는 디렉터리가 없습니다." >> "$target"
fi

if [ $u6_safe_check -ge 1 ];then
    u6=$((u6+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u6 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u6_Files_Directory_Management=1
fi

cat << EOF
===== [U-07] /etc/passwd file owner and permission settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-07   /etc/passwd 파일 소유자 및 권한 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : /etc/passwd 파일의 임의적인 변경을 차단하기 위함을 통해 비인가자가 권한 상승하는 것을 막기 위함" >> $target
echo "보안위협 : 관리자(root) 외 사용자가 /etc/passwd 파일의 사용자 정보를 변조하여 shell 변경, 사용자 추가/삭제 등 root를 포함한 사용자 권한 획득 가능" >> $target
echo "+판단기준 양호 : /etc/passwd 파일의 소유자가 root이고, 권한이 644 이하인 경우" >> $target
echo "+판단기준 취약 : /etc/passwd 파일의 소유자가 root가 아니거나, 권한이 644 이하가 아닌경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-7 점검 결과" >> $result
u7=0
u7_safe_check=0
u7_Files_Directory_Management=0

if [[ -e "/etc/passwd" ]];then
    echo "/etc/passwd 파일이 존재합니다." >> $target
    u7_file_owner_user=$(stat -c "%U" "/etc/passwd" 2> /dev/null)
    u7_file_owner=$(stat -c "%a" "/etc/passwd"  2> /dev/null| cut -c1)
    u7_file_group=$(stat -c "%a" "/etc/passwd"  2> /dev/null| cut -c2)
    u7_file_other=$(stat -c "%a" "/etc/passwd"  2> /dev/null| cut -c3)
    u7_check_suid=$(stat -c "%a" "/etc/passwd"  2> /dev/null| tr -d '\n' | wc -c)
    if [[ $u7_check_suid -ge 4 ]];then
        echo "$u7_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> $target
        u7_safe_check=$((u7_safe_check+1))
    else
        if [[ "$u7_file_owner_user" == "root" ]];then
            echo "/etc/passwd 파일의 소유자가 root로 적절하게 설정되어 있습니다." >> $target
            if [ $u7_file_owner -le 6 ];then
                echo "/etc/passwd 파일의 소유 권한이 6이하로 설정되어 있습니다." >> $target
                if [ $u7_file_group -le 4 ];then
                    echo "/etc/passwd 파일의 소유 그룹 권한이 4이하로 설정되어 있습니다." >> $target
                    if [ $u7_file_other -eq 4 ];then
                        echo "/etc/passwd 파일의 기타 사용자(Other) 권한이 4으로 설정되어 있습니다." >> $target
                    else
                        echo "/etc/passwd 파일의 기타 사용자(Other) 권한이 4이 아닌 값으로 설정되어 있습니다." >> $target
                        u7_safe_check=$((u7_safe_check+1))
                    fi
                else
                    ehco "/etc/passwd 파일의 소유 그룹 권한이 4이상으로 설정되어 있습니다." >> $target
                    u7_safe_check=$((u7_safe_check+1))
                fi
            else
                echo "/etc/passwd 파일의 소유 권한이 6이상으로 설정되어 있습니다." >> $target
                u7_safe_check=$((u7_safe_check+1))
            fi
        else
            echo "/etc/passwd 파일의 소유자가 root가 아닌 다른 사용자로 설정되어 있습니다." >> $target
            u7_safe_check=$((u7_safe_check+1))
        fi
    fi
else
    echo "/etc/passwd 파일이 존재하지 않습니다." >> $target
    u7_safe_check=$((u7_safe_check+1))
fi


if [ $u7_safe_check -ge 1 ];then
    u7=$((u7+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u7 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u7_Files_Directory_Management=1
fi


cat << EOF
===== [U-08] /etc/shadow file owner and permission settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-08   /etc/shadow 파일 소유자 및 권한 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : /etc/shadow 파일을 관리자만 제어할 수 있게 하여 비인가자들의 접근을 차q단하도록 shadow 파일 소유자 및 권한을 관리해야함" >> $target
echo "보안위협 : shadow파일은 패스워드를 암호화하여 저장하는 파일이며 해당 파일의 암호화된 해쉬값을 복호화하여(크래킹) 비밀번호를 탈취할 수 있음" >> $target
echo "+판단기준 양호 : /etc/shadow 파일의 소유자가 root이고, 권한이 400 이하인 경우" >> $target
echo "+판단기준 취약 : /etc/shadow 파일의 소유자가 root가 아니거나, 권한이 400 이하가 아닌 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-8 점검 결과" >> $result
u8=0
u8_safe_check=0
u8_Account_Management=0

if [[ -e "/etc/shadow" ]];then
    echo "/etc/shadow 파일이 존재합니다." >> $target
    u8_file_owner_user=$(stat -c "%U" "/etc/shadow" 2> /dev/null)
    u8_file_owner=$(stat -c "%a" "/etc/shadow"  2> /dev/null| cut -c1)
    u8_file_group=$(stat -c "%a" "/etc/shadow"  2> /dev/null| cut -c2)
    u8_file_other=$(stat -c "%a" "/etc/shadow"  2> /dev/null| cut -c3)
    u8_check_suid=$(stat -c "%a" "/etc/shadow"  2> /dev/null| tr -d '\n' | wc -c)
    if [[ $u8_check_suid -ge 4 ]];then
        echo "$u8_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> $target
        u8_safe_check=$((u8_safe_check+1))
    else
        if [[ "$u8_file_owner_user" == "root" ]];then
            echo "/etc/shadow 파일의 소유자가 root로 적절하게 설정되어 있습니다." >> $target
            if [ $u8_file_owner -le 4 ];then
                echo "/etc/shadow 파일의 소유 권한이 4이하로 설정되어 있습니다." >> $target
                if [[ $u8_file_group -eq 0 ]];then
                    echo "/etc/shadow 파일의 소유 그룹 권한이 0이하로 설정되어 있습니다." >> $target
                    if [ $u8_file_other -eq 0 ];then
                        echo "/etc/shadow 파일의 기타 사용자(Other) 권한이 0으로 설정되어 있습니다." >> $target
                    else
                        echo "/etc/shadow 파일의 기타 사용자(Other) 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                        u8_safe_check=$((u8_safe_check+1))
                    fi
                else
                    echo "/etc/shadow 파일의 소유 그룹 권한이 0이상으로 설정되어 있습니다." >> $target
                    u8_safe_check=$((u8_safe_check+1))
                fi
            else
                echo "/etc/shadow 파일의 소유 권한이 4이상으로 설정되어 있습니다." >> $target
                u8_safe_check=$((u8_safe_check+1)) 
            fi
        else
            echo "/etc/shadow 파일의 소유자가 root가 아닌 다른 사용자로 설정되어 있습니다." >> $target
            u8_safe_check=$((u8_safe_check+1))
        fi
    fi
else
    echo "/etc/shadow 파일이 존재하지 않습니다." >> $target
    u8_safe_check=$((u8_safe_check+1))
fi

if [ $u8_safe_check -ge 1 ];then
    u8=$((u8+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u8 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u8_Files_Directory_Management=1
fi


cat << EOF
===== [U-09] /etc/hosts file owner and permission settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-09   /etc/hosts 파일 소유자 및 권한 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : /etc/hosts 파일을 관리자만 제어할 수 있게 하여 비인가자들의 임의적인 파일 변조를 방지하기 위함" >> $target
echo "보안위협 : hosts 파일에 비인가자 쓰기 권한이 부여된 경우, 공격자는 hosts파일에 악의적인 시스템을 등록하여, 이를 통해 정상적인 DNS를 우회하여 악성사이트로의 접속을 유도하는 파밍(Pharming) 공격 등에 악용될 수 있음hosts파일에 소유자외 쓰기 권한이 부여된 경우, 일반사용자 권한으로 hosts파일에 변조된 IP주소를 등록하여 정상적인 DNS를 방해하고 악성사이트로의 접속을 유도하는 파밍(Pharming) 공격 등에 악용될 수 있음" >> $target
echo "+판단기준 양호 : /etc/hosts 파일의 소유자가 root이고, 권한이 600인 이하경우" >> $target
echo "+판단기준 취약 : /etc/hosts 파일의 소유자가 root가 아니거나, 권한이 600 이상인 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-9 점검 결과" >> $result
u9=0
u9_safe_check=0
u9_Files_Directory_Management=0

if [[ -e "/etc/hosts" ]];then
    echo "/etc/hosts 파일이 존재합니다." >> $target
    u9_file_owner_user=$(stat -c "%U" "/etc/hosts" 2> /dev/null)
    u9_file_owner=$(stat -c "%a" "/etc/hosts"  2> /dev/null| cut -c1)
    u9_file_group=$(stat -c "%a" "/etc/hosts"  2> /dev/null| cut -c2)
    u9_file_other=$(stat -c "%a" "/etc/hosts"  2> /dev/null| cut -c3)
    u9_check_suid=$(stat -c "%a" "/etc/hosts"  2> /dev/null| tr -d '\n' | wc -c)
    if [[ $u9_check_suid -ge 4 ]];then
        echo "$u9_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> $target
        u9_safe_check=$((u9_safe_check+1))
    else
        if [[ "$u9_file_owner_user" == "root" ]];then
            echo "/etc/hosts 파일의 소유자가 root로 적절하게 설정되어 있습니다." >> $target
            if [ $u9_file_owner -le 6 ];then
                echo "/etc/hosts 파일의 소유 권한이 6이하로 설정되어 있습니다." >> $target
                if [ $u9_file_group -le 0 ];then
                    echo "/etc/hosts 파일의 소유 그룹 권한이 0이하로 설정되어 있습니다." >> $target
                    if [ $u9_file_other -eq 0 ];then
                        echo "/etc/hosts 파일의 기타 사용자(Other) 권한이 0으로 설정되어 있습니다." >> $target
                    else
                        echo "/etc/hosts 파일의 기타 사용자(Other) 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                        u9_safe_check=$((u9_safe_check+1))
                    fi
                else
                    echo "/etc/hosts 파일의 소유 그룹 권한이 0이상으로 설정되어 있습니다." >> $target
                    u9_safe_check=$((u9_safe_check+1))
                fi
            else
                echo "/etc/hosts 파일의 소유 권한이 6이상으로 설정되어 있습니다." >> $target
                u9_safe_check=$((u9_safe_check+1)) 
            fi
        else
            echo "/etc/hosts 파일의 소유자가 root가 아닌 다른 사용자로 설정되어 있습니다." >> $target
            u9_safe_check=$((u9_safe_check+1))
        fi
    fi
else
    echo "/etc/hosts 파일이 존재하지 않습니다." >> $target
    u9_safe_check=$((u9_safe_check+1))
fi


if [ $u9_safe_check -ge 1 ];then
    u9=$((u9+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u9 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u9_Files_Directory_Management=1
fi


cat << EOF
===== [U-10] /etc/(x)inetd.conf file owner and permission settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-10   /etc/(x)inetd.conf 파일 소유자 및 권한 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : /etc/(x)inetd.conf 파일을 관리자만 제어할 수 있게 하여 비인가자들의 임의적인 파일 변조를 방지하기 위함" >> $target
echo "보안위협 : (x)inetd.conf 파일에 소유자외 쓰기 권한이 부여된 경우, 일반사용자 권한으로 (x)inetd.conf 파일에 등록된 서비스를 변조하거나 악의적인 프로그램(서비스)를 등록할 수 있음" >> $target
echo "+판단기준 양호 : /etc/inetd.conf 파일의 소유자가 root이고, 권한이 600인 경우" >> $target
echo "+판단기준 취약 : /etc/inetd.conf 파일의 소유자가 root가 아니거나, 권한이 600이 아닌 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-10 점검 결과" >> $result
u10=0
u10_x_inetd_confs=("/etc/inetd.conf" "/etc/xinetd.conf")
u10_safe_check=0
u10_Files_Directory_Management=0
for u10_x_inetd_conf in "${u10_x_inetd_confs[@]}";do
    if [[ -e "$u10_x_inetd_conf" ]];then
        echo "$u10_x_inetd_conf 파일이 존재합니다." >> $target
        u10_file_owner_user=$(stat -c "%U" "$u10_x_inetd_conf" 2> /dev/null)
        u10_file_owner=$(stat -c "%a" "$u10_x_inetd_conf"  2> /dev/null| cut -c1)
        u10_file_group=$(stat -c "%a" "$u10_x_inetd_conf"  2> /dev/null| cut -c2)
        u10_file_other=$(stat -c "%a" "$u10_x_inetd_conf"  2> /dev/null| cut -c3)
        u10_check_suid=$(stat -c "%a" "$u10_x_inetd_conf"  2> /dev/null| tr -d '\n' | wc -c)
        if [[ $u10_check_suid -ge 4 ]];then
            echo "$u10_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> $target
            u10_safe_check=$((u10_safe_check+1))
        else
            if [[ "$u10_file_owner_user" == "root" ]];then
                echo "/etc/hosts 파일의 소유자가 root로 적절하게 설정되어 있습니다." >> $target
                if [ $u10_file_owner -eq 6 ];then
                    echo "$u10_x_inetd_conf 파일의 소유 권한이 6으로 설정되어 있습니다." >> $target
                    if [ $u10_file_group -eq 0 ];then
                        echo "$u10_x_inetd_conf 파일의 소유 그룹 권한이 0으로 설정되어 있습니다." >> $target
                        if [ $u10_file_other -eq 0 ];then
                            echo "$u10_x_inetd_conf 파일의 기타 사용자(Other) 권한이 0으로 설정되어 있습니다." >> $target
                        else
                            echo "$u10_x_inetd_conf 파일의 기타 사용자(Other) 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                            u10_safe_check=$((u10_safe_check+1))
                        fi
                    else
                        ehco "$u10_x_inetd_conf 파일의 소유 그룹 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                        u10_safe_check=$((u10_safe_check+1))
                    fi
                else
                    echo "$u10_x_inetd_conf 파일의 소유 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                    u10_safe_check=$((u10_safe_check+1)) >> $target
                fi
            else
                echo "/etc/hosts 파일의 소유자가 root가 아닌 다른 사용자로 설정되어 있습니다." >> $target
                u10_safe_check=$((u10_safe_check+1))
            fi
        fi
    else
        echo "$u10_x_inetd_conf 파일이 존재하지 않습니다." >> $target
    fi
done

if [[ -d "/etc/xinetd.d" ]]; then
    for u10_xinetd_file in /etc/xinetd.d/*; do
        if [[ -f $u10_xinetd_file ]]; then
            echo "$u10_xinetd_file 이 존재합니다."
            u10_file_owner_user=$(stat -c "%U" "$u10_xinetd_file" 2> /dev/null)
            u10_file_owner=$(stat -c "%a" "$u10_xinetd_file"  2> /dev/null| cut -c1)
            u10_file_group=$(stat -c "%a" "$u10_xinetd_file"  2> /dev/null| cut -c2)
            u10_file_other=$(stat -c "%a" "$u10_xinetd_file"  2> /dev/null| cut -c3)
            u10_check_suid=$(stat -c "%a" "$u10_xinetd_file"  2> /dev/null| tr -d '\n' | wc -c)
            if [[ $u10_check_suid -ge 4 ]];then
                echo "$u10_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> $target
                u10_safe_check=$((u10_safe_check+1))
            else
                if [[ "$u10_file_owner_user" == "root" ]];then
                    echo "/etc/hosts 파일의 소유자가 root로 적절하게 설정되어 있습니다."
                    if [ $u10_file_owner -le 6 ];then
                        echo "$u10_xinetd_file 파일의 소유 권한이 6으로 설정되어 있습니다." >> $target
                        if [ $u10_file_group -le 0 ];then
                            echo "$u10_xinetd_file 파일의 소유 그룹 권한이 0으로 설정되어 있습니다." >> $target
                            if [ $u10_file_other -eq 0 ];then
                                echo "$u10_xinetd_file 파일의 기타 사용자(Other) 권한이 0으로 설정되어 있습니다." >> $target
                            else
                                echo "$u10_xinetd_file 파일의 기타 사용자(Other) 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                                u10_safe_check=$((u10_safe_check+1))
                            fi
                        else
                            ehco "$u10_xinetd_file 파일의 소유 그룹 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                            u10_safe_check=$((u10_safe_check+1))
                        fi
                    else
                        echo "$u10_xinetd_file 파일의 소유 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                        u10_safe_check=$((u10_safe_check+1)) 
                    fi
                else
                    echo "/etc/hosts 파일의 소유자가 root가 아닌 다른 사용자로 설정되어 있습니다."
                    u10_safe_check=$((u10_safe_check+1))
                fi 
            fi
        fi
    done
else
    echo "/etc/xinetd.d 디렉터리가 존재하지 않거나, 해당 디렉터리 내에 파일이 존재하지 않습니다."  >> $target
fi

if [[ $u10_safe_check -ge 1 ]];then
    u10=$((u10+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u10 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u10_Files_Directory_Management=1
fi

cat << EOF
===== [U-11] /etc/syslog.conf file owner and permission settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-11   /etc/syslog.conf 파일 소유자 및 권한 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : /etc/syslog.conf 파일의 권한 적절성을 점검하여, 관리자 외 비인가자의 임의적인 syslog.conf 파일 변조를 방지하기 위함" >> $target
echo "보안위협 : syslog.conf 파일의 설정내용을 참조하여 로그의 저장위치가 노출되며 로그을 기록하지 않도록 설정하거나 대량의 로그를 기록하게 하여 시스템 과부하를 유도할 수 있음" >> $target
echo "+판단기준 양호 : /etc/syslog.conf 파일의 소유자가 root(또는 bin, sys)이고, 권한이 640 이하인 경우" >> $target
echo "+판단기준 취약 : /etc/syslog.conf 파일의 소유자가 root(또는 bin, sys)가 아니거나, 권한이 640 이하가 아닌 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-11 점검 결과" >> $result
# CentOS7 에서는 기본적으로 rsyslog가 기본 로그 시스템으로 사용됨
u11=0
u11_syslog_files=("/etc/syslog.conf" "/etc/rsyslog.conf")
u11_Files_Directory_Management=0
u11_safe_check=0
for u11_syslog_file in "${u11_syslog_files[@]}";do
    echo "$u11_syslog_file Checking..." >> $target
    if [[ -e "$u11_syslog_file" ]];then
        echo "$u11_syslog_file 파일이 존재합니다." >> $target
        u11_file_owner_user=$(stat -c "%U" "$u11_syslog_file" 2> /dev/null)
        u11_file_owner=$(stat -c "%a" "$u11_syslog_file"  2> /dev/null| cut -c1)
        u11_file_group=$(stat -c "%a" "$u11_syslog_file"  2> /dev/null| cut -c2)
        u11_file_other=$(stat -c "%a" "$u11_syslog_file"  2> /dev/null| cut -c3)
        u11_check_suid=$(stat -c "%a" "$u11_syslog_file"  2> /dev/null| tr -d '\n' | wc -c)
        if [[ $u11_check_suid -ge 4 ]];then
            echo "$u11_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> $target
            u11_safe_check=$((u11_safe_check+1))
        else
            if [[ $u11_file_owner_user == "root" || $u11_file_owner_user == "bin" || $u11_file_owner_user == "sys" ]];then
                echo "$syslog_file 파일의 소유자가 root, bin, sys로 적절하게 설정되어 있습니다." >> $target
                if [ $u11_file_owner -le 6 ];then
                    echo "$u11_syslog_file 파일의 소유 권한이 6으로 설정되어 있습니다." >> $target
                    if [ $u11_file_group -le 4 ];then
                        echo "$u11_syslog_file 파일의 소유 그룹 권한이 4로 설정되어 있습니다." >> $target
                        if [ $u11_file_other -eq 0 ];then
                            echo "$u11_syslog_file 파일의 기타 사용자(Other) 권한이 0으로 설정되어 있습니다." >> $target
                        else
                            echo "$u11_syslog_file 파일의 기타 사용자(Other) 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                            u11_safe_check=$((u11_safe_check+1))
                        fi
                    else
                        echo "$u11_syslog_file 파일의 소유 그룹 권한이 4이 아닌 값으로 설정되어 있습니다." >> $target
                        u11_safe_check=$((u11_safe_check+1))
                    fi
                else
                    echo "$u11_syslog_file 파일의 소유 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                    u11_safe_check=$((u11_safe_check+1)) 
                fi
            else
                echo "$u11_syslog_file 파일의 소유자가 root, bin, sys가 아닌 다른 사용자로 설정되어 있습니다." >> $target
                u11_safe_check=$((u11_safe_check+1))
            fi 
        fi
    else
        echo "$u11_syslog_file 파일이 존재하지 않습니다." >> $target
        u11=$((u11+1))
    fi
done


if [[ $u11_safe_check -ge 1 ]];then
    u11=$((u11+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u11 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u11_Files_Directory_Management=1
fi

cat << EOF
===== [U-12] /etc/services file owner and permission settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-12   /etc/services 파일 소유자 및 권한 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : /etc/services 파일을 관리자만 제어할 수 있게 하여 비인가자들의 임의적인 파일 변조를 방지하기 위함" >> $target
echo "보안위협 : services 파일의 접근권한이 적절하지 않을 경우 비인가 사용자가 운영 포트번호를 변경하여 정상적인 서비스를 제한하거나, 허용되지 않은 포트를 오픈하여 악성 서비스를 의도적으로 실행할 수 있음" >> $target
echo "+판단기준 양호 : /etc/services 파일의 소유자가 root(또는 bin, sys)이고, 권한이 644 이하인 경우" >> $target
echo "+판단기준 취약 : /etc/services 파일의 소유자가 root(또는 bin, sys)가 아니거나, 권한이 644 이하가 아닌 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-12 점검 결과" >> $result
u12=0
u12_Files_Directory_Management=0
u12_safe_check=0
if [[ -e "/etc/services" ]];then
    echo "/etc/services 파일이 존재합니다." >> $target
    u12_file_owner_user=$(stat -c "%U" "/etc/services" 2> /dev/null)
    u12_file_owner=$(stat -c "%a" "/etc/services"  2> /dev/null| cut -c1)
    u12_file_group=$(stat -c "%a" "/etc/services"  2> /dev/null| cut -c2)
    u12_file_other=$(stat -c "%a" "/etc/services"  2> /dev/null| cut -c3)
    u12_check_suid=$(stat -c "%a" "/etc/services"  2> /dev/null| tr -d '\n' | wc -c)
    if [[ $u12_check_suid -ge 4 ]];then
        echo "$u12_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> $target
        u12_safe_check=$((u12_safe_check+1))
    else
        if [[ $u12_file_owner_user == "root" || $u12_file_owner_user == "bin" || $u12_file_owner_user == "sys" ]];then
            echo "$syslog_file 파일의 소유자가 root, bin, sys로 적절하게 설정되어 있습니다." >> $target
            if [ $u12_file_owner -le 6 ];then
                echo "/etc/services 파일의 소유 권한이 6으로 설정되어 있습니다." >> $target
                if [ $u12_file_group -le 4 ];then
                    echo "/etc/services 파일의 소유 그룹 권한이 4로 설정되어 있습니다." >> $target
                    if [ $u12_file_other -le 4 ];then
                        echo "/etc/services 파일의 기타 사용자(Other) 권한이 4 이하로 설정되어 있습니다." >> $target
                    else
                        echo "/etc/services 파일의 기타 사용자(Other) 권한이 4 이상의 값으로 설정되어 있습니다." >> $target
                        u12_safe_check=$((u12_safe_check+1))
                    fi
                else
                    echo "/etc/services 파일의 소유 그룹 권한이 4 이상의 값으로 설정되어 있습니다." >> $target
                    u12_safe_check=$((u12_safe_check+1))
                fi
            else
                echo "/etc/services 파일의 소유 권한이 4 이상의 값으로 설정되어 있습니다." >> $target
                u12_safe_check=$((u12_safe_check+1)) 
            fi
        else
            echo "/etc/services 파일의 소유자가 root, bin, sys가 아닌 다른 사용자로 설정되어 있습니다." >> $target
            u12_safe_check=$((u12_safe_check+1))
        fi 
    fi
else
    echo "/etc/services 파일이 존재하지 않습니다." >> $target
    u12=$((u12+1))
fi

if [[ $u12_safe_check -ge 1 ]];then
    u12=$((u12+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u12 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u12_Files_Directory_Management=1
fi

cat << EOF
===== [U-13] Check SUID, SGID, settings file               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-13   SUID, SGID, 설정 파일점검                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 불필요한 SUID, SGID 설정 제거로 악의적인 사용자의 권한상승을 방지하기 위함" >> $target
echo "보안위협 : SUID, SGID 파일의 접근권한이 적절하지 않을 경우 SUID, SGID 설정된 파일로 특정 명령어를 실행하여 root 권한 획득 가능함" >> $target
echo "+판단기준 양호 : 주요 실행파일의 권한에 SUID와 SGID에 대한 설정이 부여되어 있지 않은 경우" >> $target
echo "+판단기준 취약 : 주요 실행파일의 권한에 SUID와 SGID에 대한 설정이 부여되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-13 점검 결과" >> $result
u13=0
u13_Files_Directory_Management=0
u13_safe_check=0

u13_default_sugid_files=(
    "/usr/bin/fusermount"
    "/usr/bin/wall"
    "/usr/bin/ksu"
    "/usr/bin/chfn"
    "/usr/bin/chsh"
    "/usr/bin/passwd"
    "/usr/bin/su"
    "/usr/bin/chfn"
    "/usr/bin/chage"
    "/usr/bin/gpasswd"
    "/usr/bin/newgrp"
    "/usr/bin/mount"
    "/usr/bin/pkexec"
    "/usr/bin/umount"
    "/usr/bin/write"
    "/usr/bin/ssh-agent"
    "/usr/bin/crontab"
    "/usr/bin/Xorg"
    "/usr/bin/cgclassify"
    "/usr/bin/cgexec"
    "/usr/bin/at"
    "/usr/bin/sudo"
    "/usr/bin/locate"
    "/usr/bin/staprun"
    "/usr/sbin/unix_chkpwd"
    "/usr/sbin/pam_timestamp_check"
    "/usr/sbin/netreport"
    "/usr/sbin/usernetctl"
    "/usr/sbin/lockdev"
    "/usr/sbin/userhelper"
    "/usr/sbin/mount.nfs"
    "/usr/sbin/postdrop"
    "/usr/sbin/postqueue"
    "/usr/lib/polkit-1/polkit-agent-helper-1"
    "/usr/lib64/vte-2.91/gnome-pty-helper"
    "/usr/share/code/chrome-sandbox"
    "/usr/libexec/utempter/utempter"
    "/usr/libexec/qemu-bridge-helper"
    "/usr/libexec/sssd/krb5_child"
    "/usr/libexec/sssd/ldap_child"
    "/usr/libexec/sssd/selinux_child"
    "/usr/libexec/sssd/proxy_child"
    "/usr/libexec/dbus-1/dbus-daemon-launch-helper"
    "/usr/libexec/flatpak-bwrap"
    "/usr/libexec/openssh/ssh-keysign"
    "/usr/libexec/spice-gtk-x86_64/spice-client-glib-usb-acl-helper"
)

u13_check_sugid_files=(
    "/sbin/dump" 
    "/sbin/restore" 
    "/sbin/unix_chkpwd" 
    "/usr/bin/at" 
    "/usr/bin/lpq" 
    "/usr/bin/lpq-lpd" 
    "/usr/bin/lpr" 
    "/usr/bin/lpr-lpd" 
    "/usr/bin/lprm" 
    "/usr/bin/lprm-lpd" 
    "/usr/bin/newgrp" 
    "/usr/sbin/lpc" 
    "/usr/sbin/lpc-lpd" 
    "/usr/sbin/traceroute"
)
echo -e "${RED}Rocky Linux8 시스템의 기본적으로 설정된 SUID, SGID 파일을 제외한 잘못된 SUID, SGID 설정 파일들을 확인합니다.${NC}"  >> $target
# 결과를 저장할 배열
u13_questionable_files=()

# `find` 명령어의 결과를 배열로 저장합니다.
mapfile -t u13_find_results < <(find / -xdev -user root -type f \( -perm -04000 -o -perm -02000 \) 2>/dev/null)

# 각 파일에 대해 제외할 목록과 비교하여 중복을 처리합니다.
for u13_find_result in "${u13_find_results[@]}"; do
    u13_exclude=0
    for u13_exclude_file in "${u13_default_sugid_files[@]}"; do
        if [[ "$u13_find_result" == "$u13_exclude_file" ]]; then
            u13_exclude=1
            break
        fi
    done
    
    # 중복되지 않거나 제외 목록에 포함되지 않는 경우 배열에 추가
    if [[ $u13_exclude -eq 0 ]]; then
        # 배열에 추가하기 전에 중복 확인
        if [[ ! " ${u13_questionable_files[@]} " =~ " ${u13_find_result} " ]]; then
            u13_questionable_files+=("$u13_find_result")
        fi
    fi
done

if [[ ${#u13_questionable_files[@]} -gt 0 ]]; then
    u13_safe_check=$((u13_safe_check+1))
    echo "다음 파일들은 제외 목록에 없거나 중복되지 않으며, 의심스러운 SUID, SGID가 설정됭어 있습니다." >> $target
    for u13_questionable_file in "${u13_questionable_files[@]}"; do
        echo "$u13_questionable_file" >> $target
    done
else
    echo "제외 목록에 포함되지 않는 파일이 없습니다." >> $target
fi

echo -e "${RED}Check-List 기반의 불필요한 SUID/SGID 설정 파일 목록을 점검합니다.${NC}" >> $target
for u13_check_sugid_file in "${u13_check_sugid_files[@]}";do
    u13_chekc_perm=$(stat -c "%A" "$u13_check_sugid_file" 2> /dev/null )
    if [[ $u13_chekc_perm == *s* || $u13_chekc_perm == *S* ]];then
        echo "$u13_check_sugid_file 파일에 불필요한 SUID/SGID 가 설정되어 있습니다." >> $target
        u13_safe_check=$((u13_safe_check+1))
    fi
done

if [[ $u13_safe_check -ge 1 ]];then
    u13=$((u13+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u13 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u13_Files_Directory_Management=1
fi

cat << EOF
===== [U-14] Setting users, system startup files and environment file owners and permissions               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-14 사용자, 시스템 시작파일 및 환경파일 소유자 및 권한 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 비인가자의 환경변수 조작으로 인한 보안 위험을 방지하기 위함" >> $target
echo "보안위협 : 홈 디렉터리 내의 사용자 파일 및 사용자별 시스템 시작파일 등과 같은 환경변수 파일의 접근권한 설정이 적절하지 않을 경우 비인가자가 환경변수 파일을 변조하여 정상 사용중인 사용자의 서비스가 제한 될 수 있음" >> $target
echo "+판단기준 양호 : 홈 디렉터리 환경변수 파일 소유자가 root 또는, 해당 계정으로 지정되어 있고, 홈 디렉터리 환경변수 파일에 root와 소유자만 쓰기 권한이 부여된 경우" >> $target
echo "+판단기준 취약 : 홈 디렉터리 환경변수 파일 소유자가 root 또는, 해당 계정으로 지정되지 않고, 홈 디렉터리 환경변수 파일에 root와 소유자 외에 쓰기 권한이 부여된 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-14 점검 결과" >> $result
u14_Files_Directory_Management=0
u14_safe_check=0
u14=0

u14_home_Environmental_files=(
    ".profile"
    ".kshrc"
    ".cshrc"
    ".bashrc"
    ".bash_profile"
    ".login"
    ".exrc"
    ".netrc"
    ".bash_logout"
    ".env"
    ".zshrc"
    ".zprofile"
)

u14_check_users=($(cat /etc/passwd | egrep -v '/sbin|false|sync' | awk -F':' '{print $1}'))
for u14_check_user in "${u14_check_users[@]}";do
    u14_user_home=($(getent passwd "$u14_check_user" | awk -F':' '{print$6}'))
    if [ -d "$u14_user_home" ];then
        echo "--------------------------------------" >> $target
        echo "$u14_check_user 의 홈 디렉터리가 존재합니다." >> $target
        for u14_home_Environmental_file in "${u14_home_Environmental_files[@]}";do
            echo -e "${RED}Checking file: $u14_user_home/$u14_home_Environmental_file${NC}" >> $target
            if [ -e "$u14_user_home/$u14_home_Environmental_file" ];then
                echo "$u14_user_home/$u14_home_Environmental_file 파일이 존재합니다." >> $target
                u14_file_owner=$(ls -l "$u14_user_home/$u14_home_Environmental_file" | awk '{print $4}')
                if [[ "$u14_file_owner" == "root" ]] || [[ "$u14_file_owner" == "$u14_check_user" ]]; then
                    echo "$u14_user_home/$u14_home_Environmental_file 파일의 소유자가 root 혹은 해당 계정으로 적절하게 설정되어 있습니다." >> $target 
                    u14_permissions=$(stat -c "%A" "$u14_user_home/$u14_home_Environmental_file")
                    u14_group_perm=$(echo "$u14_permissions" | cut -c6)
                    u14_other_perm=$(echo "$u14_permissions" | cut -c9)
                    if [ "$u14_group_perm" == "w" ] || [ "$u14_other_perm" == "w" ]; then 
                        echo "$u14_user_home/$home_Environmental_file 파일의 소유자 및 root 외에 기타사용자(Other)에 대한 쓰기 권한이 부여되어 있어 취약합니다." >> $target
                        u14_safe_check=$((u14_safe_check+1))
                    else
                        echo "$u14_user_home/$u14_home_Environmental_file 파일의 소유자 및 root 외에 기타사용자(Other)에 대한 쓰기 권한이 부여되어 있지 않아 양호합니다." >> $target
                    fi
                else
                    echo "echo "$u14_user_home/$u14_home_Environmental_file 파일의 소유자가 root 혹은 해당 계정으로 설정되어 있지 않아 취약합니다."" >> $target
                    u14_safe_check=$((u14_safe_check+1))
                fi
            else
                echo "$u14_user_home/$u14_home_Environmental_file 파일이 존재하지 않습니다." >> $target
            fi
        done
    fi
done

if [[ $u14_safe_check -ge 1 ]];then
    u14=$((u14+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u14 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u14_Files_Directory_Management=1
fi

cat << EOF
===== [U-15] world writable file check               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-15 world writable 파일 점검                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : world writable 파일을 이용한 시스템 접근 및 악의적인 코드 실행을 방지하기 위함" >> $target
echo "보안위협 : 시스템 파일과 같은 중요 파일에 world writable 설정이 될 경우, 일반사용자 및 비인가된 사용자가 해당 파일을 임의로 수정, 삭제가 가능함" >> $target
echo "+판단기준 양호 : 시스템 중요 파일에 world writable 파일이 존재하지 않거나, 존재 시 설정 이유를 확인하고 있는 경우" >> $target
echo "+판단기준 취약 : 시스템 중요 파일에 world writable 파일이 존재하나 해당 설정 이유를 확인하고 있지 않는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-15 점검 결과" >> $result
u15_Files_Directory_Management=0
u15_safe_check=0
u15=0

u15_world_wr=$(find / -type f -perm -2 -exec ls -l {} \; 2> /dev/null | wc -l)
if [[ $u15_world_wr -gt 0 ]];then
    echo "world writable 파일들이 존재합니다. [관리자와의 상담 필요]" >> $target
    u15_safe_check=$((u15_safe_check+1))
else
    echo "world writable 파일들이 존재하지 않습니다." >> $target
fi

if [[ $u15_safe_check -ge 1 ]];then
    u15=$((u15+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u15 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u15_Files_Directory_Management=1
fi

cat << EOF
===== [U-16] Check device files that do not exist in /dev              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-16 /dev에 존재하지 않는 device 파일 점검             " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 실제 존재하지 않는 디바이스를 찾아 제거함으로써 root 파일 시스템 손상 및 다운 등의 문제를 방지하기 위함" >> $target
echo "보안위협 : 공격자는 rootkit 설정파일들을 서버 관리자가 쉽게 발견하지 못하도록 /dev에 device 파일인 것처럼 위장하는 수법을 많이 사용함" >> $target
echo "+판단기준 양호 : dev에 대한 파일 점검 후 존재하지 않은 device 파일을 제거한 경우" >> $target
echo "+판단기준 취약 : dev에 대한 파일 미점검 또는, 존재하지 않은 device 파일을 방치한 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-16 점검 결과" >> $result
u16_Files_Directory_Management=0
u16_safe_check=0
u16=0

u16_dev_find=$(find /dev -type f -exec ls -l {} \; 2> /dev/null | wc -l)
if [[ $u16_dev_find -gt 0 ]];then
    echo "/dev 디렉터리 내 불필요한 device 파일이 존재합니다." >> $target
    u16_safe_check=$((u16_safe_check+1))
else
    echo "/dev 디렉터리 내 불필요한 device 파일이 존재하지 않습니다.." >> $target
fi

if [[ $u16 -ge 1 ]];then
    High=$((High+1))
fi

if [[ $u16_safe_check -ge 1 ]];then
    u16=$((u16+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u16 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u16_Files_Directory_Management=1
fi

    cat << EOF
===== [U-17] \$HOME/.rhosts, hosts.equiv disabled              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-17 \$HOME/.rhosts, hosts.equiv 사용 금지             " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : ‘r’ command 사용을 통한 원격 접속은 인증 없이 관리자 원격접속이 가능하므로 서비스 포트를 차단해야 함" >> $target
echo "보안위협 :  rlogin, rsh 등과 같은 ‘r’ command의 보안 설정이 적용되지 않은 경우, 원격지의 공격자가 관리자 권한으로 목표 시스템상의 임의의 명령을 수행시킬수 있으며, 명령어 원격 실행을 통해 중요 정보 유출 및 시스템 장애를 유발시킬 수 있음. 또한 공격자 백도어 등으로도 활용될 수 있음" >> $target
echo "+판단기준 양호 :  login, shell, exec 서비스를 사용하지 않거나, 사용 시 아래와 같은 설정이 적용된 경우" >> $target
echo " 1. /etc/hosts.equiv 및 $HOME/.rhosts 파일 소유자가 root 또는, 해당 계정인 경우" >> $target
echo " 2. /etc/hosts.equiv 및 $HOME/.rhosts 파일 권한이 600 이하인 경우" >> $target
echo " 3. /etc/hosts.equiv 및 $HOME/.rhosts 파일 설정에 ‘+’ 설정이 없는 경우" >> $target
echo "+판단기준 취약 : ogin, shell, exec 서비스를 사용하고, 위와 같은 설정이 적용되지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-17 점검 결과" >> $result
u17_Files_Directory_Management=0
u17_safe_check=0
u17=0
u17_check_users=($(cat /etc/passwd | egrep -v 'nologin|sync|false' | awk -F':' '{print $1}'))
for u17_check_user in "${u17_check_users[@]}";do
    u17_user_home=($(getent passwd "$u17_check_user" | awk -F':' '{print$6}'))
    if [ -e "$u17_user_home/.rhosts" ];then
        u17_rhosts_owner=$(stat -c "%U" "$u17_user_home/.rhosts")
        if [[ "$u17_rhosts_owner" == "$u17_check_user" ||"$u17_rhosts_owner" == "root" ]];then
            echo "$u17_user_home/.rhosts 파일의 소유자가 roo또는 $u17_check_user 로 적절하게 설정되어 있습니다." >> $target
            u17_rhosts_perm=$(stat -c "%a" "$u17_user_home/.rhosts" | cut -c1)
            if [[ $u17_rhosts_perm -le 6 ]];then
                echo "$u17_user_home/.rhosts 파일의 권한이 600이하로 설정되어 양호합니다." >> $target
                if ! grep -qE "$u17_user_home/.rhosts";then
                    echo "$u17_user_home/.rhosts 파일에 + 설정이 되어있지 않아 양호합니다." >> $target
                else
                    echo "$u17_user_home/.rhosts 파일에 + 설정이 되어있어 취약합니다." >> $target
                    u17_safe_check=$((u17_safe_check+1))
                fi
            else
                echo "$u17_user_home/.rhosts 파일의 권한이 600이상으로 설정되어 취약합니다."  >> $target
                u17_safe_check=$((u17_safe_check+1))
            fi
        else
            echo "$u17_user_home/.rhosts파일의 소유작 $u17_check_user로 설정되어 있지 않아 취약합니다." >> $target
            u17_safe_check=$((u17_safe_check+1))
        fi
    else
        echo "$u17_user_home/.rhosts 파일이 존재하지 않습니다." >> $target
    fi
done
if [ -e "/etc/hosts.equiv" ];then
    u17_equivfile_owner=$(stat -c "%U" "/etc/hosts.equiv")
    if [[ "$u17_equivfile_owner" == "root" || "$u17_equivfile_owner" == "$u17_check_users" ]];then
        echo "/etc/hosts.equiv 파일의 소유자가 또는, 해당 계정으로 적절하게 설정되어 있습니다." >> $target
        u17_equivfile_perm=$(stat -c "%a" "/etc/hosts.equiv")
        if [[ $u17_equivfile_perm -le 600 ]];then
             echo "/etc/hosts.equiv 파일의 권한이 600이하로 설정되어 양호합니다." >> $target
            if ! grep -qE "etc/hosts.equiv";then
                echo "/etc/hosts 파일에 + 설정이 되어있지 않아 양호합니다." >> $target
            else
                echo "/etc/hosts 파일에 + 설정이 되어있어 취약합니다." >> $target
                u17_safe_check=$((u17_safe_check+1))
            fi
        else
            echo "/etc/hosts.equiv 파일의 권한이 600이상으로 설정되어 취약합니다."  >> $target
            u17_safe_check=$((u17_safe_check+1))
        fi
    else
        echo "/etc/hosts.equiv 파일의 소유작 root로 설정되어 있지 않아 취약합니다." >> $target
        u17_safe_check=$((u17_safe_check+1))
    fi
else
    echo "/etc/hosts.equiv 파일이 존재하지 않습니다." >> $target
fi

u17_service_checks=("login" "shell" "exec")
u17_service_count=0

for u17_service_check in "${u17_service_checks[@]}"; do
    if systemctl is-active --quiet "$u17_service_check"; then
        echo "login, shell, exec와 같은 서비스를 사용하고 있어 취약합니다." >> $target
        u17_safe_check=$((u17_safe_check+1))
    else
        u17_service_count=$((u17_service_count+1))
    fi
done
if [[ $u17_service_count -ge 1 ]];then
    echo "login, shell, exec 와 같은 서비스를 사용하고 있지 않아 양호합니다." >> $target
fi



if [[ $u17_safe_check -ge 1 ]];then
    u17=$((u17+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u17 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u17_Files_Directory_Management=1
fi

cat << EOF
===== [U-18] Access IP and Port Restrictions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-18 접속 IP 및 포트 제한             " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 허용한 호스트만 서비스를 사용하게 하여 서비스 취약점을 이용한 외부자 공격을 방지하기 위함" >> $target
echo "보안위협 :  허용할 호스트에 대한 IP 및 포트제한이 적용되지 않은 경우, Telnet, FTP같은 보안에 취약한 네트워크 서비스를 통하여 불법적인 접근 및 시스템 침해사고가 발생할 수 있음" >> $target
echo "+판단기준 양호 : 접속을 허용할 특정 호스트에 대한 IP 주소 및 포트 제한을 설정한 경우" >> $target
echo "+판단기준 취약 : 접속을 허용할 특정 호스트에 대한 IP 주소 및 포트 제한을 설정하지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-17 점검 결과" >> $result
u18_Files_Directory_Management=0
u18_safe_check=0
u18=0
u18_allowcheck=10
if command -v iptables &> /dev/null; then
    echo "IPtables 서비스가 설치되어 있습니다." >> $target
    if systemctl is-active --quiet "iptables";then
        echo "IPtables 서비스가 사용중입니다." >> $target
        # 모든 ACCEPT 규칙이 *와 0.0.0.0/0으로 설정되어 있는지 확인합니다.
        iptables -L -v -n | grep "ACCEPT" | grep -vE "^Chain" | while read -r u18_iptables_line; do
            # 필드를 분리합니다.
            IFS=' ' read -r -a u18_iptables_fields <<< "$u18_iptables_line"
            # 트래픽 허용 여부를 확인합니다.
            if [[ "${u18_iptables_fields[5]}" == "*" && \
                "${u18_iptables_fields[6]}" == "*" && \
                "${u18_iptables_fields[7]}" == "0.0.0.0/0" && \
                "${u18_iptables_fields[8]}" == "0.0.0.0/0" ]]; then
                # 체크할 체인 배열
                u18_chains=("INPUT" "OUTPUT" "FORWARD")

                # 각 체인에 대해 기본 정책과 규칙 확인
                for u18_chain in "${u18_chains[@]}"; do
                    # 기본 정책 확인
                    u18_default_policy=$(iptables -L $u18_chain -n | grep "Chain $u18_chain" | awk '{print $4}')

                    # 기본 정책이 DROP인지 확인
                    if [ "$u18_default_policy" == "DROP" ]; then
                        # 규칙이 있는지 확인
                        u18_rules=$(iptables -L $u18_chain -v -n | grep -v "^Chain")

                        # 규칙이 없는 경우
                        if [ -z "$u18_rules" ]; then
                            echo "DROP 정책이 기본 정책으로 되어 있지만 규칙이 없으며, 모든 트래픽을 허용하는 정책이 설정되어 있어 취약합니다." >> $target
                            echo "모든 트래픽을 허용하는 규칙: $u18_iptables_line" >> $target
                            u18_allowcheck=$((u18_allowcheck-1))
                            u18_safe_check=$((u18_safe_check+1))
                            break
                        else
                            echo "DROP 정책이 기본 정책으로 되어 있지만 규칙이 존재하며, 모든 트래픽을 허용하는 정책이 설정되어 있어 취약합니다." >> $target
                            echo "모든 트래픽을 허용하는 규칙: $u18_iptables_line" >> $target
                            u18_allowcheck=$((u18_allowcheck-1))
                            u18_safe_check=$((u18_safe_check+1))
                            break
                        fi
                    else
                        echo "기본 정책이 DROP이 아니며, 모든 트래픽을 허용하는 정책이 설정되어 있어 취약합니다." >> $target
                        echo "모든 트래픽을 허용하는 규칙: $u18_iptables_line" >> $target
                        u18_allowcheck=$((u18_allowcheck-1))
                        u18_safe_check=$((u18_safe_check+1))
                        break
                    fi
                done
            fi
        done
        if [[ $u18_allowcheck -eq 10 ]];then
            echo "모든 트래픽을 허용하는 정책이 설정되어 있지 않아 양호합니다." >> $target
        fi
    else
        echo "IPtables 서비스가 사용중이지 않습니다." >> $target
    fi
else
    echo "IPtables 서비스가 설치되어 있지 않습니다."  >> $target
fi
if [ -f "/sbin/ipf" ];then
    ehco "IPfilter를 사용하고 있습니다." >> $target
    u18_ipfilterfiles=("/etc/ipf/ipf.conf" "/etc/ipf/ipf.rules")
    for u18_ipfilterfile in "${u18_ipfilterfiles[@]}";do
        if [ -e "$u18_ipfilterfile" ];then
            if grep -q "pass" "$u18_ipfilterfile" && ! grep -q "block" "$u18_ipfilterfile"; then
                echo "기본 정책이 모든 트래픽을 허용하는 것으로 설정되어 있습니다." >> $target
                u18_safe_check=$((u18_safe_check+1))
                if ipf -l | grep -E "pass in|pass out"; then
                    echo "모든 트래픽을 허용하는 규칙이 발견되었습니다." >> $target
                    u18_allowcheck=$((u18_allowcheck+1))
                    u18_safe_check=$((u18_safe_check+1))
                else
                    echo "모든 트래픽을 허용하는 규칙이 없습니다." >> $target
                fi
            else
                echo "기본 정책에 블록 규칙이 포함되어 있거나 모든 트래픽을 허용하지 않습니다." >> $target
            fi
        else    
            echo "ipfilter설정파일이 존재하지 않습니다." >> $target
        fi 
    done
else
    echo "IPfilter를 사용하고 있지 않습니다." >> $target
fi
# TCP Wrapper를 사용하는지 확인
if [[ -f "/usr/sbin/tcpd" || -x "$(command -v tcpd)" ]]; then
    echo "TCP Wrapper를 사용하고 있습니다." >> $target

    # /etc/hosts.allow 파일 점검
    if [ -f "/etc/hosts.allow" ]; then
        if grep -vq "^\s*#" "/etc/hosts.allow";then
            if grep -iE "^\s*ALL:ALL\s*" "/etc/hosts.allow" | grep -qv "^\s*#"; then
                echo "/etc/hosts.allow 파일에 ALL:ALL 설정이 되어 있어 취약합니다." >> $target
                u18_allowcheck=$((u18_allowcheck+1))
                u18_safe_check=$((u18_safe_check+1))
            else
                echo "/etc/hosts.allow 파일에 ALL:ALL 설정이 되어 있지 않아 양호합니다." >> $target
            fi
        else
            echo "/etc/hosts.allow 파일 내에 설정값들이 존재하지 않습니다." >> $target
        fi
    else
        echo "/etc/hosts.allow 파일이 존재하지 않습니다." >> $target
    fi

    # /etc/hosts.deny 파일 점검
    if [ -f "/etc/hosts.deny" ]; then
        if grep -vq "^\s*#" "/etc/hosts.deny";then
            if grep -iE "^\s*ALL:ALL\s*" "/etc/hosts.deny" | grep -qv "^\s*#"; then
                echo "/etc/hosts.deny 파일에 ALL:ALL 설정 항목이 존재하여 양호합니다." >> $target
            else
                echo "/etc/hosts.deny 파일에 ALL:ALL 설정 항목이 존재하지 않아 취약합니다." >> $target
                u18_allowcheck=$((u18_allowcheck+1))
                u18_safe_check=$((u18_safe_check+1))
            fi
        else
            echo "/etc/hosts.deny 파일 내에 설정값들이 존재하지 않습니다." >> $target
        fi
    else
        echo "/etc/hosts.deny 파일이 존재하지 않습니다." >> $target
    fi

else
    echo "TCP Wrapper를 사용하지 않습니다." >> $target
fi

if [[ $u18_safe_check -ge 1 ]];then
    u18=$((u18+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u18 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u18_Files_Directory_Management=1
fi

cat << EOF
===== [U-19] Access IP and Port Restrictions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-19 Finger 서비스 비활성화             " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : Finger(사용자 정보 확인 서비스)를 통해서 네트워크 외부에서 해당 시스템에 등록된 사용자 정보를 확인할 수 있어 비인가자에게 사용자 정보가 조회되는 것을 차단하고자 함" >> $target
echo "보안위협 : 비인가자에게 사용자 정보가 조회되어 패스워드 공격을 통한 시스템 권한 탈취 가능성이 있으므로 사용하지 않는다면 해당 서비스를 중지하여야 함" >> $target
echo "+판단기준 양호 : Finger 서비스가 비활성화 되어 있는 경우" >> $target
echo "+판단기준 취약 : Finger 서비스가 활성화 되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-19 점검 결과" >> $result
u19_Service_Management=0
u19_safe_check=0
u19=0
#finger 서비스는 보통 systemctl이나 pgrep 명령어로는 바로 확인할 수 없음
if [ -f "/etc/inetd.conf" ];then
    if grep -iqE "^\s*finger\s*stream\s*tcp\s*nowait\s*bin" "/etc/inetd.conf";then
        echo "/etc/inetd.conf 파일에 Finger 서비스가 활성화 되어 있어 취약합니다." >> $target
        u19_safe_check=$((u19_safe_check+1))
    elif grep -iqE "^#\s*finger\s*stream\s*tcp\s*nowait\s*bin" "/etc/inetd.conf";then
        echo "/etc/inetd.conf 파일에 Finger 서비스가 비활성화 되어 있어 양호합니다." >> $target
    else
        echo "/etc/inetd.conf 파일 내에 Finger 설정 항목이 존재하지 않습니다." >> $target
    fi
elif [ -f "/etc/xinetd.d/finger" ];then
    u19_fingerconf=$(sed -n '/service finger/,/}/p' "/etc/xinetd.d/finger" | grep -v "^#" | grep -iE "^\s*disable" | awk '{print tolower($3)}' | sed -n '1p')
    u19_lower_string=$(echo "$u19_fingerconf" | tr '[:upper:]' '[:lower:]')
    if [[ $u19_lower_string == "no" ]];then
        echo "/etc/xinerd.d/finger 설정 파일 내에 finger 서비스가 활성화 되어 있어 취약합니다." >> $target
        u19_safe_check=$((u19_safe_check+1))
    elif [[ $u19_lower_string == "yes" ]];then
        echo "/etc/xinetd.d/finger 설정 파일 내에 finger 서비스가 비활성화 되어 있어 양호합니다." >> $target
    else
        echo "/etc/xinetd.d/finger 설정 파일 내에 finger 서비스 항목이 존재하지 않습니다." >> $target
    fi
else
    echo "/etc/inetd.conf 파일 및 /etc/xinetd.d/finger 파일이 존재하지 않습니다." >> $target
fi

if [[ $u19_safe_check -ge 1 ]];then
    u19=$((u19+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u19 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u19_Service_Management=1
fi

cat << EOF
===== [U-20] Disable Finger Service              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-20  Anonymous FTP 비활성화             " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 실행중인 FTP 서비스에 익명 FTP 접속이 허용되고 있는지 확인하여 접속허용을 차단하는 것을 목적으로 함" >> $target
echo "보안위협 : Anonymous FTP(익명 FTP)를 사용 시 anonymous 계정으로 로그인 후 디렉터리에 쓰기 권한이 설정되어 있다면 악의적인 사용자가 local exploit을 사용하여 시스템에 대한 공격을 가능하게 함" >> $target
echo "+판단기준 양호 : Anonymous FTP (익명 ftp) 접속을 차단한 경우" >> $target
echo "+판단기준 취약 : Anonymous FTP (익명 ftp) 접속을 차단하지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-20 점검 결과" >> $result
u20_Service_Management=0
u20_safe_check=0
u20=0
u20_ftpusers=("ftp" "anonymous")
u20_safe_check=0
for u20_ftpuser in "${u20_ftpusers[@]}";do
    if grep -q "$u20_ftpuser" "/etc/passwd";then
        u20_shellcheck_ftp=$(cat /etc/passwd | grep "$u20_ftpuser" | awk -F':' '{print $7}' | awk -F'/' '{print $3}')
        if [[ $u20_shellcheck == "nologin" ]];then
            echo "$u20_ftpuser 계정이 존재하며, 쉘 설정이 nologin 으로 설정되어 ftp 계증으로의 로그인을 제한하고 있습니다." >> $target
        else
            echo "$u20_ftpuser 계정이 존재하며, 쉘 설정이 nologin이 아닙니다. 해당 계정에 대한 삭제조치가 이루어져야 합니다." >> $target
            u20_safe_check=$((u20_safe_check+1))
        fi
    else
        echo "$u20_ftpuser 계정이 존재하지 않습니다." >> $target
    fi
done

u20_vsftpd_files=("/etc/vsftpd/vsftpd.conf" "/etc/vsftpd.conf")

for u20_vsftpd_file in "${u20_vsftpd_files[@]}";do
    if [ -f "$u20_vsftpd_file" ];then
        echo "$u20_vsftpd_file 이 존재합니다." >> $target
        u20_ftpoption=$(grep "anonymous_enable" $u20_vsftpd_file | grep -v "^\s*#" | awk -F'=' '{print $2}' | tr -d ' ')
        u20_lower_vsftpd=$(echo "$u20_ftpoption" | tr '[:upper:]' '[:lower:]')
        if [[ $u20_lower_vsftpd == "no" ]];then
            echo "$u20_vsftpd_file 파일에 Anonymous 설정이 적절하게 비활성화 되어 있습니다." >> $target
        else
            echo "$u20_vsftpd_file 파일에 Anonymous 설정이 활성화 되어 있어 취약합니다."  >> $target
            u20_safe_check=$((u20_safe_check+1))
        fi
    else
        echo "$u20_vsftpd_file 이 존재하지 않습니다." >> $target
    fi
done

u20_proftpd_files=("/etc/proftpd/proftpd.conf" "/etc/proftpd.conf")
for u20_proftpd_file in "${u20_proftpd_files[@]}"; do
    if [ -f "$u20_proftpd_file" ]; then
        echo "$u20_proftpd_file 파일이 존재합니다" >> $target
        u20_proftpdoption=$(sed -n '/<Anonymous/,/<\/Anonymous>/p' "$u20_proftpd_file" | sed -n '/<Limit LOGIN/,/<\/Limit>/p' | grep -i "DenyAll")
        u20_lower_proftpd=$(echo "$u20_proftpdoption" | tr '[:upper:]' '[:lower:]')

        if sed -n '/<Anonymous/,/<\/Anonymous>/p' "$u20_proftpd_file" | grep -Eq "^\s*#"; then
            echo "Anonymous 블록이 주석처리 되어 있어 양호합니다." >> $target
        else
            if sed -n '/<Anonymous/,/<\/Anonymous>/p' "$u20_proftpd_file" | grep -q "<Anonymous"; then
                if [[ "$u20_lower_proftpd" == *"denyall"* ]]; then
                    echo "Anonymous 계정에 대한 접근을 허용하지 않고 있어 양호합니다." >> $target
                else
                    echo "Anonymous 계정에 대한 접근을 거부하는 설정이 존재하지 않아 취약합니다." >> $target
                    u20_safe_check=$((u20_safe_check+1))
                fi
            else
                echo "Anonymous 블록이 존재하지 않아 양호합니다." >> $target
            fi
        fi
    else
        echo "$u20_proftpd_file 파일이 존재하지 않습니다." >> $target
    fi
done

if [[ $u20_safe_check -ge 1 ]];then
    u20=$((u20+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u20 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u20_Service_Management=1
fi

cat << EOF
===== [U-21] Disabling r Family Services              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-21  r 계열 서비스 비활성화             " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : r-command 사용을 통한 원격 접속은 NET Backup 또는 클러스터링 등 용도로 사용되기도 하나, 인증 없이 관리자 원격접속이 가능하여 이에 대한 보안위협을 방지하고자 함" >> $target
echo "보안위협 :  rsh, rlogin, rexec 등의 r command를 이용하여 원격에서 인증절차 없이 터미널 접속, 쉘 명령어를 실행이 가능함" >> $target
echo "+판단기준 양호 : 불필요한 r 계열 서비스가 비활성화 되어 있는 경우" >> $target
echo "+판단기준 취약 : 불필요한 r 계열 서비스가 활성화 되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-21 점검 결과" >> $result

u21_Service_Management=0
u21_safe_check=0
u21=0
u21_checkrcommands=("rsh" "rlogin" "rexec" "shell" "login" "exec")
u21_checkports=("514" "513" "512")

check_service_status "${u21_checkports}" "${u21_checkrcommands[@]}"
if [[ $? -eq 1 ]]; then
    echo "r 계열 서비스를 사용하고 있습니다." >> $target
    u24_safe_check=$((u24_safe_check+1))
else
    echo "r 계열 서비스를 사용하고 있지 않습니다." >> $target
fi

if [[ $u21_safe_check -ge 1 ]];then
    u21=$((u21+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u21 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u21_Service_Management=1
fi

cat << EOF
===== [U-22] Crond file owner and permission settings              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-22  crond 파일 소유자 및 권한 설정             " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 관리자외 cron 서비스를 사용할 수 없도록 설정하고 있는지 점검하는 것을 목적으로 함" >> $target
echo "+보안위협 : root 외 일반사용자에게도 crontab 명령어를 사용할 수 있도록 할 경우, 고의 또는 실수로 불법적인 예약 파일 실행으로 시스템 피해를 일으킬 수 있음" >> $target
echo "+판단기준 양호 : crontab 명령어 일반사용자 금지 및 cron 관련 파일 640 이하인 경우" >> $target
echo "+판단기준 취약 : crontab 명령어 일반사용자 사용가능하거나, crond 관련 파일 640 이상인 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-22 점검 결과" >> $result
u22_cron_checkfiles=("crontab" "cron.allow" "cron.deny")
u22_cron_checkdirs=("cron.d" "cron.hourly" "cron.daily" "cron.weekly" "cron.monthly")
u22_cron_spools=("/var/spool/cron" "/var/spool/cron/crontabs")
u22=0
u22_Service_Management=0
u22_safe_check=0
# 명령어 출력을 읽어 배열에 저장
u22_crontab_pass_s=($(type -a crontab | sort | uniq))
for u22_crontab_pass in "${u22_crontab_pass_s[@]}";do
    if [ -f "$u22_crontab_pass" ];then
        u22_crontab_perm=$(stat -c "%a" "$u22_crontab_pass" | cut -c1)
        u22_crontab_group=$(stat -c "%a" "$u22_crontab_pass" | cut -c2)
        u22_crontab_other=$(stat -c "%A" "$u22_crontab_pass" | awk '{print substr($1, 8, 3)}')
        u22_crontab_owner=$(stat -c "%U" "$u22_crontab_pass")
        if [[ $u22_crontab_perm -lt 6 && $u22_crontab_group -lt 4 ]];then
            if [[ $u22_crontab_other == "---" ]];then
                if [[ $u22_crontab_owner == "root" ]];then
                    echo "$u22_crontab_pass 파일에 대한 소유자 및 권한 설정이 적절하게 되어 있습니다." >> $target
                else
                    echo "$u22_crontab_pass 파일에 대한 3.5 DoS 공격에 취약한 서비스 비활성화유자가 root 소유자가 아닌 $u22_crontab_owenr로 설정되어 있어 취약합니다." >> $target
                    u22_safe_check=$((u22_safe_check+1))
                fi
            else
                echo "$u22_crontab_pass 파일에 대한 기타 사용자(Other)에 대한 권한이 $u22_crontab_other 설정되어 있어 취약합니다." >> $target
                u22_safe_check=$((u22_safe_check+1))
            fi
        else
            echo "$u22_crontab_pass 파일의 권한이 $u22_crontab_perm 으로 640 이상으로 설정되어 있으며 기타 사용자(Other)에 대한 권한이 설정되어 있어 취약합니다." >> $target
            u22_safe_check=$((u22_safe_check+1))
        fi
    fi
done
for u22_cron_checkfile in "${u22_cron_checkfiles[@]}";do
    if [ -f "/etc/$u22_cron_checkfile" ];then
        u22_crontab_file_perm=$(stat -c "%a" "/etc/$u22_cron_checkfile" | cut -c1)
        u22_crontab_file_group=$(stat -c "%a" "/etc/$u22_cron_checkfile" | cut -c2)
        u22_crontab_file_other=$(stat -c "%A" "/etc/$u22_cron_checkfile" | awk '{print substr($1, 8, 3)}')
        u22_crontab_file_owner=$(stat -c "%U" "/etc/$u22_cron_checkfile")
        if [[ $u22_crontab_file_perm -lt 6 && $u22_crontab_file_group -lt 4 ]];then
            if [[ $u22_crontab_file_other == "---" ]];then
                if [[ $u22_crontab_file_owner == "root" ]];then
                    echo "/etc/$u22_cron_checkfile 파일에 대한 소유자 및 권한 설정이 적절하게 되어 있습니다." >> $target
                else
                    echo "/etc/$u22_cron_checkfile 파일에 대한 소유자가 root 소유자가 아닌 $u22_crontab_file_perm 설정되어 있어 취약합니다." >> $target
                    u22_safe_check=$((u22_safe_check+1))
                fi
            else
                echo "/etc/$u22_cron_checkfile 파일에 대한 기타 사용자(Other)에 대한 권한이 $u22_crontab_file_other 설정되어 있어 취약합니다." >> $target
                u22_safe_check=$((u22_safe_check+1))
            fi
        else
            echo "/etc/$u22_cron_checkfile 파일의 권한이 $u22_crontab_file_perm 으로 640 이상으로 설정되어 있으며 기타 사용자(Other)에 대한 권한이 설정되어 있어 취약합니다." >> $target
            u22_safe_check=$((u22_safe_check+1))
        fi
    else
        echo "/etc/$u22_cron_checkfile 파일이 존재하지 않습니다." >> $target
    fi
done
for u22_cron_checkdir in "${u22_cron_checkdirs[@]}";do
    if [ -d "/etc/$u22_cron_checkdir" ];then
        u22_cron_dirinfiles=($(ls -al "/etc/$u22_cron_checkdir" | awk '{print $9}' | grep -v "^\." | sed '1d'))
        if [ -n "$u22_cron_dirinfiles" ];then
            for u22_cron_dirinfile in "${u22_cron_dirinfiles[@]}";do
                if [ -f "/etc/$u22_cron_checkdir/$u22_cron_dirinfile" ];then
                    u22_crontab_dirf_perm=$(stat -c "%a" "/etc/$u22_cron_checkdir/$u22_cron_dirinfile" | cut -c1)
                    u22_crontab_dirf_group=$(stat -c "%a" "/etc/$u22_cron_checkdir/$u22_cron_dirinfile" | cut -c2)
                    u22_crontab_dirf_other=$(stat -c "%A" "/etc/$u22_cron_checkdir/$u22_cron_dirinfile" | awk '{print substr($1, 8, 3)}')
                    u22_crontab_dirf_owner=$(stat -c "%U" "/etc/$u22_cron_checkdir/$u22_cron_dirinfile")
                    if [[ $u22_crontab_dirf_perm -lt 6 && $u22_crontab_dirf_group -lt 4 ]];then
                        if [[ $u22_crontab_dirf_other == "---" ]];then
                            if [[ $u22_crontab_dirf_owner == "root" ]];then
                                echo "/etc/$u22_cron_checkdir/$u22_cron_dirinfile 파일에 대한 소유자 및 권한 설정이 적절하게 되어 있습니다." >> $target
                            else
                                echo "/etc/$u22_cron_checkdir/$u22_cron_dirinfile 파일에 대한 소유자가 root 소유자가 아닌 $u22_crontab_dirf_perm 설정되어 있어 취약합니다." >> $target
                                u22_safe_check=$((u22_safe_check+1))
                            fi
                        else
                            echo "/etc/$u22_cron_checkdir/$u22_cron_dirinfile 파일에 대한 기타 사용자(Other)에 대한 권한이 $u22_crontab_dirf_other 설정되어 있어 취약합니다." >> $target
                            u22_safe_check=$((u22_safe_check+1))
                        fi
                    else
                        echo "/etc/$u22_cron_checkdir/$u22_cron_dirinfile 파일의 권한이 $u22_crontab_dirf_owner 으로 640 이상으로 설정되어 있으며 기타 사용자(Other)에 대한 권한이 설정되어 있어 취약합니다." >> $target
                        u22_safe_check=$((u22_safe_check+1))
                    fi
                fi
            done
        else
            echo "/etc/$u22_cron_checkdir 디렉터리가 존재하나, 파일은 존재하지 않습니다." >> $target
        fi
    else
        echo "/etc/$u22_cron_checkdir 디렉터리가 존재하지 않습니다." >> $target
    fi
done
for u22_cron_spool in "${u22_cron_spools[@]}";do
    if [ -d "$u22_cron_spool" ];then
        u22_cron_spoolinfiles=($(ls -al $u22_cron_spool | awk '{print $9}' | grep -v "^\." | sed '1d'))
        if [ -n "$u22_cron_spoolinfiles" ];then
            for u22_cron_spoolinfile in "${u22_Cron_spoolinfiles[@]}";do
                if [ -f "$u22_cron_spool/$u22_cron_spoolinfile" ];then
                    u22_crontab_spool_perm=$(stat -c "%a" "$u22_cron_spool/$u22_cron_spoolinfile" | cut -c1)
                    u22_crontab_spool_group=$(stat -c "%a" "$u22_cron_spool/$u22_cron_spoolinfile" | cut -c2)
                    u22_crontab_spool_other=$(stat -c "%A" "$u22_cron_spool/$u22_cron_spoolinfile" | awk '{print substr($1, 8, 3)}')
                    u22_crontab_spool_owner=$(stat -c "%U" "$u22_cron_spool/$u22_cron_spoolinfile")
                    if [[ $u22_crontab_spool_perm -lt 6 && $u22_crontab_spool_group -lt 4 ]];then
                        if [[ $u22_crontab_spool_other == "---" ]];then
                            if [[ $u22_crontab_spool_owner == "root" ]];then
                                echo "$u22_cron_spool/$u22_cron_spoolinfile 파일에 대한 소유자 및 권한 설정이 적절하게 되어 있습니다." >> $target
                            else
                                echo "$u22_cron_spool/$u22_cron_spoolinfile 파일에 대한 소유자가 root 소유자가 아닌 $u22_crontab_spool_perm 설정되어 있어 취약합니다." >> $target
                                u22_safe_check=$((u22_safe_check+1))
                            fi
                        else
                            echo "$u22_cron_spool/$u22_cron_spoolinfile 파일에 대한 기타 사용자(Other)에 대한 권한이 $u22_crontab_spool_other 설정되어 있어 취약합니다." >> $target
                            u22_safe_check=$((u22_safe_check+1))
                        fi
                    else
                        echo "$u22_cron_spool/$u22_cron_spoolinfile 파일의 권한이 $u22_crontab_spool_owner 으로 640 이상으로 설정되어 있으며 기타 사용자(Other)에 대한 권한이 설정되어 있어 취약합니다." >> $target
                        u22_safe_check=$((u22_safe_check+1))
                    fi
                fi
            done
        else
            echo "$u22_cron_spool 디렉터리가 존재하나 파일은 존재하지 않습니다." >> $target
        fi
    else
        echo "$u22_cron_spool 디렉터리가 존재하지 않습니다." >> $target
    fi
done

if [[ $u22_safe_check -ge 1 ]];then
    u22=$((u22+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u22 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u22_Service_Management=1
fi

cat << EOF
===== [U-23] Disabling a Service Vulnerable to DoS Attacks              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-23 DoS 공격에 취약한 서비스 비활성화               " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 시스템 보안성을 높이기 위해 취약점이 많이 발표된 echo, discard, daytime, chargen, ntp, snmp 등 서비스를 중지함" >> $target
echo "+보안위협 :  해당 서비스가 활성화되어 있는 경우 시스템 정보 유출 및 DoS(서비스 거부 공격)의 대상이 될 수 있음" >> $target
echo "+판단기준 양호 : 사용하지 않는 DoS 공격에 취약한 서비스가 비활성화 된 경우" >> $target
echo "+판단기준 취약 : 사용하지 않는 DoS 공격에 취약한 서비스가 활성화 된 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-23 점검 결과" >> $result
# ntp 서비스는 보통 별도의 데몬(ntpd, chronyd)으로 관리됨 (inetd.conf에는 없음)
# snmp 서비스는 별도의 데몬(snmpd)으로 관리됨 (inetd.conf에는 없음)
# dns 서비스는 보통 별도의 데몬(named, systemd-resolved)으로 관리됨 (inetd.conf에는 없음)
# smtp 서비스는 보통 별도의 데몬(postfix, exim, sendmail)으로 관리됨 (inetd.conf에는 없음)

# ntpd 또는 chronyd는 /etc/xinetd.d 파일이 아닌 별도의 데몬으로 관리되며, /etc/xinetd.d에는 항목이 없음 systemctl로 상태를 확인하고 설정할 수 있음
# snmp 는 /etc/xinetd.d 파일이 아닌 별도의 데몬으로 관리되며, /etc/xinetd.d에는 항목이 없음 systemctl로 상태를 확인하고 설정할 수 있음
# named (BIND) 또는 systemd-resolved는 /etc/xinetd.d 파일이 아닌 별도의 데몬으로 관리되며, /etc/xinetd.d에는 항목이 없음. 대신 systemctl로 상태를 확인하고 설정할 수 있음
# (smtp) postfix, exim, 또는 sendmail은 /etc/xinetd.d 파일이 아닌 별도의 데몬으로 관리되며, /etc/xinetd.d에는 항목이 없음. 대신 systemctl로 상태를 확인하고 설정할 수 있음:
u23=0
u23_Service_Management=0
u23_safe_check=0
u23_service_checks=("echo" "discard" "daytime" "chargen" "ntp" "snmp" "tcpmux" "time" "smtp" "domain")
u23_service_ports=("7" "9" "13" "19" "123" "161" "68" "37" "25" "53")
u23_inetd_checks=("echo" "discard" "daytime" "chargen" "tcpmux" "time")
u23_xinetd_checks=("echo" "discard" "daytime" "chargen" "tcpmux" "time")
u23_systemctl_checks=("ntpd" "chronyd" "snmpd" "named" "systemd-resolved" "postfix" "exim" "sendmail")
u23_length=${#u23_service_checks[@]}
# systemctl 서비스 체크
for u23_systemctl_check in "${u23_systemctl_checks[@]}"; do
    if systemctl is-active --quiet "$u23_systemctl_check"; then
        echo "현재 시스템에 $u23_systemctl_check 서비스가 활성화 되어 있습니다. 불필요한 경우 비활성화가 이루어져야 합니다." >> $target
        u23_safe_check=$((u23_safe_check+1))
    else
        echo "현재 시스템에 $u23_systemctl_check 서비스가 비활성화 되어 있습니다." >> $target
    fi
done

# 네트워크 포트 체크
u23_netstat_ports=$(netstat -tuln | awk '{print $4}' | awk -F':' '{print $2}')

for ((i=0; i<$u23_length; i++)); do
    u23_port=${u23_service_ports[$i]}
    u23_service=${u23_service_checks[$i]}
    
    if echo "$u23_netstat_ports" | grep -qE "^$u23_port$"; then
        echo "$u23_service 서비스가 $u23_port 번 포트번호로 서비스가 동작중입니다." >> $target
    else
        u23_newport=$(grep -wE "^$u23_service\s+" /etc/services | awk '{print $2}' | awk -F'/' '{print $1}' | head -n 1)
        if [ -n "$u23_newport" ]; then
            echo "$u23_service 서비스가 $u23_newport 포트번호로 설정되어 있습니다." >> $target
            if echo "$u23_netstat_ports" | grep -qE "^$u23_newport$"; then
                echo "$u23_service 서비스가 $u23_newport 포트번호로 서비스가 동작중입니다." >> $target
                u23_safe_check=$((u23_safe_check+1))
            else
                echo "$u23_service 서비스가 $u23_newport 포트번호로 동작중인 서비스가 없습니다." >> $target
            fi
        else
            echo "$u23_service 서비스가 /etc/services 파일에 정의되어 있지 않습니다." >> $target
        fi
    fi        
done

# inetd 서비스 체크
if [ -f "/etc/inetd.conf" ]; then
    for u23_inetd_check in "${u23_inetd_checks[@]}"; do
        if grep -qiwE "^\s*$u23_inetd_check" /etc/inetd.conf; then
            echo "/etc/inetd.conf 파일에서 $u23_inetd_check 서비스가 활성화 되어 있습니다." >> $target
            u23_safe_check=$((u23_safe_check+1))
        else
            echo "/etc/inetd.conf 파일에서 $u23_inetd_check 서비스가 비활성화 되어 있습니다." >> $target
        fi
    done
else
    echo "/etc/inetd.conf 파일이 존재하지 않습니다." >> $target
fi

# xinetd 서비스 체크
if [ -d "/etc/xinetd.d" ]; then
    for u23_xinetd_check in "${u23_xinetd_checks[@]}"; do
        if [ -f "/etc/xinetd.d/$u23_xinetd_check" ]; then
            u23_xinetd_conf=$(grep -iE "\s*disable" "/etc/xinetd.d/$u23_xinetd_check" | grep -v "^#" | awk '{print $3}' | head -n 1)
            if [[ "$u23_xinetd_conf" == "no" ]]; then
                echo "/etc/xinetd.d/$u23_xinetd_check 파일내에 $u23_xinetd_check 항목이 활성화 되어 있습니다." >> $target
                u23_safe_check=$((u23_safe_check+1))
            else
                echo "/etc/xinetd.d/$u23_xinetd_check 파일내에 $u23_xinetd_check 항목이 비활성화 되어 있습니다." >> $target
            fi
        else
            echo "/etc/xinetd.d/$u23_xinetd_check 파일이 존재하지 않습니다." >> $target
        fi
    done
else
    echo "/etc/xinetd.d 디렉터리가 존재하지 않습니다." >> $target
fi

if [[ $u23_safe_check -ge 1 ]];then
    u23=$((u23+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u23 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u23_Service_Management=1
fi

cat << EOF
===== [U-24] Disable NFS Service              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-24 NFS 서비스 비활성화               " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : NFS(Network File System) 서비스는 한 서버의 파일을 많은 서비스 서버들이 공유하여 사용할 때 많이 이용되는 서비스이지만 이를 이용한 침해사고 위험성이 높으므로 사용하지 않는 경우 중지함" >> $target
echo "+보안위협 : NFS 서비스는 서버의 디스크를 클라이언트와 공유하는 서비스로 적정한 보안설정이 적용되어 있지 않다면 불필요한 파일 공유로 인한 유출위험이 있음" >> $target
echo "+판단기준 양호 : 불필요한 NFS 서비스 관련 데몬이 비활성화 되어 있는 경우" >> $target
echo "+판단기준 취약 : 불필요한 NFS 서비스 관련 데몬이 활성화 되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-24 점검 결과" >> $result
u24=0
u24_Service_Management=0
u24_safe_check=0
u24_nfs_daemons=("nfs" "nfsd" "rpc.mountd" "rpcbind" "statd" "lockd" "nfs-kernel-server")
u24_nfs_ports=("111" "2049")

check_service_status "${u24_nfs_ports}" "${u24_nfs_daemons[@]}"
if [[ $? -eq 1 ]]; then
    echo "nfs 서비스를 사용하고 있습니다." >> $target
    u24_safe_check=$((u24_safe_check+1))
else
    echo "nfs 서비스를 사용하고 있지 않습니다." >> $target
fi

if [[ $u24_safe_check -ge 1 ]];then
    u24=$((u24+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u24 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u24_Service_Management=1
fi

cat << EOF
===== [U-25] NFS access control              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-25 NFS 접근 통제               " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 접근권한이 없는 비인가자의 접근을 통제함" >> $target
echo "+보안위협 : 접근제한 설정이 적절하지 않을 경우 인증절차 없이 비인가자의 디렉터리나 파일의 접근이 가능하며, 해당 공유 시스템에 원격으로 마운트하여 중요 파일을 변조하거나 유출할 위험이 있음" >> $target
echo "+판단기준 양호 : 불필요한 NFS 서비스를 사용하지 않거나, 불가피하게 사용 시 everyone 공유를 제한한 경우" >> $target
echo "+판단기준 취약 : 불필요한 NFS 서비스를 사용하고 있고, everyone 공유를 제한하지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-25 점검 결과" >> $result
u25=0
u25_Service_Management=0
u25_safe_check=0

if [ -f "/etc/exports" ];then
    echo "/etc/exports 파일이 존재합니다" >> $target
    u25_nfsoptions=$(grep -Ev "^\s*#" /etc/exports | grep "*" | awk -F'(' '{print $2}' | sed 's/[\(|\)]//g')
    if [ -n "$u25_nfsoptions" ];then
        echo "NFS 설정 파일 내에  everyone 설정을 통해 모든 사용자가 접근할 수 있도록 설정되어 있습니다." >> $target
        u25_safe_check=$((u25_safe_check+1))
        echo "설정된 값 : $u25_nfsoptions" >> $target
        IFS=',' read -ra u25_nfsoptions_arry <<< "$u25_nfsoptions"
        for u25_nfsoption in "${u25_nfsoptions_arry[@]}";do
            case "$u25_nfsoption" in
                rw)
                    echo "$u25_nfsoption 옵션이 설정되어 읽기/쓰기 모드를 허용합니다." >> $target
                    ;;
                sync)
                    echo "$u25_nfsoption 옵션이 설정되어 데이터를 디스크에 즉시 쓰고 응답합니다." >> $target
                    ;;
                no_root_squash)
                    echo "$u25_nfsoption 옵션이 설정되어 클라이언트의 루트 사용자도 서버에서는 일반 사용자 권한으로 접근하도록 허용됩니다." >> $target
                    ;;  
                no_subtree_check)
                    echo "$u25_nfsoption 옵션이 설정되어 서브트리 검사를 수행하지 않습니다." >> $target
                    ;;
                *)
                    echo "$u25_nfsoption 옵션이 설정되어 있습니다." >> $target
                    ;;
            esac
        done
    else
        echo "/etc/exports 파일은 존재하지만 관련 설정 값이 존재하지 않습니다." >> $target
    fi
else
    echo "/etc/exports 파일이 존재하지 않습니다."  >> $target
fi

if [[ $u25_safe_check -ge 1 ]];then
    u25=$((u25+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u25 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u25_Service_Management=1
fi

cat << EOF
===== [U-26] Remove automountd              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-26 automountd 제거               " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 로컬 공격자가 automountd 데몬에 RPC(Remote Procedure Call)를 보낼 수 있는 취약점이 존재하기 때문에 해당 서비스가 실행중일 경우 서비스를 중지시키기 위함" >> $target
echo "+보안위협 : 파일 시스템의 마운트 옵션을 변경하여 root 권한을 획득할 수 있으며, 로컬 공격자가 automountd 프로세스 권한으로 임의의 명령을 실행할 수 있음" >> $target
echo "+판단기준 양호 : automountd 서비스가 비활성화 되어 있는 경우" >> $target
echo "+판단기준 취약 : automountd 서비스가 활성화 되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-26 점검 결과" >> $result
u26_Service_Management=0
u26_safe_check=0
u26=0
u26_automount_checks=("automoun" "autofs" "automountd") 
u26_ports=("0")

check_service_status "${u26_ports[@]}" "${u26_automount_checks[@]}"
if [ $? -eq 1 ]; then
    echo "automountd 프로토콜만을 사용하고 있습니다." >> $target
    u26_safe_check=$((u26_safe_check+1))
else
    echo "automountd 프로토콜을 사용하지 않고 있습니다." >> $target
fi

cat << EOF
===== [U-26] Remove automountd              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-26 automountd 제거               " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 로컬 공격자가 automountd 데몬에 RPC(Remote Procedure Call)를 보낼 수 있는 취약점이 존재하기 때문에 해당 서비스가 실행중일 경우 서비스를 중지시키기 위함" >> $target
echo "+보안위협 : 파일 시스템의 마운트 옵션을 변경하여 root 권한을 획득할 수 있으며, 로컬 공격자가 automountd 프로세스 권한으로 임의의 명령을 실행할 수 있음" >> $target
echo "+판단기준 양호 : automountd 서비스가 비활성화 되어 있는 경우" >> $target
echo "+판단기준 취약 : automountd 서비스가 활성화 되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u26_Service_Management=0
u26_safe_check=0
u26=0
u26_automount_checks=("automoun" "autofs" "automountd") 
u26_ports=("0")

check_service_status "${u26_ports[@]}" "${u26_automount_checks[@]}"
if [ $? -eq 1 ]; then
    echo "automountd 프로토콜만을 사용하고 있습니다." >> $target
    u26_safe_check=$((u26_safe_check+1))
else
    echo "automountd 프로토콜을 사용하지 않고 있습니다." >> $target
fi

for u26_automount_check in "${u26_automount_checks[@]}";do
    u26_automount_rc=$(find /etc/rc.d/rc*.d/ -type f -name  "$u26_automount_check")
    if [ -n "$u26_automount_rc" ];then
        echo "$u26_automount_rc 시동 스크립트가 식별되었습니다. 삭제 또는 스크립트 이름을 변경하십시오." >> $target
        u26_safe_check=$((u26_safe_check+1))
    else
        echo "/etc/rc.d/rc*.d/ 경로에서 $u26_automount_check 시동 스크립트가 식별되지 않았습니다." >> $target
    fi
done

if [[ $u26_safe_check -ge 1 ]];then
    u26=$((u26+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u26 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u26_Service_Management=1
fi

if [[ $u26_safe_check -ge 1 ]];then
    u26=$((u26+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u26 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u26_Service_Management=1
fi

cat << EOF
===== [U-27] Check RPC service              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-27 RPC 서비스 확인               " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 다양한 취약성(버퍼 오버플로우, Dos, 원격실행 등)이 존재하는 RPC 서비스를 점검하여 해당 서비스를 비활성화 하도록 함" >> $target
echo "+보안위협 : 버퍼 오버플로우(Buffer Overflow), Dos, 원격실행 등의 취약성이 존재하는 RPC 서비스를 통해 비인가자의 root 권한 획득 및 침해사고 발생 위험이 있으므로 서비스를 중지하여야 " >> $target
echo "+판단기준 양호 : 불필요한 RPC 서비스가 비활성화 되어 있는 경우" >> $target
echo "+판단기준 취약 : 불필요한 RPC 서비스가 활성화 되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-27 점검 결과" >> $result
u27=0
u27_Service_Management=0
u27_safe_check=0
u27_services=(
    "rpc.cmsd"
    "rpc.ttdbserverd"
    "sadmind"
    "rusersd"
    "walld"
    "sprayd"
    "rstatd"
    "rpc.nisd"
    "rexd"
    "rpc.pcnfsd"
    "rpc.statd"
    "rpc.ypupdated"
    "rpc.rquotad"
    "kcms_server"
    "cachefsd"
    "rpc.lockd"
    "rpc.mountd"
    "rpc.quotad"
    "rpc.smserverd"
    "rpc.vxid"
    "rpc.ypserv"
    "rpc.yppasswdd"
    "rpc.bootparamd"
)
u27_ports=("111" "512" "150001" "875" "2108" "20048")

check_service_status "${u27_ports}" "${u27_services[@]}"
if [ $? -eq 1 ]; then
    echo "불필요한 RPC 서비스를  사용하고 있습니다." >> $target
    u27_safe_check=$((u27_safe_check+1))
else
    echo "불필요한 RPC 서비스를  사용하지 않고 있습니다." >> $target
fi

if [[ $u27_safe_check -ge 1 ]];then
    u27=$((u27+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u27 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u27_Service_Management=1
fi

cat << EOF
===== [U-28] NIS, NIS+ check              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-28 NIS, NIS+ 점검               " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 안전하지 않은 NIS 서비스를 비활성화 하고 안전한 NIS+ 서비스를 활성화 하여 시스템 보안수준을 향상하고자 함" >> $target
echo "+보안위협 : 보안상 취약한 서비스인 NIS를 사용하는 경우 비인가자가 타시스템의 root 권한 획득이 가능하므로 사용하지 않는 것이 가장 바람직하나 만약 NIS를 사용해야 하는 경우 사용자 정보보안에 많은 문제점을 내포하고 있는 NIS보다 NIS+를 사용하는 것을 권장함 " >> $target
echo "+판단기준 양호 : NIS 서비스가 비활성화 되어 있거나, 필요 시 NIS+를 사용하는 경우" >> $target
echo "+판단기준 취약 : NIS 서비스가 활성화 되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-28 점검 결과" >> $result
u28=0
u28_Service_Management=0
u28_safe_check=0
u28_services=(
    "ypserv"
    "ypbind"
    "ypxfrd"
    "rpc.yppasswdd"
    "rpc.ypupdated"
)
u28_port=("111")

check_service_status "${u28_port[@]}" "${u28_services[@]}"
if [ $? -eq 1 ]; then
    echo "불필요한 RPC 서비스를  사용하고 있습니다." >> $target
    u28_safe_check=$((u28_safe_check+1))
else
    echo "불필요한 RPC 서비스를  사용하지 않고 있습니다." >> $target
fi

for u28_service in "${u28_services[@]}";do
    u28_nic_rc=$(find /etc/rc.d/rc*.d/ -type f -name "*$u28_service*")
    if [ -n "$u28_nic_rc" ];then
        echo "$u28_nic_rc 시동 스크립트가 식별되었습니다. 삭제 또는 스크립트 이름을 변경하십시오." >> $target
        u28=$((u28+1))
    else
        echo "/etc/rc.d/rc*.d/ 경로에서 $u28_service 시동 스크립트가 식별되지 않았습니다." >> $target
    fi
done


if [[ $u28_safe_check -ge 1 ]];then
    u28=$((u28+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u28 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u28_Service_Management=1
fi

cat << EOF
===== [U-29] tftp, talk service disabled              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-29 tftp, talk 서비스 비활성화               " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 안전하지 않거나 불필요한 서비스를 제거함으로써 시스템 보안성 및 리소스의 효율적 운용" >> $target
echo "+보안위협 : 사용하지 않는 서비스나 취약점이 발표된 서비스 운용 시 공격 시도 가능" >> $target
echo "+판단기준 양호 : tftp, talk, ntalk 서비스가 비활성화 되어 있는 경우" >> $target
echo "+판단기준 취약 : tftp, talk, ntalk 서비스가 활성화 되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-29 점검 결과" >> $result
u29=0
u29_Service_Management=0
u29_safe_check=0
u29_services=("tftp" "talk" "ntalk")
u29_ports=("69" "517" "518")

check_service_status "${u29_ports}" "${u29_services[@]}"
if [ $? -eq 1 ]; then
    echo "불필요한 RPC 서비스를  사용하고 있습니다." >> $target
    u29_safe_check=$((u29_safe_check+1))
else
    echo "불필요한 RPC 서비스를  사용하지 않고 있습니다." >> $target
fi

if [[ $u29_safe_check -ge 1 ]];then
    u29=$((u29+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u29 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u29_Service_Management=1
fi

cat << EOF
===== [U-30] Check Sendmail version              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-30 Sendmail 버전 점검               " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : Sendmail 서비스 사용 목적 검토 및 취약점이 없는 버전의 사용 유무 점검으로 최적화된 Sendmail 서비스의 운영" >> $target
echo "+보안위협 : 취약점이 발견된 Sendmail 버전의 경우 버퍼 오버플로우(Buffer Overflow) 공격에 의한 시스템 권한 획득 및 주요 정보 요출 가능성이 있음" >> $target
echo "+판단기준 양호 : Sendmail 버전이 최신버전인 경우" >> $target
echo "+판단기준 취약 : Sendmail 버전이 최신버전이 아닌 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-30 점검 결과" >> $result
u30=0
u30_sendmail_ver=$(sendmail -d0.1 -t < /dev/null | grep -i "version" | awk '{print $2}')
#apt-cache show sendmail | grep Version  :  Debian 에서 최신버전확인
#yum info sendmail | grep Version  :  Red Had 계열에서 최신버전 확인
u30_sendmail_latest=$(yum info sendmail | grep -i Version | awk '{print $3}')
u30_Service_Management=0
u30_safe_check=0

check_service_status "${u30_ports}" "${u30_service[@]}"
if [[ $? -eq 1 ]]; then
    echo "sendmail 서비스를 사용하고 있습니다." >> $target
    if [[ "$u30_sendmail_ver" == "$u30_sendmail_latest" ]]; then
        echo "현재 실행중인 서비스가 최신버전과 동일합니다." >> $target
        echo "현재 설치되어 있는 sendmail 서비스 버전 : $u30_sendmail_ver" >> $target
        echo "최신 sendmail 서비스 버전 : $u30_sendmail_latest" >> $target
    else
        echo "현재 설치되어 있는 sendmail 서비스의 버전이 최신버전과 일치하지 않습니다." >> $target
        echo "현재 설치되어 있는 sendmail 서비스 버전 : $u30_sendmail_ver" >> $target
        echo "최신 sendmail 서비스 버전 : $u30_sendmail_latest" >> $target
        u30_safe_check=$((u30_safe_check+1))
    fi
else
    echo "sendmail 서비스를 사용하고 있지 않습니다." >> $target
    if [[ "$u30_sendmail_ver" == "$u30_sendmail_latest" ]]; then
        echo "현재 실행중인 서비스가 최신버전과 동일합니다." >> $target
        echo "현재 설치되어 있는 sendmail 서비스 버전 : $u30_sendmail_ver" >> $target
        echo "최신 sendmail 서비스 버전 : $u30_sendmail_latest" >> $target
    else
        echo "현재 설치되어 있는 sendmail 서비스의 버전이 최신버전과 일치하지 않습니다." >> $target
        echo "현재 설치되어 있는 sendmail 서비스 버전 : $u30_sendmail_ver" >> $target
        echo "최신 sendmail 서비스 버전 : $u30_sendmail_latest" >> $target
        u30_safe_check=$((u30_safe_check+1))
    fi
fi

if [[ $u30_safe_check -ge 1 ]];then
    u30=$((u30+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u30 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u30_Service_Management=1
fi

cat << EOF
===== [U-31] Spam mail relay restrictions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-31 스팸 메일 릴레이 제한              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 스팸 메일 서버로의 악용방지 및 서버 과부하의 방지를 위함" >> $target
echo "+보안위협 : SMTP 서버의 릴레이 기능을 제한하지 않는 경우, 악의적인 사용목적을 가진 사용자들이 스팸메일 서버로 사용하거나 Dos공격의 대상이 될 수 있음" >> $target
echo "+판단기준 양호 : SMTP 서비스를 사용하지 않거나 릴레이 제한이 설정되어 있는 경우" >> $target
echo "+판단기준 취약 : SMTP 서비스를 사용하며 릴레이 제한이 설정되어 있지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-31 점검 결과" >> $result
u31=0
u31_Service_Management=0
u31_safe_check=0
u31_service=("sendmail" "postfix" "exim" "sendmail.service" "postfix.service" "exim.service")
u31_ports=("25" "465" "587")
u31_logic() {
    if [ -f "/etc/mail/sendmail.cf" ];then
        echo "/etc/mail/sendmail.cf 파일이 존재합니다." >> $target
        if grep -iv "^\s*#" "/etc/mail/sendmail.cf" | grep -iqE 'R\$\*\s*\$:\s*\$1\s*RELAY';then
            echo "모든 조건에서 모든 릴레이를 허용하는 규칙이 정의되어 있습니다." >> $target
            u31_safe_check=$((u31_safe_check+1))
        elif grep -ivE "^\s*#" "/etc/mail/sendmail.cf" | grep -iE 'R\$\s*' | grep -iqE '\$@\s*5\.7\.1|(Relaying|Relay?ing)\s*(denie?d|denied)';then
            echo "릴레이를 제한하는 규칙이 정의되어 있습니다." >> $target
        else
            echo "/etc/mail/sendmail.cf 파일 내에서 모든 조건에서 모든 릴레이를 허용하는 규칙 및 릴레이를 제한하는 규칙이 존재하지 않습니다." >> $target
        fi
    else
        echo "/etc/mail/sendmail.cf 파일이 존재하지 않습니다." >> $target
    fi
    if [ -f "/etc/mail/access" ];then
        echo "/etc/mail/access 파일이 존재합니다." >> $target
        if grep -vE "^\s*#" "/etc/mail/access" | grep -iqE "\s*Connect:ALL\s*RELAY";then
            echo "모든 연결에 대한 릴레이 설정이 존재합니다." >> $target
            u31_safe_check=$((u31_safe_check+1))
        else
            if grep -vE "^\s*#" "/etc/mail/access" | grep -iE "relay$" | awk '{print $1}' | awk -F':' '{print $2}' | grep -ivqE "localhost.localdomain|localhost|127.0.0.1|127|IPv6:::1|IPv6";then
                echo "localhost를 제외한 IP, domain, Email Address에 대한 릴레이 허용 설정값이 존재합니다."  >> $target
            else
                echo "localhost를 제외한 IP, domain, Email Address에 대한 릴레이 허용을 제외한 설정값이 존재하지 않습니다." >> $target
            fi
        fi
    else
        echo "/etc/mail/access 파일이 존재하지 않습니다." >> $target
    fi
}

check_service_status "${u31_ports}" "${u31_service[@]}"
if [[ $? -eq 1 ]]; then
    echo "sendmail 서비스를 사용하고 있습니다." >> $target
    u31_logic
    u31_safe_check=$((u31_safe_check+1))
else
    echo "sendmail 서비스를 사용하고 있지 않습니다." >> $target
    u31_logic
fi

if [[ $u31_safe_check -ge 1 ]];then
    u31=$((u31+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u31 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u31_Service_Management=1
fi


cat << EOF
===== [U-32] Prevent end-user Sendmail execution              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-32 일반사용자의 Sendmail 실행 방지              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 일반사용자의 q 옵션을 제한하여 Sendmail 설정 및 메일큐를 강제적으로 drop 시킬 수 없게 하여 비인가자에 의한 SMTP 서비스 오류 방지" >> $target
echo "+보안위협 : 일반 사용자가 q 옵션을 이용해서 메일큐, Sendmail 설정을 보거나 메일큐를 강제적으로 drop 시킬 수 있어 악의적으로 SMTP 서버의 오류를 발생시킬 수 있음" >> $target
echo "+판단기준 양호 : SMTP 서비스 미사용 또는, 일반 사용자의 Sendmail 실행 방지가 설정된 경우" >> $target
echo "+판단기준 취약 : SMTP 서비스 사용 및 일반 사용자의 Sendmail 실행 방지가 설정되어 있지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-32 점검 결과" >> $result
u32=0
u32_Service_Management=0
u32_safe_check=0
u32_service=("sendmail" "postfix" "exim" "sendmail.service" "postfix.service" "exim.service")
u32_ports=("25" "465" "587")

check_service_status "${u32_ports}" "${u32_service[@]}"
if [[ $? -eq 1 ]]; then
    echo "sendmail 서비스를 사용하고 있습니다." >> $target
    u32_sendmail_conf=$(grep -vE "^\s*#" "/etc/mail/sendmail.cf" | grep -i "PrivacyOptions")
    if grep -vE "^\s*#" "/etc/mail/sendmail.cf" | grep -i "PrivacyOptions" | grep -qi "restrictqrun";then
        echo "메일 큐(queue)에 대한 일반 사용자의 접근을 제한하고 있습니다." >> $target
        echo "현재 설정된 값 : $u32_sendmail_conf" >> $target
    else
        echo "메일 큐(queue)에 대한 일반 사용자의 접근을 제한하고 있지 않습니다." >> $target
        echo "현재 설정된 값 : $u32_sendmail_conf" >> $target
        u32_safe_check=$((u32_safe_check+1))
    fi
    u32_safe_check=$((u32_safe_check+1))
else
    echo "sendmail 서비스를 사용하고 있지 않습니다." >> $target
    u32_sendmail_conf=$(grep -vE "^\s*#" "/etc/mail/sendmail.cf" | grep -i "PrivacyOptions")
    if grep -vE "^\s*#" "/etc/mail/sendmail.cf" | grep -i "PrivacyOptions" | grep -qi "restrictqrun";then
        echo "메일 큐(queue)에 대한 일반 사용자의 접근을 제한하고 있습니다." >> $target
        echo "현재 설정된 값 : $u32_sendmail_conf" >> $target
    else
        echo "메일 큐(queue)에 대한 일반 사용자의 접근을 제한하고 있지 않습니다." >> $target
        echo "현재 설정된 값 : $u32_sendmail_conf" >> $target
        u32_safe_check=$((u32_safe_check+1))
    fi
fi

if [[ $u32_safe_check -ge 1 ]];then
    u32=$((u32+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u32 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u32_Service_Management=1
fi

cat << EOF
===== [U-33] DNS Security Version Patch              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-33 DNS 보안 버전 패치              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 취약점이 발표되지 않은 BIND 버전의 사용을 목적으로 함" >> $target
echo "+보안위협 : 최신버전(2016.01 기준 9.10.3-P2) 이하의 버전에서는 서비스거부 공격, 버퍼오버플로우(Buffer Overflow) 및 DNS 서버 원격 침입 등의 취약성이 존재함" >> $target
echo "+판단기준 양호 : DNS 서비스를 사용하지 않거나 주기적으로 패치를 관리하고 있는 경우" >> $target
echo "+판단기준 취약 : DNS 서비스를 사용하며 주기적으로 패치를 관리하고 있지 않는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-33 점검 결과" >> $result
# Inverse Query 취약점 (Buffer Overflow) : BIND 4.9.7이전 버전과 BIND 8.1.2 이전 버전
# NXT버그 (buffer overflow) : BIND 8.2, 8.2 p1, 8.2.1버전

# solinger버그 (Denial of Service) : BIND 8.1 이상버전
# fdmax 버그 (Denial of Service) : BIND 8.1 이상버전
# Remote Execution of Code(Buffer Overflow) : BIND 4.9.5 to 4.9.10, 8.1, 8.2 to 8.2.6, 8.3.0 to 8.3.3 버전
# Multiple Denial of Service: BIND 8.3.0 - 8.3.3, 8.2 - 8.2.6 버전
# LIBRESOLV: buffer overrun(Buffer Overflow) : BIND 4.9.2 to 4.9.10 버전
# OpenSSL (buffer overflow) : BIND 9.1, BIND 9.2 if built with OpenSSL(configure --with-openssl)
# libbind (buffer overflow) : BIND 4.9.11, 8.2.7, 8.3.4, 9.2.2 이외의 모든 버전
# DoS internal consistency check (Denial of Service) : BIND 9 ~ 9.2.0 버전
# tsig bug (Access possible) : BIND 8.2 ~ 8.2.3 버전
# complain bug (Stack corruption, possible remote access) : BIND 4.9.x 거의 모든 버전
# zxfr bug (Denial of service) : BIND 8.2.2, 8.2.2 patchlevels 1 through 6 버전
# sigdiv0 bug (Denial of service) : BIND 8.2, 8.2 patchlevel 1, 8.2.2 버전
# srv bug(Denial of service): BIND 8.2, 8.2 patchlevel 1, 8.2.1, 8.2.2, 8.2.2 patchlevels 1-6 버전
# nxt bug (Access possible) : BIND 8.2, 8.2 patchlevel 1, 8.2.1 버전

# BIND 4.9.8 이전 버전, 8.2.3 이전 버전과 관련된 취약점
# - TSIG 핸들링 버퍼오버플로우 취약점
# - nslookupComplain() 버퍼오버플로우 취약점
# - nslookupComplain() input validation 취약점
# - information leak 취약점
# - sig bug Denial of service 취약점
# - naptr bug Denial of service 취약점
# - maxdname bug Denial of service 취약점
u33=0
U33_current_ver=$(named -v | awk '{print$2}' | awk -F'-' '{print $1}')
u33_latest_ver=$(yum info bind | grep -i "version" | awk '{print $3}')
u33_Service_Management=0
u33_safe_check=0
u33_services=("named" "dnsmasq" "unbound" "pdns_server" "bind9.service" "pdns_server" "bind9" "dnsmasq.service" "unbound.service" "pdns.service")
u33_ports=("53" "853 " "443")

check_service_status "${u33_ports}" "${u33_services[@]}"
if [[ $? -eq 1 ]]; then
    echo "DNS 서비스를 사용하고 있습니다." >> $target
    if [[ "$u33_current_ver" == "$u33_latest_ver" ]];then
        echo "현재 설치되어 있는 DNS(named) 서비스의 버전이 최신버전과 일치합니다." >> $target
        echo "현재 설치되어 있는 DNS(named) 서비스 버전 : $U33_cuu33_current_verrrent_ver" >> $target
        echo "최신 DNS(named) 서비스 버전 : $u33_latest_ver" >> $target
    else
        echo "현재 설치되어 있는 DNS(named) 서비스의 버전이 최신버전과 일치하지 않습니다." >> $target
        echo "현재 설치되어 있는 DNS(named) 서비스 버전 : $u33_current_ver" >> $target
        echo "최신 DNS(named) 서비스 버전 : $u33_latest_ver" >> $target
        u33_safe_check=$((u33_safe_check+1))
    fi
    u33_safe_check=$((u33_safe_check+1))
else
    echo "DNS 서비스를 사용하고 있지 않습니다." >> $target
    if [[ "$u33_current_ver" == "$u33_latest_ver" ]];then
        echo "현재 설치되어 있는 DNS(named) 서비스의 버전이 최신버전과 일치합니다." >> $target
        echo "현재 설치되어 있는 DNS(named) 서비스 버전 : $U33_cuu33_current_verrrent_ver" >> $target
        echo "최신 DNS(named) 서비스 버전 : $u33_latest_ver" >> $target
        
    else
        echo "현재 설치되어 있는 DNS(named) 서비스의 버전이 최신버전과 일치하지 않습니다." >> $target
        echo "현재 설치되어 있는 DNS(named) 서비스 버전 : $U33_cuu33_current_verrrent_ver" >> $target
        echo "최신 DNS(named) 서비스 버전 : $u33_latest_ver" >> $target
        u33_safe_check=$((u33_safe_check+1))
    fi
fi

if [[ $u33_safe_check -ge 1 ]];then
    u33=$((u33+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u33 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u33_Service_Management=1
fi

cat << EOF
===== [U-34] DNS Area Transfer Settings              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-34 DNS Zone Transfer 설정              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 허가되지 않는 사용자에게 Zone Transfer를 제한함으로써 호스트 정보, 시스템 정보 등 정보 유출의 방지를 목적으로 함" >> $target
echo "+보안위협 : 비인가자 Zone Transfer를 이용해 Zone 정보를 전송받아 호스트 정보, 시스템 정보, 네트워크 구성 형태 등의 많은 정보를 파악할 수 있음" >> $target
echo "+판단기준 양호 : DNS 서비스 미사용 또는, Zone Transfer를 허가된 사용자에게만 허용한 경우" >> $target
echo "+판단기준 취약 : DNS 서비스를 사용하며 Zone Transfer를 모든 사용자에게 허용한 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-34 점검 결과" >> $result
u34=0
u34_Service_Management=0
u34_safe_check=0
u34_services=("named" "dnsmasq" "unbound" "pdns_server" "bind9.service" "pdns_server" "bind9" "dnsmasq.service" "unbound.service" "pdns.service")
u34_ports=("53" "853 " "443")

check_service_status "${u34_ports}" "${u34_services[@]}"
if [[ $? -eq 1 ]]; then
    echo "DNS 서비스를 사용하고 있습니다." >> $target
    if grep -vE "^\s*#" "/etc/named.conf" | grep -qi "allow-transfer";then
        echo "특정 ip에 대해서 Zone Transfer를 허용하도록 설정되어 있습니다." >> $target
        echo "현재 Zone Transfer 설정 값 :$(grep -vE "^\s#" "/etc/named.conf" | grep -i "allow-transfer")" >> $target
    elif grep -vE "^\s*#" "/etc/named.conf" | grep -qi "xfrnets";then
        echo "특정 ip에 대해서 Zone Transfer 허용하도록 설정되어 있습니다." >> $target
        echo "현재 Zone Transfer 설정 값 :$(grep -vE "^\s#" "/etc/named.conf" | grep -i "xfrnets")" >> $target
    else
        echo "allow-transfer 및 xfrnets 옵션이 설정되지 않아 모든 클라이언트가 Zone Transfer를 요청할 수 있습니다" >> $target
        u34_safe_check=$((u34_safe_check+1))
    fi
else
    echo "DNS 서비스를 사용하고 있지 않습니다." >> $target
    if grep -vE "^\s*#" "/etc/named.conf" | grep -qi "allow-transfer";then
        echo "특정 ip에 대해서 Zone Transfer를 허용하도록 설정되어 있습니다." >> $target
        echo "$(grep -vE "^\s*#" "/etc/named.conf" | grep -i "allow-transfer")" >> $target
    elif grep -vE "^\s#" "/etc/named.conf" | grep -qi "xfrnets";then
        echo "특정 ip에 대해서 Zone Transfer 허용하도록 설정되어 있습니다." >> $target
        echo "$(grep -vE "^\s*#" "/etc/named.conf" | grep -i "xfrnets")" >> $target
    else
        echo "allow-transfer 및 xfrnets 옵션이 설정되지 않아 모든 클라이언트가 Zone Transfer를 요청할 수 있습니다" >> $target
        u34_safe_check=$((u34_safe_check+1))
    fi
    echo "DNS(named) 비활성화 되어 있습니다." >> $target
fi

if [[ $u34_safe_check -ge 1 ]];then
    u34=$((u34+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u34 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u34_Service_Management=1
fi

cat << EOF
===== [U-35] Removing a Web Service Directory Listing              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-35 웹서비스 디렉토리 리스팅 제거              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 외부에서 디렉터리 내의 모든 파일에 대한 접근 및 열람을 제한함을 목적으로 함" >> $target
echo "+보안위협 : 디렉터리 검색 기능이 활성화 되어 있을 경우, 사용자에게 디렉터리내 파일이 표시되어 WEB 서버 구조 노출뿐만 아니라 백업 파일이나 소스파일, 공개되어서는 안되는 파일 등이 노출 가능함" >> $target
echo "+판단기준 양호 : 디렉터리 검색 기능을 사용하지 않는 경우" >> $target
echo "+판단기준 취약 : 디렉터리 검색 기능을 사용하는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-35 점검 결과" >> $result
u35=0
u35_Service_Management=0
u35_safe_check=0
u35_apache_files=("/etc/httpd/conf.d/*.conf" "/etc/httpd/sites-available/*.conf" "/etc/httpd/sites-enabled/*.conf")
u35_nginx_files=("/etc/nginx/conf.d/*.conf")
u35_idx=0
u35_idxn=0
u35_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
u35_break=0
echo "※Cent OS 7 기준 Apache 메인 설정파일 경로와 Nginx 메인 설정 파일인 /etc/nginx/nginx.conf를 점검합니다. 해당 경로가 존재하지 않을 경우, 아파치 웹 서비스 구성 파일명을 토대로 파일 탐색 후 점검이 진행됩니다. 중복된 파일명이 존재할 경우 수동 점검을 권장합니다.※"  >> $target
for u35_apache_home_check in "${u35_apache_home_checks[@]}";do
    u35_apache_home=$(find / -type f -name "$u35_apache_home_check" 2> /dev/null | egrep -v "tmp|temp|swap|swp")
    if [ -f "$u35_apache_home" ];then
        echo "$u35_apache_home 파일이 존재합니다." >> $target
        u35_dir_lisconfs_a=($(grep -vE "^\s*#" "$u35_apache_home" | sed -n '/<Directory/,/<\/Directory>/p' | grep -i "^\s*options" | grep -i indexes | awk '{print $1}' ))
        u35_check_dirpath_a=($(grep -vE "^\s*#" "$u35_apache_home" | awk 'BEGIN { inBlock = 0; block = "" }/<Directory/ {block = $0;inBlock = 1;dirPath = $2; gsub("\"", "", dirPath)}/<\/Directory>/ {block = block "\n" $0;inBlock = 0;if (block ~ /Indexes/) { print dirPath }block = ""}inBlock && ! /<\/Directory>/ { block = block "\n" $0 }' | tr -d '>'))
        for u35_dir_lisconf_a in "${u35_dir_lisconfs_a[@]}";do
            if [ -n $u35_dir_lisconf_a ];then
                echo "웹 서비스 디렉토리 리스팅이 활성화 있습니다." >> $target
                echo "디렉토리 리스팅이 활성화된 디렉토리 경로 : ${u35_check_dirpath_a[$u35_idx]}" >> $target
                u35_safe_check=$((u35_safe_check+1))
                u35_idx=$((u35_idx+1))
            else
                echo "웹 서비스 디렉토리 리스팅이 비활성화 되어 있습니다" >> $target
                echo "디렉토리 리스팅이 비활성화된 디렉토리 경로 : ${u35_check_dirpath_a[$u35_idx]}" >> $target
                u35_idxn=$((u35_idxn+1))
            fi
        done
        break
    else
        u35_idx=0
        if [[ $35_break -eq 1 ]];then
            break
        fi
        u35_break=$((u35_break+1))
        for u35_apache_file in "${u35_apache_files[@]}";do
            for u35_apache_check in $u35_apache_file;do
                if [ -f "$u35_apache_check" ];then
                    u35_adected_filecks=$(grep -vE "^\s*#" "$u35_apache_check" | grep -iw "options" | grep -iw "indexes" | grep -iwv "\-indexes" )
                    for u35_adected_fileck in "${u35_adected_filecks[@]}";do
                        if [[ -n "$u35_adected_fileck" ]];then
                            echo "$u35_apache_check 파일에서 디렉토리 리스팅을 허용하는 indexes 설정값이 존재합니다." >> $target
                            echo "디렉토리 리스팅이 활성화된 디렉토리 경로 : ${u35_check_dirpath_a[$u35_idx]}" >> $target
                            u35_safe_check=$((u35_safe_check+1))
                            u35_idx=$((u35_idx+1))
                        else
                            echo "$u35_apache_check 파일은 존재하지만 디렉토리 리스팅을 허용하는 indexes 설정값이 존재하지 않습니다." >> $target
                            u35_idxn=$((u35_idxn+1))
                        fi
                    done
                fi
            done
        done
        u35_idx=0
    fi
done
echo "추가적인 Apache 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
u35_idx=0
u35_idxn=0
if [ -f "/etc/nginx/nginx.conf" ];then
    echo "/etc/nginx/nginx.conf 파일이 존재합니다." >> $target
    u35_dir_lisconfs_n=($(grep -vE "^\s*#" "/etc/nginx/nginx.conf" | grep -iw "^\s*autoindex" | sed 's/^[ \t]*//' | awk '{print tolower($2)}' | tr -d ';'))
    for u35_dir_lisconf_n in "${u35_dir_lisconfs_n[@]}";do
        if [[ $u35_dir_lisconf_n == "on" ]];then
            u35_safe_check=$((u35_safe_check+1))
            u35_idx=$((u35_idx+1))
        else
            u35_idxn=$((u35_idxn+1))
        fi
    done
    echo "웹 서비스 디렉토리 리스팅이 활성화 있습니다." >> $target
    echo "설정 값 : $u35_dir_lisconf_n" >> $target
    echo "총 $u35_idx 개의 취약한 on 설정이 존재합니다. /etc/nginx/nginx.conf 파일을 확인하십시오." >> $target
    echo "웹 서비스 디렉토리 리스팅이 비활성화된 $u35_idxn 개의 안전한  off 설정이 존재 합니다. /etc/nginx/nginx.conf 파일을 확인하십시오." >> $target
else 
    echo "/etc/nginx/nginx.conf 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> $target
    for u35_ngnix_file in ${u35_nginx_files[@]};do
        for u35_nginx_check in $u35_ngnix_file;do
            u35_dir_lisconfs_n=($(grep -vE "^\s*#" "$u35_nginx_check" 2> /dev/null | grep -iw "^\s*autoindex" | sed 's/^[ \t]*//' | awk '{print tolower($2)}' | tr -d ';'))
            if [ -f "$u35_nginx_check" ];then
                #u35_ndected_filecks=$(grep -vE "^\s*#" "$u35_nginx_check" | grep -iw "autoindex" | tr -d ';' | grep -iw "on")
                for u35_dir_lisconf_n in "${u35_dir_lisconfs_n[@]}";do
                    if [ -n "$u35_dir_lisconf_n" ];then
                        if [ "$u35_dir_lisconf_n" == "on" ];then
                            u35_safe_check=$((u35_safe_check+1))
                            u35_idx=$((u35_idx+1))
                        else
                            u35_idxn=$((u35_idxn+1))
                        fi
                    else
                        echo "$u35_nginx_check 파일은 존재하지만 디렉토리 리스팅을 허용하는 autoindex 설정값이 존재하지 않습니다." >> $target
                        u35_idxn=$((u35_idxn+1))
                    fi
                done
                if [[ $u35_idx -ge 1 ]];then
                    echo "$u35_nginx_check 파일에서 디렉토리 리스팅이 허용되어 있습니다." >> $target
                    echo "설정 값 : $u35_dir_lisconf_n" >> $target
                    echo "총 $u35_idx 개의 취약한 on 설정이 존재합니다. $u35_nginx_check 파일을 확인하십시오." >> $target
                    echo "웹 서비스 디렉토리 리스팅이 비활성화된 $u35_idxn 개의 안전한  off 설정이 존재 합니다. $u35_nginx_check 파일을 확인하십시오." >> $target
                fi
            fi
        done
    done
    echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
fi
if [[ $u35_safe_check -ge 1 ]];then
    u35=$((u35+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u35 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u35_Service_Management=1
fi
cat << EOF
===== [U-36] Restrict Web Services Web Process Permissions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-36 웹서비스 웹 프로세스 권한 제한              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : Apache 데몬을 root 권한으로 구동하지 않고 별도의 권한으로 구동함으로써 침해사고 발생 시 피해범위 확산 방지를 목적으로 함" >> $target
echo "+보안위협 : 웹서비스 데몬을 root 권한으로 실행시 웹서비스가 파일을 생성, 수정하는 과정에서 웹서비스에 해당하지 않는 파일도 root 권한에 의해 쓰기가 가능하며 해킹 발생시 root 권한이 노출 될 수 있음" >> $target
echo "+판단기준 양호 : Apache 데몬이 root 권한으로 구동되지 않는 경우" >> $target
echo "+판단기준 취약 : Apache 데몬이 root 권한으로 구동되는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-36 점검 결과" >> $result
u36=0
u36_safe_check=0
u36_Service_Management=0
u36_break=0
u36_apache_files=("/etc/httpd/conf.d/*.conf" "/etc/httpd/sites-available/*.conf" "/etc/httpd/sites-enabled/*.conf")
u36_nginx_files=("/etc/nginx/conf.d/*.conf")
u36_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
echo "※Cent OS 7 기준 Apache 메인 설정파일 경로와 Nginx 메인 설정 파일인 /etc/nginx/nginx.conf를 점검합니다. 해당 경로가 존재하지 않을 경우, 아파치 웹 서비스 구성 파일명을 토대로 파일 탐색 후 점검이 진행됩니다. 중복된 파일명이 존재할 경우 수동 점검을 권장합니다.※"  >> $target
for u36_apache_home_check in "${u36_apache_home_checks[@]}";do
    u36_apache_home=$(find / -type f -name "$u36_apache_home_check" 2> /dev/null | egrep -v "tmp|temp|swap|swp")
    if [ -f "$u36_apache_home" ];then
        echo "$u36_apache_home 파일이 존재합니다." >> $target
        u36_apache_user=$(grep -vE "^\s*#" "$u36_apache_home" | grep -wiE "^\s*user" | awk '{print tolower($2)}')
        u36_apache_group=$(grep -vE "^\s*#" "$u36_apache_home" | grep -wiE "^\s*group" | awk '{print tolower($2)}')
        if [ -n "$u36_apache_user" ] || [ -n "$u36_apache_group" ];then
            if [ "$u36_apache_user" == "www-data" ] || [ "$u36_apache_user" == "apache" ];then
                echo "Apache 웹 서비스 설정파일의 User 권한이 www-data 혹은 apache로 적절하게 설정되어 있습니다." >> $target
                if [ "$u36_apache_group" == "www-data" ] || [ "$u36_apache_group" == "apache" ];then
                    echo "Apache 웹 서비스 설정파일의 Group 권한이 www-data 혹은 apache로 적절하게 설정되어 있습니다." >> $target
                else
                    if [ "$u36_apache_group" == "root" ];then
                        echo "Apache 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> $target
                        u35_safe_check=$((u35_safe_check+1))
                    else
                        echo "Apache 웹 서비스 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> $target
                    fi
                fi
            else
                if [[ "$u36_apache_user" == "root" ]];then
                    echo "Apache 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> $target
                    u35_safe_check=$((u35_safe_check+1))
                else
                    echo "Apache 웹 서비스 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> $target
                    if [ "$u36_apache_group" == "www-data" ] || [ "$u36_apache_group" == "apache" ];then
                        echo "Apache 웹 서비스 설정파일의 Group 권한이 wwww-data 혹은 apache로 적절하게 설정되어 있습니다." >> $target
                    else
                        if [ "$u36_apache_group" == "root" ];then
                            echo "Apache 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> $target
                        else
                            echo "Apache 웹 서비스 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> $target
                        fi
                    fi
                fi
            fi
        else
            echo "$u36_apache_home 파일은 존재하지만, User 및 Group 설정 옵션이 존재하지 않습니다." >> $target
        fi
    else 
        if [ $u36_break -eq 1 ];then
            break
        fi
        for u36_apache_file in "${u36_apache_files[@]}";do
            for u36_apache_check in $u36_apache_file;do
                if [ -f "$u36_apache_check" ];then
                    echo "$u36_apache_check 파일이 존재합니다." >> $target
                    u36_apache_user=$(grep -vE "^\s*#" "$u36_apache_check" | grep -wiE "^\s*user" | awk '{print tolower($2)}')
                    u36_apache_group=$(grep -vE "^\s*#" "$u36_apache_check" | grep -wiE "^\s*group" | awk '{print tolower($2)}')
                    if [ -n "$u36_apache_user" ] || [ -n "$u36_apache_group" ];then
                        if [ "$u36_apache_user" == "www-data" ] || [ "$u36_apache_user" == "apache" ];then
                            echo "$u36_apache_check 설정파일의 User 권한이 www-data 혹은 apache로 적절하게 설정되어 있습니다." >> $target
                            if [ "$u36_apache_group" == "www-data" ] || [ "$u36_apache_group" == "apache" ];then
                                echo "$u36_apache_check 설정파일의 Group 권한이 www-data 혹은 apache로 적절하게 설정되어 있습니다." >> $target
                            else
                                if [ "$u36_apache_group" == "root" ];then
                                    echo "$u36_apache_check 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> $target
                                    u35_safe_check=$((u35_safe_check+1))
                                else
                                    echo "$u36_apache_check 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> $target
                                fi
                            fi
                        else
                            if [[ "$u36_apache_user" == "root" ]];then
                                echo "$u36_apache_check 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> $target
                                u35_safe_check=$((u35_safe_check+1))
                            else
                                echo "$u36_apache_check 설정파일의 User 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> $target
                                if [ "$u36_apache_group" == "www-data" ] || [ "$u36_apache_group" == "apache" ];then
                                    echo "$u36_apache_check 설정파일의 Group 권한이 wwww-data 혹은 apache로 적절하게 설정되어 있습니다." >> $target
                                else
                                    if [ "$u36_apache_group" == "root" ];then
                                        echo "$u36_apache_check 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> $target
                                        u35_safe_check=$((u35_safe_check+1))
                                    else
                                        echo "$u36_apache_check 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> $target
                                    fi
                                fi
                            fi
                        fi
                    else
                        echo "$u36_apache_check 파일은 존재하지만, User 및 Group 설정 옵션이 존재하지 않습니다." >> $target
                    fi
                fi
            done
        done
        echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
    fi
done

if [ -f "/etc/nginx/nginx.conf" ];then
    echo "/etc/nginx/nginx.conf 파일이 존재합니다." >> $target
    u36_nginx_user=$(grep -vE "^\s*#" "/etc/nginx/nginx.conf" | grep -wiE "^\s*user" | awk '{print tolower($2)}')
    u36_nginx_group=$(grep -vE "^\s*#" "/etc/nginx/nginx.conf" | grep -wiE "^\s*user" | awk '{print tolower($3)}')
    if [ -n "$u36_nginx_user" ] || [ -n "$u36_nginx_group" ];then
        if [ "$u36_nginx_user" == "www-data" ] || [ "$u36_nginx_user" == "nginx" ];then
            echo "Nginx 웹 서비스 설정파일의 User 권한이 www-data 혹은 nginx로 적절하게 설정되어 있습니다." >> $target
            if [ "$u36_nginx_group" == "www-data" ] || [ "$u36_nginx_group" == "nginx" ];then
                echo "Nginx 웹 서비스 설정파일의 Group 권한이 www-data 혹은 nginx로 적절하게 설정되어 있습니다." >> $target
            else
                if [[ "$u36_nginx_group" == "root" ]];then
                    echo "Nginx 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> $target
                    u35_safe_check=$((u35_safe_check+1))
                else
                    echo "Nginx 웹 서비스 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> $target
                fi
            fi
        else
            if [[ "$u36_nginx_user" == "root" ]];then
                echo "Nginx 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> $target
                u35_safe_check=$((u35_safe_check+1))
            else
                echo "Nginx 웹 서비스 설정파일의 User 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> $target
                if [ "$u36_nginx_group" == "www-data" ] || [ "$u36_nginx_group" == "nginx" ];then
                    echo "Nginx 웹 서비스 설정파일의 Group 권한이 wwww-data 혹은 apache로 적절하게 설정되어 있습니다." >> $target
                else
                    if [ "$u36_nginx_group" == "root" ];then
                        echo "Nginx 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> $target
                        u35_safe_check=$((u35_safe_check+1))
                    else
                        echo "Nginx 웹 서비스 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> $target
                    fi
                fi
            fi
        fi
    else
        echo "/etc/nginx/nginx.conf 파일은 존재하지만, User 및 Group 설정 옵션이 존재하지 않습니다." >> $target
    fi
else 
    echo "/etc/nginx/nginx.conf 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> $target
    for u36_ngnix_file in "${u36_nginx_files[@]}";do
        for u36_nginx_check in $u36_ngnix_file;do
            if [ -f "$u36_nginx_check" ];then
                echo "$u36_nginx_check 파일이 존재합니다." >> $target
                u36_nginx_user=$(grep -vE "^\s*#" "$u36_nginx_check" | grep -wiE "^\s*user" | awk '{print $2}')
                u36_nginx_group=$(grep -vE "^\s*#" "$u36_nginx_check" | grep -wiE "^\s*user" | awk '{print $3}')
                if [ -n "$u36_nginx_user" ] || [ -n "$u36_nginx_group" ];then
                    if [ "$u36_nginx_user" == "www-data" ] || [ "$u36_nginx_user" == "nginx" ];then
                        echo "Nginx 웹 서비스 설정파일의 User 권한이 www-data 혹은 nginx로 적절하게 설정되어 있습니다." >> $target
                        if [ "$u36_nginx_group" == "www-data" ] || [ "$u36_nginx_group" == "nginx" ];then
                            echo "Nginx 웹 서비스 설정파일의 Group 권한이 www-data 혹은 nginx로 적절하게 설정되어 있습니다." >> $target
                        else
                            if [[ "$u36_nginx_group" == "root" ]];then
                                echo "Nginx 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> $target
                                u35_safe_check=$((u35_safe_check+1))
                            else
                                echo "Nginx 웹 서비스 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> $target
                            fi
                        fi
                    else
                        if [[ "$u36_nginx_user" == "root" ]];then
                            echo "Nginx 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> $target
                            u35_safe_check=$((u35_safe_check+1))
                        else
                            echo "Nginx 웹 서비스 설정파일의 User 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> $target
                            if [ "$u36_nginx_group" == "www-data" ] || [ "$u36_nginx_group" == "nginx" ];then
                                echo "Nginx 웹 서비스 설정파일의 Group 권한이 wwww-data 혹은 apache로 적절하게 설정되어 있습니다." >> $target
                            else
                                if [ "$u36_nginx_group" == "root" ];then
                                    echo "Nginx 웹 서비스 설정파일의 Group 권한이 root 계정으로 부적절하게 설정되어 있습니다." >> $target
                                    u35_safe_check=$((u35_safe_check+1))
                                else
                                    echo "Nginx 웹 서비스 설정파일의 Group 권한이 없거나 root 를 제외한 별도의 계정으로 적절하게 설정되어 있습니다." >> $target
                                fi
                            fi
                        fi
                    fi
                else
                    echo "$u36_nginx_check 파일은 존재하지만, User 및 Group 설정 옵션이 존재하지 않습니다." >> $target
                fi
            fi
        done
    done
    echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
fi

if [[ $u36_safe_check -ge 1 ]];then
    u36=$((u36+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u36 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u36_Service_Management=1
fi

cat << EOF
===== [U-37] Do not access the web service parent directory              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-37 웹서비스 상위 디렉토리 접근 금지              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 상위 경로 이동 명령으로 비인가자의 특정 디렉터리에 대한 접근 및 열람을 제한하여 중요 파일 및 데이터 보호를 목적으로 함" >> $target
echo "+보안위협 : 상위 경로로 이동하는 것이 가능할 경우 접근하고자 하는 디렉터리의 하위 경로에 접속하여 상위경로로 이동함으로써 악의적인 목적을 가진 사용자의 접근이 가능함" >> $target
echo "+판단기준 양호 : 상위 디렉터리에 이동제한을 설정한 경우" >> $target
echo "+판단기준 취약 : 상위 디렉터리에 이동제한을 설정하지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-37 점검 결과" >> $result
u37=0
u37_safe_check=0
u37_Service_Management=0
u37_apache_files=("/etc/apache2/conf-available/*.conf" "/etc/apache2/sites-available/*.conf" "/etc/apache2/sites-enabled/*.conf")
u37_nginx_files=("/etc/nginx/conf.d/*.conf" "/etc/nginx/sites-available/*.conf" "/etc/nginx/sites-enabled/*.conf")
u37_idx=0
u37_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
u37_break=0
echo "※Cent OS 7 기준 Apache 메인 설정파일 경로와 Nginx 메인 설정 파일인 /etc/nginx/nginx.conf를 점검합니다. 해당 경로가 존재하지 않을 경우, 아파치 웹 서비스 구성 파일명을 토대로 파일 탐색 후 점검이 진행됩니다. 중복된 파일명이 존재할 경우 수동 점검을 권장합니다.※"  >> $target
echo "apache, nginx 의 주요 설정파일을 토대로 apache 홈 디렉터리 점검 후 추가 설정 파일 및 디렉터리를 점검하므로, 중복된 결과가 존재할 수 있습니다." >> $target
for u37_apache_home_check in "${u37_apache_home_checks[@]}";do
    u37_apache_home=$(find / -type f -name "$u37_apache_home_check" 2> /dev/null | egrep -v "tmp|temp|swap|swp")
    if [ -f "$u37_apache_home" ];then
        echo "$u37_apache_home 파일이 존재합니다." >> $target
        u37_dir_pathconfs_a=($(grep -vE "^\s*#" "$u37_apache_home" | sed -n '/<Directory/,/<\/Directory>/p' | grep -i "^\s*AllowOverride" | awk '{print tolower($2)}'))
        u37_check_dirpath_a=($(grep -vE "^\s*#" "$u37_apache_home" | awk 'BEGIN { inBlock = 0; block = "" }/<Directory/ {block = $0;inBlock = 1;dirPath = $2; gsub("\"", "", dirPath)}/<\/Directory>/ {block = block "\n" $0;inBlock = 0;if (block ~ /AllowOverride/) { print dirPath }block = ""}inBlock && ! /<\/Directory>/ { block = block "\n" $0 }' | tr -d '>'))
        for u37_dir_pathconf_a in "${u37_dir_pathconfs_a[@]}";do
            if [ -n "$u37_dir_pathconf_a" ];then
                if [[ "$u37_dir_pathconf_a" == "none" ]];then
                    echo "AllowOverride 지시자의 옵션이 $u37_dir_pathconf_a 로 설정되어 상위 디렉토리로의 접근을 허용하고 있습니다." >> $target
                    #u37_result=$(grep -vE "^\s*#" "/etc/httpd/conf/httpd.conf" | awk 'BEGIN { IGNORECASE = 1 }/<Directory/ { block = $0; inBlock = 1 }/<\/Directory>/ { block = block "\n" $0; inBlock = 0; if (block ~ /AllowOverride\s+all/) { print block; block="" } }inBlock && !/<\/Directory>/ { block = block "\n" $0 }' | sed '1d')
                    #echo "$u37_result"
                    echo "$u37_dir_pathconf_a 로 설정된 경로 : ${u37_check_dirpath_a[$u37_idx]}"   >> $target
                    u37_safe_check=$((u37_safe_check+1))
                    u37_idx=$((u37_idx+1))
                elif [ "$u37_dir_pathconf_a" == "authconfig" ] || [ "$u37_dir_pathconf_a" == "all" ];then
                    echo "AllowOverride 지시자의 옵션이 $u37_dir_pathconf_a 로 설정되어 상위 디렉토리로의 접근을 거부하고 있습니다." >> $target
                    echo "$u37_dir_pathconf_a 로 설정된 경로 : ${u37_check_dirpath_a[$u37_idx]}" >> $target
                    u37_idx=$((u37_idx+1))
                else
                    echo "AllowOverride 지시자의 옵션이 $u37_dir_pathconf_a 로 설정되어 있습니다. 관리자와의 상의바랍니다." >> $target
                fi
            else
                echo "$u37_apache_home 파일이 존재하지만, 설정값이 존재하지 않습니다."
            fi
        done
        break
    else 
        u37_idx=0
        if [ $u37_break -eq 1 ];then
            continue
        fi
        u37_break=$((u37_break+1))
        echo "$u37_apache_home_check 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> $target
        for u37_apache_file in "${u37_apache_files[@]}";do
            for u37_apache_check in $u37_apache_file;do
                if [ -f "$u37_apache_check" ];then
                    echo "$u37_apache_check 파일이 존재합니다." >> $target
                    u37_dir_pathconfs=($(grep -vE "^\s*#" "$u37_apache_check" | sed -n '/<Directory/,/<\/Directory>/p' | grep -i "^\s*AllowOverride" | awk '{print tolower($2)}'))
                    u37_check_dirpath=($(grep -vE "^\s*#" "$u37_apache_check" | awk 'BEGIN { inBlock = 0; block = "" }/<Directory/ {block = $0;inBlock = 1;dirPath = $2; gsub("\"", "", dirPath)}/<\/Directory>/ {block = block "\n" $0;inBlock = 0;if (block ~ /AllowOverride/) { print dirPath }block = ""}inBlock && ! /<\/Directory>/ { block = block "\n" $0 }' | tr -d '>'))
                    if [ ${#u37_dir_pathconfs[@]} -gt 0 ];then
                        for u37_dir_pathconf in "${u37_dir_pathconfs[@]}";do
                            if [[ "$u37_dir_pathconf" == "none" ]];then
                                echo "$u37_apache_check 파일은 존재하지만, AllowOverride 지시자의 옵션이 $u37_dir_pathconf 로 설정되어 상위 디렉토리로의 접근을 허용하고 있습니다." >> $target
                                #u37_result=$(grep -vE "^\s*#" "$u37_apache_check" | awk 'BEGIN { IGNORECASE = 1 }/<Directory/ { block = $0; inBlock = 1 }/<\/Directory>/ { block = block "\n" $0; inBlock = 0; if (block ~ /AllowOverride\s+all/) { print block; block="" } }inBlock && !/<\/Directory>/ { block = block "\n" $0 }' | sed '1d')
                                #echo "$u37_result"
                                echo "$u37_dir_pathconf 로 설정된 경로 : ${u37_check_dirpath[$u37_idx]}"   >> $target
                                u37_safe_check=$((u37_safe_check+1))
                                u37_idx=$((u37_idx+1))
                            elif [ "$u37_dir_pathconf" == "authconfig" ] || [ "$u37_dir_pathconf" == "all" ];then
                                echo "AllowOverride 지시자의 옵션이 $u37_dir_pathconf 로 설정되어 상위 디렉토리로의 접근을 거부하고 있습니다." >> $target
                                #u37_result=$(grep -vE "^\s*#" "$u37_apache_check" | awk 'BEGIN { IGNORECASE = 1 }/<Directory/ { block = $0; inBlock = 1 }/<\/Directory>/ { block = block "\n" $0; inBlock = 0; if (block ~ /AllowOverride\s+all/) { print block; block="" } }inBlock && !/<\/Directory>/ { block = block "\n" $0 }' | sed '1d')
                                #echo "$u37_result"
                                echo "$u37_dir_pathconf 로 설정된 경로 : ${u37_check_dirpath[$u37_idx]}" >> $target
                                u37_idx=$((u37_idx+1))
                            else
                                echo "$u37_apache_check 파일이 존재하며, AllowOverride 지시자의 옵션이 $u37_dir_pathconf 로 설정되어 있습니다. 관리자와의 상의바랍니다." >> $target
                            fi
                        done
                    else
                        echo "$u37_apache_check 파일은 존재하지만, 관련 설정값이 존재하지 않습니다." >> $target
                    fi
                fi
            done
        done
        echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
        u37_idx=0
    fi
done
u37_idx=0
if [ -f "/etc/nginx/nginx.conf" ];then
    echo "/etc/nginx/nginx.conf 파일이 존재합니다." >> $target
    u37_dir_pathconfs_n=($(cat /etc/nginx/nginx.conf | sed -n '/location ~\* \/\\.\\. /,/}/p' | grep -i 'deny' | awk '{print $2}' | tr -d ';'))
    if [ -n "$u37_dir_pathconfs_n" ];then
        for u37_dir_pathconf_n in "${u37_dir_pathconfs_n[@]}";do
            if [[ "$u37_dir_pathconf_n" == "all" ]];then 
                echo "/etc/nginx/nginx.conf 파일에서 상위 디렉토리로의 접근 제한 설정 deny 값이 all로 적절하게 설정되어 있습니다." >> $target
                u37_idx=$((u37_idx+1))
            else
                echo "/etc/nginx/nginx.conf 파일에서 상위 디렉토리로의 접근 제한 설정 deny 값이 all로 설정되어 있지 않습니다." >> $target
                u37_safe_check=$((u37_safe_check+1))
            fi
        done
        if [[ $u37_idx -ge 1 ]];then
            echo "/etc/nginx/nginx.conf 파일에서 상위 디렉토리로의 이동이 허용되어 있습니다." >> $target
            echo "설정 값 : $u37_dir_pathconf_n" >> $target
            echo "총 $u37_idx 개의 취약한 all 설정이 존재합니다. /etc/nginx/nginx.conf 파일을 확인하십시오." >> $target
        else
            echo "/etc/nginx/nginx.conf 파일에서 상위 디렉토리로의 이동이 허용되어 있지 않습니다." >> $target
        fi
    else
        echo "/etc/nginx/nginx.conf 파일은 존재하지만, 상위 디렉토리의 접근을 제한하는 설정값이 존재하지 않습니다." >> $target
    fi
else 
    echo "/etc/nginx/nginx.conf 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> $target
    for u37_ngnix_file in "${u37_nginx_files[@]}";do
        for u37_nginx_check in $u37_ngnix_file;do 
            if [ -f "$u37_nginx_check" ];then
                echo "$u37_nginx_check 파일이 존재합니다." >> $target
                u37_dir_pathconfs_n=($(cat "$u37_nginx_check" | sed -n '/location ~\* \/\\.\\. /,/}/p' | grep -i 'deny' | awk '{print $2}' | tr -d ';'))
                if [ ${#u37_dir_pathconfs_n[@]} -gt 0 ];then
                    for u37_dir_pathconf_n in "${u37_dir_pathconfs_n[@]}";do
                        if [[ "$u37_dir_pathconf_n" == "all" ]];then
                            echo "/etc/nginx/nginx.conf 파일에서 상위 디렉토리로의 접근 제한 설정 deny 값이 all로 적절하게 설정되어 있습니다." >> $target
                            u37_idx=$((u37_idx+1))
                        else
                            echo "$u37_nginx_check 파일은 존재하나, 상위 디렉토리로의 이동이 제한 설정값이 deny all로 설정되어 있지 않습니다." >> $target
                            u37_safe_check=$((u37_safe_check+1))
                        fi
                    done
                else
                    echo echo "$u37_nginx_check 파일은 존재하나, 상위 디렉토리로의 이동이 제한 설정이 존재하지 않습니다." >> $target
                fi
                if [[ $u37_idx -ge 1 ]];then
                    echo "$u37_nginx_check 파일에서 상위 디렉토리로의 이동이 허용되어 있습니다." >> $target
                    echo "설정 값 : $u37_dir_pathconf_n" >> $target
                    echo "총 $u37_idx 개의 취약한 all 설정이 존재합니다. $u37_nginx_check 파일을 확인하십시오." >> $target
                fi
            fi
        done
    done
    echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
fi

if [[ $u37_safe_check -ge 1 ]];then
    u37=$((u37+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u37 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u37_Service_Management=1
fi


cat << EOF
===== [U-38] Remove unnecessary Web Services files              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-38 웹서비스 불필요한 파일 제거              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : Apache 설치 시 디폴트로 설치되는 불필요한 파일을 제거함을 목적으로 함" >> $target
echo "+보안위협 : Apache 설치 시 htdocs 디렉터리 내에 매뉴얼 파일은 시스템 관련정보를 노출하거나 해킹에 악용될 수 있음" >> $target
echo "+판단기준 양호 : 기본으로 생성되는 불필요한 파일 및 디렉터리가 제거되어 있는 경우" >> $target
echo "+판단기준 취약 : 기본으로 생성되는 불필요한 파일 및 디렉터리가 제거되지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-38 점검 결과" >> $result
u38=0
u38_safe_check=0
u38_Service_Management=0
echo "Apache 및 Nginx 에 대해 설치 시 디폴트로 설치되는 불필요한 파일을 탐색합니다." >> $target
u38_unnecessary_dirs=("/usr/share/doc/httpd/" "/usr/share/httpd/" "/usr/share/doc/apache2" "/usr/share/examples/apache2" "/etc/httpd/conf/htdocs/manual" "/etc/httpd/conf/manual" "/var/www/error/" "/var/www/icons/" "/var/www/cgi-bin/" "/usr/share/doc/nginx/" "/usr/share/nginx/modules/" "/usr/share/nginx/html/" "/usr/share/examples/nginx")
u38_unnecessary_files=("/etc/apache2/sites-available/000-default.conf" "/usr/share/man/man8/httpd.8.gz" "/etc/httpd/conf.d/welcome.conf" "/etc/httpd/conf.d/autoindex.conf" "/var/www/html/index.html" "/var/www/html/favicon.ico" "/etc/httpd/conf.d/welcome.conf" "/usr/share/man/man1/apache2.1.gz""/usr/share/nginx/html/index.html" "/usr/share/nginx/html/50x.html" "/usr/share/nginx/html/favicon.ico" "/etc/nginx/conf.d/default.conf" "/usr/share/man/man1/nginx.1.gz" "/usr/share/man/man8/nginx.8.gz")
u38_unnecessary_files_sample=("/var/www/html/*.png" "/var/www/html/*.gif")
u38_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
u38_idx=0
#/etc/nginx/sites-available/default -> debian 
# /etc/httpd/conf.d/welcome.conf -> REHL
echo "apache, nginx 의 주요 설정파일을 토대로 apache 홈 디렉터리 점검 후 추가 설정 파일 및 디렉터리를 점검하므로, 중복된 결과가 존재할 수 있습니다." >> $target
for u38_apache_home_check in "${u38_apache_home_checks[@]}";do
    u38_apache_home=$(find / -type f -name "$u38_apache_home_check" 2> /dev/null | egrep -v "tmp|temp|swap|swp")
    if [ -f "$u38_apache_home" ];then
        u38_documentroot=$(grep -i 'documentroot' "$u38_apache_home" | grep -v "#" | awk '{print $2}' | tr -d '"')
        if [ -n "$u38_documentroot" ];then
            u38_unnecessary_apache_home=$(ls -d "$u38_documentroot/htdocs/manual" 2> /dev/null)
            if [ -d "$u38_unnecessary_apache_home" ];then
                echo "$u38_unnecessary_apache_home 경로가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                u38_safe_check=$((u38_safe_check+1))
                for u38_unnecessary_apache_file in "$u38_unnecessary_apache_home/*";do
                    if [ -f "$u38_unnecessary_apache_file" ];then
                        echo "$u38_unnecessary_apache_file 파일이 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                        u38_safe_check=$((u38_safe_check+1))
                    elif [ -d "$u38_unnecessary_apache_file" ];then
                        echo "$u38_unnecessary_apache_file 디렉터리가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                        u38_safe_check=$((u38_safe_check+1))
                        echo "$u38_unnecessary_apache_file 디렉터리를 재귀적으로 탐색합니다." >> $target
                        echo "$(tree $u38_unnecessary_apache_file)" >> $target
                    else
                        u38_idx=$((u38_idx+1))
                    fi
                done
                if [ $u38_idx -eq 0 ];then
                    echo "$u38_unnecessary_apache_home 경로 내에 파일 및 디렉터리가 존재하지 않습니다." >> $target
                fi
            else
                u38_unnecessary_apache_home=$(ls -d "$u38_documentroot/manual" 2> /dev/null)
                if [ -d "$u38_unnecessary_apache_home" ];then
                    echo "$u38_unnecessary_apache_home 경로가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                    u38_safe_check=$((u38_safe_check+1))
                    for u38_unnecessary_apache_file in "$u38_unnecessary_apache_home/*";do
                        if [ -f "$u38_unnecessary_apache_file" ];then
                            echo "$u38_unnecessary_apache_file 파일이 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                            u38_safe_check=$((u38_safe_check+1))
                        elif [ -d "$u38_unnecessary_apache_file" ];then
                            echo "$u38_unnecessary_apache_file 디렉터리가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                            u38_safe_check=$((u38_safe_check+1))
                            echo "$u38_unnecessary_apache_file 디렉터리를 재귀적으로 탐색합니다." >> $target
                            echo "$(tree $u38_unnecessary_apache_file)" >> $target
                        else
                            u38_idx=$((u38_idx+1))

                        fi
                    done
                    if [ $u38_idx -eq 0 ];then
                        echo "$u38_unnecessary_apache_home 경로 내에 파일 및 디렉터리가 존재하지 않습니다." >> $target
                    fi
                fi
            fi
        else
            for i in "/etc/httpd/conf.d/*";do
                u38_documentroot=$(grep -i 'documentroot' /etc/httpd/conf.d/* | grep -v "#" | awk -F':' '{print $2}' | awk '{print $2}' | tr -d '"')
                if [ -n "$u38_documentroot" ];then
                    u38_unnecessary_apache_home=$(ls -ld "$u38_documentroot/htdocs/manual" 2> /dev/null)
                    if [ -d "$u38_unnecessary_apache_home" ];then
                        echo "$u38_unnecessary_apache_home 경로가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                        u38_safe_check=$((u38_safe_check+1))
                        for u38_unnecessary_apache_file in "$u38_unnecessary_apache_home/*";do
                            if [ -f "$u38_unnecessary_apache_file" ];then
                                echo "$u38_unnecessary_apache_file 파일이 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                                u38_safe_check=$((u38_safe_check+1))
                            elif [ -d "$u38_unnecessary_apache_file" ];then
                                echo "$u38_unnecessary_apache_file 디렉터리가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                                u38_safe_check=$((u38_safe_check+1))
                                echo "$u38_unnecessary_apache_file 디렉터리를 재귀적으로 탐색합니다." >> $target
                                echo "$(tree $u38_unnecessary_apache_file)" >> $target
                            else
                                u38_idx=$((u38_idx+1))

                            fi
                        done
                        if [ $u38_idx -eq 0 ];then
                            echo "$u38_unnecessary_apache_home 경로 내에 파일 및 디렉터리가 존재하지 않습니다." >> $target
                        fi
                    else
                        u38_unnecessary_apache_home=$(ls -ld "$u38_documentroot/manual" 2> /dev/null)
                        if [ -d "$u38_unnecessary_apache_home" ];then
                            echo "$u38_unnecessary_apache_home 경로가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                            u38_safe_check=$((u38_safe_check+1))
                            for u38_unnecessary_apache_file in "$u38_unnecessary_apache_home/*";do
                                if [ -f "$u38_unnecessary_apache_file" ];then
                                    echo "$u38_unnecessary_apache_file 파일이 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                                    u38_safe_check=$((u38_safe_check+1))
                                elif [ -d "$u38_unnecessary_apache_file" ];then
                                    echo "$u38_unnecessary_apache_file 디렉터리가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                                    u38_safe_check=$((u38_safe_check+1))
                                    echo "$u38_unnecessary_apache_file 디렉터리를 재귀적으로 탐색합니다." >> $target
                                    echo "$(tree $u38_unnecessary_apache_file)" >> $target
                                else
                                    u38_idx=$((u38_idx+1))

                                fi
                            done
                            if [ $u38_idx -eq 0 ];then
                                echo "$u38_unnecessary_apache_home 경로 내에 파일 및 디렉터리가 존재하지 않습니다." >> $target
                            fi
                        fi
                    fi
                fi
            done
        fi     
    fi
done
u38_idx=0
for u38_unnecessary_dir in "${u38_unnecessary_dirs[@]}";do
    echo "$u38_unnecessary_dir 경로에 대해 점검합니다." >> $target
    if [ -d "$u38_unnecessary_dir" ];then
         for u38_dected_file in "$u38_unnecessary_dir";do
            if [ -f "$u38_dected_file" ];then
                echo "$u38_unnecessary_dir 경로에서 $u38_dected_file 파일이 식별되었습니다. 불필요한 파일일 경우 삭제 바랍니다." >> $target
                u38_safe_check=$((u38_safe_check+1))
            elif [ -d "$u38_dected_file" ];then
                echo "$u38_dected_file 디렉터리가 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
                u38_safe_check=$((u38_safe_check+1))
                echo "$u38_dected_file 디렉터리를 재귀적으로 탐색합니다." >> $target
                echo "$(tree $u38_dected_file)" >> $target
            else
                u38_idx=$((u38_idx+1))

            fi
         done
    else
        echo "$u38_unnecessary_dir 경로가 존재하지 않습니다." >> $target
    fi  
done

for u38_unnecessary_file in "${u38_unnecessary_files[@]}";do
    if [ -f "$u38_unnecessary_file" ];then
        echo "$u38_unnecessary_file 파일이 존재합니다. 불필요한경우 삭제 바랍니다." >> $target
        u38_safe_check=$((u38_safe_check+1))
        u38_idx=$((u38_idx+1))
    else
        echo "$u38_unnecessary_file 파일은 존재하지 않습니다." >> $target
    fi
done
if [ $u38_idx -eq 0 ];then
    echo "기본적으로 불필요한 파일은 발견되지 않았습니다. 추가적인 수동 점검을 권장합니다." >> $target
fi
for u38_unnecessary_file_sample in "$u38_unnecessary_files_sample";do
    if [ -f "$u38_unnecessary_file_sample" ];then >> $target
        echo "$u38_unnecessary_file_sample 파일이 존재합니다. 불필요한 경우 삭제 바랍니다." >> $target
        u38_safe_check=$((u38_safe_check+1))
    fi
done

if [[ $u38_safe_check -ge 1 ]];then
    u38=$((u38+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u38 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u38_Service_Management=1
fi

cat << EOF
===== [U-39] Disabling Web Service Links              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-39 웹서비스 링크 사용금지              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 :  무분별한 심볼릭 링크, aliases 사용제한으로 시스템 권한의 탈취 방지를 목적으로 함" >> $target
echo "+보안위협 : 웹 루트 폴더(DocumentRoot)에 root 디렉터리(/)를 링크하는 파일이 있으며 디렉터리 인덱싱 기능이 차단되어 있어도 root 디렉터리 열람이 가능함" >> $target
echo "+판단기준 양호 : 심볼릭 링크, aliases 사용을 제한한 경우" >> $target
echo "+판단기준 취약 : 심볼릭 링크, aliases 사용을 제한하지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-39 점검 결과" >> $result
u39=0
u39_apache_files=("/etc/httpd/conf.d/*.conf" "/etc/httpd/sites-available/*.conf" "/etc/httpd/sites-enabled/*.conf")
u39_nginx_files=("/etc/nginx/conf.d/*.conf")
u39_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
u39_idx=0
u39_break=0
u39_idxn=0
u39_safe_check=0
u39_Service_Management=0
echo "※Cent OS 7 기준 Apache 메인 설정파일 경로와 Nginx 메인 설정 파일인 /etc/nginx/nginx.conf를 점검합니다. 해당 경로가 존재하지 않을 경우, 아파치 웹 서비스 구성 파일명을 토대로 파일 탐색 후 점검이 진행됩니다. 중복된 파일명이 존재할 경우 수동 점검을 권장합니다.※"  >> $target
echo "apache, nginx 의 주요 설정파일을 토대로 apache 홈 디렉터리 점검 후 추가 설정 파일 및 디렉터리를 점검하므로, 중복된 결과가 존재할 수 있습니다." >> $target
for u39_apache_home_check in "${u39_apache_home_checks[@]}";do
    u39_apache_home=$(find / -type f -name "$u39_apache_home_check" 2> /dev/null | egrep -v "tmp|temp|swap|swp")
    if [ -f "$u39_apache_home" ];then
        echo "$u39_apache_home 파일이 존재합니다." >> $target
        u39_dir_pathconfs_a=($(grep -vE "^\s*#" "$u39_apache_home" | sed -n '/<Directory/,/<\/Directory>/p' | grep -i "^\s*options" | grep -i "FollowSymLinks" | awk '{print $1}'))
        u39_check_dirpath_a=($(grep -vE "^\s*#" "$u39_apache_home" | awk 'BEGIN { inBlock = 0; block = "" }/<Directory/ {block = $0;inBlock = 1;dirPath = $2; gsub("\"", "", dirPath)}/<\/Directory>/ {block = block "\n" $0;inBlock = 0;if (block ~ /FollowSymLinks/) { print dirPath }block = ""}inBlock && ! /<\/Directory>/ { block = block "\n" $0 }' | tr -d '>'))
        for u39_dir_pathconf_a in "${u39_dir_pathconfs_a[@]}";do
            if [ -n "$u39_dir_pathconfs_a" ];then
                echo "웹 서비스 링크가 활성화 있습니다." >> $target
                echo "웹 서비스 링크가 활성화된 디렉토리 경로 : ${u39_check_dirpath_a[$u39_idx]}" >> $target
                u39_safe_check=$((u39_safe_check+1))
                u39_idx=$((u39_idx+1))
            else
                echo "웹 서비스 링크가 비활성화 되어 있습니다" >> $target
                echo "웹 서비스 링크가 비활성화된 디렉토리 경로 : ${u39_check_dirpath_a[$u39_idx]}" >> $target
                u39_idxn=$((u39_idxn+1))
            fi
        done
        break
    else 
        u39_idx=0
        if [ $u39_break -eq 1 ];then
            break
        fi
        u39_break=$((u39_break+1))
        echo "$u39_apache_home 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> $target
        for u39_apache_file in "${u39_apache_files[@]}";do
            for u39_apache_check in $u39_apache_file;do
                if [ -f "$u39_apache_check" ];then
                    u39_adected_filecks=$(grep -vE "^\s*#" "$u39_apache_check" | grep -iw "options" | grep -iw "FollowSymLinks" | grep -iwv "\-FollowSymLinks" | awk '{print $1}')
                    for u39_adected_fileck in "${u39_adected_filecks[@]}";do
                        if [[ -n "$u39_adected_fileck" ]];then
                            echo "$u39_apache_check 파일에서 웹 서비스 링크를 허용하는 FollowSymLinks 설정값이 존재합니다." >> $target
                            echo "웹 서비스 링크가 설정된 디렉토리 경로 : ${u39_check_dirpath_a[$u39_idx]}" >> $target
                            u39_safe_check=$((u39_safe_check+1))
                            u39_idx=$((u39_idx+1))
                        else
                            echo "$u39_apache_check 파일은 존재하지만 웹 서비스 링크를 허용하는 FollowSymLinks 설정값이 존재하지 않습니다." >> $target
                            u39_idxn=$((u39_idxn+1))
                        fi
                    done
                fi
            done
        done
        u39_idx=0
    fi
done
echo "추가적인 Apache 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
u39_idx=0
u39_idxn=0
#if [ -f "/etc/nginx/nginx.conf" ];then
#    echo "/etc/nginx/nginx.conf 파일이 존재합니다." >> $target
#    u39_dir_lisconfs_n=($(grep -vE "^\s*#" "/etc/nginx/nginx.conf" | grep -iw "^\s*autoindex" | sed 's/^[ \t]*//' | awk '{print tolower($2)}' | tr -d ';'))
#    for u39_dir_lisconf_n in "${u39_dir_lisconfs_n[@]}";do
#         if [[ $u39_dir_lisconf_n == "on" ]];then
#             u39=$((u39+1))
#             u39_idx=$((u39_idx+1))
#         else
#             echo "웹 서비스 디렉토리 리스팅이 비활성화 되어 있습니다" >> $target
#             u39_idxn=$((u39_idxn+1))
#         fi
#     done
#     echo "웹 서비스 디렉토리 리스팅이 활성화 있습니다." >> $target
#     echo "설정 값 : $u95_dir_lisconf_n" >> $target
#     echo "총 $u39_idx 개의 취약한 on 설정이 존재합니다. /etc/nginx/nginx.conf 파일을 확인하십시오." >> $target
#     echo "웹 서비스 디렉토리 리스팅이 비활성화된 $u39_idxn 개의 안전한  off 설정이 존재 합니다. /etc/nginx/nginx.conf 파일을 확인하십시오." >> $target
# else 
#     echo "/etc/nginx/nginx.conf 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> $target
#     for u39_ngnix_file in "${u39_nginx_files[@]}";do
#         for u39_nginx_check in $u39_ngnix_file;do
#             u39_dir_lisconfs_n=($(grep -vE "^\s*#" "$u39_nginx_check" | grep -iw "^\s*autoindex" | sed 's/^[ \t]*//' | awk '{print tolower($2)}' | tr -d ';'))
#             if [ -f "$u39_nginx_check" ];then
#                 #u39_ndected_filecks=$(grep -vE "^\s*#" "$u39_nginx_check" | grep -iw "autoindex" | tr -d ';' | grep -iw "on")
#                 for u39_dir_lisconf_n in "${u39_dir_lisconfs_n[@]}";do
#                     if [ -n "$u39_dir_lisconf_n" ];then
#                         if [ -n "$u39_dir_lisconf_n" ];then
#                             u39=$((u39+1))
#                             u39_idx=$((u39_idx+1))
#                         else
#                             echo "$u39_nginx_check 파일은 존재하지만 디렉토리 리스팅을 허용하는 autoindex 설정값이 존재하지 않습니다." >> $target
#                             u39_idxn=$((u39_idxn+1))
#                         fi
#                     else
#                         echo "$u39_nginx_check 파일은 존재하지만 디렉토리 리스팅을 허용하는 autoindex 설정값이 존재하지 않습니다." >> $target
#                         u39_idxn=$((u39_idxn+1))
#                     fi
#                 done
#                 if [[ $u39_idx -ge 1 ]];then
#                     echo "$u39_nginx_check 파일에서 디렉토리 리스팅이 허용되어 있습니다." >> $target
#                     echo "설정 값 : $u39_dir_lisconf_n" >> $target
#                     echo "총 $u39_idx 개의 취약한 on 설정이 존재합니다. $u39_nginx_check 파일을 확인하십시오." >> $target
#                     echo "웹 서비스 디렉토리 리스팅이 비활성화된 $u39_idxn 개의 안전한  off 설정이 존재 합니다. $u39_nginx_check 파일을 확인하십시오." >> $target
#                 fi
#             fi
#         done
#     done
#     echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
# fi
if [[ $u39_safe_check -ge 1 ]];then
    u39=$((u39+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u39 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u39_Service_Management=1
fi

cat << EOF
===== [U-40] Upload and downloading web service file files              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-40 웹서비스 파일 업로드 및 다운로드 제한              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 기반시설 특성상 원칙적으로 파일 업로드 및 다운로드를 금지하고 있지만불가피하게 필요시 용량 사이즈를 제한함으로써 불필요한 업로드와 다운로드를 방지해 서버의 과부하 예방 및 자원을 효율적으로 관리하기 위함" >> $target
echo "+보안위협 : 악의적 목적을 가진 사용자가 반복 업로드 및 웹 쉘 공격 등으로 시스템 권한을 탈취하거나 대용량 파일의 반복 업로드로 서버자원을 고갈시키는 공격의 위험이 있음" >> $target
echo "+판단기준 양호 : 일 업로드 및 다운로드를 제한한 경우" >> $target
echo "+판단기준 취약 : 파일 업로드 및 다운로드를 제한하지 않은 경" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-40 점검 결과" >> $result
u40=0
u40_apache_files=("/etc/httpd/conf.d/*.conf" "/etc/httpd/sites-available/*.conf" "/etc/httpd/sites-enabled/*.conf")
u40_nginx_files=("/etc/nginx/conf.d/*.conf")
u40_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
u40_idx=0
u40_break=0
u40_idxn=0
u40_safe_check=0
u40_Service_Management=0
echo "※Cent OS 7 기준 Apache 메인 설정파일 경로와 Nginx 메인 설정 파일인 /etc/nginx/nginx.conf를 점검합니다. 해당 경로가 존재하지 않을 경우, 아파치 웹 서비스 구성 파일명을 토대로 파일 탐색 후 점검이 진행됩니다. 중복된 파일명이 존재할 경우 수동 점검을 권장합니다.※"  >> $target
echo "apache, nginx 의 주요 설정파일을 토대로 apache 홈 디렉터리 점검 후 추가 설정 파일 및 디렉터리를 점검하므로, 중복된 결과가 존재할 수 있습니다." >> $target
for u40_apache_home_check in "${u40_apache_home_checks[@]}";do
    u40_apache_home=$(find / -type f -name "$u40_apache_home_check" 2> /dev/null | egrep -v "tmp|temp|swap|swp")
    if [ -f "$u40_apache_home" ];then
        echo "$u40_apache_home 파일이 존재합니다." >> $target
        u40_dir_pathconfs_a=($(grep -vE "^\s*#" "$u40_apache_home" | sed -n '/<Directory/,/<\/Directory>/p' | grep -i "^\s*LimitRequestBody" | awk '{print $2}'))
        u40_check_dirpath_a=($(grep -vE "^\s*#" "$u40_apache_home" | awk 'BEGIN { inBlock = 0; block = "" }/<Directory/ {block = $0;inBlock = 1;dirPath = $2; gsub("\"", "", dirPath)}/<\/Directory>/ {block = block "\n" $0;inBlock = 0;if (block ~ /LimitRequestBody/) { print dirPath }block = ""}inBlock && ! /<\/Directory>/ { block = block "\n" $0 }' | tr -d '>'))
        if [ -n "$u40_dir_pathconfs_a" ];then
            for u40_dir_pathconf_a in "${u40_dir_pathconfs_a[@]}";do
                if [[ $u40_dir_pathconf_a -ge 5242880 ]];then
                    echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이상 설정되어 있습니다." >> $target
                    echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이상으로 설정된 디렉토리 경로 : ${u40_check_dirpath_a[$u40_idx]}" >> $target
                    u40_safe_check=$((u40_safe_check+1))
                    u40_idx=$((u40_idx+1))
                else
                    echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이하로 적절하게 설정되어 있습니다.." >> $target
                    echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이상으로 설정된 디렉토리 경로 : ${u40_check_dirpath_a[$u40_idx]}" >> $target
                    u40_idxn=$((u40_idxn+1))
                fi
            done
            break
        else
            echo "$u40_dir_pathconfs_a 파일은 존재하지만, 파일 업로드 및 다운로드 사이즈를 설정할 수 있는 LimitRequestBody 지시자가 존재하지 않습니다." >> $target
        fi
    else 
        u40_idx=0
        if [ "$u40_break" -eq 1 ];then
            break
        fi
        u40_break=$((u40_break+1))
        echo "$u40_apache_home_check 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> $target
        for u40_apache_file in "${u40_apache_files[@]}";do
            for u40_apache_check in $u40_apache_file;do
                if [ -f "$u40_apache_check" ];then
                    u40_adected_filecks=$(grep -vE "^\s*#" "$u40_apache_check" | grep -iw "LimitRequestBody" | awk '{print $2}' )
                    for u40_adected_fileck in "${u40_adected_filecks[@]}";do
                        if [ -n "$u40_adected_fileck" ];then
                            if [[ "$u40_adected_fileck" -ge 5242880 ]];then
                                echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이상 설정되어 있습니다." >> $target
                                echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이상으로 설정된 디렉토리 경로 : ${u40_apache_check[$u40_idx]}" >> $target
                                u40_safe_check=$((u40_safe_check+1))
                                u40_idx=$((u40_idx+1))
                            else
                                echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이하로 적절하게 설정되어 있습니다.." >> $target
                                echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이하로 설정된 디렉토리 경로 : ${u40_check_dirpath_a[$u40_idx]}" >> $target
                                u40_idxn=$((u40_idxn+1))
                            fi
                        else
                            echo "$u40_apache_check 파일은 존재하지만 파일 업로드 및 다운로드 사이즈를 설정할 수 있는 LimitRequestBody 지시자가 존재하지 않습니다." >> $target
                            u40_idxn=$((u40_idxn+1))
                        fi
                    done
                fi
            done
        done
        u40_idx=0
    fi
done
echo "추가적인 Apache 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
u40_idx=0
u40_idxn=0
if [ -f "/etc/nginx/nginx.conf" ];then
    echo "/etc/nginx/nginx.conf 파일이 존재합니다." >> $target
    u40_dir_sizechecks_n=($(grep -vE "^\s*#" "/etc/nginx/nginx.conf" | grep -iw "^\s*client_max_body_size" | sed 's/^[ \t]*//' | awk '{print $2}' | tr -d ';'))
    if [ -n "$u40_dir_sizechecks_n" ];then
        for u40_dir_sizecheck_n in "${u40_dir_sizechecks_n[@]}";do
            if [[ $u40_dir_sizecheck_n -ge 5242880 ]];then
                echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이상 설정되어 있습니다." >> $target
                u40_safe_check=$((u40_safe_check+1))
                u40_idx=$((u40_idx+1))
            else
                echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이하로 적절하게 설정되어 있습니다.." >> $target
                u40_idxn=$((u40_idxn+1))
            fi
        done
    else
        echo "/etc/nginx/nginx.conf 파일은 존재하지만, 파일 업로드 및 다운로드 사이즈를 설정할 수 있는 client_max_body_size 지시자가 존재하지 않습니다." >> $target
    fi    
else 
    echo "/etc/nginx/nginx.conf 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> $target
    for u40_ngnix_file in "${u40_nginx_files[@]}";do
        for u40_nginx_check in $u39_ngnix_file;do
            u40_dir_sizechecks_n=($(grep -vE "^\s*#" "$u40_nginx_check" | grep -iw "^\s*client_max_body_size" | sed 's/^[ \t]*//' | awk '{print $2}' | tr -d ';'))
            if [ -f "$u40_nginx_check" ];then
                echo "$u40_nginx_check 파일이 존재합니다." >> $target
                #u39_ndected_filecks=$(grep -vE "^\s*#" "$u39_nginx_check" | grep -iw "autoindex" | tr -d ';' | grep -iw "on")
                for u40_dir_sizecheck_n in "${u40_dir_sizechecks_n[@]}";do
                    if [ -n "$u40_dir_sizecheck_n" ];then
                        if [ "$u40_dir_sizecheck_n" -ge 5242880 ];then
                            echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이상 설정되어 있습니다." >> $target
                            u40_safe_check=$((u40_safe_check+1))
                            u40_idx=$((u40_idx+1))
                        else
                            echo "파일 업로드 및 다운로드 파일의 사이즈가 5M 이하로 적절하게 설정되어 있습니다.." >> $target
                            u40_idxn=$((u40_idxn+1))
                        fi
                    else
                        echo "$u39_nginx_check 파일은 존재하지만 Body 사이즈를 제한하는 client_max_body_size 지시자가 존재하지 않습니다." >> $target
                        u40_idxn=$((u40_idxn+1))
                    fi
                done
                if [[ $u40_idx -ge 1 ]];then
                    echo "$u40_nginx_check 파일에서 파일 업로드 및 다운로드 사이즈가 5M이상으로 설정된 client_max_body_size가 있습니다." >> $target
                    echo "설정 값 : $u40_dir_sizecheck_n" >> $target
                    echo "총 $u40_idx 개의 취약한 사이즈 설정이 존재합니다. $u40_nginx_check 파일을 확인하십시오." >> $target
                    echo "파일 업로드 및 다운로드 사이즈가 적절하게 설정된 $u40_idxn 개의 설정이 존재 합니다. $u40_nginx_check 파일을 확인하십시오." >> $target
                fi
            fi
        done
    done
    echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
fi
if [[ $u40_safe_check -ge 1 ]];then
    u40=$((u40+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u40 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u40_Service_Management=1
fi

cat << EOF
===== [U-41] Separation of Web Service Areas              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-41 웹서비스 영역의 분리              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 웹 서비스 영역과 시스템 영역을 분리시켜서 웹 서비스의 침해가 시스템 영역으로 확장될 가능성을 최소화하기 위함" >> $target
echo "+보안위협 : 웹 서버의 루트 디렉터리와 OS의 루트 디렉터리를 다르게 지정하지 않았을 경우, 비인가자가 웹 서비스를 통해 해킹이 성공할 경우 시스템 영역까지 접근이 가능하여 피해가 확장될 수 있음" >> $target
echo "+판단기준 양호 : DocumentRoot를 별도의 디렉터리로 지정한 경우" >> $target
echo "+판단기준 취약 : DocumentRoot를 기본 디렉터리로 지정한 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-42 점검 결과" >> $result
u41=0
u41_Service_Management=0
u41_safe_check=0
u41_apache_files=("/etc/httpd/conf.d/*.conf" "/etc/httpd/sites-available/*.conf" "/etc/httpd/sites-enabled/*.conf")
u41_nginx_files=("/etc/nginx/conf.d/*.conf")
u41_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
u41_idx=0
u41_break=0
u41_home_dected=0
echo "apache, nginx 의 주요 설정파일을 토대로 apache 홈 디렉터리 점검 후 추가 설정 파일 및 디렉터리를 점검하므로, 중복된 결과가 존재할 수 있습니다." >> $target
for u41_apache_home_check in "${u41_apache_home_checks[@]}";do
    u41_apache_home=$(find / -type f -name "$u41_apache_home_check" 2> /dev/null | egrep -v "tmp|temp|swap|swp")
    if [ -f "$u41_apache_home" ];then
        u41_virutalhost=$(grep -v "#" "$u41_apache_home" | awk '/<VirtualHost/,/<\/VirtualHost>/' | sed -n '/<VirtualHost/,/<\/VirtualHost>/p')
        u41_default_documentroot=$(grep -v "#" $u41_apache_home | grep -m 1 -i "^DocumentRoot" | awk '{print $2}' | tr -d '"')
        echo "$u41_apache_home 파일이 존재합니다." >> $target
        u41_home_dected=$((u41_home_dected+1))
        if [ -n "$u41_default_documentroot" ];then
            if [[ "$u41_default_documentroot" == "/usr/local/apache/htdocs" || "$u41_default_documentroot" == "/usr/local/apache2/htdocs" || "$u41_default_documentroot" ==  "/var/www/html" ]];then
                echo "기본 서버의 DocumentRoot가 $u41_default_documentroot 로 설정되어, 기본 디렉터리로 지정되어 있는 설정값이 존재합니다. $u41_apache_home 파일을 확인하십시오." >> $target
                u41_safe_check=$((u41_safe_check+1))
            else
                echo "기본 서버의 DocumentRoot가 기본 디렉터리 이외의 별도의 디렉터리로 적절하게 설정되어 있습니다." >> $target
            fi
        else
            echo "$u41_apache_home_check 파일은 존재하지만, 관련 설정값이 존재하지 않습니다." >> $target
        fi
        if [ -n "$u41_virutalhost" ];then
            echo "가상 호스트 설정이 존재합니다." >> $target
            u41_virutalhost_documentroot=($(grep -v "#" "$u41_apache_home" | awk '/<VirtualHost/,/<\/VirtualHost>/' | sed -n '/<VirtualHost/,/<\/VirtualHost>/p' | grep -E "(DocumentRoot|ServerName)" | grep -i 'DocumentRoot' | awk '{print $2}' | tr -d '"' ))
            u41_virutalhost_servdrname=($(grep -v "#" "$u41_apache_home" | awk '/<VirtualHost/,/<\/VirtualHost>/' | sed -n '/<VirtualHost/,/<\/VirtualHost>/p' | grep -E "(DocumentRoot|ServerName)" | grep -i 'ServerName' | awk '{print $2}' | tr -d '"' ))
            for (( u41_i=0; u41_i<${#u41_virutalhost_documentroot[@]}; u41_i++ )); do
                if [[ "${u41_virutalhost_documentroot[$u41_i]}" == "/usr/local/apache/htdocs" || "${u41_virutalhost_documentroot[$u41_i]}" == "/usr/local/apache2/htdocs" || "${u41_virutalhost_documentroot[$u41_i]}" ==  "/var/www/html" ]]; then
                    echo "가상 호스트 주소 ${u41_virutalhost_servdrname[$u41_i]} 의 DocumentRoot 값이 ${u41_virutalhost_documentroot[$u41_i]} 인 기본 디렉터리로 설정되어 있습니다." >> $target
                    u41_safe_check=$((u41_safe_check+1))
                else
                    echo "가상 호스트 주소 ${u41_virutalhost_servdrname[$u41_i]} DocumentRoot 값이 기본 디렉터리 이외의 별도의 디렉터리로 적절하게 설정되어 있습니다." >> $target
                fi
            done
            echo "가상 호스트 설정의 전체 값" >> $target
            echo "$u41_virutalhost" >> $target
        else
            echo "가상 호스트 설정은 따로 존재하지 않습니다." >> $target
        fi
    else
        u41_idx=0
        if [[ $u41_break -eq 1 && $u41_home_dected -eq 1 ]];then
            break 
        fi
        u41_break=$((u41_break+1))
        for u41_apache_file in "${u41_apache_files[@]}";do
            for u41_apache_check in $u41_apache_file;do
                if [ -f "$u41_apache_check" ];then
                    u41_virutalhost=$(grep -v "#" "$u41_apache_check" | awk '/<VirtualHost/,/<\/VirtualHost>/' | sed -n '/<VirtualHost/,/<\/VirtualHost>/p')
                    u41_default_documentroot=$(grep -v "#" $u41_apache_check | grep -m 1 -i "^DocumentRoot" | awk '{print $2}' | tr -d '"')
                    echo "$u41_apache_check 파일이 존재합니다." >> $target
                    u41_home_dected=$((u41_home_dected+1))
                    if [ -n "$u41_default_documentroot" ];then
                        if [[ "$u41_default_documentroot" == "/usr/local/apache/htdocs" || "$u41_default_documentroot" == "/usr/local/apache2/htdocs" || "$u41_default_documentroot" ==  "/var/www/html" ]];then
                            echo "기본 서버의 DocumentRoot가 $u41_default_documentroot 로 설정되어, 기본 디렉터리로 지정되어 있는 설정값이 존재합니다. $u41_apache_check 파일을 확인하십시오." >> $target
                            u41_safe_check=$((u41_safe_check+1))
                        else
                            echo "기본 서버의 DocumentRoot가 기본 디렉터리 이외의 별도의 디렉터리로 적절하게 설정되어 있습니다." >> $target
                        fi
                    else
                        echo "$u41_apache_check 파일은 존재하지만, 관련 설정값이 존재하지 않습니다." >> $target
                    fi
                    if [ -n "$u41_virutalhost" ];then
                        echo "가상 호스트 설정이 존재합니다." >> $target
                        u41_virutalhost_documentroot=($(grep -v "#" "$u41_apache_check" | awk '/<VirtualHost/,/<\/VirtualHost>/' | sed -n '/<VirtualHost/,/<\/VirtualHost>/p' | grep -E "(DocumentRoot|ServerName)" | grep -i 'DocumentRoot' | awk '{print $2}' | tr -d '"' ))
                        u41_virutalhost_servdrname=($(grep -v "#" "$u41_apache_check" | awk '/<VirtualHost/,/<\/VirtualHost>/' | sed -n '/<VirtualHost/,/<\/VirtualHost>/p' | grep -E "(DocumentRoot|ServerName)" | grep -i 'ServerName' | awk '{print $2}' | tr -d '"' ))
                        for (( u41_i=0; u41_i<${#u41_virutalhost_documentroot[@]}; u41_i++ )); do
                            if [[ "${u41_virutalhost_documentroot[$u41_i]}" == "/usr/local/apache/htdocs" || "${u41_virutalhost_documentroot[$u41_i]}" == "/usr/local/apache2/htdocs" || "${u41_virutalhost_documentroot[$u41_i]}" ==  "/var/www/html" ]]; then
                                echo "가상 호스트 주소 ${u41_virutalhost_servdrname[$u41_i]} 의 DocumentRoot 값이 ${u41_virutalhost_documentroot[$u41_i]} 인 기본 디렉터리로 설정되어 있습니다." >> $target
                                u41_safe_check=$((u41_safe_check+1))
                            else
                                echo "가상 호스트 주소 ${u41_virutalhost_servdrname[$u41_i]} DocumentRoot 값이 기본 디렉터리 이외의 별도의 디렉터리로 적절하게 설정되어 있습니다." >> $target
                            fi
                        done
                        echo "가상 호스트 설정의 전체 값" >> $target
                        echo "$u41_virutalhost" >> $target
                    else
                        echo "가상 호스트 설정은 따로 존재하지 않습니다." >> $target
                    fi
                fi
            done
        done
    fi
done

if [ -f "/etc/nginx/nginx.conf" ];then
    echo "/etc/nginx/nginx.conf 파일이 존재합니다." >> $target
    u41_default_root=(grep -m 1 -i "root" "/etc/nginx/nginx.conf")
    u41_default_aliass=($(grep -i "alias" "/etc/nginx/nginx.conf"))
    u41_virutalhost_roots=($(grep -i "root" /etc/nginx/nginx.conf | sed '1d'))
    if [ -n "$u41_default_root" ];then
        if [[ "$u41_default_root" == "/usr/share/nginx/html" || "$u41_default_root" == "/var/www/html" ]];then
            echo "nginx 설정 파일 내에 root 지시자로 인해 기본 디렉터리인 $u41_default_root 로 설정되어 있습니다." >> $target
            u41_safe_check=$((u41_safe_check+1))
        else
            echo "nginx 설정 파일 내에 root 지시자가 기본 디렉터리 이외의 디렉터리로 적절하게 설정되어 있습니다." >> $target
        fi
    else
        echo "/etc/nginx/nginx.conf 파일은 존재하지만 관련 설정값이 존재하지 않습니다." >> $target
    fi
    if [ -n "$u41_default_aliass" ];then
        echo "/etc/nginx/nginx.conf 파일내에 alias 설정이 존재합니다." >> $target
        u41_count=1
        for u41_default_alias in "${u41_default_aliass[@]}";do
            if [[ "$u41_default_alias" == "/usr/share/nginx/html" || "$u41_default_alias" == "/var/www/html" ]];then
                echo "$u41_count 번째로 설정된 alias에 설정되어 있는 경로가 기본 디렉터리인 $u41_default_alias 로 설정되어 있습니다." >> $target
                u41_safe_check=$((u41_safe_check+1))
            else
                echo "$u41_count 번째로 설정된 alias에 설정되어 있는 경로가 $u41_default_alias 로 설정되어, 기본 디렉터리 이외의 디렉터리로 적절하게 설정되어 있습니다." >> $target
            fi
            u41_count=$((u41_count+1))
        done
    else
        echo "/etc/nginx/nginx.conf 파일 내에 alias 설정이 존재하지 않습니다." >> $target
    fi
    if [ -n "$u41_virutalhost_root" ];then
        echo "/etc/nginx/nginx.conf 파일 내에 가상 호스트 설정이 존재합니다." >> $target
        u41_count=1
        for u41_virutalhost_root in "${u41_virutalhost_roots[@]}";do
            if [[ "$u41_virutalhost_root" == "/usr/share/nginx/html" || "$u41_virutalhost_root" == "/var/www/html" ]];then
                echo "$u41_count 번째 가상 호스트의 설정 경로가 기본 디렉터리인 $u41_virutalhost_root 로 설정되어 있습니다."
                u41_safe_check=$((u41_safe_check+1))
            else
                echo "$u41_count 번째 가상 호스트 설정 내에 설정되어 있는 경로가 기본 디렉터리 이외의 디렉터리로 적절하게 설정되어 있습니다." >> $target
            fi
            u41_count=$((u41_count+1))
        done
    else
        echo "/etc/nginx/nginx.conf 파일 내에 가상 호스트 설정은 존재하지 않습니다." >> $target
    fi
else 
    echo "/etc/nginx/nginx.conf 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다."  >> $target
    for u41_ngnix_file in "${u41_nginx_files[@]}";do
        for u41_nginx_check in $u41_ngnix_file;do
            if [ -f "$u41_nginx_check" ];then
                echo "$u41_nginx_check 파일이 존재합니다." >> $target
                u41_default_root=(grep -m 1 -i "root" "$u41_nginx_check")
                u41_default_aliass=($(grep -i "alias" "$u41_nginx_check"))
                u41_virutalhost_roots=($(grep -i "root" $u41_nginx_check | sed '1d'))
                if [ -n "$u41_default_root" ];then
                    if [[ "$u41_default_root" == "/usr/share/nginx/html" || "$u41_default_root" == "/var/www/html" ]];then
                        echo "nginx 설정 파일 내에 root 지시자로 인해 기본 디렉터리인 $u41_default_root 로 설정되어 있습니다."  >> $target
                        u41_safe_check=$((u41_safe_check+1))
                    else
                        echo "nginx 설정 파일 내에 root 지시자가 기본 디렉터리 이외의 디렉터리로 적절하게 설정되어 있습니다." >> $target
                    fi
                else
                    echo "$u41_nginx_check 파일은 존재하지만 관련 설정값이 존재하지 않습니다." >> $target
                fi
                if [ -n "$u41_default_aliass" ];then
                    echo "$u41_nginx_check 파일내에 alias 설정이 존재합니다." >> $target
                    u41_count=1
                    for u41_default_alias in "${u41_default_aliass[@]}";do
                        if [[ "$u41_default_alias" == "/usr/share/nginx/html" || "$u41_default_alias" == "/var/www/html" ]];then
                            echo "$u41_count 번째로 설정된 alias 에 설정되어 있는 경로가 기본 디렉터리인 $u41_default_alias 로 설정되어 있습니다." >> $target
                            u41_safe_check=$((u41_safe_check+1))
                        else
                            echo "$u41_count 번째로 설정된 alias 로 설정되어 있는 경로가 $u41_default_alias 로 설정되어, 기본 디렉터리 이외의 디렉터리로 적절하게 설정되어 있습니다." >> $target
                        fi
                        u41_count=$((u41_count+1))
                    done
                else
                    echo "$u41_nginx_check 파일 내에 alias 설정이 존재하지 않습니다." >> $target
                fi
                if [ -n "$u41_virutalhost_root" ];then
                    echo "$u41_nginx_check 파일 내에 가상 호스트 설정이 존재합니다." >> $target
                    for u41_virutalhost_root in "${u41_virutalhost_roots[@]}";do
                        u41_count=1
                        if [[ "$u41_virutalhost_root" == "/usr/share/nginx/html" || "$u41_virutalhost_root" == "/var/www/html" ]];then
                            echo "$u41_count 번째 가상 호스트의 설정 경로가 기본 디렉터리인 $u41_virutalhost_root 로 설정되어 있습니다." >> $target
                            u41_safe_check=$((u41_safe_check+1))
                        else
                            echo "$u41_count 번째 가상 호스트 설정 내에 설정되어 있는 경로가 기본 디렉터리 이외의 디렉터리로 적절하게 설정되어 있습니다." >> $target
                        fi
                        u41_count=$((u41_count+1))
                    done
                else
                    echo "$u41_nginx_check 파일 내에 가상 호스트 설정은 존재하지 않습니다." >> $target
                fi
            fi
        done
    done
    echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
fi

if [[ $u41_safe_check -ge 1 ]];then
    u41=$((u41+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u41 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u41_Service_Management=1
fi

cat << EOF
===== [U-42] Apply the latest security patches and vendor recommendations              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-42 최신 보안패치 및 벤더 권고사항 적용              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 주기적인 패치 적용을 통하여 보안성 및 시스템 안정성을 확보함" >> $target
echo "+보안위협 : 최신 보안패치가 적용되지 않을 경우, 이미 알려진 취약점을 통하여 공격자에 의해 시스템 침해사고 발생 가능성이 존재함" >> $target
echo "+판단기준 양호 : 패치 적용 정책을 수립하여 주기적으로 패치관리를 하고 있으며, 패치 관련 내용을 확인하고 적용했을 경우" >> $target
echo "+판단기준 취약 : 패치 적용 정책을 수립하지 않고 주기적으로 패치관리를 하지 않거나 패치 관련 내용을 확인하지 않고 적용하지 않았을 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-42 점검 결과" >> $result
echo "귀사의 시스템에 대한 보안 담당자와의 상담을 통해 O/S 관리자, 서비스 개발자가 패치 적용에 따른 서비스 영향 정도를 파악하여 OS 관리자 및 벤더에서의 적용여부를 확인해야함." >> $target
u42_Patch_Management=0


cat << EOF
===== [U-43] Periodic review and reporting of logs              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-43 로그의 정기적 검토 및 보고              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : 정기적인 로그 점검을 통해 안정적인 시스템 상태 유지 및 외부 공격 여부를 파악하기 위함" >> $target
echo "+보안위협 : 로그의 검토 및 보고 절차가 없는 경우 외부 침입 시도에 대한 식별이 누락될 수 있고, 침입 시도가 의심되는 사례 발견 시 관련 자료를 분석하여 해당장비에 대한 접근을 차단하는 등의 추가 조치가 어려움" >> $target
echo "+판단기준 양호 : 접속기록 등의 보안 로그, 응용 프로그램 및 시스템 로그 기록에 대해 정기적으로 검토, 분석, 리포트 작성 및 보고 등의 조치가 이루어지는 경우" >> $target
echo "+판단기준 취약 : 위 로그 기록에 대해 정기적으로 검토, 분석, 리포트 작성 및 보고 등의 조치가 이루어 지지 않는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-43 점검 결과" >> $result
echo "귀사의 시스템에 대한 보안 담당자와의 상담을 통해 접속기록 등의 보안 로그, 응용 프로그램 및 시스템 로그 기록에 대해 정기적으로 검토, 분석, 리포트 작성 및 보고 등의 조치가 이루어지에 대한 확인 필요" >> $target
u43_Log_Management=0


cat << EOF
===== [U-44] No UID other than root '0'              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-44 root 이외의 UID가 ‘0’ 금지              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : root 계정과 동일한 UID가 존재하는지 점검하여 root권한이 일반 사용자 계정이나 비인가자의 접근 위협에 안전하게 보호되고 있는지 확인하기 위함" >> $target
echo "+보안위협 : root 계정과 동일 UID가 설정되어 있는 일반사용자 계정도 root 권한을 부여받아 관리자가 실행 할 수 있는 모든 작업이 가능함(서비스 시작, 중지, 재부팅, root 권한 파일 편집 등) root와 동일한 UID를 사용하므로 사용자 감사 추적 시 어려움이 발생함" >> $target
echo "+판단기준 양호 : root 계정과 동일한 UID를 갖는 계정이 존재하지 않는 경우" >> $target
echo "+판단기준 취약 : root 계정과 동일한 UID를 갖는 계정이 존재하는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-44 점검 결과" >> $result

u44_Account_Management=0
u44_safe_check=0
u44=0
u44_uid_checks=($(grep -v "root" /etc/passwd | awk -F: '$3 == 0 {print $1}'))
u44_gid_checks=($(grep -v "root" /etc/passwd | awk -F: '$4 == 0 {print $1}'))

if [ -n "$u44_uid_check"  ];then
    for u44_uid_check in "${u44_uid_checks[@]}";do
        echo "$u44_uid_check 계정의 UID값이 root 유저와 동일한 0 으로 설정되어 있습니다." >> $target
        u44_safe_check=$((u44_safe_check+1))
    done
else
    echo "UID 값이 root 유저와 동일한 0으로 설정된 계정은 존재하지 않습니다." >> $target
fi
echo "추가적으로 GID 점검을 진행합니다." >> $target
if [ -n "$u44_gid_checks"  ];then
    for u44_gid_check in "${u44_gid_checks[@]}";do
        echo "$u44_gid_check 계정의 GID값이 root 유저와 동일한 0 으로 설정되어 있습니다." >> $target
        u44_safe_check=$((u44_safe_check+1))
    done
else
    echo "GID 값이 root 유저와 동일한 0으로 설정된 계정은 존재하지 않습니다." >> $target
fi

if [ $u44_safe_check -ge 1 ];then
    u44=$((u44+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u44 -ge 1 ]];then
    Mid=$((Mid+1))
    Account_Management=$((Account_Management+1))
    u44_Account_Management=1
fi

cat << EOF
===== [U-45] Restrict root account su              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-45 root 계정 su 제한              " >> $target
echo "--------------------------------------------------------------------------" >> $target-F: '{print $4}'
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : su 관련 그룹만 su 명령어 사용 권한이 부여되어 있는지 점검하여 su 그룹에 포함되지 않은 일반 사용자의 su 명령 사용을 원천적으로 차단하는지 확인하기 위함" >> $target
echo "보안위협 : 무분별한 사용자 변경으로 타 사용자 소유의 파일을 변경 할 수 있으며root 계정으로 변경하는 경우 관리자 권한을 획득 할 수 있음" >> $target
echo "※ 일반사용자 계정 없이 root 계정만 사용하는 경우 su 명령어 사용제한 불필요" >> $target
echo "+판단기준 양호 : su 명령어를 특정 그룹에 속한 사용자만 사용하도록 제한되어 있는 경우" >> $target
echo "+판단기준 취약 : su 명령어를 모든 사용자가 사용하도록 설정되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-45 점검 결과" >> $result
u45_Account_Management=0
u45_safe_check=0
u45=0
u45_wheel_check=$(grep -i "wheel" "/etc/passwd" | awk '{print $1}')
u45_whell_group=$(grep -i "wheel" "/etc/group" | awk -F: '{print $4}')
u45_su_perm=$(stat -c "%a" /usr/bin/su)
u45_su_perm_other=$(stat -c "%A" /usr/bin/su | rev | cut -c 1-3 | rev)
if [ -n "$u45_wheel_check" ];then
    echo "$u45_wheel_check 계정이 존재합니다." >> $target
    if grep -i "wheel" "/etc/group";then
        if [ -n "$u45_whell_group" ];then
            echo "$u45_whell_group 계정들이 wheel 그룹에 속해있습니다." >> $target
        else
            echo "wheel 그룹의 포함된 계정이 존재하지 않습니다." >> $target
            u45_safe_check=$((u45_safe_check+1))
        fi
    fi
else
    echo "wheel 계정이 존재하지 않습니다." >> $target
    u45_safe_check=$((u45_safe_check+1))
fi

if [[ $u45_su_perm -eq 4750 && "$u45_su_perm_other" == "---" ]];then
    echo "/usr/bin/su 파일의 권한이 적절하게 설정되어 있습니다." >> $target
else
    echo "/usr/bin/su 파일의 권한이 $(stat -c "%A" /usr/bin/su) 로 적절하지 않게 설정되어 있습니다." >> $target
    u45_safe_check=$((u45_safe_check+1))
fi

if [ -f "/etc/pam.d/su" ];then
    u45_pam=$(grep -v "#" "/etc/pam.d/su" | grep auth | grep required | grep pam_wheel.so | egrep -E "use_uid|debug\s*group=wheel")
    if [ -n "$u45_pam" ];then
        echo "/etc/pam.d/su 파일 내에 pam_wheel.so 모듈을 사용하여 wheel 그룹의 사용자들만 su 명령을 사용할 수 있게 제한하고 있습니다." >> $target
    else
        echo "/etc/pam.d/su 파일 내에 whell 그룹의 사용자들만 su명령을 사용하도록 하는 설정값이 존재하지 않습니다." >> $target
        u45_safe_check=$((u45_safe_check+1))
    fi
else
    echo "/etc/pam.d/su 파일이 존재하지 않습니다." >> $target
fi

if [ $u45_safe_check -ge 1 ];then
    u45=$((u45+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u45 -ge 1 ]];then
    Low=$((Low+1))
    Account_Management=$((Account_Management+1))
    u45_Account_Management=1
fi

cat << EOF
===== [U-46] Set password minimum length              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-46 패스워드 최소 길이 설정              " >> $target
echo "--------------------------------------------------------------------------" >> $target-F: '{print $4}'
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 패스워드 최소 길이 설정이 적용되어 있는지 점검하여 짧은(8자 미만) 패스워드 길이로 발생하는 취약점을 이용한 공격(무작위 대입 공격, 사전 대입 공격 등)에 대한 대비(사용자 패스워드 유출)가 되어 있는지 확인하기 위함" >> $target
echo "보안위협 : 패스워드 문자열이 짧은 경우 유추가 가능 할 수 있으며 암호화된 패스워드 해시값을 무작위 대입공격, 사전대입 공격 등으로 단시간에 패스워드 크렉이 가능함" >> $target
echo "+판단기준 양호 : 패스워드 최소 길이가 8자 이상으로 설정되어 있는 경우 " >> $target
echo "+판단기준 취약 : 패스워드 최소 길이가 8자 미만으로 설정되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-46 점검 결과" >> $result
u46_Account_Management=0
u46_safe_check=0
u46=0
if [ -f "/etc/pamd.d/system-auth" ];then
    u46_systemauth_min=$(grep -v "^\s*#" "/etc/pam.d/system-auth" | grep -iE "^\s*password" | grep -i "min|minlen" | grep -oP 'min=\K\d+|minlen=\K\d+')
    if [ -n "$u46_systemauth_min" ];then
        echo "/etc/pam.d/system-auth 파일내에 패스워드 최소 길이 옵션값이 존재합니다." >> $target
        if [ $u46_systemauth_min -gt 90 ];then
            echo "패스워드 최소 길이 설정이 90 이상으로 부적절하게 설정되어 있습니다." >> $target
            echo "현재 설정 값 : $u46_systemauth_min" >> $target
            u46_safe_check=$((u46_safe_check+1)) 
        else
            echo "패스워드 최소 길이 설정이 90 이하로 적절하게 설정되어 있습니다." >> $target
        fi
    else
        echo ""/etc/pam.d/system-auth 파일내에 패스워드 최소 길이 옵션값이 존재하지 않습니다."" >> $target
    fi
fi
if [ -f "/etc/security/pwquality.conf" ];then
    echo "패스워드 최소길이 설정파일인 /etc/security/pwquality.conf 파일이 존재합니다." >> $target
    u46_pwqualuty_passlen=$(grep -v "^\s*#" "/etc/security/pwquality.conf" | grep -i "minlen" | awk -F= '{print $2}' | tr -d ' ')
    if [ -n "$u46_pwqualuty_passlen" ];then
        if [ $u46_pwqualuty_passlen -lt 8 ];then
            echo "패스워드 최소 길이가 8미만으로 부적절하게 설정되어 있습니다." >> $target
            echo "현재 설정 값 : $u46_pwqualuty_passlen" >> $target
            u46_safe_check=$((u46_safe_check+1)) 
        else
            echo "패스워드 최소 길이가 8이상으로 적절하게 설정되어 있습니다." >> $target
        fi
    else
        echo "/etc/security/pwquality.conf 파일은 조재하지만 관련 설정값이 존재하지 않습니다." >> $target
    fi
else
    echo "패스워드 최소길이 설정파일인 /etc/security/pwquality.conf 파일이 존재하지 않습니다." >> $target
fi
if [ -f "/etc/login.defs" ];then
    echo "패스워드 최소길이 설정파일인 /etc/login.defs 파일이 존재합니다.">> $target
    u46_logindefs_passlen=$(grep -v "^\s*#" "/etc/login.defs" | grep -i "pass_min_len" | awk '{print $2}')
    if [ -n "$u46_logindefs_passlen" ];then
        if [ $u46_logindefs_passlen -lt 8 ];then
            echo "패스워드 최소 길이가 8미만으로 부적절하게 설정되어 있습니다." >> $target
            echo "현재 설정 값 : $u46_logindefs_passlen" >> $target
            u46_safe_check=$((u46_safe_check+1)) 
        else
            echo "패스워드 최소 길이가 8이상으로 적절하게 설정되어 있습니다." >> $target
        fi
    else
        echo "/etc/login.defs 파일은 조재하지만 관련 설정값이 존재하지 않습니다." >> $target
        u46_safe_check=$((u46_safe_check+1)) 
    fi
else
    echo "패스워드 최소길이 설정파일인 /etc/login.defs 파일이 존재하지 않습니다." >> $target
fi
if [ $u46_safe_check -ge 1 ];then
    u46=$((u46+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u46 -ge 1 ]];then
    Mid=$((Mid+1))
    Account_Management=$((Account_Management+1))
    u46_Account_Management=1
fi

cat << EOF
===== [U-47] Setting the password maximum usage period              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-47 패스워드 최대 사용기간 설정              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 패스워드 최대 사용 기간 설정이 적용되어 있는지 점검하여 시스템 정책에서 사용자 계정의 장기간 패스워드 사용을 방지하고 있는지 확인하기 위함" >> $target
echo "보안위협 : 패스워드 최대 사용기간을 설정하지 않은 경우 비인가자의 각종 공격(무작위 대입 공격, 사전 대입 공격 등)을 시도할 수 있는 기간 제한이 없으므로 공격자 입장에서는 장기적인 공격을 시행할 수 있어 시행한 기간에 비례하여 사용자 패스워드가 유출될 수 있는 확률이 증가함" >> $target
echo "+판단기준 양호 : 패스워드 최대 사용기간이 90일(12주) 이하로 설정되어 있는 경우" >> $target
echo "+판단기준 취약 : 패스워드 최대 사용기간이 90일(12주) 이하로 설정되어 있지 않는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-47 점검 결과" >> $result
u47_Account_Management=0
u47_safe_check=0
u47=0
if [ -f "/etc/login.defs" ];then
    echo "패스워드 최대 사용기간 설정파일인 /etc/login.defs 파일이 존재합니다." >> $target
    u47_logindefs_maxdays=$(grep -v "^\s*#" "/etc/login.defs" | grep -i "PASS_MAX_DAYS" | awk '{print $2}')
    if [ -n "$u47_logindefs_maxdays" ];then
        if [ $u47_logindefs_maxdays -gt 90 ];then
            echo "패스워드 최대 사용기간이 90 이상으로 부적절하게 설정되어 있습니다." >> $target
            echo "현재 설정 값 : $u47_logindefs_maxdays" >> $target
            u47_safe_check=$((u47_safe_check+1))
        else
            echo "패스워드 최대 사용기간이 90 이하로 적절하게 설정되어 있습니다." >> $target
        fi
    else
        echo "/etc/login.defs 파일에 패스워드 최대 기간 설정값이 존재하지 않습니다." >> $target
        u47_safe_check=$((u47_safe_check+1))
    fi
else
    echo "패스워드 최대 사용기간 설정파일인 /etc/login.defs 파일이 존재하지 않습니다." >> $target
fi

if [ $u47_safe_check -ge 1 ];then
    u47=$((u47+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u47 -ge 1 ]];then
    Mid=$((Mid+1))
    Account_Management=$((Account_Management+1))
    u47_Account_Management=1
fi

cat << EOF
===== [U-48] Setting the minimum password usage period              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-48 패스워드 최소 사용기간 설정              " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 사용자가 자주 패스워드를 변경할 수 없도록 하고 관련 설정(최근 암호 기억)과 함께 시스템에 적용하여 패스워드 변경 전에 사용했던 패스워드를 재사용 할 수 없도록 방지하는지 확인하기 위함" >> $target
echo "보안위협 : ※ 최소 사용기간이 설정되어 있지 않아 반복적으로 즉시 변경이 가능한 경우 이전 패스워드 기억 횟수를 설정하여도 반복적으로 즉시 변경하여 이전 패스워드로 설정이 가능함" >> $target
echo "+판단기준 양호 : 패스워드 최소 사용기간이 1일 이상 설정되어 있는 경우" >> $target
echo "+판단기준 취약 : 패스워드 최소 사용기간이 설정되어 있지 않는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-48 점검 결과" >> $result
u48_Account_Management=0
u48_safe_check=0
u48=0
if [ -f "/etc/login.defs" ];then
    echo "패스워드 최소길이 설정파일인 /etc/login.defs 파일이 존재합니다." >> $target
    u48_logindefs_mindays=$(grep -v "^\s*#" "/etc/login.defs" | grep -i "PASS_MIN_DAYS" | awk '{print $2}')
    if [ -n "$u48_logindefs_mindays" ];then
        if [ $u48_logindefs_mindays -le 1 ];then
            echo "패스워드 최소 사용기간이 1 미만으로 부적절하게 설정되어 있습니다." >> $target
            echo "현재 설정 값 : $u48_logindefs_mindays" >> $target
            u48_safe_check=$((u48_safe_check+1))
        else
            echo "패스워드 최소 사용기간이 1 이상으로 적절하게 설정되어 있습니다." >> $target
        fi
    else
        echo "/etc/login.defs 파일에 패스워드 최소 기간 설정값이 존재하지 않습니다." >> $target
        u48_safe_check=$((u48_safe_check+1))
    fi
else
    echo "패스워드 최소길이 설정파일인 /etc/login.defs 파일이 존재하지 않습니다." >> $target
fi

if [ $u48_safe_check -ge 1 ];then
    u48=$((u48+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u48 -ge 1 ]];then
    Mid=$((Mid+1))
    Account_Management=$((Account_Management+1))
    u48_Account_Management=1
fi

cat << EOF
===== [U-49] Remove unnecessary accounts              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-49 불필요한 계정 제거              " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 불필요한 계정이 존재하는지 점검하여 관리되지 않은 계정에 의한 침입에 대비하는지 확인하기 위함" >> $target
echo "보안위협 : 로그인이 가능하고 현재 사용하지 않는 불필요한 계정은 사용중인 계정보다 상대적으로 관리가 취약하여 공격자의 목표가 되어 계정이 탈취될 수 있음" >> $target
echo " ※ 퇴직, 전직, 휴직 등의 사유발생시 즉시 권한을 회수" >> $target
echo "+판단기준 양호 : 불필요한 계정이 존재하지 않는 경우" >> $target
echo "+판단기준 취약 : 불필요한 계정이 존재하는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-49 점검 결과" >> $result
u49_Account_Management=0
u49_safe_check=0
u49_general_users=($(egrep -v "root|nologin|shutdown|sync|halt|false" "/etc/passwd" | awk -F: '{print $1}'))
u49=0
u49_idx=0
u49_never_loggeds=($(lastlog | grep -i 'Never logged in' | awk '{print $1}'))
u49_corrent_timestamp=$(date +%s)
u49_2weeks_check=0


u49_lastlog_dates=($(lastlog | grep -vi 'Never logged in' | awk '{for (i=3; i<=NF; i++) printf "%s%s", $i, (i < NF ? OFS : "\n")}'  | sed '1d'))
u49_lastlog_timestamps=()

for u49_date_str in "${u49_lastlog_dates[@]}"; do
    u49_timestamp=$(date -d "$u49_date_str" +%s 2>/dev/null)
    if [ $? -eq 0 ]; then
        u49_lastlog_timestamps+=("$u49_timestamp")
    fi
done

u49_lastlog_users=($(lastlog | grep -vi 'Never logged in' | awk 'NR>1 {print $1}'))
u49_two_weeks_seconds=$((14 * 24 * 60 * 60))

if [ -n "$u49_general_users" ];then
    echo "root 제외한 시스템 사용자 목록입니다. 불필요한 계정이 존재할 경우 삭제조치 바랍니다." >> $target
    for u49_general_user in "${u49_general_users[@]}";do
        echo "$u49_general_user" >> $target
    done
else
    echo "root 제외한 시스템 사용자 목록이 존재하지 않습니다." >> $target
fi


if [ -n "$u49_never_loggeds" ];then
    echo "계정 생성 후 시스템에 로그인한 적 없는 계정들입니다. 불필요한 경우 삭제 조치 바랍니다." >> $target
    u49_safe_check=$((u49_safe_check+1))
    for u49_never_logged in "${u49_never_loggeds[@]}";do
        echo "계정 명 : $u49_never_logged" >> $target
    done
else
    echo "시스템에 로그인한 적 없는 계정이 존재하지 않습니다." >> $target
fi

if [ ${#u49_general_users[@]} -gt 0 ];then
    echo "시스템에 2주 이상 로그인(접근) 기록이 없는 계정 목록입니다. 불필요한 경우 삭제 조치 바랍니다." >> $target
    u49_safe_check=$((u49_safe_check+1))
    for u49_lastlog_user in "${u49_lastlog_users[@]}";do
        if (( u49_lastlog_timestamps[u49_idx] <= u49_corrent_timestamp - u49_two_weeks_seconds )); then
            echo "$u49_lastlog_user"
        else
            u49_2weeks_check=$((u49_2weeks_check+1))
        fi
        u49_idx=$((u49_idx+1))
    done
    if [ $u49_2weeks_check -ge 1 ];then
        echo "시스템에 2주 이상 로그인(접근) 기록이 없는 계정이 존재하지 않습니다." >> $target
    fi
fi

if [ $u49_safe_check -ge 1 ];then
    u49=$((u49+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u49 -ge 1 ]];then
    Low=$((Low+1))
    Account_Management=$((Account_Management+1))
    u49_Account_Management=1
fi

cat << EOF
===== [U-50] Include minimal accounts in administrator groups              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-50 관리자 그룹에 최소한의 계정 포함              " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 관리자 그룹에 최소한의 계정만 존재하는지 점검하여 불필요하게 권한이 남용되고 있는지 확인하기 위함" >> $target
echo "보안위협 : 시스템을 관리하는 root 계정이 속한 그룹은 시스템 운영 파일에 대한 접근 권한이 부여되어 있으므로 해당 관리자 그룹에 속한 계정이 비인가자에게 유출될 경우 관리자 권한으로 시스템에 접근하여 계정 정보 유출, 환경설정 파일 및 디렉터리 변조 등의 위협이 존재함" >> $target
echo "+판단기준 양호 : 관리자 그룹에 불필요한 계정이 등록되어 있지 않은 경우" >> $target
echo "+판단기준 취약 : 관리자 그룹에 불필요한 계정이 등록되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-50 점검 결과" >> $result
u50_Account_Management=0
u50_safe_check=0
u50=0
u50_rootgroup=$(cat /etc/group | grep root | awk -F: '{print $4}')

if [ -n "$u50_rootgroup" ];then
    echo "root 계정의 그룹에 포함된 계정입니다. 불필요한 계정이 존재할 경우 제거 조치 바랍니다." >> $target
    echo "$u50_rootgroup" >> $target
    u50_safe_check=$((u50_safe_check+1))
else
    echo "root 계정의 그룹에 포함된 계정들이 존재하지 않습니다." >> $target
fi

if [ $u50_safe_check -ge 1 ];then
    u50_safe_check=$((u50_safe_check+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u50 -ge 1 ]];then
    Low=$((Low+1))
    Account_Management=$((Account_Management+1))
    u50_Account_Management=1
fi 

cat << EOF
===== [U-51] Prohibiting GIDs whose accounts do not exist              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-51 계정이 존재하지 않는 GID 금지              " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 시스템에 불필요한 그룹이 존재하는지 점검하여 불필요한 그룹의 소유권으로 설정되어 있는 파일의 노출에 의해 발생할 수 있는 위험에 대한 대비가 되어 있는지 확인하기 위함" >> $target
echo "보안위협 : 계정이 존재하지 않는 그룹은 현재 사용되고 있는 그룹이 아닌 불필요한 그룹으로 삭제 조치가 필요함" >> $target
echo "+판단기준 양호 : 시스템 관리나 운용에 불필요한 그룹이 삭제 되어있는 경우" >> $target
echo "+판단기준 취약 : 시스템 관리나 운용에 불필요한 그룹이 존재할 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-51 점검 결과" >> $result
u51_Account_Management=0
u51_safe_check=0
u51=0
# /etc/passwd 파일에서 GID 목록 추출
u51_gid_list=$(cut -d: -f4 /etc/passwd | sort -u)

echo "계정이 존재하지 않는 그룹이 존재할 경우 아래에 출력됩니다." >> $target  

# GID 목록을 순회하면서 /etc/group에 없는 GID 찾기 
for u51_gid in $u51_gid_list; do
    if ! grep -q ":$u51_gid:" /etc/group; then
        echo "GID $u51_gid 는 /etc/group에 존재하지 않습니다." >> $target
        u51_safe_check=$((u51_safe_check+1))
    fi
done

# /etc/group 파일을 순회하면서 존재하지 않는 사용자 찾기
echo "존재하지 않는 사용자 목록이 존재할 경우 아래에 출력됩니다." >> $target
u51_count=0
while IFS=: read -r u51_group_name _ _ u51_group_users; do
    IFS=',' read -ra u51_users <<< "$u51_group_users"
    for u51_user in "${u51_users[@]}"; do
        if [[ -n "$u51_user" ]] && ! grep -q "^$u51_user:" /etc/passwd; then
            echo "그룹 $u51_group_name 에 속한 사용자 $u51_user 는 /etc/passwd에 존재하지 않습니다." >> $target
            u51_safe_check=$((u51_safe_check+1))
        else
            u51_count=$((u51_count+1))
        fi
    done
done < /etc/group

if [[ $u51_count -ge 1 ]];then
    echo "각각의 그룹 내에 존재하지 않는 사용자는 없습니다." >> $target
fi

if [ $u51_safe_check -ge 1 ];then
    u51=$((u51+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u51 -ge 1 ]];then
    Low=$((Low+1))
    Account_Management=$((Account_Management+1))
    u51_Account_Management=1
fi

cat << EOF
===== [U-52] Do not allow the same UID              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-52 동일한 UID 금지              " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : UID가 동일한 사용자 계정을 점검함으로써 타 사용자 계정 소유의 파일 및 디렉터리로의 악의적 접근 예방 및 침해사고 시 명확한 감사추적을 목적으로 함" >> $target
echo "보안위협 : 중복된 UID가 존재할 경우 시스템은 동일한 사용자로 인식하여 소유자의 권한이 중복되어 불필요한 권한이 부여되며 시스템 로그를 이용한 감사 추적시 사용자가 구분되지 않음 (권한 할당은 그룹권한을 이용하여 운영)" >> $target
echo "+판단기준 양호 : 동일한 UID로 설정된 사용자 계정이 존재하지 않는 경우" >> $target
echo "+판단기준 취약 : 동일한 UID로 설정된 사용자 계정이 존재하는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-52 점검 결과" >> $result
u52_Account_Management=0
u52_safe_check=0
u52=0
u52_user_uid=$(awk -F: '{print $3}' "/etc/passwd" 2> /dev/null)
u52_uniq_uids=$(awk -F: '{print $3}' "/etc/passwd" 2> /dev/null | sort | uniq -d | paste -sd '|')
u52_uniq_users=$(awk -F: '{print $1, $3}' /etc/passwd 2> /dev/null | egrep -iw "$u52_uniq_uids" | sort -r)
readarray -t u52_lines <<< "$u52_uniq_users"


if [ -n "$u52_uniq_uids" ];then
    echo "동일한 UID를 가진 계정들이 존재합니다." >> $target
    for i in "${u52_lines[@]}";do
        echo "$i" >> $target >> $target
        u52_safe_check=$((u52_safe_check+1))
    done
else
    echo "동일한 UID를 가진 계정들이 존재하지 않습니다." >> $target
fi

if [ $u52_safe_check -ge 1 ];then
    u52=$((u52+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u52 -ge 1 ]];then
    Mid=$((Mid+1))
    Account_Management=$((Account_Management+1))
    u52_Account_Management=1
fi

cat << EOF
===== [U-53] Check user shell              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-53 사용자 shell 점검              " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 로그인이 불필요한 계정에 쉘 설정을 제거하여, 로그인이 필요하지 않은 계정을 통한 시스템 명령어를 실행하지 못하게 하기 위함" >> $target
echo "보안위협 : 로그인이 불필요한 계정은 일반적으로 OS 설치 시 기본적으로 생성되는 계정으로 쉘이 설정되어 있을 경우, 공격자는 기본 계정들을 이용하여 시스템에 명령어를 실행 할 수 있음" >> $target
echo "+판단기준 양호 : 로그인이 필요하지 않은 계정에 /bin/false(/sbin/nologin) 쉘이 부여되어 있는 경우" >> $target
echo "+판단기준 취약 : 로그인이 필요하지 않은 계정에 /bin/false(/sbin/nologin) 쉘이 부여되지 않은 경우" >> $target
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++w+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-53 점검 결과" >> $result
u53_Account_Management=0
u53_safe_check=0
u53=0

u53_passwd_lists=$(sudo awk -F: '($3 <= 999 || $3 >= 60000) && $1 != "root" {
    split($7, u53_path, "/");
    u53_shell = u53_path[length(u53_path)];
    if (u53_shell != "nologin" && u53_shell != "false" && u53_shell != "sync" && u53_shell != "shutdown" && u53_shell != "halt") {
        print $1, $7;
    }
}' /etc/passwd
)
u53_shadow_lists=$(awk -F: '($2 == "*" || $2 == "!!") {print $1}' /etc/shadow)

if [ -n "$u53_passwd_lists" ];then
    echo "일반 사용자가 아닌 계정에 대해 Shell이 부여되어 있습니다." >> $target
    u53_safe_check=$((u53_safe_check+1))
    for u53_passwd_list in "${u53_passwd_lists[@]}";do
        echo "$u53_passwd_list" >> $target
    done
fi

readarray -t u53_user_list <<< "$u53_shadow_lists"
u53_result=""
u53_check='for u53_user in "${u53_user_list[@]}"; do
    u53_result+=$(awk -F: -v u53_user="$u53_user" '\''($1 == u53_user) {
        split($7, u53_path, "/");
        shell = u53_path[length(u53_path)];
        if (shell != "nologin" && shell != "false" && shell != "sync" && shell != "shutdown" && shell != "halt") {
            print $1, $7;
        }
    }'\'' /etc/passwd)
done'

if [[ ${#u53_user_list[@]} -gt 0 ]]; then
    eval "$u53_check"
    if [[ -n "$u53_result" ]]; then
        echo "패스워드를 필요로 하지 않는, 격리된 계정에 대해 쉘이 설정되어 있습니다." >> $target
        u53_safe_check=$((u53_safe_check+1))
        echo "$u53_result" >> $target
    else
        echo "/etc/shadow 파일에서 격리된 계정에 대해 전부 쉘이 설정되어 있지 않습니다." >> $target
    fi
else
    echo "'*' 혹은 '!!' 으로 설정된 계정이 /etc/shadow 파일에 존재하지 않습니다." >> $target
fi

if [ $u53_safe_check -ge 1 ];then
    u53=$((u53+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u53 -ge 1 ]];then
    Low=$((Low+1))
    Account_Management=$((Account_Management+1))
    u53_Account_Management=1
fi

cat << EOF
===== [U-54] Session timeout setting              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-54 Session Timeout 설정             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 사용자의 고의 또는 실수로 시스템에 계정이 접속된 상태로 방치됨을 차단하기 위함" >> $target
echo "보안위협 : Session timeout 값이 설정되지 않은 경우 유휴 시간 내 비인가자의 시스템 접근으로 인해 불필요한 내부 정보의 노출 위험이 존재함" >> $target
echo "+판단기준 양호 : Session Timeout이 600초(10분) 이하로 설정되e어 있는 경우" >> $target
echo "+판단기준 취약 : Session Timeout이 600초(10분) 이하로 설정되지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-54 점검 결과" >> $result
u54_Account_Management=0
u54_safe_check=0
u54=0
u54_files=("/etc/bash.bashrc" "/etc/zsh/zshrc" "/etc/ksh.kshrc" "/etc/profile" "/etc/.profile")
u54_individual_files=(".bashrc" ".zshrc" ".kshrc" ".bash_profile")
u54_dirs=("/etc/profile.d/*.sh" "/etc/profile.d/*.csh" "/etc/profil.d/*.ksh")
u54_csh_files=("/etc/csh.cshrc" "/etc/csh.login")
u54_csh_individual_files=(".cshrc" ".login")
u54_check_users=($(awk -F':' '!/\/sbin|false|sync/ {print $1}' /etc/passwd))

for u54_check_dir in ${u54_dirs[@]}; do
    for u54_dir in $u54_check_dir; do
        if [ -e "$u54_dir" ]; then
            echo "$u54_dir 파일이 존재합니다." >> $target
            u54_dir_tmoutsh=$(grep -Ev "^\s*#" "$u54_dir" | grep -Ei "^\s*TMOUT" | tr -d ' ' | awk -F'=' '{print $2}')
            if [ -n "$u54_dir_tmoutsh" ]; then
                echo "$u54_dir 파일에 세션 타임아웃 설정 값이 존재합니다." >> $target
                if [ "$u54_dir_tmoutsh" -le 600 ]; then
                    echo "세션 타임아웃 설정 값이 600이하로 적절하게 설정되어 있습니다." >> $target
                    echo "현재 설정 값 : $u54_dir_tmoutsh" >> $target
                else   
                    echo "세션 타임아웃 설정 값이 600이상으로 부적절하게 설정되어 있습니다." >> $target
                    echo "현재 설정 값 : $u54_dir_tmoutsh" >> $target
                    u54_safe_check=$((u54_safe_check+1))
                fi
            else
                echo "$u54_dir 파일에 세션 타임아웃 설정 값이 존재하지 않습니다." >> $target
                u54_safe_check=$((u54_safe_check+1))
            fi
        fi
    done
done

for u54_file in "${u54_files[@]}"; do
    if [ -e "$u54_file" ]; then
        echo "$u54_file 파일이 존재합니다." >> $target
        u54_file_tmout=$(grep -Ev "^\s*#" "$u54_file" | grep -Ei "^\s*TMOUT" | tr -d ' ' | awk -F'=' '{print $2}')
        if [ -n "$u54_file_tmout" ]; then
            echo "$u54_file 파일에 세션 타임아웃 설정 값이 존재합니다." >> $target
            if [ "$u54_file_tmout" -le 600 ]; then
                echo "세션 타임아웃 설정 값이 600이하로 적절하게 설정되어 있습니다." >> $target
                echo "현재 설정 값 : $u54_file_tmout" >> $target
            else   
                echo "세션 타임아웃 설정 값이 600이상으로 부적절하게 설정되어 있습니다." >> $target
                echo "현재 설정 값 : $u54_file_tmout" >> $target
                u54_safe_check=$((u54_safe_check+1))
            fi
        else
            echo "$u54_file 파일에 세션 타임아웃 설정 값이 존재하지 않습니다." >> $target
            u54_safe_check=$((u54_safe_check+1))
        fi
    fi
done

for u54_csh_file in "${u54_csh_files[@]}"; do
    if [ -e "$u54_csh_file" ]; then
        echo "$u54_csh_file 파일이 존재합니다." >> $target
        u54_cshfile_tmout=$(grep -Ev "^\s*#" "$u54_csh_file" | grep -Ei "^\s*set\s*autologout" | tr -d ' ' | awk -F'=' '{print $2}')
        if [ -n "$u54_cshfile_tmout" ]; then
            echo "$u54_csh_file 파일에 세션 타임아웃 설정 값이 존재합니다." >> $target
            if [ "$u54_cshfile_tmout" -le 10 ]; then
                echo "세션 타임아웃 설정 값이 10이하로 적절하게 설정되어 있습니다." >> $target
                echo "현재 설정 값 : $u54_cshfile_tmout" >> $target
            else   
                echo "세션 타임아웃 설정 값이 10이상으로 부적절하게 설정되어 있습니다." >> $target
                echo "현재 설정 값 : $u54_cshfile_tmout" >> $target
                u54_safe_check=$((u54_safe_check+1))
            fi
        else
            echo "$u54_csh_file 파일에 세션 타임아웃 설정 값이 존재하지 않습니다." >> $target
            u54_safe_check=$((u54_safe_check+1))
        fi
    fi
done

for u54_check_user in "${u54_check_users[@]}"; do
    u54_user_home=$(getent passwd "$u54_check_user" | awk -F':' '{print $6}')
    if [ -d "$u54_user_home" ]; then
        echo "--------------------------------------"  >> $target
        echo "$u54_check_user 의 홈 디렉터리가 존재합니다." >> $target
        for u54_individual_file in "${u54_individual_files[@]}"; do
            echo -e "Checking file: $u54_user_home/$u54_individual_file"  >> $target
            if [ -e "$u54_user_home/$u54_individual_file" ]; then
                echo "$u54_user_home/$u54_individual_file 파일이 존재합니다."  >> $target
                u54_check_timeout=$(grep -Ev "^\s*#" "$u54_user_home/$u54_individual_file" | grep -Ei "^\s*TMOUT" | tr -d ' ' | awk -F'=' '{print $2}')
                if [ -n "$u54_check_timeout" ]; then
                    echo "$u54_user_home/$u54_individual_file 파일에 세션 타임아웃 설정 값이 존재합니다." >> $target
                    if [ "$u54_check_timeout" -le 600 ]; then
                        echo "세션 타임아웃 설정 값이 600이하로 적절하게 설정되어 있습니다." >> $target
                        echo "현재 설정 값 : $u54_check_timeout" >> $target
                    else   
                        echo "세션 타임아웃 설정 값이 600이상으로 부적절하게 설정되어 있습니다." >> $target
                        echo "현재 설정 값 : $u54_check_timeout" >> $target
                        u54_safe_check=$((u54_safe_check+1))
                    fi
                else
                    echo "$u54_user_home/$u54_individual_file 파일에 세션 타임아웃 설정 값이 존재하지 않습니다." >> $target
                    u54_safe_check=$((u54_safe_check+1))
                fi
            else
                echo "$u54_user_home/$u54_individual_file 파일이 존재하지 않습니다." >> $target
            fi
        done
        for u54_csh_individual_file in "${u54_csh_individual_files[@]}"; do
            echo -e "Checking file: $u54_user_home/$u54_csh_individual_file"  >> $target
            if [ -e "$u54_user_home/$u54_csh_individual_file" ]; then
                echo "$u54_user_home/$u54_csh_individual_file 파일이 존재합니다."  >> $target
                u54_check_timeout=$(grep -Ev "^\s*#" "$u54_user_home/$u54_csh_individual_file" | grep -Ei "^\s*set\s*autologout" | tr -d ' ' | awk -F'=' '{print $2}')
                if [ -n "$u54_check_timeout" ]; then
                    echo "$u54_user_home/$u54_csh_individual_file 파일에 세션 타임아웃 설정 값이 존재합니다." >> $target
                    if [ "$u54_check_timeout" -le 10 ]; then
                        echo "세션 타임아웃 설정 값이 10이하로 적절하게 설정되어 있습니다." >> $target
                        echo "현재 설정 값 : $u54_check_timeout" >> $target
                    else   
                        echo "세션 타임아웃 설정 값이 10이상으로 부적절하게 설정되어 있습니다." >> $target
                        echo "현재 설정 값 : $u54_check_timeout" >> $target
                        u54_safe_check=$((u54_safe_check+1))
                    fi
                else
                    echo "$u54_user_home/$u54_csh_individual_file 파일에 세션 타임아웃 설정 값이 존재하지 않습니다." >> $target
                    u54_safe_check=$((u54_safe_check+1))
                fi
            else
                echo "$u54_user_home/$u54_csh_individual_file 파일이 존재하지 않습니다." >> $target
            fi
        done
    else
        echo "$u54_check_user 의 홈 디렉터리가 존재하지 않습니다." >> $target
    fi
done

if [ $u54_safe_check -ge 1 ];then
    u54=$((u54+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u54 -ge 1 ]];then
    Low=$((Low+1))
    Account_Management=$((Account_Management+1))
    u54_Account_Management=1
fi

cat << EOF
===== [U-55] hosts.lpd file owner and permission settings              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-55 hosts.lpd 파일 소유자 및 권한 설정             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 비인가자의 임의적인 hosts.lpd 변조를 막기 위해 hosts.lpd 파일 삭제 또는 소유자 및 권한 관리를 해야 함" >> $target
echo "보안위협 : hosts.lpd 파일의 접근권한이 적절하지 않을 경우 비인가자가 /etc/hosts.lpd 파일을 수정하여 허용된 사용자의 서비스를 방해할 수 있으며, 호스트 정보를 획득 할 수 있음" >> $target
echo "+판단기준 양호 : hosts.lpd 파일이 삭제되어 있거나 불가피하게 hosts.lpd 파일을 사용할 시 파일의 소유자가 root이고 권한이 600인 경우" >> $target
echo "+판단기준 취약 : hosts.lpd 파일이 삭제되어 있지 않거나 파일의 소유자가 root가 아니고 권한이 600이 아닌 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-55 점검 결과" >> $result
u55=0
u55_Files_Directory_Management=0
u55_safe_check=0
if [[ -e "/etc/hosts.lpd" ]];then
    echo "/etc/hosts.lpd 파일이 존재합니다." >> $target
    u55_hostsfile_owner=$(stat -c "%U" "/etc/hosts.lpd")
    u55_hostsfile_perm=$(stat -c "%a" "/etc/hosts.lpd")
    if [[ $shadowfile_owner == "root" ]];then
        if [[ $shadowfile_perm -eq 600 ]];then
            echo "/etc/hosts.lpd 파일 소유자가 root 이며, 권한이 600 으로 적절하게 설정되어 있습니다." >> $target
            echo "현재 설정 값 : $shadowfile_perm" >> $target
        else
            echo "/etc/hosts.lpd 파일 권한이 600이 아닌 값으로 설정되어 취약합니다. " >> $target
            echo "현재 설정 값 : $shadowfile_perm" >> $target
            u55_safe_check=$((u55_safe_check+1))
        fi
    else
        echo "/etc/hosts.lpd 파일 소유자가 root 사용자가 아니므로 취약합니다."  >> $target
        echo "현재 설정 값 : $shadowfile_owner" >> $target
        u55_safe_check=$((u55_safe_check+1))
    fi
else
    echo "/etc/hosts.lpd 파일이 존재하지 않습니다." >> $target
fi

if [[ $u55_safe_check -ge 1 ]];then
    u55=$((u55+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u55 -ge 1 ]];then
    Low=$((Low+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u55_Files_Directory_Management=1
fi

cat << EOF
===== [U-56] Managing UMASK Settings              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-56  UMASK 설정 관리             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 잘못 설정된 UMASK 값으로 인해 신규 파일에 대한 과도한 권한 부여되는 것을 방지하기 위함" >> $target
echo "보안위협 : 잘못된 UMASK 값으로 인해 파일 및 디렉터리 생성시 과도하게 퍼미션이 부여 될 수 있다." >> $target
echo "+판단기준 양호 : UMASK 값이 022 이상으로 설정된 경우" >> $target
echo "+판단기준 취약 : UMASK 값이 022 이상으로 설정되지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-56 점검 결과" >> $result

u56_Files_Directory_Management=0
u56_safe_check=0
u56=0
u56_files=("/etc/bash.bashrc" "/etc/zsh/zshrc" "/etc/ksh.kshrc" "/etc/profile" "/etc/.profile" "/etc/login.defs" "/etc/default/useradd" "/etc/default/login" "/etc/.login")
u56_individual_files=(".bashrc" ".zshrc" ".kshrc" ".bash_profile" ".cshrc" ".login" )
u56_dirs=("/etc/profile.d/*.sh" "/etc/profile.d/*.csh" "/etc/profile.d/*.ksh")
u56_csh_files=("/etc/csh.cshrc" "/etc/csh.login")

u56_check_users=($(awk -F':' '!/sbin|sync|false/ {print $1}' /etc/passwd))

u56_to_decimal() {
    printf "%d\n" "$((8#$1))"
}
u56_umask=$(u56_to_decimal 022)
for u56_check_dir in ${u56_dirs[@]}; do
    for u56_dir in $u56_check_dir; do
        if [ -e "$u56_dir" ]; then
            echo "$u56_dir 파일이 존재합니다." >> $target
            IFS=$'\n' u56_dir_umasksh=($(grep -Ev "^\s*#" "$u56_dir" | grep -Ei "^\s*umask" | awk '{print $2}'))
            if [ -n "$u56_dir_umasksh" ]; then
                echo "$u56_dir umask 설정 값이 존재합니다." >> $target
                for u56_dir_umask in "${u56_dir_umasksh[@]}";do
                    u56_dec_dir=$(u56_to_decimal $u56_dir_umasksh)
                    if [ $u56_dec_dir -ge $u56_umask ]; then
                        echo "umask 설정 값이 022이상으로 적절하게 설정되어 있습니다." >> $target
                        echo "현재 설정 값 : $u56_dir_umask" >> $target
                    else   
                        echo "umask 설정 값이 022이하로 부적절하게 설정되어 있습니다." >> $target
                        echo "현재 설정 값 : $u56_dir_umask" >> $target
                        u56_safe_check=$((u56_safe_check+1))
                    fi
                done
            else
                echo "$u56_dir 파일에 umask 설정 값이 존재하지 않습니다." >> $target
                u56_safe_check=$((u56_safe_check+1))
            fi
        fi
    done
done

for u56_file in "${u56_files[@]}"; do
    if [ -e "$u56_file" ]; then
        echo "$u56_file 파일이 존재합니다." >> $target
        u56_file_umask=($(grep -Ev "^\s*#" "$u56_file" | grep -Ei "^\s*umask" | awk '{print $2}'))
        if [ -n "$u56_file_umask" ]; then
            echo "$u56_file umask 설정 값이 존재합니다." >> $target
            for u56_umask_value in "${u56_file_umask[@]}"; do
                u56_dec_file=$(u56_to_decimal "$u56_umask_value")    
                if [ "$u56_dec_file" -ge "$u56_umask" ]; then
                    echo "umask 설정 값이 022이상으로 적절하게 설정되어 있습니다." >> $target
                    echo "현재 설정 값 : $u56_umask_value" >> $target
                else   
                    echo "umask 설정 값이 022이하로 부적절하게 설정되어 있습니다." >> $target
                    echo "현재 설정 값 : $u56_umask_value" >> $target
                    u56_safe_check=$((u56_safe_check+1))
                fi
            done    
        else
            echo "$u56_file 파일에 umask 설정 값이 존재하지 않습니다." >> $target
            u56_safe_check=$((u56_safe_check+1))
        fi
    fi
done

for u56_csh_file in "${u56_csh_files[@]}"; do
    if [ -e "$u56_csh_file" ]; then
        echo "$u56_csh_file 파일이 존재합니다." >> $target
        u56_cshfile_umask=($(grep -Ev "^\s*#" "$u56_csh_file" | grep -Ei "^\s*umask" | awk '{print $2}'))
        if [ -n "$u56_cshfile_umask" ]; then
            echo "$u56_csh_file umask 설정 값이 존재합니다." >> $target
            for u56_csh_umask in "${u56_cshfile_umask[@]}";do
                u56_dec_cshfile=$(u56_to_decimal $u56_csh_umask)
                if [ $u56_dec_cshfile -ge $u56_umask ]; then
                    echo "umask 설정 값이 022이상으로 적절하게 설정되어 있습니다." >> $target
                    echo "현재 설정 값 : $u56_csh_umask" >> $target
                else   
                    echo "umask 설정 값이 022이하로 부적절하게 설정되어 있습니다." >> $target
                    echo "현재 설정 값 : $u56_csh_umask" >> $target
                    u56_safe_check=$((u56_safe_check+1))
                fi
            done
        else
            echo "$u56_csh_file 파일에 umask 설정 값이 존재하지 않습니다." >> $target
            u56_safe_check=$((u56_safe_check+1))
        fi
    fi
done

for u56_check_user in "${u56_check_users[@]}"; do
    u56_user_home=$(getent passwd "$u56_check_user" | awk -F':' '{print $6}')w
    if [ -d "$u56_user_home" ]; then
        echo "--------------------------------------"  >> $target
        echo "$u56_check_user 의 홈 디렉터리가 존재합니다." >> $target
        for u56_individual_file in "${u56_individual_files[@]}"; do
            echo -e "Checking file: $u56_user_home/$u56_individual_file"  >> $target
            if [ -e "$u56_user_home/$u56_individual_file" ]; then
                echo "$u56_user_home/$u56_individual_file 파일이 존재합니다."  >> $target
                u56_check_umask=($(grep -Ev "^\s*#" "$u56_user_home/$u56_individual_file" | grep -Ei "^\s*umask" | awk '{print $2}'))
                if [ -n "$u56_check_umask" ]; then
                    echo "$u56_user_home/$u56_individual_file 파일에 umask 설정 값이 존재합니다." >> $target
                    for u56_individual_umask in "${u56_check_umask[@]}";do
                    u56_dec_userumask=$(u56_to_decimal $u56_individual_umask)
                    if [ $u56_dec_userumask -ge $u56_umask ]; then
                        echo "umask 설정 값이 022이상으로 적절하게 설정되어 있습니다." >> $target
                        echo "현재 설정 값 : $u56_individual_umask" >> $target
                    else   
                        echo "umask 설정 값이 022이하로 부적절하게 설정되어 있습니다." >> $target
                        echo "현재 설정 값 : $u56_individual_umask" >> $target
                        u56_safe_check=$((u56_safe_check+1))
                    fi
                    done
                else
                    echo "$u56_user_home/$u56_individual_file 파일에 파일에 umask 설정 값이 존재하지 않습니다." >> $target
                    u56_safe_check=$((u56_safe_check+1))
                fi
            else
                echo "$u56_user_home/$u56_individual_file 파일이 존재하지 않습니다." >> $target
            fi
        done
    else
        echo "$u56_check_user 의 홈 디렉터리가 존재하지 않습니다." >> $target
    fi
done

if [[ $u56_safe_check -ge 1 ]];then
    u56=$((u56+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u56 -ge 1 ]];then
    Mid=$((Mid+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u56_Files_Directory_Management=1
fi

cat << EOF
===== [U-57] Set Home Directory Owners and Permissions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-57  홈디렉토리 소유자 및 권한 설정             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 사용자 홈 디렉터리 내 설정파일이 비인가자에 의한 변조를 방지함" >> $target
echo "보안위협 : 홈 디렉터리 내 설정파일 변조 시 정상적인 서비스 이용이 제한될 우려가 존재함" >> $target
echo "+판단기준 양호 : 홈 디렉터리 소유자가 해당 계정이고, 타 사용자 쓰기 권한이 제거된 경우" >> $target
echo "+판단기준 취약 : 홈 디렉터리 소유자가 해당 계정이 아니고, 타 사용자 쓰기 권한이 부여된  경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-57 점검 결과" >> $result

u57_Files_Directory_Management=0
u57_safe_check=0
u57=0
u57_check_users=($(awk -F':' '!/sbin|sync|false/ {print $1}' /etc/passwd))

for u57_check_user in "${u57_check_users[@]}"; do
    u57_user_home=$(getent passwd "$u57_check_user" | awk -F':' '{print $6}')
    if [ -d "$u57_user_home" ]; then
        echo "--------------------------------------"   >> $target
        echo "$u57_check_user 의 홈 디렉터리가 존재합니다."  >> $target
        u57_dir_owner=$(stat -c "%U" "$u57_user_home")
        u57_dir_other=$(stat -c "%A" "$u57_user_home" | awk '{print substr($0, length($0)-1)}' | grep -i "w")
        if [ "$u57_dir_owner" == "$u57_check_user" ];then
            if [ -n "$u57_dir_other" ];then
                echo "홈 디렉터리의 기타 사용자(Other)에 대한 쓰기 권한이 부여되어 있습니다." >> $target
                echo "현재 설정값 : $u57_dir_other" >> $target
                u57_safe_check=$((u57_safe_check+1))
            else
                echo "홈 디렉터리 소유자가 해당 계정으로 되어 있으며, 타 사용자 쓰기 권한이 제거되어 있습니다." >> $target
                echo "현재 설정값 : $u57_dir_owner , $(stat -c "%A" "$u57_user_home")" >> $target
            fi
        else
            echo "홈 디렉터리 소유자가 해당 계정이 아닙니다." >> $target
            echo "현재 설정값 : $u57_dir_owner" >> $target
            u57_safe_check=$((u57_safe_check+1))
        fi
    fi 
done

if [[ $u57_safe_check -ge 1 ]];then
    u57=$((u57+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u57 -ge 1 ]];then
    Mid=$((Mid+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u57_Files_Directory_Management=1
fi

cat << EOF
===== [U-58] Managing the existence of a directory that you specify as your home directory              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-58 홈디렉토리로 지정한 디렉토리의 존재 관리             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : /home 이외 사용자의 홈 디렉터리 존재 여부를 점검하여 비인가자가 시스템 명령어의 무단 사용을 방지하기 위함" >> $target
echo "보안위협 : passwd 파일에 설정된 홈디렉터리가 존재하지 않는 경우, 해당 계정으로 로그인시 홈디렉터리가 루트 디렉터리(“/“)로 할당되어 접근이 가능함" >> $target
echo "+판단기준 양호 : 홈 디렉터리가 존재하지 않는 계정이 발견되지 않는 경우" >> $target
echo "+판단기준 취약 : 홈 디렉터리가 존재하지 않는 계정이 발견된 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-58 점검 결과" >> $result

u58_safe_check=0
u58_Files_Directory_Management=0
u58=0
IFS=$'\n' u58_check_users=($(awk -F':' '!/sbin|sync|false/ && $1 != "root" {print $1}' /etc/passwd))

for u58_check_user in "${u58_check_users[@]}"; do
    u58_user_home=$(getent passwd "$u58_check_user" | awk -F':' '{print $6}')
    if [[ "$u58_user_home" == "/home/$u58_check_user" ]]; then
        echo "$u58_check_user 의 홈 디렉터리가 존재합니다." >> $target
    else
        echo "--------------------------------------"  >> $target
        echo "$u58_check_user 의 홈 디렉터리가 /home하위에 존재하지 않습니다." >> $target
        u58_safe_check=$((u58_safe_check+1))
    fi
done

if [[ $u58_safe_check -ge 1 ]];then
    u58=$((u58+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u58 -ge 1 ]];then
    Mid=$((Mid+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u58_Files_Directory_Management=1
fi

cat << EOF
===== [U-59] Search and remove hidden files and directories              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-59 숨겨진 파일 및 디렉토리 검색 및 제거             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 숨겨진 파일 및 디렉터리 중 의심스러운 내용은 정상 사용자가 아닌 공격자에 의해 생성되었을 가능성이 높음으로 이를 발견하여 제거함" >> $target
echo "보안위협 : 공격자는 숨겨진 파일 및 디렉터리를 통해 시스템 정보 습득, 파일 임의 변경 등을 할 수 있음" >> $target
echo "+판단기준 양호 : 불필요하거나 의심스러운 숨겨진 파일 및 디렉터리를 삭제한 경우" >> $target
echo "+판단기준 취약 : 불필요하거나 의심스러운 숨겨진 파일 및 디렉터리를 방치한 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-59 점검 결과" >> $result

u59_safe_check=0
u59_Files_Directory_Management=0
u59=0
u59_secret_file=$(find / -type f -name ".*" -atime -30 2> /dev/null)
u59_secret_dir=$(find / -type d -name ".*" -atime -30 2> /dev/null)

if [ -n "$u59_secret_file" ];then
    echo "최근 30일 동안 접근된 숨겨진 파일 목록이 존재합니다. 불필요하거나 의심스러운 파일의 경우 삭제조치가 필요합니다." >> $target
    echo "$u59_secret_file" >> $target
    u59_safe_check=$((u59_safe_check+1))
else
    echo "최근 30일 동안 접근된 숨겨진 파일이 존재하지 않습니다." >> $target
fi
if [ -n "$u59_secret_dir" ];then
    echo "최근 30일 동안 접근된 숨겨진 디렉터리 목록이 존재합니다. 불필요하거나 의심스러운 파일의 경우 삭제조치가 필요합니다." >> $target
    echo "$u59_secret_dir" >> $target
    u59_safe_check=$((u59_safe_check+1))
else
    echo "최근 30일 동안 접근된 숨겨진 디렉터리가 존재하지 않습니다." >> $target
fi

if [[ $u59_safe_check -ge 1 ]];then
    u59=$((u59+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u59 -ge 1 ]];then
    Low=$((Low+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u59_Files_Directory_Management=1
fi

cat << EOF
===== [U-60] Allow ssh remote access              =====w
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-60 ssh 원격접속 허용             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 비교적 안전한 SSH 프로토콜을 사용함으로써 스니핑 등 아이디/패스워드의 누출의 방지를 목적으로함" >> $target
echo "보안위협 : 원격 접속 시 Telnet, FTP 등은 암호화되지 않은 상태로 데이터를 전송하기 때문에 아이디/패스워드 및 중요 정보가 외부로 유출될 위험성이 있음" >> $target
echo "+판단기준 양호 : 원격 접속 시 SSH 프로토콜을 사용하는 경우" >> $target
echo "※ ssh, telnet이 동시에 설치되어 있는 경우 취약한 것으로 평가됨" >> $target
echo "+판단기준 취약 : 원격 접속 시 Telnet, FTP 등 안전하지 않은 프로토콜을 사용하는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-60 점검 결과" >> $result

u60_safe_check=0
u60_Service_Management=0
u60=0
u60_ssh_checks=("ssh" "sshd")
u60_telnet_ftp_checks=("telnet" "vsftpd" "proftpd")

u60_telnet_ports=("23" "21" "20")

# 함수 호출
u60_ssh_port=("22")  # 단일 포트 번호를 배열 형태로 설정

check_service_status "${u60_ssh_port[@]}" "${u60_ssh_checks[@]}"
if [ $? -eq 1 ]; then
    check_service_status "${u60_telnet_ports}" "${u60_telnet_ftp_checks[@]}"
    if [ $? -eq 1 ]; then
        echo "ssh 서비스와 함께 telnet 또는 ftp 서비스를 사용하고 있습니다." >> $target
        u60_safe_check=$((u60_safe_check+1))
    else
        echo "ssh 프로토콜만을 사용하고 있습니다." >> $target
    fi
else
    echo "ssh 프로토콜을 사용하지 않고 있습니다." >> $target
    u60_safe_check=$((u60_safe_check+1))
fi

if [[ $u60_safe_check -ge 1 ]];then
    u60=$((u60+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u60 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u60_Service_Management=1
fi

cat << EOF
===== [U-61] Check ftp service              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-61 ftp 서비스 확인             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 취약한 서비스인 FTP서비스를 가급적 제한함을 목적으로 함" >> $target
echo "보안위협 : FTP 서비스는 통신구간이 평문으로 전송되어 계정정보(아이디, 패스워드) 및 전송 데이터의 스니핑이 가능함" >> $target
echo "+판단기준 양호 : FTP 서비스가 비활성화 되어 있는 경우" >> $target
echo "+판단기준 취약 : FTP 서비스가 활성화 되어 있는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-60 점검 결과" >> $result

u61_safe_check=0
u61_Service_Management=0
u61=0
# 값 설정
u61_ftp_checks=("ftp" "vsftpd" "proftpd")

u61_ftp_ports=("21" "20")

check_service_status "${u61_ftp_ports}" "${u61_ftp_checks[@]}"
if [[ $? -eq 1 ]]; then
    echo "ftp 서비스를 사용하고 있습니다." >> $target
    u61_safe_check=$((u61_safe_check+1))
else
    echo "ftp 서비스를 사용하고 있지 않습니다." >> $target
fi

if [[ $u61_safe_check -ge 1 ]];then
    u61=$((u61+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u61 -ge 1 ]];then
    Low=$((Low+1))
    Service_Management=$((Service_Management+1))
    u61_Service_Management=1
fi

cat << EOF
===== [U-62] restricting tp account shell              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-62 tp 계정 shell 제한             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : FTP 서비스 설치 시 기본으로 생성되는 ftp 계정은 로그인이 필요하지 않은 계정으로 쉘을 제한하여 해당 계정으로의 시스템 접근을 차단하기 위함" >> $target
echo "보안위협 :  불필요한 기본 계정에 쉘(Shell)을 부여할 경우, 공격자에게 해당 계정이 노출되어 ftp 기본 계정으로 시스템 접근하여 공격이 가능해" >> $target
echo "+판단기준 양호 : ftp 계정에 /bin/false 쉘이 부여되어 있는 경우" >> $target
echo "+판단기준 취약 : ftp 계정에 /bin/false 쉘이 부여되어 있지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-62 점검 결과" >> $result
u62_safe_check=0
u62_Service_Management=0
u62=0
u62_ftp_shell=$(grep -i "ftp" "/etc/passwd" | awk -F':' '{print $7}' | awk -F'/' '{print $NF}')
u62_check_safe_shells=("nologin" "false" "ftp-only")

if [ -n "$u62_ftp_shell" ];then
    echo "ftp 계정이 존재합니다." >> $target
    u62_check=0
    for u62_check_safe_shell in "${u62_check_safe_shells[@]}";do
        if [[ "$u62_ftp_shell" == "$u62_check_safe_shell" ]];then
            echo "ftp 계정의 shell 이 $u62_ftp_shell 로 설정되어 있습니다." >> $target
            u62_check=$((u62_check+1))
            break
        else   
            if [ $u62_check -eq 1 ];then
                echo "ftp 계정의 shell 이 $u62_ftp_shell 로 설정되어 있습니다." >> $target
                u62_safe_check=$((u62_safe_check+1))
            fi
        fi
    done
else
    echo "ftp 계정이 존재하지 않습니다." >> $target
fi
if [[ $u62_safe_check -ge 1 ]];then
    u62=$((u62+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u62 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u62_Service_Management=1
fi

cat << EOF
===== [U-63] ftpersus file owner and permission settings              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-63 ftpusers 파일 소유자 및 권한 설정             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 비인가자들의 ftp 접속을 차단하기 위해 ftpusers 파일 소유자 및 권한을 관리해야함" >> $target
echo "보안위협 : ftpusers 파일에 인가되지 않은 사용자를 등록하여 해당 계정을 이용, 불법적인 FTP 서비스에 접근이 가능함" >> $target
echo "+판단기준 양호 : ftpusers 파일의 소유자가 root이고, 권한이 640 이하인 경우" >> $target
echo "+판단기준 취약 : tpusers 파일의 소유자가 root가 아니거나, 권한이 640 이하가 아닌경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-63 점검 결과" >> $result

u63=0
u63_safe_check=0
u63_Service_Management=0
u63_check_ftpfiles=("/etc/ftpusers" "/etc/ftpd/ftpusers" "/etc/vsftpd/ftpusers" "/etc/vsftpd/user_list" "/etc/vsftpd.user_list")
u63_safe_check=0
for u63_check_ftpfile in "${u63_check_ftpfiles[@]}";do
    if [ -e "$u63_check_ftpfile" ];then
        echo "$u63_check_ftpfile 파일이 존재합니다."  >> $target
        u63_file_owner=$(stat -c "%U" "$u63_check_ftpfile" 2> /dev/null)
        u63_file_perm_user=$(stat -c "%a" "$u63_check_ftpfile" 2> /dev/null | cut -c1)
        u63_file_perm_group=$(stat -c "%a" "$u63_check_ftpfile" 2> /dev/null | cut -c2)
        u63_file_perm_other=$(stat -c "%a" "$u63_check_ftpfile" 2> /dev/null | cut -c3)
        if [[ "$u63_file_owner" == "root" ]];then
            echo "$u63_check_ftpfile 파일의 소유자가 root로 설정되어 있습니다."  >> $target
            if [[ $u63_file_perm_user -le 6 ]];then
                echo "$u63_check_ftpfile 파일의 소유 권한이 6이하로 설정되어 있습니다."  >> $target
                if [[ $u63_file_perm_group -le 4 ]];then
                    echo "$u63_check_ftpfile 파일의 소유 그룹 권한이 4이하로 설정되어 있습니다."  >> $target
                    if [[ $u63_file_perm_other -eq 0 ]];then
                        echo "$u63_check_ftpfile 파일의 기타 사용자(Other)의 권한이 0으로 설정되어 있습니다."  >> $target
                    else
                        echo "$u63_check_ftpfile 파일의 기타 사용자(Other)의 권한이 0이상으로 설정되어 있습니다."  >> $target
                        u63_safe_check=$((u63_safe_check+1))
                    fi
                else
                    echo "$u63_check_ftpfile 파일의 소유 그룹 권한이 4이상으로 설정되어 있습니다."  >> $target
                    u63_safe_check=$((u63_safe_check+1))
                fi
            else
                echo "$u63_check_ftpfile 파일의 소유 권한이 6이상으로 설정되어 있습니다."  >> $target
                u63_safe_check=$((u63_safe_check+1))
            fi
        else
            echo "$u63_check_ftpfile 파일의 소유자가 root가 아닌 다른 사용자로 되어 있습니다."  >> $target
            u63_safe_check=$((u63_safe_check+1))
        fi
    else
        echo "$u63_check_ftpfile 파일이 존재하지 않습니다."  >> $target
    fi
done

if [[ $u63_safe_check -ge 1 ]];then
    u63=$((u63+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi

if [[ $u63 -ge 1 ]];then
    Low=$((Low+1))
    Service_Management=$((Service_Management+1))
    u62_Service_Management=1
fi

cat << EOF
===== [U-64] FTP service root account access restrictions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-64 ftpusers 파일 설정(FTP 서비스 root 계정 접근제한             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : root의 FTP 직접 접속을 방지하여 root 패스워드 정보를 노출되지 않도록 하기 위함" >> $target
echo "보안위협 : FTP 서비스는 아이디 및 패스워드가 암호화되지 않은 채로 전송되어 스니핑에 의해서 관리자 계정의 아이디 및 패스워드가 노출될 수 있" >> $target
echo "+판단기준 양호 : FTP 서비스가 비활성화 되어 있거나, 활성화 시 root 계정 접속을 차단한 경우" >> $target
echo "+판단기준 취약 : FTP 서비스가 활성화 되어 있고, root 계정 접속을 허용한 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-64 점검 결과" >> $result

u64_Service_Management=0
u64=0
u64_ftp_checks=("ftp" "vsftpd" "proftpd")
u64_ftp_ports=("21" "20")
u64_ftp_root_setting_files=("/etc/ftpusers" "/etc/ftpd/ftpusers" "/etc/vsftpd/ftpusers" "/etc/vsftpd/user_list" "/etc/vsftpd.user_list" "/etc/proftpd.conf")
u64_safe_check=0
check_service_status "${u64_ftp_ports}" "${u64_ftp_checks[@]}"
if [[ $? -eq 1 ]]; then
    echo "ftp 서비스를 사용하고 있습니다." >> $target
    u64=$((u64+1))
    for u64_ftp_root_setting_file in "${u64_ftp_root_setting_files[@]}";do
        if [ -e "$u64_ftp_root_setting_file" ];then
            echo "$u64_ftp_root_setting_file 파일이 존재합니다.">> $target
            if [[ "$u64_ftp_root_setting_file" == "/etc/proftpd.conf" ]];then
                if grep -iv "^\s*#" "$u64_ftp_root_setting_file" | grep -iqE  "^\s*RootLogin\s*on$";then
                    echo "$u64_ftp_root_setting_file 에서 root 계정 접속을 허용하고 있습니다.">> $target
                    echo "현재 설정값 : $(grep -i "RootLogin" "$u64_ftp_root_setting_file")">> $target
                    u64=$((u64+1))
                    u64_safe_check=$((u64_safe_check+1))
                else
                    echo "$u64_ftp_root_setting_file 에서 root 계정 접속을 차단 하고 있습니다.">> $target
                    echo "현재 설정값 (존재할 경우 출력): $(grep -i "RootLogin" "$u64_ftp_root_setting_file")">> $target
                fi
            else
                if grep -iv "^\s*#" "$u64_ftp_root_setting_file" | grep -iqE  "^\s*root$";then
                    echo "$u64_ftp_root_setting_file 에서 root 계정 접속을 허용하고 있습니다.">> $target
                    echo "현재 설정값 : $(grep -i "root" "$u64_ftp_root_setting_file")">> $target
                    u64=$((u64+1))
                    u64_safe_check=$((u64_safe_check+1))
                else
                    echo "$u64_ftp_root_setting_file 에서 root 계정 접속을 차단 하고 있습니다.">> $target
                    echo "현재 설정값 (존재할 경우 출력): $(grep -i "root" "$u64_ftp_root_setting_file")">> $target
                fi
            fi
        fi
    done
else
    echo "ftp 서비스를 사용하고 있지 않습니다." >> $target
    u64_safe_check=$((u64_safe_check+1))
fi
if [[ $u64_safe_check -ge 1 ]];then
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi

if [[ $u64 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u64_Service_Management=1
fi

cat << EOF
===== [U-65] Set at Service Permissions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-65 at 서비스 권한 설정             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 관리자외 at 서비스를 사용할 수 없도록 설정하고 있는지 점검하는 것을 목적으로 함" >> $target
echo "보안위협 : root 외 일반사용자에게도 at 명령어를 사용할 수 있도록 할 경우, 고의 또는 실수로 불법적인 예약 파일 실행으로 시스템 피해를 일으킬 수 있음" >> $target
echo "+판단기준 양호 : at 명령어 일반사용자 금지 및 at 관련 파일 640 이하인 경우" >> $target
echo "+판단기준 취약 : at 명령어 일반사용자 사용가능하거나, at 관련 파일 640 이상인 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-65 점검 결과" >> $result

u65_Service_Management=0
u65=0
u65_path_at=$(which at)
u65_Other_at_perm=$(stat -c "%a" "$u65_path_at"  2> /dev/null| rev | cut -c1 | rev)
u65_at_files=("/etc/at.allow" "/etc/at.deny")
u65_safe_check=0
if [ -e "$u65_path_at" ];then
    if ! [[ $u65_Other_at_perm -eq 0 ]];then
        echo "at 명령어에 대한 기타 사용자(Other)에 대한 권한이 주어져 있습니다." >> $target
        u65=$((u65+1))
        u65_safe_check=$((u65_safe_check+1))
    else
        echo "at 명령어에 대한 기타 사용자(Other)에 대한 권한이 주어져 있지 않습니다." >> $target
        for u65_at_file in "${u65_at_files[@]}";do
            if [ -e "$u65_at_file" ];then
                echo "$u65_at_file 이 존재합니다." >> $target
                u65_at_file_owner=$(stat -c "%a" "$u65_at_file"  2> /dev/null| cut -c1)
                u65_at_file_group=$(stat -c "%a" "$u65_at_file"  2> /dev/null| cut -c2)
                u65_at_file_other=$(stat -c "%a" "$u65_at_file"  2> /dev/null| cut -c3)
                u65_check_suid=$(stat -c "%a" "$u65_at_file"  2> /dev/null| tr -d '\n' | wc -c)
                if [[ $u65_check_suid -ge 4 ]];then
                    echo "$u65_at_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> $target
                    u65_safe_check=$((u65_safe_check+1))
                else
                    if [ $u65_at_file_owner -le 6 ];then
                        echo "$u65_at_file 파일의 소유 권한이 6이하로 설정되어 있습니다." >> $target
                        if [ $u65_at_file_group -le 4 ];then
                            echo "$u65_at_file 파일의 소유 그룹 권한이 4이하로 설정되어 있습니다." >> $target
                            if [ $u65_at_file_other -eq 0 ];then
                                echo "$u65_at_file 파일의 기타 사용자(Other) 권한이 0으로 설정되어 있습니다." >> $target
                            else
                                echo "$u65_at_file 파일의 기타 사용자(Other) 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                                u65_safe_check=$((u65_safe_check+1))
                            fi
                        else
                            ehco "$u65_at_file 파일의 소유 그룹 권한이 4이상으로 설정되어 있습니다." >> $target
                            u65_safe_check=$((u65_safe_check+1))
                        fi
                    else
                        echo "$u65_at_file 파일의 소유 권한이 6이상으로 설정되어 있습니다." >> $target
                        u65_safe_check=$((u65_safe_check+1)) >> $target
                    fi
                fi
            else
                echo "$u65_at_file 이 존재하지 않습니다." >> $target
            fi
        done
    fi
else
    echo "at 실행파일이 존재하지 않습니다."  >> $target
fi

if [[ $u65_safe_check -ge 1 ]];then
    u65=$((u65+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u65 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u65_Service_Management=1
fi

cat << EOF
===== [U-66] Check SNMP service drive...              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-66 SNMP 서비스 구동 점검             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 불필요한 SNMP 서비스 활성화로 인해 필요 이상의 정보가 노출되는 것을 막기 위해 SNMP 서비스를 중지해야함" >> $target
echo "보안위협 : SNMP 서비스로 인하여 시스템의 주요 정보 유출 및 정보의 불법수정이 발생할 수 있음" >> $target
echo "+판단기준 양호 : SNMP 서비스를 사용하지 않는 경우" >> $target
echo "+판단기준 취약 : SNMP 서비스를 사용하는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-66 점검 결과" >> $result

u66_Service_Management=0
u66_safe_check=0
u66=0
u66_snmp_checks=("snmp" "snmpd")
u66_snmp_ports=("161" "162")

check_service_status "${u66_snmp_ports}" "${u66_snmp_checks[@]}"
if [[ $? -eq 1 ]]; then
    echo "snmp 서비스를 사용하고 있습니다.">> $target
    66_safe_check=$((66_safe_check+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "snmp 서비스를 사용하지 않고 있습니다.">> $target
    echo "점검 결과 : 양호" >> $result
fi

if [[ $u66_safe_check -ge 1 ]];then
    u66=$((u66+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u66 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u66_Service_Management=1
fi

cat << EOF
===== [U-67] Configuring the Complexity of SNMP Service Community Strings              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-67 SNMP 서비스 Community String의 복잡성 설정             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : Community String 기본 설정인 Public, Private는 공개된 내용으로 공격자가 이를 이용하여 SNMP 서비스를 통해 시스템 정보를 얻을 수 있기 때문에 Community String을 유추하지 못하도록 설정해야함" >> $target
echo "보안위협 : Community String은 Default로 public, private로 설정된 경우가 많으며, 이를 변경하지 않으면 이 String을 악용하여 환경설정 파일 열람 및 수정을 통한 공격, 간단한 정보수집에서부터 관리자 권한 획득 및 Dos공격까지 다양한 형태의 공격이 가능함" >> $target
echo "+판단기준 양호 : SNMP Community 이름이 public, private 이 아닌 경우" >> $target
echo "+판단기준 취약 : SNMP Community 이름이 public, private 인 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-67 점검 결과" >> $result

u67_Service_Management=0
u67_safe_check=0
u67=0
u67_snmpd_conf_paths=($(find / -type f -name "snmpd.conf" 2> /dev/null))
if [ -n "$u67_snmpd_conf_paths" ];then
    for u67_snmpd_conf_path in "${u67_snmpd_conf_paths[@]}";do
        if [ -e "$u67_snmpd_conf_path" ];then
            echo "$u67_snmpd_conf_path 파일이 존재합니다." >> $target
            u67_check_string=$(grep -v "^\s*#" "$u67_snmpd_conf_path" 2> /dev/null | grep -i "public" | grep -i "private")
            if [ -n "$u67_check_string" ];then
                echo "SNMP Community 이름이 public, private로 설정되어 있습니다." >> $target
                echo "현재 설정값 : $u67_check_string" >> $target
                u67_safe_check=$((u67_safe_check+1))
            else
                echo "SNMP Community 이름이 public, private로 설정되어 있지 않습니다." >> $target
                echo "현재 설정값 : $u67_check_string" >> $target
            fi
        fi
    done
else
    echo "snmp 설정파일이 존재하지 않습니다." >> $target
fi

if [[ $u67_safe_check -ge 1 ]];then
    u67=$((u67+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u67 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u67_Service_Management=1
fi

cat << EOF
===== [U-68] Provides a warning message when logged on              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-68 로그온 시 경고 메시지 제공             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 비인가자들에게 서버에 대한 불필요한 정보를 제공하지 않고, 서버 접속 시 관계자만 접속해야 한다는 경각심을 심어 주기위해 경고 메시지 설정이 필요함" >> $target
echo "보안위협 : 로그인 배너가 설정되지 않을 경우 배너에 서버 OS 버전 및 서비스 버전이 공격자에게 노출될 수 있으며 공격자는 이러한 정보를 통하여 해당 OS 및 서비스의 취약점을 이용하여 공격을 시도할 수 있음" >> $target
echo "+판단기준 양호 : 서버 및 Telnet, FTP, SMTP, DNS 서비스에 로그온 메시지가 설정되어 있는 경우" >> $target
echo "+판단기준 취약 : 서버 및 Telnet, FTP, SMTP, DNS 서비스에 로그온 메시지가 설정되어 있지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-68 점검 결과" >> $result

u68_Service_Management=0
u68_safe_check=0
u68=0
u68_check_files=("motd" "inssue.net" "vsftpd.conf" "proftpd.conf" "main.cf" "sendmail.cf" "named.conf") 
u68_safe_check=0
for u68_check_file in "${u68_check_files[@]}";do
    u68_find_file=$(find / -type f -name "$u68_check_file" 2> /dev/null)
    if [ -e "$u68_find_file" ];then
        echo "$u68_find_file 파일이 존재합니다." >> $target
        u68_file_name=$(basename "$u68_find_file")
        case $u68_file_name in
            "motd")
                if [[ $(wc -c < "$u68_find_file") -ge 1 ]];then
                    echo "$u68_file_name 파일 내에 로그온 메시지가 설정되어 있습니다." >> $target
                else
                    echo "$u68_file_name 파일 내에 로그온 메시지가 출력되어 있지 않습니다." >> $target
                    u68_safe_check=$((u68_safe_check+1))
                fi
                ;;
            "inssue.net")
                if [[ $(wc -c < "$u68_find_file") -ge 1 ]];then
                    echo "$u68_file_name 파일 내에 로그온 메시지가 설정되어 있습니다." >> $target
                else
                    echo "$u68_file_name 파일 내에 로그온 메시지가 출력되어 있지 않습니다." >> $target
                    u68_safe_check=$((u68_safe_check+1))
                fi
                ;;
            "vsftpd.conf")
                if grep -v "^\s*#" "$u68_find_file" | grep -iqE "^\s*ftpd_banner\s*=\s*.";then
                    echo "$u68_file_name 파일 내에 로그온 메시지가 설정되어 있습니다." >> $target
                else
                    echo "$u68_file_name 파일 내에 로그온 메시지가 출력되어 있지 않습니다." >> $target
                    u68_safe_check=$((u68_safe_check+1))
                fi
                ;;
            "proftpd.conf")
                if grep -v "^\s*#" "$u68_find_file" | grep -iqE "^\s*ServerIdent\s*on\s*.";then
                    echo "$u68_file_name 파일 내에 로그온 메시지가 설정되어 있습니다." >> $target
                else
                    echo "$u68_file_name 파일 내에 로그온 메시지가 출력되어 있지 않습니다." >> $target
                    u68_safe_check=$((u68_safe_check+1))
                fi                ;;
            "main.cf")
                if grep -v "^\s*#" "$u68_find_file" | grep -iqE "^\s*smtpd_banner\s*=\s*.";then
                    echo "$u68_file_name 파일 내에 로그온 메시지가 설정되어 있습니다." >> $target
                else
                    echo "$u68_file_name 파일 내에 로그온 메시지가 출력되어 있지 않습니다." >> $target
                    u68_safe_check=$((u68_safe_check+1))
                fi 
                ;;
            "sendmail.cf")
                if grep -v "^\s*#" "$u68_find_file" | grep -iqE "^\s*O\s*SmtpGreetingMessage\s*=\s*.";then
                    echo "$u68_file_name 파일 내에 로그온 메시지가 설정되어 있습니다." >> $target
                else
                    echo "$u68_file_name 파일 내에 로그온 메시지가 출력되어 있지 않습니다." >> $target
                    u68_safe_check=$((u68_safe_check+1))
                fi 
                ;;
            "named.conf")
                 if grep -q "logging" "$u68_find_file";then
                    echo "$u68_file_name 파일 내에 로그온 메시지가 설정되어 있습니다." >> $target
                else
                    echo "$u68_file_name 파일 내에 로그온 메시지가 출력되어 있지 않습니다." >> $target
                    u68_safe_check=$((u68_safe_check+1))
                fi 
                ;;
            *)
                echo "해당 파일은 존재하지 않는 파일입니다.: $file" >> $target
                ;;
        esac
    fi
done
if [[ $u68_safe_check -ge 1 ]];then
    u68=$((u68+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u68 -ge 1 ]];then
    Low=$((Low+1))
    Service_Management=$((Service_Management+1))
    u68_Service_Management=1
fi


cat << EOF
===== [U-69] NFS Configuration File Access Permissions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-69 NFS 설정파일 접근권한             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 비인가자에 의한 불법적인 외부 시스템 마운트를 차단하기 위해 NFS 접근 제어 파일의 소유자 및 파일 권한을 설정" >> $target
echo "보안위협 : NFS 접근제어 설정파일에 대한 권한 관리가 이루어지지 않을 시 인가되지 않은 사용자를 등록하고 파일시스템을 마운트하여 불법적인 변조를 시도할 수 있음" >> $target
echo "+판단기준 양호 : NFS 접근제어 설정파일의 소유자가 root 이고, 권한이 644 이하인 경우" >> $target
echo "+판단기준 취약 : NFS 접근제어 설정파일의 소유자가 root 가 아니거나, 권한이 644 이하가 아닌 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-69 점검 결과" >> $result

u69_Service_Management=0
u69_safe_check=0
u69=0
if [ -e "/etc/exports" ];then
    echo "exports 파일이 존재 합니다." >> $target
    u69_file_owner=$(stat -c "%U" "/etc/exports" 2> /dev/null)
        u69_file_perm_user=$(stat -c "%a" "/etc/exports" 2> /dev/null | cut -c1)
        u69_file_perm_group=$(stat -c "%a" "/etc/exports" 2> /dev/null | cut -c2)
        u69_file_perm_other=$(stat -c "%a" "/etc/exports" 2> /dev/null | cut -c3)
        if [[ "$u69_file_owner" == "root" ]];then
            echo "/etc/exports 파일의 소유자가 root로 설정되어 있습니다." >> $target
            if [[ $u69_file_perm_user -le 6 ]];then
                echo "/etc/exports 파일의 소유 권한이 6이하로 설정되어 있습니다." >> $target
                if [[ $u69_file_perm_group -le 4 ]];then
                    echo "/etc/exports 파일의 소유 그룹 권한이 4이하로 설정되어 있습니다." >> $target
                    if [[ $u69_file_perm_other -le 4 ]];then
                        echo "/etc/exports 파일의 기타 사용자(Other)의 권한이 4이하로 설정되어 있습니다." >> $target
                    else
                        echo "/etc/exports 파일의 기타 사용자(Other)의 권한이 6이상으로 설정되어 있습니다." >> $target
                        u69_safe_check=$((u69_safe_check+1))
                    fi
                else
                    echo "/etc/exports 파일의 소유 그룹 권한이 4이상으로 설정되어 있습니다." >> $target
                    u69_safe_check=$((u69_safe_check+1))
                fi
            else
                echo "/etc/exports 파일의 소유 권한이 6이상으로 설정되어 있습니다." >> $target
                u69_safe_check=$((u69_safe_check+1))
            fi
        else
            echo "/etc/exports 파일의 소유자가 root가 아닌 다른 사용자로 되어 있습니다." >> $target
            u69_safe_check=$((u69_safe_check+1))
        fi
else
    echo "exports 파일이 존재하지 않습니다." >> $target
fi
if [[ $u69_safe_check -ge 1 ]];then
    u69=$((u69+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi

if [[ $u69 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u69_Service_Management=1
fi

cat << EOF
===== [U-70] NFS Configuration File Access Permissions              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-70 NFS 설정파일 접근권한             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : SMTP 서비스의 expn, vrfy 명령을 통한 정보 유출을 막기 위하여 두 명령어를 사용하지 못하게 옵션을 설정해야함" >> $target
echo "보안위협 : VRFY, EXPN 명령어를 통하여 특정 사용자 계정의 존재유무를 알 수 있고, 사용자의 정보를 외부로 유출 할 수 있음" >> $target
echo "+판단기준 양호 : SMTP 서비스 미사용 또는, noexpn, novrfy 옵션이 설정되어 있는 경우" >> $target
echo "+판단기준 취약 : SMTP 서비스를 사용하고, noexpn, novrfy 옵션이 설정되어 있지 않는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-70 점검 결과" >> $result

u70_Service_Management=0
u70_safe_check=0
u70=0
u70_snmp_checks=("snmp" "snmpd")
u70_snmp_ports=("161" "162")
u70_safe_check=0

check_service_status "${u70_snmp_ports}" "${u70_snmp_checks[@]}"
if [[ $? -eq 1 ]]; then
    echo "snmp 서비스를 사용하고 있습니다.">> $target
    u70_safe_check=$((u70_safe_check+1))
else
    echo "snmp 서비스를 사용하지 않고 있습니다.">> $target
fi

u70_files=("sendmail.cf" "main.cf")
for u70_file in "${u70_files[@]}";do
    u70_file_path=$(find / -type f -name "$u70_file" 2> /dev/null)
    if [ -n "$u70_file_path" ];then
        echo "$u70_file 파일이 존재합니다.">> $target
        if [[ "$u70_file" == "sendmail.cf" ]];then
            u70_check_option=$(grep -vE "^\s*#" "$u70_file_path" 2> /dev/null | grep -iE "^\s*O\s*PrivacyOptions\s*=\s*." | grep -iE "noexpn|goaway" | grep -iE "novrfy|goaway")
            if [ -n "$u70_check_option" ];then
                echo "$u70_file 파일에 noexpn, novrfy 옵션이 설정되어 있습니다.">> $target
                echo "현재 설정 값 : $u70_check_option" >> $target 
            else
                echo "$u70_file 파일에 noexpn, novrfy 옵션이 설정되어 있지 않습니다.">> $target
                u70_safe_check=$((u70_safe_check+1))
            fi
        else
            u70_check_option=$(grep -vE "^\s*#" "$u70_file_path" 2> /dev/null | grep -iE "^\s*smtpd_privacy_options\s*=\s*." | grep -iE "noexpn|goaway" | grep -iE "novrfy|goaway")
            if [ -n "$u70_check_option" ];then
                echo "$u70_file 파일에 noexpn, novrfy 옵션이 설정되어 있습니다.">> $target
                echo "현재 설정 값 : $u70_check_option" >> $target
            else
                echo "$u70_file 파일에 noexpn, novrfy 옵션이 설정되어 있지 않습니다.">> $target
                u70_safe_check=$((u70_safe_check+1))
            fi
        fi
    fi
done

if [[ $u70_safe_check -ge 1 ]];then
    u70=$((u70+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi

if [[ $u70 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u70_Service_Management=1
fi


cat << EOF
===== [U-71] Hide Apache Web Services Information              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-71 Apache 웹 서비스 정보 숨김             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : HTTP 헤더, 에러페이지에서 웹 서버 버전 및 종류, OS 정보 등 웹 서버와 관련된 불필요한 정보가 노출되지 않도록 하기 위함" >> $target
echo "보안위협 : 불필요한 정보가 노출될 경우 해당 정보를 이용하여 시스템의 취약점을 수 s집할 수 있음" >> $target
echo "+판단기준 양호 : ServerTokens Prod, ServerSignature Off로 설정되어있는 경우" >> $target
echo "+판단기준 취약 : ServerTokens Prod, ServerSignature Off로 설정되어있지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-71 점검 결과" >> $result

u71_Service_Management=0
u71=0
u71_safe_check=0
u71_apache_files=("/etc/httpd/conf.d/*.conf" "/etc/httpd/sites-available/*.conf" "/etc/httpd/sites-enabled/*.conf")
u71_nginx_files=("/etc/nginx/conf.d/*.conf")
u71_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
u71_break=0
echo "※Cent OS 7 기준 Apache 메인 설정파일 경로와 Nginx 메인 설정 파일인 /etc/nginx/nginx.conf를 점검합니다. 해당 경로가 존재하지 않을 경우, 아파치 웹 서비스 구성 파일명을 토대로 파일 탐색 후 점검이 진행됩니다. 중복된 파일명이 존재할 경우 수동 점검을 권장합니다.※" >> $target
for u71_apache_home_check in "${u71_apache_home_checks[@]}";do
    u71_apache_home=$(find / -type f -name "$u71_apache_home_check" 2> /dev/null | egrep -v "tmp|temp|swap|swp")
    if [ -f "$u71_apache_home" ];then
        echo "$u71_apache_home 파일이 존재합니다." >> $target
        u71_server_tokens=$(grep -vE "^\s*#" "$u71_apache_home" | grep -i "ServerTokens" | grep -i "prod")
        u71_serversignature=$(grep -E "^\s*#" "$u71_apache_home" | grep -i "ServerSignature" | grep -i "off")
        if [ -n "$u71_server_tokens" ];then
            echo "ServerTokens 지시자의 옵션이 Prod로 설정되어 있습니다." >> $target
            echo "현재 설정 값 : $u71_server_tokens" >> $target
            if [ -n "$u71_serversignature" ];then
                echo "ServerSignature 지시자의 옵션이 off로 설정되어 있습니다." >> $target
                echo "현재 설정 값 : $u71_serversignature" >> $target
            else
                echo "ServerSignature 지시자의 옵션이 존재하지 않거나, off로 설정되어 있지 않습니다." >> $target
                u71_safe_check=$((u71_safe_check+1))
            fi
        else
            echo "ServerTokens 지시자의 옵션이 존재하지 않거나, Prod로 설정되어 있지 않습니다." >> $target
            u71_safe_check=$((u71_safe_check+1))
        fi
    else 
        if [ $u71_break -eq 1 ];then
            continue
        fi
        u71_break=$((u71_break+1))
        for u71_apache_file in "${u71_apache_files[@]}";do
            for u71_apache_check in $u71_apache_file;do
                if [ -f "$u71_apache_check" ];then
                    echo "$u71_apache_check 파일이 존재합니다." >> $target
                    u71_server_tokens=$(grep -v "^\s*#" "$u71_apache_check" | grep -i "ServerTokens" | grep -i "prod")
                    u71_serversignature=$(grep -v "^\s*#" "$u71_apache_check" | grep -i "ServerSignature" | grep -i "off")
                    if [ -n "$u71_server_tokens" ];then
                        echo "ServerTokens 지시자의 옵션이 Prod로 설정되어 있습니다." >> $target
                        echo "현재 설정 값 : $u71_server_tokens" >> $target
                        if [ -n "$u71_serversignature" ];then
                            echo "ServerSignature 지시자의 옵션이 off로 설정되어 있습니다." >> $target
                            echo "현재 설정 값 : $u71_serversignature" >> $target
                        else
                            echo "ServerSignature 지시자의 옵션이 존재하지 않거나, off로 설정되어 있지 않습니다." >> $target
                            u71_safe_check=$((u71_safe_check+1))
                        fi
                    else
                        echo "ServerTokens 지시자의 옵션이 존재하지 않거나, Prod로 설정되어 있지 않습니다." >> $target
                        u71_safe_check=$((u71_safe_check+1))
                    fi
                fi
            done
        done
    fi
done
echo "추가적인 Apache 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
if [ -f "/etc/nginx/nginx.conf" ];then
    echo "/etc/nginx/nginx.conf 파일이 존재합니다." >> $target
    u71_server_tokens_nginx=$(grep -v "^\s*#" "/etc/nginx/nginx.conf" | grep -i "server_tokens" | grep -i "off")
    if [ -n "$u71_server_tokens_nginx" ];then
        echo "server_tokens 지시자의 옵션이 off로 설정되어 있습니다." >> $target
        echo "현재 설정 값 : $u71_server_tokens_nginx" >> $target
    else
        echo "server_tokens 지시자의 옵션이 존재하지 않거나, off로 설정되어 있지 않습니다." >> $target
        u71_safe_check=$((u71_safe_check+1))
    fi
else 
    echo "/etc/nginx/nginx.conf 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> $target
    for u71_ngnix_file in ${u71_nginx_files[@]};do
        for u71_nginx_check in $u71_ngnix_file;do
            if [ -e "$u71_nginx_check" ];then
                echo "$u71_nginx_check 파일이 존재합니다." >> $target
                u71_server_tokens_nginx=$(grep -v "^\s*#" "$u71_nginx_check" | grep -i "server_tokens" | grep -i "off")
                if [ -n "$u71_server_tokens_nginx" ];then
                    echo "server_tokens 지시자의 옵션이 off로 설정되어 있습니다." >> $target
                    echo "현재 설정 값 : $u71_server_tokens_nginx" >> $target
                else
                    echo "server_tokens 지시자의 옵션이 존재하지 않거나, off로 설정되어 있지 않습니다." >> $target
                    u71_safe_check=$((u71_safe_check+1)) >> $target
                fi
            fi
        done
    done
    echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
fi

if [[ $u71_safe_check -ge 1 ]];then
    u71=$((u71+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi

if [[ $u71 -ge 1 ]];then
    Mid=$((Mid+1))
    Service_Management=$((Service_Management+1))
    u71_Service_Management=1
fi

cat << EOF
===== [U-72] Setting up system logging according to policy              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-72 정책에 따른 시스템 로깅 설정             " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 보안 사고 발생 시 원인 파악 및 각종 침해 사실에 대한 확인을 하기 위함" >> $target
echo "보안위협 : 로깅 설정이 되어 있지 않을 경우 원인 규명이 어려우며, 법적 대응을 위한 충분한 증거로 사용할 수 없음" >> $target
echo "+판단기준 양호 : 로그 기록 정책이 정책에 따라 설정되어 수립되어 있으며 보안정책에 따라 로그를 남기고 있을 경우" >> $target
echo "+판단기준 취약 : 로그 기록 정책 미수립 또는, 정책에 따라 설정되어 있지 않거나 보안정책에 따라 로그를 남기고 있지 않을 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-72 점검 결과" >> $result
u72_Log_Management=0
u72_safe_check=0
u72=0
echo "귀사의 시스템에 대한 보안 담당자와의 상담을 통해 로그 기록 정책이 정책에 따라 설정되어 수립되어 보안정책에 따라 로그를 남기고 있는지 확인해야함." >> $target


if [[ $u72_safe_check -ge 1 ]];then
    u72=$((u72+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi

if [[ $u72 -ge 1 ]];then
    Low=$((Mid+1))
    Log_Management=$((Log_Management+1))
    u72_Log_Management=1
fi











echo "위험도 (상)" >> $severity_total
echo "$High" >> $severity_total
echo "위험도 (중)" >> $severity_total 
echo "$Mid" >> $severity_total
echo "위험도 (하)" >> $severity_total
echo "$Low" >> $severity_total
 
curl -X POST http://<ip>:<port>/severity_total -H "Content-Type: application/json" -d "{\"High\":\"$High\"}" 2> /dev/null
curl -X POST http://<ip>:<port>/severity_total -H "Content-Type: application/json" -d "{\"Mid\":\"$Mid\"}" 2> /dev/null
curl -X POST http://<ip>:<port>/severity_total -H "Content-Type: application/json" -d "{\"Low\":\"$Low\"}" 2> /dev/null
curl -X POST http://<ip>:<port>/Inspection_Items -H "Content-Type: application/json" -d "{\"Account_Management\":\"$Account_Management\"}" 2> /dev/null
curl -X POST http://<ip>:<port>/Inspection_Items -H "Content-Type: application/json" -d "{\"Files_Directory_Management\":\"$Files_Directory_Management\"}" 2> /dev/null
curl -X POST http://<ip>:<port>/Inspection_Items -H "Content-Type: application/json" -d "{\"Service_Management\":\"$Service_Management\"}" 2> /dev/null
curl -X POST http://<ip>:<port>/Inspection_Items -H "Content-Type: application/json" -d "{\"Patch_Management\":\"$Patch_Management\"}" 2> /dev/null
curl -X POST http://<ip>:<port>/Inspection_Items -H "Content-Type: application/json" -d "{\"Log_Management\":\"$Log_Management\"}" 2> /dev/null
# 시스템 정보 관련 JSON 데이터를 jq를 사용하여 생성
json_data=$(jq -n \
  --arg hostname "$hostname" \
  --arg date_time "$date_time" \
  --arg info "$info" \
  --arg release "$release" \
  '{hostname: $hostname, date_time: $date_time, info: $info, release: $release}')

# 생성한 JSON 데이터를 POST 요청으로 서버에 전송
curl -X POST http://<ip>:<port>/system_info -H "Content-Type: application/json" -d "$json_data" 2> /dev/null

# 관리되는 인덱스
account_management_indices=(1 2 3 4 44 45 46 47 48 49 50 51 52 53 54)
files_directory_management_indices=(5 6 7 8 9 10 11 12 13 14 15 16 17 18 55 56 57 58 59)
service_management_indices=(19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 60 61 62 63 64 65 66 67 68 69 70 71)
patch_management_indices=(42)
log_management_indices=(43 72) # log_management_indices 추가

# 라우터 경로 및 데이터 초기화
declare -A categorys
categorys["Account_Management"]=""
categorys["Files_Directory_Management"]=""
categorys["Service_Management"]=""
categorys["Patch_Management"]=""
categorys["Log_Management"]=""

# 함수: 인덱스를 확인하고 해당 값이 1인 경우 JSON 데이터에 추가
check_and_add() {
    local var_name="u$1_$2"
    if [[ ${!var_name} -eq 1 ]]; then
        categorys[$2]+="\"u${1}_$2\":1,"
    fi
}

# 인덱스 확인 및 라우터에 값 추가
for i in "${account_management_indices[@]}"; do
    check_and_add "$i" "Account_Management"
done

for i in "${files_directory_management_indices[@]}"; do
    check_and_add "$i" "Files_Directory_Management"
done

for i in "${service_management_indices[@]}"; do
    check_and_add "$i" "Service_Management"
done

for i in "${patch_management_indices[@]}"; do
    check_and_add "$i" "Patch_Management"
done

for i in "${log_management_indices[@]}"; do
    check_and_add "$i" "Log_Management"
done

# curl 명령어로 전송
for category in "${!categorys[@]}"; do
    json_data=${categorys[$category]}
    if [[ -n $json_data ]]; then
        json_data="{${json_data%,}}" # 마지막 콤마 제거 및 JSON 포맷으로 감싸기
        #echo "Sending data to /$category: $json_data"
        curl -X POST "http://<ip>:<port>/$category" -H "Content-Type: application/json" -d "$json_data" 2> /dev/null
    fi
done
echo ''
echo ''
echo "모든 점검이 완료되었습니다. 자세한 내용은 $target 파일을 확인하십시오."

