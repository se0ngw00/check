cat << EOF
===== [U-02] Weak password complexity settings          =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-02 패스워드 복잡성 설정 미흡 점검                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo '' >> $target
echo "/etc/pam.d/login.defs 파일 점검" >> $target
echo "-------------" >> $result
echo "U-2 점검 결과" >> $result
u2=0
u2_safe_check=0
u2_Account_Management=0
if [ -e "/etc/login.defs" ]; then
    u2_defs_check_values=("PASS_MAX_DAYS" "PASS_REUSE_DAYS" "PASS_MIN_DAYS" "PASS_WARN_AGE" "PASS_MIN_LEN")

    for u2_defs_check_value in "${u2_defs_check_values[@]}"; do
        # 설정값 가져오기
        u2_defs_value=$(grep -iE "^\s*$u2_defs_check_value" /etc/login.defs | tr -d ' ' | grep -v '^#' | awk '{print $2}')

        if grep -iqE "^#.*$u2_defs_check_value[[:space:]]*([0-9]{1,4})?$" /etc/login.defs; then
            echo "$u2_defs_check_value 설정이 주석처리 되어 비활성화 되어있습니다." >> $target
            u2_safe_check=$((u2_safe_check+1))
        else
            case "$u2_defs_check_value" in
                "PASS_MAX_DAYS")
                    if grep -q "$u2_defs_check_value" /etc/login.defs; then
                    	if [[ $u2_defs_value -gt 90 ]]; then 
                        	echo "$u2_defs_check_value 의 보안권고 설정 값인 90 보다 크게 설정되어 있습니다. | 현재 설정된 값 $u2_defs_value" >> $target
                            u2_safe_check=$((u2_safe_check+1))
                    	else
                        	echo "$u2_defs_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
                    	fi
                    else
                    	echo "$u2_defs_check_value 설정값이 존재하지 않습니다."  >> $target
                    fi
                    ;;
                "PASS_REUSE_DAYS")               
                    if grep -q "$u2_defs_check_value" /etc/login.defs; then
                    	if [[ $u2_defs_value -gt 4 ]]; then 
                        	echo "$u2_defs_check_value 의 보안권고 설정 값인 4 보다 크게 설정되어 있습니다. | 현재 설정된 값 $u2_defs_value" >> $target
                            u2_safe_check=$((u2_safe_check+1))
                    	else
                        	echo "$u2_defs_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
                    	fi
                    else
                    	echo "$u2_defs_check_value 설정값이 존재하지 않습니다." >> $target
                    fi
                    ;;
                "PASS_MIN_DAYS"|"PASS_WARN_AGE")
                    if grep -q "$u2_defs_check_value" /etc/login.defs; then
                    	if [[ $u2_defs_value -gt 7 ]]; then 
                        	echo "$u2_defs_check_value 의 보안권고 설정 값인 7 보다 크게 설정되어 있습니다. | 현재 설정된 값 $u2_defs_value" >> $target
                            u2_safe_check=$((u2_safe_check+1))
                    	else
                        	echo "$u2_defs_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
                    	fi
                    else
                    	echo "$u2_defs_check_value 설정값이 존재하지 않습니다." >> $target
                    fi
                    ;;
                "PASS_MIN_LEN")
                    if grep -q "$u2_defs_check_value" /etc/login.defs; then
                    	if [[ $u2_defs_value -gt 8 ]]; then 
                        	echo "$u2_defs_check_value 의 보안권고 설정 값인 8 보다 크게 설정되어 있습니다. | 현재 설정된 값 $u2_defs_value" >> $target
                            u2_safe_check=$((u2_safe_check+1))
                    	else
                        	echo "$u2_defs_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
                    	fi
                    else
                    	echo "$u2_defs_check_value 설정값이 존재하지 않습니다." >> $target
                    fi
                    ;;
                *)
                    echo "해당 설정값이 존재하지 않습니다.: $u2_defs_check_value" >> $target
                    ;;
            esac
        fi
    done
else
    echo "/etc/login.defs 파일이 존재하지 않습니다." >> $target
fi
echo "" >> $target
echo "/etc/pam.d/common-password 파일 점검" >> $target
if [ -e "/etc/pam.d/common-password" ]; then
    u2_com_module_check=("pam_cracklib.so" "pam_pwquality.so" "pam_unix.so")
    u2_com_check=("minlen" "ucredit" "lcredit" "dcredit" "ocredit" "difok" "retry")
    u2_modules_found=0
   
    for u2_com_module in "${u2_com_module_check[@]}"; do
        # 모듈이 존재하는지 확인
        if grep -q "$u2_com_module" /etc/pam.d/common-password; then
            u2_modules_found=$((u2_modules_found + 1))
            # 설정이 존재하는 경우에만 검증 및 주석 검증
            if grep -qiE "^\s*#.*password\s+.*$u2_com_module" "/etc/pam.d/common-password"; then
                echo "패스워드 복잡성 설정($u2_com_module)이 주석처리 되어 있습니다. : 취약" >> "$target"
                u2_safe_check=$((u2_safe_check+1))
			elif [ "$u2_com_module" == "pam_unix.so" ]; then
				if grep -iE "^\s*#.*password\s+.*$u2_com_module" "/etc/pam.d/common-password" | awk '{print $1}' | grep -Eo "^#"; then
					echo "패스워드 복잡성 설정($u2_com_module)이 주석처리 되어 있습니다." >> "$target"
                    u2_safe_check=$((u2_safe_check+1))
				else grep -qiE "^\s*#.*password\s+.*$u2_com_module" "/etc/pam.d/common-password"; 
					echo "/etc/pam.d/common-password 파일이 존재하며, 패스워드 복잡도 설정($u2_com_module)이 설정되어 있습니다." >> "$target"
					#검증로직 설정 하기
					u2_com_check_value2=$(cat /etc/pam.d/common-password | grep -iE "^\s*password\s+.*$u2_com_module" | sed "s/.*$u2_com_module\s*//")
					echo "현재 $u2_com_module 모듈에 적용된 설정값은 아래와 같습니다." >> $target
					echo "$u2_com_check_value2" | sed 's/\s\+/\n/g' | while read -r u2_com_field; do
    					echo "$u2_com_field" >> $target
						done
                    u2_corrent_control_keyworld=$( grep -iE "^\s*password\s+.*$u2_com_module" "/etc/pam.d/common-password" | sed 's/ \+/\\t/g' | awk '{print $2}')
                    if [[ $u2_corrent_control_keyworld == "required" ]]; then
                        echo "$u2_com_module 모듈의 제어 키워드로 $u2_corrent_control_keyworld 로 적절하게 설정되어 있습니다." >> $target
                    else
                        echo "$u2_com_module 모듈의 제어 키워드로 $u2_corrent_control_keyworld 로 부적절하게 설정되어 있습니다." >> $target
                        u2_safe_check=$((u2_safe_check+1))
                    fi
				fi
            else
                if grep -qiE "^\s*password\s+.*$u2_com_module" /etc/pam.d/common-password; then
                    echo "/etc/pam.d/common-password 파일이 존재하며, 패스워드 복잡도 설정($u2_com_module)이 설정되어 있습니다." >> "$target"
                    for u2_com_value in "${u2_com_check[@]}"; do
                        # 설정 값 확인
                        u2_com_check_value=$(grep "$u2_com_module" /etc/pam.d/common-password | grep -o "$u2_com_value=[^ ]*" | tr -d ' ' | awk -F= '{print $2}')
                        
                        # 설정 값이 존재하는 경우에만 출력
                        if [[ -n "$u2_com_check_value" ]]; then
                            case "$u2_com_value" in	
                                "minlen")
                                    if [[ $u2_com_check_value -lt 8 ]]; then
                                        echo "$u2_com_value 의 보안 권고 설정 값인 8 보다 작게 설정되어 있습니다. | 현재 설정 값 : $u2_com_check_value" >> "$target"
                                        u2_safe_check=$((u2_safe_check+1))
                                    else
                                        echo "$com_value 의 설정값이 적절하게 설정되어 있습니다." >> "$target"
                                    fi
                                    ;;
                                "ucredit"|"lcredit"|"dcredit"|"ocredit"|"difok")
                                    if [[ $u2_com_check_value -lt 1 ]]; then
                                        echo "$u2_com_value 의 보안 권고 설정 값인 1 보다 작게 설정되어 있습니다. | 현재 설정 값 : $u2_com_check_value" >> "$target"
                                        u2_safe_check=$((u2_safe_check+1))
                                    else
                                        echo "$u2_com_value 의 설정값이 적절하게 설정되어 있습니다." >> "$target"
                                    fi 
                                    ;;
								"retry")
									if [[ $u2_com_check_value -gt 3 ]]; then
										echo "$u2_com_value 의 보안 권고 설정 값인 3 보다 크게 설정되어 있습니다. | 현재 설정 값 : $u2_com_check_value" >> "$target"
                                        u2_safe_check=$((u2_safe_check+1))
									else
										echo "$u2_com_value 의 설정값이 적절하게 설정되어 있습니다." >> "$target"
									fi
									;;
                                *)
                                    echo "알 수 없는 설정 값: $u2_com_value" >> "$target"
                                    ;;
                            esac
                        else
                            echo "$u2_com_value 설정이 존재하지 않습니다." >> "$target"
                            u2_safe_check=$((u2_safe_check+1))
                        fi
                    done
                    if [[ "$u2_com_module" == "pam_pwquality.so" || "$u2_com_module" == "pam_cracklib.so" ]]; then
                        u2_corrent_control_keyworld=$( grep -iE "^\s*password\s+.*$u2_com_module" "/etc/pam.d/common-password" | awk '{print $2}')
                        if [[ $u2_corrent_control_keyworld == "requisite" ]]; then
                            echo "$u2_com_module 모듈의 제어 키워드로 $u2_corrent_control_keyworld 로 적절하게 설정되어 있습니다." >> $target
                        else
                            echo "$u2_com_module 모듈의 제어 키워드로 $u2_corrent_control_keyworld 로 부적절하게 설정되어 있습니다." >> $target
                            u2_safe_check=$((u2_safe_check+1))
                        fi
                    fi
                else
                    echo "/etc/pam.d/common-password 파일이 존재하며, 패스워드 복잡성 설정이($u2_com_module)이 존재하지 않습니다." >> "$target"
                    u2_safe_check=$((u2_safe_check+1))
                fi
            fi
        else
            echo "/etc/pam.d/common-password 파일이 존재하며, 패스워드 복잡성 설정이($u2_com_module)이 존재하지 않습니다." >> "$target"
            u2_safe_check=$((u2_safe_check+1))
        fi
    done
    
    #  모듈 모두 발견되지 않았을 경우
    if [[ $u2_modules_found -eq 0 ]]; then
        echo "/etc/pam.d/common-password 파일이 존재하지만, 패스워드 복잡성 설정 관련 모듈이 존재하지 않습니다." >> "$target"
        u2_safe_check=$((u2_safe_check+1))
    fi
else
    echo "/etc/pam.d/common-password 파일이 존재하지 않습니다." >> "$target"
fi

echo '' >> $target
echo "/etc/security/pwquality.conf 파일 점검" >> $target
if [ -e "/etc/security/pwquality.conf" ]; then
    u2_pwquality_check_values=("minlen" "dcredit" "ucredit" "ocredit" "lcredit" "minclass" "retry")
    for u2_pwquality_check_value in "${u2_pwquality_check_values[@]}"; do
        u2_pwquality_value=$(grep "^\s*$u2_pwquality_check_value" /etc/security/pwquality.conf | tr -d ' ' | awk -F= '{print $2}')
        
        u2_pwquality_Annotations=$(grep "^\s*#.*$u2_pwquality_check_value" /etc/security/pwquality.conf)

	if [[ -n $u2_pwquality_Annotations ]]; then
	    echo "$u2_pwquality_check_value 값은 주석처리 되어 비활성화 되어있습니다." >> $target
        u2_safe_check=$((u2_safe_check+1))
        else
	    if [[ -n $u2_pwquality_value ]]; then
	        case "$u2_pwquality_check_value" in
	            "minlen")
                    if [[ $u2_pwquality_value -lt 8 ]]; then
                        echo "$u2_pwquality_check_value 의 보안권고 설정 값인 8 보다 작게 설정되어 있습니다. | 현재 설정된 값 $u2_pwquality_value" >> $target
                        u2_safe_check=$((u2_safe_check+1))
                    else
                        echo "$u2_pwquality_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
                    fi
                    ;;
	            "dcredit"|"ucredit"|"ocredit"|"lcredit")
		        if [[ $u2_pwquality_value -lt 1 ]]; then
                    echo "$u2_pwquality_check_value 의 보안권고 설정 값인 1 보다 작게 설정되어 있습니다. | 현재 설정된 값 $u2_pwquality_value" >> $target
                    u2_safe_check=$((u2_safe_check+1))
		        else
			        echo "$u2_pwquality_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
		        fi
		        ;;
		    "minclass")
		        if [[ $u2_pwquality_value -lt 3 ]]; then
                    echo "$u2_pwquality_check_value 의 보안권고 설정 값인 3 보다 작게 설정되어 있습니다. | 현재 설정된 값 $u2_pwquality_value" >> $target
                    u2_safe_check=$((u2_safe_check+1))
		        else
                    echo "$u2_pwquality_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
		        fi
			;;
		    "retry")
		        if [[ $u2_pwquality_value -gt 3 ]]; then
                    echo "$u2_pwquality_check_value 의 보안권고 설정 값인 3 보다 크게 설정되어 있습니다. | 현재 설정 값 : $u2_pwquality_value" >> $target
                    u2_safe_check=$((u2_safe_check+1))
		        else
                    echo "$u2_pwquality_check_value 의 설정값이 적절하게 설정되어 있습니다." >> $target
			fi
		        ;;
	        *)
	        esac
	    else
            echo "해당 옵션은 값이 설정되어 있지 않습니다.: $u2_pwquality_check_value" >> $target
            u2_safe_check=$((u2_safe_check+1))
	    fi
	fi
    done
fi	

if [ $u2_safe_check -ge 1 ];then
    u2=$((u2+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u2 -ge 1 ]];then
    High=$((High+1))
    Account_Management=$((Account_Management+1))
    u2_Account_Management=1
fi