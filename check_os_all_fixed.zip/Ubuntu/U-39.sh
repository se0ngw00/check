cat << EOF
===== [U-39] Disabling Web Service Links              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-39 웹서비스 링크 사용금지              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 :  무분별한 심볼릭 링크, aliases 사용제한으로 시스템 권한의 탈취 방지를 목적으로 함" >> $target
echo "+보안위협 : 웹 루트 폴더(DocumentRoot)에 root 디렉터리(/)를 링크하는 파일이 있으며 디렉터리 인덱싱 기능이 차단되어 있어도 root 디렉터리 열람이 가능함" >> $target
echo "+판단기준 양호 : 심볼릭 링크, aliases 사용을 제한한 경우" >> $target
echo "+판단기준 취약 : 심볼릭 링크, aliases 사용을 제한하지 않은 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u39=0
u39_safe_check=0
u39_Service_Management=0
u39_apache_files=("/etc/apache2/conf-available/*.conf" "/etc/apache2/sites-available/*.conf" "/etc/apache2/sites-enabled/*.conf")
u39_nginx_files=("/etc/nginx/conf.d/*.conf" "/etc/nginx/sites-available/*.conf" "/etc/nginx/sites-enabled/*.conf")
u39_apache_home_checks=("httpd.conf" "apache2.conf" ".htaccess")
u39_idx=0
u39_break=0
u39_idxn=0
echo "※Cent OS 7 기준 Apache 메인 설정파일 경로와 Nginx 메인 설정 파일인 /etc/nginx/nginx.conf를 점검합니다. 해당 경로가 존재하지 않을 경우, 아파치 웹 서비스 구성 파일명을 토대로 파일 탐색 후 점검이 진행됩니다. 중복된 파일명이 존재할 경우 수동 점검을 권장합니다.※"  >> $target
echo "apache, nginx 의 주요 설정파일을 토대로 apache 홈 디렉터리 점검 후 추가 설정 파일 및 디렉터리를 점검하므로, 중복된 결과가 존재할 수 있습니다." >> $target
for u39_apache_home_check in "${u39_apache_home_checks[@]}";do
    u39_apache_home=$(find / -type f -name "$u39_apache_home_check" 2> /dev/null | egrep -v "tmp|temp|swap|swp")
    if [ -f "$u39_apache_home" ];then
        echo "$u39_apache_home 파일이 존재합니다." >> $target
        u39_dir_pathconfs_a=($(grep -vE "^\s*#" "$u39_apache_home" | sed -n '/<Directory/,/<\/Directory>/p' | grep -i "^\s*options" | grep -i "FollowSymLinks" | awk '{print $1}'))
        u39_check_dirpath_a=($(grep -vE "^\s*#" "$u39_apache_home" | awk 'BEGIN { inBlock = 0; block = "" }/<Directory/ {block = $0;inBlock = 1;dirPath = $2; gsub("\"", "", dirPath)}/<\/Directory>/ {block = block "\n" $0;inBlock = 0;if (block ~ /FollowSymLinks/) { print dirPath }block = ""}inBlock && ! /<\/Directory>/ { block = block "\n" $0 }' | tr -d '>'))
        for u39_dir_pathconf_a in "${u39_dir_pathconfs_a[@]}";do
            if [ -n "$u39_dir_pathconfs_a" ];then
                echo "웹 서비스 링크가 활성화 있습니다." >> $target
                echo "웹 서비스 링크가 활성화된 디렉토리 경로 : ${u39_check_dirpath_a[$u39_idx]}" >> $target
                u39_safe_check=$((u39_safe_check+1))
                u39_idx=$((u39_idx+1))
            else
                echo "웹 서비스 링크가 비활성화 되어 있습니다" >> $target
                echo "웹 서비스 링크가 비활성화된 디렉토리 경로 : ${u39_check_dirpath_a[$u39_idx]}" >> $target
                u39_idxn=$((u39_idxn+1))
            fi
        done
        break
    else 
        u39_idx=0
        if [ $u39_break -eq 1 ];then
            break
        fi
        u39_break=$((u39_break+1))
        echo "$u39_apache_home 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> $target
        for u39_apache_file in "${u39_apache_files[@]}";do
            for u39_apache_check in $u39_apache_file;do
                if [ -f "$u39_apache_check" ];then
                    u39_adected_filecks=$(grep -vE "^\s*#" "$u39_apache_check" | grep -iw "options" | grep -iw "FollowSymLinks" | grep -iwv "\-FollowSymLinks" | awk '{print $1}')
                    u39_check_dirpath_a=($(grep -vE "^\s*#" "$u39_apache_check" | awk 'BEGIN { inBlock = 0; block = "" }/<Directory/ {block = $0;inBlock = 1;dirPath = $2; gsub("\"", "", dirPath)}/<\/Directory>/ {block = block "\n" $0;inBlock = 0;if (block ~ /FollowSymLinks/) { print dirPath }block = ""}inBlock && ! /<\/Directory>/ { block = block "\n" $0 }' | tr -d '>'))
                    if [ ${#u39_adected_filecks[@]} -gt 0 ];then
                        for u39_adected_fileck in "${u39_adected_filecks[@]}";do
                            if [[ -n "$u39_adected_fileck" ]];then
                                echo "$u39_apache_check 파일에서 웹 서비스 링크를 허용하는 FollowSymLinks 설정값이 존재합니다." >> $target
                                echo "웹 서비스 링크가 설정된 디렉토리 경로 : ${u39_check_dirpath_a[$u39_idx]}" >> $target
                                u39_safe_check=$((u39_safe_check+1))
                                u39_idx=$((u39_idx+1))
                            else
                                echo "$u39_apache_check 파일은 존재하지만 웹 서비스 링크를 허용하는 FollowSymLinks 설정값이 존재하지 않습니다." >> $target
                                u39_idxn=$((u39_idxn+1))
                            fi
                        done
                    else
                        echo "$u39_adected_filecks 파일은 존재하지만, 관련 설정값은 존재하지 않습니다."
                    fi
                fi
            done
        done
        echo "웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
    fi
    u39_idx=0
done
u39_idx=0
u39_idxn=0
#if [ -f "/etc/nginx/nginx.conf" ];then
#    echo "/etc/nginx/nginx.conf 파일이 존재합니다." >> $target
#    u39_dir_lisconfs_n=($(grep -vE "^\s*#" "/etc/nginx/nginx.conf" | grep -iw "^\s*autoindex" | sed 's/^[ \t]*//' | awk '{print tolower($2)}' | tr -d ';'))
#    for u39_dir_lisconf_n in "${u39_dir_lisconfs_n[@]}";do
#         if [[ $u39_dir_lisconf_n == "on" ]];then
#             u39=$((u39+1))
#             u39_idx=$((u39_idx+1))
#         else
#             echo "웹 서비스 디렉토리 리스팅이 비활성화 되어 있습니다" >> $target
#             u39_idxn=$((u39_idxn+1))
#         fi
#     done
#     echo "웹 서비스 디렉토리 리스팅이 활성화 있습니다." >> $target
#     echo "설정 값 : $u95_dir_lisconf_n" >> $target
#     echo "총 $u39_idx 개의 취약한 on 설정이 존재합니다. /etc/nginx/nginx.conf 파일을 확인하십시오." >> $target
#     echo "웹 서비스 디렉토리 리스팅이 비활성화된 $u39_idxn 개의 안전한  off 설정이 존재 합니다. /etc/nginx/nginx.conf 파일을 확인하십시오." >> $target
# else 
#     echo "/etc/nginx/nginx.conf 파일이 존재하지 않으며, 웹 서비스 구성 파일명을 토대로 점검을 진행합니다." >> $target
#     for u39_ngnix_file in "${u39_nginx_files[@]}";do
#         for u39_nginx_check in $u39_ngnix_file;do
#             u39_dir_lisconfs_n=($(grep -vE "^\s*#" "$u39_nginx_check" | grep -iw "^\s*autoindex" | sed 's/^[ \t]*//' | awk '{print tolower($2)}' | tr -d ';'))
#             if [ -f "$u39_nginx_check" ];then
#                 #u39_ndected_filecks=$(grep -vE "^\s*#" "$u39_nginx_check" | grep -iw "autoindex" | tr -d ';' | grep -iw "on")
#                 for u39_dir_lisconf_n in "${u39_dir_lisconfs_n[@]}";do
#                     if [ -n "$u39_dir_lisconf_n" ];then
#                         if [ -n "$u39_dir_lisconf_n" ];then
#                             u39=$((u39+1))
#                             u39_idx=$((u39_idx+1))
#                         else
#                             echo "$u39_nginx_check 파일은 존재하지만 디렉토리 리스팅을 허용하는 autoindex 설정값이 존재하지 않습니다." >> $target
#                             u39_idxn=$((u39_idxn+1))
#                         fi
#                     else
#                         echo "$u39_nginx_check 파일은 존재하지만 디렉토리 리스팅을 허용하는 autoindex 설정값이 존재하지 않습니다." >> $target
#                         u39_idxn=$((u39_idxn+1))
#                     fi
#                 done
#                 if [[ $u39_idx -ge 1 ]];then
#                     echo "$u39_nginx_check 파일에서 디렉토리 리스팅이 허용되어 있습니다." >> $target
#                     echo "설정 값 : $u39_dir_lisconf_n" >> $target
#                     echo "총 $u39_idx 개의 취약한 on 설정이 존재합니다. $u39_nginx_check 파일을 확인하십시오." >> $target
#                     echo "웹 서비스 디렉토리 리스팅이 비활성화된 $u39_idxn 개의 안전한  off 설정이 존재 합니다. $u39_nginx_check 파일을 확인하십시오." >> $target
#                 fi
#             fi
#         done
#     done
#     echo "추가적인 웹 서비스 구성 파일들이 존재하지 않습니다. 추가적인 수동 점검을 권장합니다." >> $target
# fi
if [[ $u39_safe_check -ge 1 ]];then
    u39=$((u39+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u39 -ge 1 ]];then
    High=$((High+1))
    Service_Management=$((Service_Management+1))
    u39_Service_Management=1
fi