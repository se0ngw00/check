# Linux Server Security Check Script

## 실행 방법
./ALL_system_check.sh

경과 시간은 한 줄에서 갱신됩니다.
