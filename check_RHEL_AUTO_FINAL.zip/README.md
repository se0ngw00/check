# Linux Server Security Check Script - FINAL

## Features
- Auto OS detection (RHEL 계열 / Ubuntu)
- 안전한 타이머 처리 (Ctrl+C 완전 종료)
- --test 모드 지원
- 실행 권한 없이도 U-xx.sh 실행 가능
- 전체/취약 결과 파일 분리

## Usage
./ALL_system_check.sh
./ALL_system_check.sh --test
