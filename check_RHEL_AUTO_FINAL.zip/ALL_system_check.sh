#!/bin/bash
# ALL_system_check.sh - FINAL STABLE VERSION

set -uo pipefail

START_TIME=$SECONDS
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
NOW="$(date +%Y%m%d-%H%M%S)"
RESULT_DIR="$BASE_DIR/results"
mkdir -p "$RESULT_DIR"

TEST_MODE=0
if [[ "${1:-}" == "--test" ]]; then
  TEST_MODE=1
fi

show_timer() {
  while true; do
    elapsed=$((SECONDS - START_TIME))
    printf "\r[Running] Elapsed time: %dm %02ds" $((elapsed/60)) $((elapsed%60))
    sleep 10
  done
}

cleanup() {
  echo
  [ -n "${TIMER_PID:-}" ] && kill "$TIMER_PID" 2>/dev/null
}
trap cleanup EXIT INT TERM

show_timer &
TIMER_PID=$!

if [ -f /etc/os-release ]; then
  . /etc/os-release
else
  echo "[ERROR] Cannot detect OS"
  exit 1
fi

case "$ID" in
  centos|rhel|rocky|almalinux)
    RUN_DIR="Rocky_Linux"
    OS_TAG="rhel"
    ;;
  ubuntu)
    RUN_DIR="Ubuntu"
    OS_TAG="ubuntu"
    ;;
  *)
    echo "[ERROR] Unsupported OS: $ID"
    exit 2
    ;;
esac

RESULT_PREFIX="${OS_TAG}_${NOW}"
TOTAL_FILE="$RESULT_DIR/${RESULT_PREFIX}.total"
VULN_FILE="$RESULT_DIR/${RESULT_PREFIX}.vuln"

touch "$TOTAL_FILE" "$VULN_FILE"

if [ "$TEST_MODE" -eq 1 ]; then
  echo "[TEST MODE] Security check scripts are not executed." >>"$TOTAL_FILE"
else
  for f in "$BASE_DIR/$RUN_DIR"/U-*.sh; do
    [ -f "$f" ] || continue
    bash "$f" >>"$TOTAL_FILE" 2>&1 ||       echo "[WARN] $f failed" >>"$VULN_FILE"
  done
fi

elapsed=$((SECONDS - START_TIME))
echo
echo "Total execution time: $((elapsed/60))m $((elapsed%60))s"
echo "Results:"
echo "  $TOTAL_FILE"
echo "  $VULN_FILE"
