cat << EOF
===== [U-04] password file protection                 =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-04 패스워드 파일 보호                        " >> $target
echo "--------------------------------------------------------------------------" >> $target

u4=0
u4_safe_check=0
u4_Account_Management=0
if [ -e "/etc/passwd" ];then
    u4_check_encryption=$(cat "/etc/passwd" | awk -F':' '{print $2}' | grep -v 'x')
    u4_count_noencryption=$(cat "/etc/passwd" | awk -F':' '{print $2}' | grep -v 'x' | wc -l)
    if [[ -n $u4_check_encryption ]];then
        echo "passwd 파일 내에 패스워드가 암호화 저장이 아닌 평문으로 저장된 계정이 $u4_count_noencryption 개 존재합니다." >> $target
        echo "$u4_check_encryption" | while IFS= read -r view_account; do
            echo "암호화 되지 않은 계정 : $u4_view_account" >> "$target"
            u4_safe_check=$((u4_safe_check+1))
        done
    else
        echo "passwd 파일 내에 평문 저장된 계정은 확인되지 않았습니다." >> $target
    fi
    if [ -e "/etc/shadow" ];then
        u4_check_hash=$(cat /etc/shadow | awk -F':' '{print $2}')
        u4_unsafe_user=$(grep -vE '^([^:]+:(\*|\$y|\$5|\$6|\!|\!!))' /etc/shadow)
        u4_count_unsafe_user=$(grep -vE '^([^:]+:(\*|\$y|\$5|\$6|\!|\!!))' /etc/shadow | wc -l)
        if [[ $u4_count_unsafe_user -eq 0 ]];then
            echo "passwd 파일이 존재하며, 모든 계정에 대한 패스워드가 암호화 되어 안전하게 shadow 파일에 저장되어 있습니다." >> $target
        else
            echo "shadow 파일 내에 패스워드가 존재하지 않거나 안전하지 않은 해시 알고르짐으로 저장된 계정이 존재합니다." >> $target
            echo "안전하지 않은 계정 : $u4_unsafe_user" >> $target
            u4_safe_check=$((u4_safe_check+1))
        fi
    else
        echo "shadow 파일이 존재하지 않으며, 패스워드 암호화가 되어있지 않습니다." >> $target
        u4_safe_check=$((u4_safe_check+1))
    fi
fi

if [ $u4_safe_check -ge 1 ];then
    u4=$((u4+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u4 -ge 1 ]];then
    High=$((High+1))
    Account_Management=$((Account_Management+1))
    u4_Account_Management=1
fi