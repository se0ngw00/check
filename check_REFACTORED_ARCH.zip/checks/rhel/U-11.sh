cat << EOF
===== [U-11] /etc/syslog.conf file owner and permission settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-11   /etc/syslog.conf 파일 소유자 및 권한 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : /etc/syslog.conf 파일의 권한 적절성을 점검하여, 관리자 외 비인가자의 임의적인 syslog.conf 파일 변조를 방지하기 위함" >> $target
echo "보안위협 : syslog.conf 파일의 설정내용을 참조하여 로그의 저장위치가 노출되며 로그을 기록하지 않도록 설정하거나 대량의 로그를 기록하게 하여 시스템 과부하를 유도할 수 있음" >> $target
echo "+판단기준 양호 : /etc/syslog.conf 파일의 소유자가 root(또는 bin, sys)이고, 권한이 640 이하인 경우" >> $target
echo "+판단기준 취약 : /etc/syslog.conf 파일의 소유자가 root(또는 bin, sys)가 아니거나, 권한이 640 이하가 아닌 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-11 점검 결과" >> $result
# CentOS7 에서는 기본적으로 rsyslog가 기본 로그 시스템으로 사용됨
u11=0
u11_syslog_files=("/etc/syslog.conf" "/etc/rsyslog.conf")
u11_Files_Directory_Management=0
u11_safe_check=0
for u11_syslog_file in "${u11_syslog_files[@]}";do
    echo "$u11_syslog_file Checking..." >> $target
    if [[ -e "$u11_syslog_file" ]];then
        echo "$u11_syslog_file 파일이 존재합니다." >> $target
        u11_file_owner_user=$(stat -c "%U" "$u11_syslog_file" 2> /dev/null)
        u11_file_owner=$(stat -c "%a" "$u11_syslog_file"  2> /dev/null| cut -c1)
        u11_file_group=$(stat -c "%a" "$u11_syslog_file"  2> /dev/null| cut -c2)
        u11_file_other=$(stat -c "%a" "$u11_syslog_file"  2> /dev/null| cut -c3)
        u11_check_suid=$(stat -c "%a" "$u11_syslog_file"  2> /dev/null| tr -d '\n' | wc -c)
        if [[ $u11_check_suid -ge 4 ]];then
            echo "$u11_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> $target
            u11_safe_check=$((u11_safe_check+1))
        else
            if [[ $u11_file_owner_user == "root" || $u11_file_owner_user == "bin" || $u11_file_owner_user == "sys" ]];then
                echo "$syslog_file 파일의 소유자가 root, bin, sys로 적절하게 설정되어 있습니다." >> $target
                if [ $u11_file_owner -le 6 ];then
                    echo "$u11_syslog_file 파일의 소유 권한이 6으로 설정되어 있습니다." >> $target
                    if [ $u11_file_group -le 4 ];then
                        echo "$u11_syslog_file 파일의 소유 그룹 권한이 4로 설정되어 있습니다." >> $target
                        if [ $u11_file_other -eq 0 ];then
                            echo "$u11_syslog_file 파일의 기타 사용자(Other) 권한이 0으로 설정되어 있습니다." >> $target
                        else
                            echo "$u11_syslog_file 파일의 기타 사용자(Other) 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                            u11_safe_check=$((u11_safe_check+1))
                        fi
                    else
                        echo "$u11_syslog_file 파일의 소유 그룹 권한이 4이 아닌 값으로 설정되어 있습니다." >> $target
                        u11_safe_check=$((u11_safe_check+1))
                    fi
                else
                    echo "$u11_syslog_file 파일의 소유 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                    u11_safe_check=$((u11_safe_check+1)) 
                fi
            else
                echo "$u11_syslog_file 파일의 소유자가 root, bin, sys가 아닌 다른 사용자로 설정되어 있습니다." >> $target
                u11_safe_check=$((u11_safe_check+1))
            fi 
        fi
    else
        echo "$u11_syslog_file 파일이 존재하지 않습니다." >> $target
        u11=$((u11+1))
    fi
done


if [[ $u11_safe_check -ge 1 ]];then
    u11=$((u11+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u11 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u11_Files_Directory_Management=1
fi