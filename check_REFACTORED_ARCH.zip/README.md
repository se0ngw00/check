Refactored security check tool based on modular architecture.
