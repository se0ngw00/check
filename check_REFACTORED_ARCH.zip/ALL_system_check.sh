#!/bin/bash
set -uo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$BASE_DIR/lib/common.sh"

RESULT_DIR="$BASE_DIR/results/raw"
SUMMARY="$BASE_DIR/results/summary/summary.txt"
mkdir -p "$RESULT_DIR" "$(dirname "$SUMMARY")"

. /etc/os-release

if [[ "$ID" =~ (centos|rhel|rocky|almalinux) ]]; then
  CHECK_DIR="$BASE_DIR/checks/rhel"
else
  CHECK_DIR="$BASE_DIR/checks/ubuntu"
fi

> "$SUMMARY"

for f in "$CHECK_DIR"/U-*.sh; do
  id=$(basename "$f" .sh)
  bash "$f" >/dev/null 2>&1
  rc=$?
  case $rc in
    0) log_pass "$id" | tee -a "$SUMMARY" ;;
    1) log_fail "$id" | tee -a "$SUMMARY" ;;
    2) log_manual "$id" | tee -a "$SUMMARY" ;;
    *) echo "[ERROR] $id" | tee -a "$SUMMARY" ;;
  esac
done

echo "Results saved to results/"
