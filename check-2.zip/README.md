check-2: fixed --test mode and Ctrl+C handling
