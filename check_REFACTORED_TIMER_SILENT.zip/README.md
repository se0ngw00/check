Timer-only stdout version. Per-check results are written to summary file only.
