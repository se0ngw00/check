#!/bin/bash
log_pass() { echo "[PASS] $1" >> "$SUMMARY"; }
log_fail() { echo "[FAIL] $1" >> "$SUMMARY"; }
log_manual() { echo "[MANUAL] $1" >> "$SUMMARY"; }
