#!/bin/bash
set -uo pipefail

START_TIME=$SECONDS
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

RESULT_RAW="$BASE_DIR/results/raw"
SUMMARY="$BASE_DIR/results/summary/summary.txt"
mkdir -p "$RESULT_RAW" "$(dirname "$SUMMARY")"

TIMER_RUNNING=1

show_timer() {
  while [ "$TIMER_RUNNING" -eq 1 ]; do
    elapsed=$((SECONDS - START_TIME))
    printf "\r[Running] Elapsed time: %dm %02ds" $((elapsed/60)) $((elapsed%60))
    sleep 10
  done
}

cleanup() {
  TIMER_RUNNING=0
  echo
  [ -n "${TIMER_PID:-}" ] && kill "$TIMER_PID" 2>/dev/null
}
trap cleanup EXIT INT TERM

show_timer &
TIMER_PID=$!

. /etc/os-release

if [[ "$ID" =~ (centos|rhel|rocky|almalinux) ]]; then
  CHECK_DIR="$BASE_DIR/checks/rhel"
else
  CHECK_DIR="$BASE_DIR/checks/ubuntu"
fi

> "$SUMMARY"

for f in "$CHECK_DIR"/U-*.sh; do
  id=$(basename "$f" .sh)
  bash "$f" >/dev/null 2>&1
  rc=$?
  case $rc in
    0) echo "[PASS] $id" >> "$SUMMARY" ;;
    1) echo "[FAIL] $id" >> "$SUMMARY" ;;
    2) echo "[MANUAL] $id" >> "$SUMMARY" ;;
    *) echo "[ERROR] $id" >> "$SUMMARY" ;;
  esac
done

elapsed=$((SECONDS - START_TIME))
echo
echo "Total execution time: $((elapsed/60))m $((elapsed%60))s"
echo "Results saved to results/summary/summary.txt"
