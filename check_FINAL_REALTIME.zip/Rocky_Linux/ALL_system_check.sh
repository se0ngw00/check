#!/bin/bash
set -e

TOTAL_FILE="$RESULT_DIR/${RESULT_PREFIX}.total"
VULN_FILE="$RESULT_DIR/${RESULT_PREFIX}.vuln"

export target="$TOTAL_FILE"
export result="$VULN_FILE"

> "$TOTAL_FILE"
> "$VULN_FILE"

if [ "$TEST_MODE" = "1" ]; then
  SCRIPTS="U-TEST.sh"
else
  SCRIPTS=$(ls U-[0-9][0-9].sh 2>/dev/null)
fi

for script in $SCRIPTS; do
  bash "$script" >> "$TOTAL_FILE" 2>/dev/null
done

grep "취약" "$TOTAL_FILE" > "$VULN_FILE" || true
