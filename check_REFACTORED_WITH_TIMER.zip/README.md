Refactored version with live elapsed-time display.
