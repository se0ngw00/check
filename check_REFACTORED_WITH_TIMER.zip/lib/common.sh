#!/bin/bash
log_pass() { echo "[PASS] $1"; }
log_fail() { echo "[FAIL] $1"; }
log_manual() { echo "[MANUAL] $1"; }
