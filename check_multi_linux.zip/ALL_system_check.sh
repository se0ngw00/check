#!/bin/bash

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
RESULT_DIR="$BASE_DIR/results"
mkdir -p "$RESULT_DIR"

START_TIME=$(date +%s)

TEST_MODE=0
if [[ "${1:-}" == "--test" ]]; then
  TEST_MODE=1
fi

RESULT_PREFIX="$(date +%Y%m%d-%H%M%S)"
TOTAL_FILE="$RESULT_DIR/${RESULT_PREFIX}.total"
VULN_FILE="$RESULT_DIR/${RESULT_PREFIX}.vuln"

# ---------------- TEST MODE ----------------
if [ "$TEST_MODE" -eq 1 ]; then
  echo "[TEST MODE]" > "$TOTAL_FILE"
  echo "[TEST MODE]" > "$VULN_FILE"
  echo "Results:"
  echo "  $TOTAL_FILE"
  echo "  $VULN_FILE"
  exit 0
fi

# ---------------- TIMER ----------------
TIMER_RUNNING=1
timer() {
  while [ "$TIMER_RUNNING" -eq 1 ]; do
    elapsed=$(( $(date +%s) - START_TIME ))
    printf "\r[Running] Elapsed time: %dm %02ds" $((elapsed/60)) $((elapsed%60))
    sleep 10
  done
}

cleanup() {
  TIMER_RUNNING=0
  [ -n "${TIMER_PID:-}" ] && kill "$TIMER_PID" 2>/dev/null
}
trap cleanup INT TERM EXIT

timer &
TIMER_PID=$!

# ---------------- OS DETECTION (GENERIC) ----------------
. /etc/os-release

CHECK_DIR=""
case "$ID" in
  rocky|rhel|centos|almalinux|ol)
    CHECK_DIR="$BASE_DIR/Rocky_Linux"
    ;;
  ubuntu|debian|linuxmint)
    CHECK_DIR="$BASE_DIR/Ubuntu"
    ;;
  *)
    if [[ "$ID_LIKE" =~ (rhel|fedora) ]]; then
      CHECK_DIR="$BASE_DIR/Rocky_Linux"
    elif [[ "$ID_LIKE" =~ (debian|ubuntu) ]]; then
      CHECK_DIR="$BASE_DIR/Ubuntu"
    else
      echo "Unsupported Linux distribution: $ID"
      cleanup
      exit 1
    fi
    ;;
esac

# ---------------- RUN CHECKS ----------------
for f in "$CHECK_DIR"/U-*.sh; do
  id=$(basename "$f" .sh)
  echo "===== $id =====" >> "$TOTAL_FILE"
  bash "$f" >> "$TOTAL_FILE" 2>&1 || true
  echo "$id REVIEW_REQUIRED" >> "$VULN_FILE"
done

cleanup
END_TIME=$(date +%s)
ELAPSED=$((END_TIME - START_TIME))
echo
echo "Total execution time: ${ELAPSED}s"
echo "Results:"
echo "  $TOTAL_FILE"
echo "  $VULN_FILE"
