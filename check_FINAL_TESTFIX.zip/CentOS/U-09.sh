cat << EOF
===== [U-09] /etc/hosts file owner and permission settings               =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-09   /etc/hosts 파일 소유자 및 권한 설정                        " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : /etc/hosts 파일을 관리자만 제어할 수 있게 하여 비인가자들의 임의적인 파일 변조를 방지하기 위함" >> $target
echo "보안위협 : hosts 파일에 비인가자 쓰기 권한이 부여된 경우, 공격자는 hosts파일에 악의적인 시스템을 등록하여, 이를 통해 정상적인 DNS를 우회하여 악성사이트로의 접속을 유도하는 파밍(Pharming) 공격 등에 악용될 수 있음hosts파일에 소유자외 쓰기 권한이 부여된 경우, 일반사용자 권한으로 hosts파일에 변조된 IP주소를 등록하여 정상적인 DNS를 방해하고 악성사이트로의 접속을 유도하는 파밍(Pharming) 공격 등에 악용될 수 있음" >> $target
echo "+판단기준 양호 : /etc/hosts 파일의 소유자가 root이고, 권한이 600인 이하경우" >> $target
echo "+판단기준 취약 : /etc/hosts 파일의 소유자가 root가 아니거나, 권한이 600 이상인 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
echo "-------------" >> $result
echo "U-9 점검 결과" >> $result
u9=0
u9_safe_check=0
u9_Files_Directory_Management=0

if [[ -e "/etc/hosts" ]];then
    echo "/etc/hosts 파일이 존재합니다."
    u9_file_owner_user=$(stat -c "%U" "/etc/hosts" 2> /dev/null)
    u9_file_owner=$(stat -c "%a" "/etc/hosts"  2> /dev/null| cut -c1)
    u9_file_group=$(stat -c "%a" "/etc/hosts"  2> /dev/null| cut -c2)
    u9_file_other=$(stat -c "%a" "/etc/hosts"  2> /dev/null| cut -c3)
    u9_check_suid=$(stat -c "%a" "/etc/hosts"  2> /dev/null| tr -d '\n' | wc -c)
    if [[ $u9_check_suid -ge 4 ]];then
        echo "$u9_file 파일에 SUID 가 설정되어 있습니다. [잘못된 SUID 설정]" >> $target
        u9_safe_check=$((u9_safe_check+1))
    else
        if [[ "$u9_file_owner_user" == "root" ]];then
            echo "/etc/hosts 파일의 소유자가 root로 적절하게 설정되어 있습니다." >> $target
            if [ $u9_file_owner -le 6 ];then
                echo "/etc/hosts 파일의 소유 권한이 6이하로 설정되어 있습니다." >> $target
                if [ $u9_file_group -le 0 ];then
                    echo "/etc/hosts 파일의 소유 그룹 권한이 0이하로 설정되어 있습니다." >> $target
                    if [ $u9_file_other -eq 0 ];then
                        echo "/etc/hosts 파일의 기타 사용자(Other) 권한이 0으로 설정되어 있습니다." >> $target
                    else
                        echo "/etc/hosts 파일의 기타 사용자(Other) 권한이 0이 아닌 값으로 설정되어 있습니다." >> $target
                        u9_safe_check=$((u9_safe_check+1))
                    fi
                else
                    echo "/etc/hosts 파일의 소유 그룹 권한이 0이상으로 설정되어 있습니다." >> $target
                    u9_safe_check=$((u9_safe_check+1))
                fi
            else
                echo "/etc/hosts 파일의 소유 권한이 6이상으로 설정되어 있습니다." >> $target
                u9_safe_check=$((u9_safe_check+1)) 
            fi
        else
            echo "/etc/hosts 파일의 소유자가 root가 아닌 다른 사용자로 설정되어 있습니다." >> $target
            u9_safe_check=$((u9_safe_check+1))
        fi
    fi
else
    echo "/etc/hosts 파일이 존재하지 않습니다." >> $target
    u9_safe_check=$((u9_safe_check+1))
fi


if [ $u9_safe_check -ge 1 ];then
    u9=$((u9+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u9 -ge 1 ]];then
    High=$((High+1))
    Files_Directory_Management=$((Files_Directory_Management+1))
    u9_Files_Directory_Management=1
fi