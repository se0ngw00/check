#!/bin/bash
echo "[TEST MODE] Check framework execution OK" >> "$target"
