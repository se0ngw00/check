#!/bin/bash
set -e

TOTAL_FILE="$RESULT_DIR/${RESULT_PREFIX}.total"
VULN_FILE="$RESULT_DIR/${RESULT_PREFIX}.vuln"

# Legacy compatibility
export target="$TOTAL_FILE"
export result="$VULN_FILE"

> "$TOTAL_FILE"
> "$VULN_FILE"

if [ "$TEST_MODE" = "1" ]; then
  SCRIPTS="U-TEST.sh"
else
  SCRIPTS=$(ls U-[0-9][0-9].sh 2>/dev/null)
fi

for script in $SCRIPTS; do
  bash "$script"
done

grep "취약" "$TOTAL_FILE" > "$VULN_FILE" || true

echo "모든 보안 점검이 정상적으로 완료되었습니다."
echo "전체 결과 파일:"
echo "  $TOTAL_FILE"
echo "취약 항목 파일:"
echo "  $VULN_FILE"
