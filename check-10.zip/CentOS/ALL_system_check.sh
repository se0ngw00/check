#!/bin/bash
set -e

. /etc/os-release

TOTAL_FILE="$RESULT_DIR/${RESULT_PREFIX}.total"
VULN_FILE="$RESULT_DIR/${RESULT_PREFIX}.vuln"

> "$TOTAL_FILE"
> "$VULN_FILE"

{
  echo "Linux Security Check Result"
  echo "Host : $(hostname)"
  echo "OS   : $PRETTY_NAME"
  echo "Date : $(date '+%Y-%m-%d %H:%M:%S')"
  echo "----------------------------------------"
} >> "$TOTAL_FILE"

if [ "$TEST_MODE" = "1" ]; then
  SCRIPTS="U-TEST.sh"
else
  SCRIPTS=$(ls U-[0-9][0-9].sh 2>/dev/null | sort)
fi

TOTAL_COUNT=0
VULN_COUNT=0

echo "[취약 항목 점검 결과]" >> "$VULN_FILE"
echo >> "$VULN_FILE"

for script in $SCRIPTS; do
  ITEM_ID="$(basename "$script" .sh)"
  TMP_OUT=$(mktemp)

  echo >> "$TOTAL_FILE"
  echo "[$ITEM_ID]" >> "$TOTAL_FILE"

  bash "$script" 2>/dev/null | tee -a "$TOTAL_FILE" > "$TMP_OUT"

  if grep -q "점검 결과 : 취약" "$TMP_OUT"; then
    echo "- $ITEM_ID : REVIEW_REQUIRED" >> "$VULN_FILE"
    VULN_COUNT=$((VULN_COUNT + 1))
  elif grep -q "점검 결과 : 양호" "$TMP_OUT"; then
    :
  else
    echo "- $ITEM_ID : REVIEW_REQUIRED" >> "$VULN_FILE"
    VULN_COUNT=$((VULN_COUNT + 1))
  fi

  TOTAL_COUNT=$((TOTAL_COUNT + 1))
  rm -f "$TMP_OUT"
done

echo >> "$VULN_FILE"
echo "총 점검 항목 수 : $TOTAL_COUNT" >> "$VULN_FILE"
echo "검토 필요 항목 수 : $VULN_COUNT" >> "$VULN_FILE"
