Refactored version with non-overlapping timer and result output.
