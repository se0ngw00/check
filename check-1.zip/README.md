Final result structure: results/*.total and *.vuln only.
