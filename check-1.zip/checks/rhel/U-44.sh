cat << EOF
===== [U-44] No UID other than root '0'              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-44 root 이외의 UID가 ‘0’ 금지              " >> $target
echo "--------------------------------------------------------------------------" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "+점검목적 : root 계정과 동일한 UID가 존재하는지 점검하여 root권한이 일반 사용자 계정이나 비인가자의 접근 위협에 안전하게 보호되고 있는지 확인하기 위함" >> $target
echo "+보안위협 : root 계정과 동일 UID가 설정되어 있는 일반사용자 계정도 root 권한을 부여받아 관리자가 실행 할 수 있는 모든 작업이 가능함(서비스 시작, 중지, 재부팅, root 권한 파일 편집 등) root와 동일한 UID를 사용하므로 사용자 감사 추적 시 어려움이 발생함" >> $target
echo "+판단기준 양호 : root 계정과 동일한 UID를 갖는 계정이 존재하지 않는 경우" >> $target
echo "+판단기준 취약 : root 계정과 동일한 UID를 갖는 계정이 존재하는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u44_Account_Management=0
u44_safe_check=0
u44=0
u44_uid_checks=($(grep -v "root" /etc/passwd | awk -F: '$3 == 0 {print $1}'))
u44_gid_checks=($(grep -v "root" /etc/passwd | awk -F: '$4 == 0 {print $1}'))

if [ -n "$u44_uid_check"  ];then
    for u44_uid_check in "${u44_uid_checks[@]}";do
        echo "$u44_uid_check 계정의 UID값이 root 유저와 동일한 0 으로 설정되어 있습니다." >> $target
        u44_safe_check=$((u44_safe_check+1))
    done
else
    echo "UID 값이 root 유저와 동일한 0으로 설정된 계정은 존재하지 않습니다." >> $target
fi
echo "추가적으로 GID 점검을 진행합니다." >> $target
if [ -n "$u44_gid_checks"  ];then
    for u44_gid_check in "${u44_gid_checks[@]}";do
        echo "$u44_gid_check 계정의 GID값이 root 유저와 동일한 0 으로 설정되어 있습니다." >> $target
        u44_safe_check=$((u44_safe_check+1))
    done
else
    echo "GID 값이 root 유저와 동일한 0으로 설정된 계정은 존재하지 않습니다." >> $target
fi

if [ $u44_safe_check -ge 1 ];then
    u44=$((u44+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u44 -ge 1 ]];then
    Mid=$((Mid+1))
    Account_Management=$((Account_Management+1))
    u44_Account_Management=1
fi