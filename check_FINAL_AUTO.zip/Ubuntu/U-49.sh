cat << EOF
===== [U-49] Remove unnecessary accounts              =====
=====                  Checking...........               =====
EOF
echo "--------------------------------------------------------------------------" >> $target
echo "                        U-49 불필요한 계정 제거              " >> $target
echo "--------------------------------------------------------------------------"  >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "점검목적 : 불필요한 계정이 존재하는지 점검하여 관리되지 않은 계정에 의한 침입에 대비하는지 확인하기 위함" >> $target
echo "보안위협 : 로그인이 가능하고 현재 사용하지 않는 불필요한 계정은 사용중인 계정보다 상대적으로 관리가 취약하여 공격자의 목표가 되어 계정이 탈취될 수 있음" >> $target
echo " ※ 퇴직, 전직, 휴직 등의 사유발생시 즉시 권한을 회수" >> $target
echo "+판단기준 양호 : 불필요한 계정이 존재하지 않는 경우" >> $target
echo "+판단기준 취약 : 불필요한 계정이 존재하는 경우" >> $target
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> $target
echo "" >> $target
u49_Account_Management=0
u49_safe_check=0
u49_general_users=($(egrep -v "root|nologin|shutdown|sync|halt|false" "/etc/passwd" | awk -F: '{print $1}'))
u49=0
u49_idx=0
u49_never_loggeds=($(lastlog | grep -i 'Never logged in' | awk '{print $1}'))
u49_corrent_timestamp=$(date +%s)
u49_2weeks_check=0


u49_lastlog_dates=($(lastlog | grep -vi 'Never logged in' | awk '{for (i=3; i<=NF; i++) printf "%s%s", $i, (i < NF ? OFS : "\n")}'  | sed '1d'))
u49_lastlog_timestamps=()

for u49_date_str in "${u49_lastlog_dates[@]}"; do
    u49_timestamp=$(date -d "$u49_date_str" +%s 2>/dev/null)
    if [ $? -eq 0 ]; then
        u49_lastlog_timestamps+=("$u49_timestamp")
    fi
done

u49_lastlog_users=($(lastlog | grep -vi 'Never logged in' | awk 'NR>1 {print $1}'))
u49_two_weeks_seconds=$((14 * 24 * 60 * 60))

if [ -n "$u49_general_users" ];then
    echo "root 제외한 시스템 사용자 목록입니다. 불필요한 계정이 존재할 경우 삭제조치 바랍니다." >> $target
    for u49_general_user in "${u49_general_users[@]}";do
        echo "$u49_general_user" >> $target
    done
else
    echo "root 제외한 시스템 사용자 목록이 존재하지 않습니다." >> $target
fi


if [ -n "$u49_never_loggeds" ];then
    echo "계정 생성 후 시스템에 로그인한 적 없는 계정들입니다. 불필요한 경우 삭제 조치 바랍니다." >> $target
    u49_safe_check=$((u49_safe_check+1))
    for u49_never_logged in "${u49_never_loggeds[@]}";do
        echo "계정 명 : $u49_never_logged" >> $target
    done
else
    echo "시스템에 로그인한 적 없는 계정이 존재하지 않습니다." >> $target
fi

if [ ${#u49_general_users[@]} -gt 0 ];then
    echo "시스템에 2주 이상 로그인(접근) 기록이 없는 계정 목록입니다. 불필요한 경우 삭제 조치 바랍니다." >> $target
    u49_safe_check=$((u49_safe_check+1))
    for u49_lastlog_user in "${u49_lastlog_users[@]}";do
        if (( u49_lastlog_timestamps[u49_idx] <= u49_corrent_timestamp - u49_two_weeks_seconds )); then
            echo "$u49_lastlog_user" >> $target
        else
            u49_2weeks_check=$((u49_2weeks_check+1))
        fi
        u49_idx=$((u49_idx+1))
    done
    if [ $u49_2weeks_check -ge 1 ];then
        echo "시스템에 2주 이상 로그인(접근) 기록이 없는 계정이 존재하지 않습니다." >> $target
    fi
fi

if [ $u49_safe_check -ge 1 ];then
    u49=$((u49+1))
    echo "점검 결과 : 취약" >> $result
else
    echo "점검 결과 : 양호" >> $result
fi
if [[ $u49 -ge 1 ]];then
    Low=$((Low+1))
    Account_Management=$((Account_Management+1))
    u49_Account_Management=1
fi
