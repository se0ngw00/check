#!/bin/bash
set -e

TOTAL_FILE="$RESULT_DIR/${RESULT_PREFIX}.total"
VULN_FILE="$RESULT_DIR/${RESULT_PREFIX}.vuln"

export target="$TOTAL_FILE"
export result="$VULN_FILE"

> "$TOTAL_FILE"
> "$VULN_FILE"

CPU_CORES=$(nproc 2>/dev/null || echo 2)
PARALLEL_JOBS=${PARALLEL_JOBS:-$CPU_CORES}

if [ "$MODE" = "safe" ]; then
  PARALLEL_JOBS=1
elif [ "$MODE" = "fast" ]; then
  PARALLEL_JOBS=$CPU_CORES
fi

if [ "$TEST_MODE" = "1" ]; then
  echo "[TEST MODE] OK" >> "$target"
else
  ls U-[0-9][0-9].sh | xargs -n 1 -P "$PARALLEL_JOBS" bash >> "$target" 2>/dev/null
fi

grep "취약" "$TOTAL_FILE" > "$VULN_FILE" || true

rm -f "${target}-F:" 2>/dev/null
rm -f "${result}-F:" 2>/dev/null
