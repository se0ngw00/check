# Linux Server Security Check Script

## 개요
이 스크립트는 Linux 서버(OS 기준)의 보안 설정을 자동으로 점검하기 위한 도구입니다.
서버의 CPU 코어 수를 자동 감지하여 병렬 점검을 수행하며,
필요 시 사용자가 직접 병렬 수 또는 실행 모드를 지정할 수 있습니다.

## 실행 방법
```bash
./ALL_system_check.sh
```

## 실행 옵션

### 기본 실행 (AUTO)
```bash
./ALL_system_check.sh
```
- CPU 코어 수 자동 감지
- 코어 수 만큼 병렬 실행

### FAST 모드
```bash
./ALL_system_check.sh --fast
```
- 최대 병렬 실행
- 점검 속도 최우선

### SAFE 모드
```bash
./ALL_system_check.sh --safe
```
- 직렬 실행
- 운영 중인 중요 서버에 권장

### 병렬 수 수동 지정
```bash
./ALL_system_check.sh --jobs 4
```
- 병렬 실행 개수를 직접 지정

### 테스트 모드
```bash
./ALL_system_check.sh --test
```
- 실제 점검 스크립트 실행하지 않음
- 구조 및 실행 여부만 확인

## 결과 파일
결과는 `results/` 디렉터리에 생성됩니다.

- *.total : 전체 점검 결과
- *.vuln  : 취약 항목만 추출

## 권장 사용 예
- 일반 서버 : AUTO
- 고성능 서버 : FAST
- DB/중요 서버 : SAFE
